/**
 * @file cryptoPrimitiveDefaultsQL.js - 1.2.0 - 3826bc12533e078a8e37cfe70ee04d9e85c8530e
 * 
 * @copyright Copyright (C) 2016-2023, ISARA Corporation, All Rights Reserved.
 * 
 * @license The code and other content set out herein is not in the public
 * domain, is considered a trade secret and is confidential to ISARA
 * Corporation. Use, reproduction or distribution, in whole or in part, of such
 * code or other content is strictly prohibited except by express written
 * permission of ISARA Corporation. Please contact ISARA Corporation at
 * info@isara.com for more information.
 */

/**
 * This module contains crypto primitive defaults focused queries.
 * @module graphql/cryptoPrimitiveDefaultsQL
 */
const { createUpdateDelete } = require('../isaraql/cud')
var { fetchWanted } = require('../isaraql/fetch')
const { roles, GraphQLEnum, SORT_DIRECTION_ENUM } = require('./commonQL')
const { graphQLStateToWanted } = require('../isaraql/wantedUtil')

const SORTABLE_FIELDS_ENUM = new GraphQLEnum('SortableCryptoPrimitiveDefaultFields', ['cryptoPrimitive', 'defaultPrimitive'])


async function cryptoPrimitiveDefaultsQuery(fields, request, graphQLState, ids) {
    let wanted = graphQLStateToWanted(graphQLState)
    wanted = wanted[Object.keys(wanted)[0]]
    if (!('paging' in fields)) {
        fields.paging = { offset: 0n, limit: 5n }
    }
    let wpcs = { 'CryptoPrimitiveDefault': { paging: fields.paging } }
    if (wanted.paging && wanted.paging.count) {
        wpcs.CryptoPrimitiveDefault.count = []
    }
    if ('id' in fields) {
        ids = [fields.id]
    }
    let specificIDWanted = ids !== undefined && ids.length !== 0

    if (specificIDWanted) {
        wpcs.CryptoPrimitiveDefault.where = {
            and: [{ in: { column: 'id', value: ids } }],
        }
    }

    if (fields.orderBy) {
        wpcs.CryptoPrimitiveDefault.sort = `"${
            SORTABLE_FIELDS_ENUM.graphQLToInternal[fields.orderBy.field]
        }" ${SORT_DIRECTION_ENUM.graphQLToInternal[fields.orderBy.direction]}`
    }
    
    let cryptoPrimitiveDefaults = await fetchWanted('CryptoPrimitiveDefault', wanted.cryptoPrimitiveDefaults, wpcs)
    if (cryptoPrimitiveDefaults.length === 0 && specificIDWanted) {
        throw 'Crypto Primitive Default not found.'
    }
    const toReturn = { cryptoPrimitiveDefaults }

    return toReturn
}

const checkExistingTables = {}
const deletableTables = { CryptoPrimitiveDefault: true }
const modifiableTables = deletableTables

async function cryptoPrimitiveDefaultUpdateMutation(fields, request, graphQLState) {
    var cryptoPrimitiveDefaults = fields.cryptoPrimitiveDefaults
    var config = {
        allowDelete: true,
        allowInsert: true,
        allowUpdate: true,
        checkExistingTables,
        deletableTables,
        modifiableTables,
    }

    for (let cryptoPrimitiveDefault of cryptoPrimitiveDefaults) {
        const { defaultPrimitive, DELETE } = cryptoPrimitiveDefault
        if (!DELETE) {
            if(!defaultPrimitive.trim()) {
                throw new Error('Crypto Primitive field cannot be empty')
            } 
        }
    }

    var ids = await createUpdateDelete('CryptoPrimitiveDefault', cryptoPrimitiveDefaults, config)
    return cryptoPrimitiveDefaultsQuery(fields, request, graphQLState, ids)
}

exports.graphQL = {
    types: `
        type PagedCryptoPrimitiveDefaults {
            paging: Paging!
            cryptoPrimitiveDefaults: [CryptoPrimitiveDefault!]!
        }
        
        ${SORTABLE_FIELDS_ENUM.toGraphQL()}

        input CryptoPrimitiveDefaultSortingInput {
            field: SortableCryptoPrimitiveDefaultFields!,
            direction: SortDirection!,
        }
    `,

    queries: `
        """
            Gets all the Cryptoprimitive Defaults.
        """
        cryptoPrimitiveDefaults(
            """
                Used to control how many Cryptoprimitive Defaults are returned. The default (without paging) will be 5.
            """
            paging: PagingInput
            """
                When provided, will attempt to find a single Cryptoprimitive Default. The CP-Default may not exist, or you may not have access.
            """
            id: BigInt
            """
                Used to set the sort order of the Cryptoprimitive Defaults
            """
            orderBy: CryptoPrimitiveDefaultSortingInput
        ): PagedCryptoPrimitiveDefaults!

    `,
    mutations: `
        cryptoPrimitiveDefaultsUpdate(
            cryptoPrimitiveDefaults: [CryptoPrimitiveDefaultInput!]!
        ) : PagedCryptoPrimitiveDefaults!
    `,
    root: {
        cryptoPrimitiveDefaults: cryptoPrimitiveDefaultsQuery,
        cryptoPrimitiveDefaultsUpdate: cryptoPrimitiveDefaultUpdateMutation,
    },
    restrictions: {
        cryptoPrimitiveDefaults: [roles.ADMIN],
        cryptoPrimitiveDefaultsUpdate: [roles.ADMIN],
    },
}