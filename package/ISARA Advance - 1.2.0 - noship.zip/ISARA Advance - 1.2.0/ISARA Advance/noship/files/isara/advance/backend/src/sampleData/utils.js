/**
 * @file utils.js - 1.2.0 - 3826bc12533e078a8e37cfe70ee04d9e85c8530e
 * 
 * @copyright Copyright (C) 2016-2023, ISARA Corporation, All Rights Reserved.
 * 
 * @license The code and other content set out herein is not in the public
 * domain, is considered a trade secret and is confidential to ISARA
 * Corporation. Use, reproduction or distribution, in whole or in part, of such
 * code or other content is strictly prohibited except by express written
 * permission of ISARA Corporation. Please contact ISARA Corporation at
 * info@isara.com for more information.
 */

var log = require('../util/log')(module)
var {
    hashPassword
} = require('../util/passwordUtils')


const { insertRecord } = require('../isaraql/fetch')


const {
    allTypes,
    discoverSchema
} = require('../isaraql/schemaDiscovery')
const fetch = (...args) => import('node-fetch').then(({ default: fetch }) => fetch(...args));

exports.getSampleUserToken = async () => {
    const query = JSON.stringify({
        query: `mutation {
      login(userName :"fred", password :"password") {
      token
      }
    }`
    })
    let backendPath = 'https://localhost:4000/service/'
    try {
        const getTokenCallResp = await fetch(`${backendPath}graphql`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'Accept': 'application/json'
            },
            body: query
        })
        const getTokenCall = await getTokenCallResp.json();
        const token = getTokenCall.data.login.token;
        console.log("getTokenCall", getTokenCall)
        console.log("TOKEN", token)
        if (token) {
            return token;
        }
    } catch (err) {
        log.log(`Can not import sample zip ${err}`)
    }
}

exports.getSampleUser = async (session) => {
    let curUser = null;
    let res = null;
    try {
        res = await session.query(`SELECT * FROM advance."User" where "User"."userName"='fred' ORDER BY id ASC limit 1;`);
        curUser = res.rows[0];
    } catch (e) {
        console.log("No default user found", e);
    }
    if (!curUser) {
        const user = {
            userName: 'fred',
            humanName: 'fred',
            passwordExpiry: new Date(), // expiry is disabled system wide
            lockedOut: false,
            hidden: false,
            passwordHash: await hashPassword('password')
        }
        let userId = (await insertRecord('User', user)).id
        try {
            await insertRecord('UserRole', { user: userId, role: 2 })
        } catch (e) {
            console.log("can't seem to insert - check db session")
        }
        curUser = { ...user, id: userId }
    }
    return curUser;
}
const clamp = (num, min, max) => Math.min(Math.max(num, min), max)
exports.clamp = clamp
const getIpPart = () => {
    const min = 0, max = 255;
    const gen = clamp(Math.random() * 10, min, max);
    if (gen * 100 > 255) {
        return Math.floor(gen * 10)
    }
    return Math.floor(gen * 100)
}
exports.generateIp4Addr = () => {
    const parts = [
        getIpPart(),
        getIpPart(),
        getIpPart(),
        getIpPart(),
    ]
    return parts.join('.')
}
exports.generateMac = () => "XX:XX:XX:XX:XX:XX".replace(/X/g, function () {
    return "0123456789ABCDEF".charAt(Math.floor(Math.random() * 16))
})
const checkProcess = async (session) => {
    try {
        const scanQuery = `select s."lastStatus" from advance."DataSourceScan" as s order by s.id desc limit 1`
        const scanData = (await session.query(scanQuery)).rows
        const [scan] = scanData
        scan.lastStatus = Number(scan.lastStatus)

        if (scan.lastStatus === 1) {
            log.log('Script failed')
            process.exit(1)
        }

        if (scan.lastStatus === null || [0, 2, 3].includes(scan.lastStatus)) {
            log.log('Ingestion is still running, Sleeping for 5 seconds')
            await require('../util/sleep').sleep(5000)
            return await checkProcess(session)
        }

        if (scan.lastStatus === 4) {
            return false
        } else {
            return true
        }
    } catch (err) {
        log.log(`Error in checkProcess ${err}`)
        process.exit(1)
    }
}
exports.usage = function () {
    console.log(`Usage: node ${process.argv[1]}`)
    console.log('\n')
    console.log('Optional arguments:\n\n')
    for (let arg of Object.keys(optionalArguments)) {
        console.log(`\t--${arg}${arg !== 'help' && arg !== 'baselineOnly' ? '=<val>' : ''}: ${optionalArguments[arg]}`)
    }
    console.log('\n')
    process.exit(0)
}
exports.checkProcess = checkProcess;

exports.showCount = (title, number, total) => {
    var lastPercentage = showCount.last[title]
    var percentage = Math.round(number / total * 1000) / 10
    if (lastPercentage === undefined || (percentage === 100 && lastPercentage != 100) || (percentage - lastPercentage > 1)) {
        log.log(`${title}: Created ${number} of ${total} (${percentage}%)`)
        showCount.last[title] = percentage
    }
}

exports.tidyOldRecords = async function (connection) {
    // Do not tidy Enum tables.
    const tables = {
        'Netmask': `netmask != ''`,
        'AgentCertificate': null,
        'Agent': null,
        'DataSourceScanResultDetail': null,
        'DataSourceScanResult': null,
        'DataSourceScanSchedule': null,
        'DataSourceScanTag': null,
        'DataSourceScan': null,
        'DataSource': null,
        'NotificationAction': null,
        'Notification': null,
        'ConnectionCertificate': null,
        'ConnectionCipherSuite': null,
        'ConnectionCryptoPrimitive': null,
        'DeviceSoftwareConnection': null,
        'ConnectionProtocolVariantCertificate': null,
        'ConnectionProtocolVariant': null,
        'ConnectionScore': null,
        'ConnectionTag': null,
        'Connection': null,
        'DeviceAddressMACAddress': null,
        'DeviceAttribute': null,
        'DeviceMACAddress': null,
        'DeviceAddressPort': null,
        'DeviceAddress': null,
        'DeviceScore': null,
        'DeviceTag': null,
        'DeviceCertificate': null,
        'CAIssuedCertificate': null,
        'CertificateCryptoPrimitive': null,
        'ConfigurationFileCipherSuite': null,
        'ConfigurationFileCertificate': null,
        'ConfigurationFile': null,
        'Certificate': null,
        'OneTimeKey': null,
        'CertificationAuthority': null,
        'KeyStoreKey': null,
        'KeyStore': null,
        'DeviceSoftware': null,
        'Device': null,
        'SoftwareVersionTag': null,
        'Tag': null,
        'SoftwareVersion': `software NOT IN (select id FROM "Software" WHERE "softwareType" = ${allTypes['SoftwareType']._enum.idByName['DATA']})`,
        'Software': `"softwareType" != ${allTypes['SoftwareType']._enum.idByName['DATA']}`,
        'View': null,
        'UserPreference': null,
        'UserRole': null,
        'User': null
    }
    for (var table in tables) {
        let where = ''
        if (tables[table]) {
            where = `where ${tables[table]}`
        }
        try {
            await connection.query(`delete from "${table}" ${where}`)
        } catch (e) {
            log.log(e)
        }
        try {
            await connection.query(`delete from history."${table}" ${where}`)
        } catch (e) {
            log.log(e)
        }
    }
}


