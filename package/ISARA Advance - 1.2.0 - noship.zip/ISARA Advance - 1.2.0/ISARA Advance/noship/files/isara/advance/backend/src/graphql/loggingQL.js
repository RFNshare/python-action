/**
 * @file loggingQL.js - 1.2.0 - 3826bc12533e078a8e37cfe70ee04d9e85c8530e
 * 
 * @copyright Copyright (C) 2016-2023, ISARA Corporation, All Rights Reserved.
 * 
 * @license The code and other content set out herein is not in the public
 * domain, is considered a trade secret and is confidential to ISARA
 * Corporation. Use, reproduction or distribution, in whole or in part, of such
 * code or other content is strictly prohibited except by express written
 * permission of ISARA Corporation. Please contact ISARA Corporation at
 * info@isara.com for more information.
 */

/**
 * This module contains Notification related queries.
 * @module graphql/notificationsQL
 */

var {
    roles
} = require('./commonQL')
var log = require('../util/log')(module)

async function saveLogsQuery(fields/*, request, graphQLState*/) {
    if (fields.logs && Array.isArray(fields.logs) && fields.logs.length > 0) {
        for (var row of fields.logs) {
            // TODO: GAP1628 - probably going to need a database storage system for logs?
            log.log('UI Log', JSON.stringify(row, null, 2))
        }
    }
    return true
}

exports.graphQL = {
    types: `
        input LogInput {
            user: UserInput # user is optional as failed logins may have no user.
            action: String!
            value: String!
            timestamp: DateTime!
            meta: JSON
        }
        `,
    mutations: `
        saveLogs(logs: [LogInput!]!): Boolean
    `,
    root: {
        saveLogs: saveLogsQuery,
    },
    restrictions: {
        saveLogs: [roles.UNAUTHENTICATED], // If the problem is with sign in; they'd never be able to log it...
    }
}
