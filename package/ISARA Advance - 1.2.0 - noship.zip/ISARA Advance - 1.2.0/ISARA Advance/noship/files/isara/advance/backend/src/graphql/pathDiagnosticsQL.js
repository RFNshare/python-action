/**
 * @file pathDiagnosticsQL.js - 1.2.0 - 3826bc12533e078a8e37cfe70ee04d9e85c8530e
 * 
 * @copyright Copyright (C) 2016-2023, ISARA Corporation, All Rights Reserved.
 * 
 * @license The code and other content set out herein is not in the public
 * domain, is considered a trade secret and is confidential to ISARA
 * Corporation. Use, reproduction or distribution, in whole or in part, of such
 * code or other content is strictly prohibited except by express written
 * permission of ISARA Corporation. Please contact ISARA Corporation at
 * info@isara.com for more information.
 */

const schemaDiscovery = require('../isaraql/schemaDiscovery')

const facets = require('../filterql/facets')

const { cloneDeep } = require('lodash')

var {
    UNAUTHENTICATED
} = require('./commonQL').roles

async function discoveredPaths() {
    let toReturn = []
    const paths = schemaDiscovery.discoveredPaths()
    for (const key of Object.keys(paths)) {
        const current = paths[key]
        current.key = key
        toReturn.push(current)
    }
    toReturn.sort((a,b)=> {
        for (const which of ['from','to','key']) {
            const compared = a[which].localeCompare(b[which])
            if (compared) {
                return compared
            }
        }
        return 0
    })
    toReturn = toReturn.filter(item => {
        return !((!item.queries) || item.queries.length === 0)
    })
    return toReturn
}

async function facetAttributes() {
    const attributes = cloneDeep(facets.facets.attributes)
    attributes.forEach(attr => {
        if (Array.isArray(attr.column)) {
            attr.column = attr.column.join(',')
        }
    })
    attributes.sort((a,b) => a.name.localeCompare(b.name))
    return attributes
}

function buildFacetPathExclusions() {
    let toReturn = 'type FacetPathExclusions {\n'

    let any = false

    for (const table in schemaDiscovery.allTypes) {
        any = true
        toReturn += `${table}: Boolean!\n`
    }

    if (!any) {
        throw Error('Schema not discovered yet')
    }

    toReturn += '}\n\n'
    return toReturn
}

exports.graphQL = {
    types: `
        type DiscoveredPath {
            key: String!
            from: String!
            to: String!
            queries: [String]!
        }

        ${buildFacetPathExclusions()}

        type FacetPaths {
            Device: [String!]
            Connection: [String!]
            SoftwareVersion: [String!]
            pathExclusions: FacetPathExclusions
        }

        type FacetAttributes {
            name: String!
            type: String!
            description: String!
            column: String!
            isTag: Boolean!
            paths: FacetPaths!
        }


    `,
    queries: `
        discoveredPaths: [DiscoveredPath!]!
        facetAttributes: [FacetAttributes!]!
    `,
    root: {
        discoveredPaths,
        facetAttributes,
    },
    restrictions: {
        discoveredPaths: [UNAUTHENTICATED],
        facetAttributes: [UNAUTHENTICATED],
    }
}
