/**
 * @file wantedUtil.js - 1.2.0 - 3826bc12533e078a8e37cfe70ee04d9e85c8530e
 * 
 * @copyright Copyright (C) 2016-2023, ISARA Corporation, All Rights Reserved.
 * 
 * @license The code and other content set out herein is not in the public
 * domain, is considered a trade secret and is confidential to ISARA
 * Corporation. Use, reproduction or distribution, in whole or in part, of such
 * code or other content is strictly prohibited except by express written
 * permission of ISARA Corporation. Please contact ISARA Corporation at
 * info@isara.com for more information.
 */

/**
 * Convert graphQL state to a nested dictionary of which fields are wanted.
 * @param {Object} graphQLState GraphQL state.
 * @param {Object} [selections] GraphQL selections - used for recursion. You probably don't need to pass this in.
 * @returns {Object} Object matching which fields were wanted in the GraphQL query.
 */
function graphQLStateToWanted(graphQLState, selections) {
    if (!selections) {
        var toReturn = {}
        for (var fieldNode of graphQLState.fieldNodes) {
            // Use object assign so that if same query field is provided multiple times with different sub fields it doesn't
            // overwrite the previous fields requested
            toReturn[fieldNode.name.value] = Object.assign(toReturn[fieldNode.name.value] || {}, graphQLStateToWanted(graphQLState, fieldNode.selectionSet.selections))
        }
        return toReturn
    } else {
        toReturn = {}
        for (var selection of selections) {
            if (selection.kind === 'FragmentSpread') {
                var fragmentName = selection.name.value
                var fragment = graphQLState.fragments[fragmentName]
                selection = fragment.selectionSet.selections
                var sub = graphQLStateToWanted(graphQLState, fragment.selectionSet.selections)
                return sub
            }
            if (!(selection.selectionSet) || !(selection.selectionSet.selections)) {
                toReturn[selection.name.value] = true
            } else {
                // Use object assign so that if same query field is provided multiple times with different sub fields it doesn't
                // overwrite the previous fields requested
                toReturn[selection.name.value] = Object.assign(toReturn[selection.name.value] || {} , graphQLStateToWanted(graphQLState, selection.selectionSet.selections))
            }
        }
        return toReturn
    }
}
exports.graphQLStateToWanted = graphQLStateToWanted