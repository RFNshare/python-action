/**
 * @file lazySingleton.js - 1.2.0 - 3826bc12533e078a8e37cfe70ee04d9e85c8530e
 * 
 * @copyright Copyright (C) 2016-2023, ISARA Corporation, All Rights Reserved.
 * 
 * @license The code and other content set out herein is not in the public
 * domain, is considered a trade secret and is confidential to ISARA
 * Corporation. Use, reproduction or distribution, in whole or in part, of such
 * code or other content is strictly prohibited except by express written
 * permission of ISARA Corporation. Please contact ISARA Corporation at
 * info@isara.com for more information.
 */

/**
 * A class to run an async block once.
 * @module util/lazySingleton
 */

/**
 * A lazily initialised thread safe singleton.
 */
class LazySingleton {
    /**
     * Construct a LazySingleton.
     *
     * @param initFunction {function} A function that will be called the first time get is called.
     *                     Note that it is an error for this function to return `undefined`.
     * @param purgeFunction {function} A function that takes the singleton value that will be called
     *                      before the singleton is purged, if the singleton was previously initialized.
     */
    constructor(initFunction, purgeFunction) {
        this.initFunction = initFunction
        this.purgeFunction = purgeFunction
        this.initInprogress = false
        this.value = undefined
        this.error = undefined
        this.waiting = []
    }

    /**
     * Waits for the initialization to be finished.
     * @private
     * @return Nothing
     */
    _wait() {
        return new Promise((accept, reject) => {
            this.waiting.push({
                accept,
                reject
            })
        })
    }

    /**
     * Notify all threads that the initialization has completed.
     *
     * @private
     * @return Nothing
     */
    async _notify() {
        if (this.value === undefined && this.error === undefined) {
            throw `Unable to notify when nothing has happened`
        }
        var toNotify = [...this.waiting]
        this.waiting.length = 0

        var value = this.value
        var error = this.error

        for (var who of toNotify) {
            try {
                if (value !== undefined) {
                    who.accept(value)
                } else {
                    who.reject(error)
                }
            } catch (e) {
                console.log('Error during notify', e)
            }
        }
    }

    /**
     * Get the value of the singleton. If this is the first time, or the singleton has been `purge()`d,
     * the function passed to the constructor will be called.
     *
     * @return The value produced by the initialisation function
     * @throws An error if the initialisation function throws an error
     */
    async get() {
        if (this.value !== undefined) {
            return this.value
        }
        if (this.error !== undefined) {
            throw this.error
        }
        if (this.initInprogress) {
            return await this._wait()
        }
        this.initInprogress = true
        try {
            this.value = await this.initFunction()
            if (this.value === undefined) {
                throw `LazySingleton can't work because the initFunction returned undefined`
            }
            return this.value
        } catch (error) {
            this.error = error
            throw error
        } finally {
            this.initInprogress = false
            this._notify()
        }
    }

    /**
     * Purge the internal value of the singleton. The next call to `get()` will call the initialisation
     * function again.
     *
     * Purging while the value is being established does not
     * (and should not) prevent or abort that from completing.
     */
    async purge() {
        if (this.value !== undefined && this.purgeFunction) {
            await this.purgeFunction(this.value)
        }
        this.value = this.error = undefined
    }
}

function sleep(ms) {
    return new Promise(accept => {
        setTimeout(accept, ms)
    })
}

function working() {
    var events = []

    var s = new LazySingleton(async () => {
        events.push('init.in')
        await sleep(50)
        events.push('init.out')
        return 6
    })

    async function a() {
        await sleep(25)
        events.push('a.in')
        if (await s.get() != 6) {
            throw 'bad value'
        }
        events.push('a.out')
    }

    async function b() {
        events.push('b.in')
        if (await s.get() != 6) {
            throw 'bad value'
        }
        events.push('b.out')
    }

    Promise.all([a(), b()]).then(() => {}).catch(error => {
        console.log('Failed', error)
    })

    var expected = ['b.in', 'init.in', 'a.in', 'init.out', 'b.out', 'a.out']

    if (!events.every((value, index) => value === expected[index])) {
        throw 'Un matched expectations'
    } else {
        console.log('Passed')
    }
}

function withException() {
    var events = []
    var s = new LazySingleton(async () => {
        events.push('init.in')
        await sleep(50)
        throw 'breaked'
    })

    async function a() {
        try {
            await sleep(25)
            events.push('a.in')
            await s.get()
            throw 'a - should not get here'
        } catch (e) {
            if (e !== 'breaked') {
                throw e
            }
        }
    }

    async function b() {
        try {
            events.push('b.in')
            await s.get()
            throw 'b - should not get here'
        } catch (e) {
            if (e !== 'breaked') {
                throw e
            }
        }
    }

    Promise.allSettled([a(), b()]).then(results => {

        if (!results.every(result => result.status === 'fulfilled')) {
            throw 'Expected success for all promises'
        }

        var expected = ['b.in', 'init.in', 'a.in']

        if (!events.every((value, index) => value === expected[index])) {
            throw 'Un matched expectations'
        } else {
            console.log('Passed')
        }
    })
}

if (require.main === module) {
    console.log('Testing lazy singleton')

    try {

        working()

        withException()
    } catch (failure) {
        console.log('Failed', failure)
    }
}

module.exports = LazySingleton
