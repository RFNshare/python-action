/**
 * @file taniumScanner.js - 1.2.0 - 3826bc12533e078a8e37cfe70ee04d9e85c8530e
 * 
 * @copyright Copyright (C) 2016-2023, ISARA Corporation, All Rights Reserved.
 * 
 * @license The code and other content set out herein is not in the public
 * domain, is considered a trade secret and is confidential to ISARA
 * Corporation. Use, reproduction or distribution, in whole or in part, of such
 * code or other content is strictly prohibited except by express written
 * permission of ISARA Corporation. Please contact ISARA Corporation at
 * info@isara.com for more information.
 */

/**
 * This module is the Tanium Scanner for pulling data out of Tanium.
 * @module scanners/taniumScanner
 */

const { Session } = require('../../isaraql/session')
const { createTaniumSession } = require('./taniumClient')
const log = require('../../util/log')(module)
const systemPreferences = require('../../util/systemPreferences')
const { hasNetmaskZone } = require('../netmaskMatching')
const { sleep } = require('../../util/sleep')
const {
    inspectIPAddress,
    ADDRESS_TYPE,
    updateTables,
    normalizeMacAddress,
    reportResultDetail,
    IngestionStatus,
    getRoundedObservationTime,
    updateScanResultSummary,
    // populateTags
} = require('../commonIngestion')
const zlib = require('zlib')
const { BatchManager } = require('../batchManager')

const { Interact, Sensor, PollLimiter, AdvanceSensor } = require('./interact')
const { NetmaskMatchModes } = require('../netmaskMatching')

const ISARA_ADVANCE_SENSOR = 'ISARA Advance - Program Connections'

class SensorGroup {
    name
    sensorNames
    constructor(name, sensorNames) {
        this.name = name
        this.sensorNames = sensorNames
    }
}

const IP_SENSORS = [
    'IPv6 Address',
    'Network Adapters',
]

const DEVICE_SENSOR_GROUP = new SensorGroup(
    'Devices',
    [
        'Computer ID',
        'Computer Name',
        'Domain Name',
        'IPv6 Address',
        'Network Adapters',
        'OS Platform',
    ]
)

/**
 * Return a standardised name for the device.
 * @param {String} computerName Tanium sensor Computer Name.
 * @param {String} shortHostname Tanium sensor Short Hostname.
 */
// For #2261, commented off the following as a piece of unreachable code
// function canonicalDeviceName(computerName, shortHostname) {
//     return (computerName || shortHostname || '').toLowerCase()
// }

function processDevice(row, processTime) {
    let entries = []

    // id, observedAt, taniumName, ipAddress, ipVersion, deviceType, macAddress, osType
    let addresses = [
        ...row.getColumnMultipleText('Network Adapters', 'IP Address'),
        ...row.getColumnMultipleText('IPv6 Address')
    ]

    let macs = row.getColumnMultipleText('Network Adapters', 'IP Address').reduce(
        (m, ip, i) => {
            m[ip] = row.rowData['Network Adapters']['MAC Address'][i]
            return m
        },
        {})

    for (let ip of addresses) {
        let ipInfo = inspectIPAddress(ip, NetmaskMatchModes.DO_NOT_MATCH)
        let zoneIn = hasNetmaskZone(ipInfo.address,NetmaskMatchModes.CLIENT)
        let zoneOut = hasNetmaskZone(ipInfo.address,NetmaskMatchModes.SERVER)
        if (ipInfo.isIngestible) {
            let entry = {
                observedAt: processTime,
                taniumName: row.getColumnText('Computer Name'), // Should this be Computer ID?
                ipAddress: ipInfo.address,
                ipVersion: ipInfo.version,
                macAddress: normalizeMacAddress(macs[ip]),
                osType: row.getColumnText('OS Platform'),
                hostnames: [row.getColumnText('hostname')], // potential change in hostname
                zoneIn,
                zoneOut,
            }
            entries.push(entry)
        }
    }
    return entries
}

function processPrograms(row, processTime) {
    let softwares = []
    let addresses = [
        ...row.getColumnMultipleText('Network Adapters', 'IP Address'),
        ...row.getColumnMultipleText('IPv6 Address')
    ]
    let validAddresses = addresses.map(ip => inspectIPAddress(ip, NetmaskMatchModes.SERVER)).filter(i => i.isIngestible).map(ip => ip.address)

    let sensorData = row.rowData[ISARA_ADVANCE_SENSOR]
    let sensorKey = Object.keys(sensorData)[0]
    let softwareData = sensorData[sensorKey]
    let version = softwareData.manifest?.version
    let hostname = softwareData?.hostname

    for (let app of softwareData.data) {
        for (let connection of app.tcp_connections) {
            if (!connection.local.is_server) {
                continue
            }

            let ipInfo = inspectIPAddress(connection.local.address, NetmaskMatchModes.DO_NOT_MATCH)
            let boundAddresses = [ipInfo.address]
            if (ipInfo.addressType === ADDRESS_TYPE.UNSPECIFIED) {
                boundAddresses = validAddresses
            } else if (!ipInfo.isIngestible) {
                continue
            }

            for (let boundAddress of boundAddresses) {
                // create entry
                softwares.push({
                    'observedAt': processTime,
                    'path': app.path,
                    'user': app.user,
                    'device': boundAddress,
                    'sortableVersion': 0,
                    'version': app.version || '0.0',
                    'name': app.name,
                    'hostname': hostname,
                    'port': connection.local.port,
                })
            }
        }
    }

    return { softwares, version, hostname }
}

/**
 * Processes a Tanium data row for custom sensor Software and Connections.
 * @param {object} config The CUD config to use to access the database.
 * @param {object} softwareConnections The complete parsed object returned by the sensor.
 * @param {object} localDevice The primary Device on the "local" end of the Connections.
 * @param {Object[]|null} tags The ID of the Tags to associate with all Devices, Connections, and Software.
 * @param {Date} processTime The date-time that the row is being processed.
 */
// For #2261, commented off the following as a piece of unreachable code
// async function processSoftwareConnections(config, softwareConnections, localDevice, tags, processTime) {
//     if (!softwareConnections.manifest || !softwareConnections.manifest.version) {
//         throw {
//             message: `Sensor '${ISARA_ADVANCE_SENSOR}' missing manifest data`,
//             column: ISARA_ADVANCE_SENSOR
//         }
//     }
//     let softwareConnectionsVersion = softwareConnections.manifest.version.toString()
//     // Version in 'Major.Minor' format
//     let versionSplit = softwareConnectionsVersion.split('.')
//     // Switch on Major version, since Minor increments shouldn't change schema
//     switch (versionSplit[0]) {
//     case '1':
//         await processSoftwareConnectionsV1(config, softwareConnections, localDevice, tags, processTime)
//         break
//     default:
//         throw {
//             message: `Sensor '${ISARA_ADVANCE_SENSOR}' unexpected version '${softwareConnections.manifest.version}'`,
//             column: ISARA_ADVANCE_SENSOR
//         }
//     }
//     return softwareConnectionsVersion
// }

/**
 * Processes a Tanium data row for Connection and Software for sensor schema version 1.
 * @param {object} config The CUD config to use to access the database.
 * @param {object} softwareData The Software Connections sensor data to process.
 * @param {object} localDevice The primary Device on the "local" end of the Connections.
 * @param {Object[]|null} tags The ID of the Tags to associate with all Devices, Connections, and Software.
 * @param {Date} processTime The date-time that the row is being processed.
 */
// For #2261, commented off the following as a piece of unreachable code
// async function processSoftwareConnectionsV1(config, softwareData, localDevice, tags, processTime) {
//     for (const app of softwareData.data) {
//         let appName = app.name
//         let deviceSoftware = null
//
//         if (appName) {
//             // Lookup/create Software
//             let software = (await selectByLooks('Software', { name: appName }, config.session))[0]
//             if (!software) {
//                 software = {
//                     name: appName,
//                     softwareType: allTypes['SoftwareType']._enum.idByName['APP'],
//                 }
//                 await createUpdateDelete('Software', [software], config)
//             }
//
//             // Lookup/create SoftwareVersion
//             let softwareVersionSearch = { name: appName, version: '0.0', software: software.id }
//             let softwareVersion = (await selectByLooks('SoftwareVersion', softwareVersionSearch, config.session))[0]
//             if (!softwareVersion) {
//                 softwareVersion = {
//                     name: appName,
//                     version: 'Unknown',
//                     sortableVersion: 0,
//                     software,
//                 }
//             }
//
//             populateTags(softwareVersion, 'softwareVersionTags', tags)
//             await createUpdateDelete('SoftwareVersion', [softwareVersion], config)
//
//             // Lookup/create DeviceSoftware
//             deviceSoftware = {
//                 device: { id: localDevice.id },
//                 softwareVersion: { id: softwareVersion.id },
//                 path: app.path,
//             }
//             await createUpdateDelete('DeviceSoftware', [deviceSoftware], config)
//         }
//
//         // Process the Software Connections
//         for (const tcp of app.tcp_connections) {
//             // If bound to all interfaces, find/create a connection for each Device Address
//             let localAddresses = localDevice.deviceAddresses
//             if (tcp.local.address !== '0.0.0.0' && tcp.local.address !== '::') {
//                 // If bound to one interface, find/create one connection
//                 localAddresses = localAddresses.filter(da => da.address === tcp.local.address)
//             }
//
//             // Create a Connection entity for each address the Connection is bound to
//             for(let localAddress of localAddresses) {
//                 // Lookup/create DAP entry
//                 let localPortNumber = tcp.local.is_server ? tcp.local.port : -1
//                 let remotePortNumber = tcp.local.is_server ? -1 : tcp.remote.port
//                 let localDeviceAddressPort = {
//                     deviceAddress: { id: localAddress.id },
//                     l4Protocol: allTypes['Layer4Protocol']._enum.idByName['TCP'],
//                     port: localPortNumber,
//                     manuallyAdded: new SQLUpdateOp('=', false, false),
//                     observedAt: new SQLUpdateOp('=', processTime, processTime),
//                 }
//                 await createUpdateDelete('DeviceAddressPort', [localDeviceAddressPort], config)
//
//                 let connection = {
//                     connectionCount: new SQLUpdateOp('+', 1, 1),
//                 }
//
//                 // Determine if Connection is Established or Listening
//                 if (tcp.remote.address !== '0.0.0.0' && tcp.remote.address !== '::') {
//                     // Connection is Established
//                     // Lookup/create remote Device
//                     let remoteDevice = await findExistingOrCreateDevice(config.session, null, [tcp.remote.address])
//
//                     // Lookup/create remote DeviceAddress
//                     let remoteDeviceAddress = {
//                         device: {id: remoteDevice.id, lastTimeOnline: processTime},
//                         address: tcp.remote.address,
//                         manuallyAdded: new SQLUpdateOp('=', false, false),
//                         observedAt: new SQLUpdateOp('=', processTime, processTime),
//                     }
//
//                     populateTags(remoteDeviceAddress.device, 'deviceTags', tags)
//
//                     await createUpdateDelete('DeviceAddress', [remoteDeviceAddress], config)
//
//                     // Lookup/create remote DeviceAddress
//                     let remoteDeviceAddressPort = {
//                         deviceAddress: remoteDeviceAddress.id,
//                         l4Protocol: allTypes['Layer4Protocol']._enum.idByName['TCP'],
//                         port: remotePortNumber,
//                         manuallyAdded: new SQLUpdateOp('=', false, false),
//                         observedAt: new SQLUpdateOp('=', processTime, processTime),
//                     }
//                     await createUpdateDelete('DeviceAddressPort', [remoteDeviceAddressPort], config)
//
//                     // Determine client-server orientation
//                     if (tcp.local.is_server) {
//                         // Local is server
//                         connection.serverDeviceAddressPort = localDeviceAddressPort
//                         connection.clientDeviceAddressPort = remoteDeviceAddressPort
//                     } else {
//                         // Local is client
//                         connection.clientDeviceAddressPort = localDeviceAddressPort
//                         connection.serverDeviceAddressPort = remoteDeviceAddressPort
//                     }
//                 } else if (
//                     (tcp.remote.address === '0.0.0.0' && localAddress.address.includes('.'))
//                     ||
//                     (tcp.remote.address === '::' && localAddress.address.includes(':'))
//                 ) {
//                     // Remote address is unspecified and the same version as the local device address
//                     // Connection is Listening
//                     connection.clientDeviceAddressPort = null
//                     connection.serverDeviceAddressPort = localDeviceAddressPort
//                 } else
//                     // No connection
//                     continue
//                 populateTags(connection, 'connectionTags', tags)
//
//                 // Create/update connection
//                 await createUpdateDelete('Connection', [connection], config)
//
//                 if (deviceSoftware) {
//                     // Create DeviceSoftwareConnection
//                     let deviceSoftwareConnection = {
//                         deviceSoftware: { id: deviceSoftware.id },
//                         connection: connection.id,
//                     }
//                     await createUpdateDelete('DeviceSoftwareConnection', [deviceSoftwareConnection], config)
//                 }
//             }
//         }
//     }
// }

/**
 * Ingests a Tanium data row into the database.
 * @param {Interact} interact initialization
 * @param {Object} scanConfig configuration of datasource scan
 * @param {Session} session The database session to use.
 * @param {Object[]|null} tags The ID of the Tags to associate with all Devices, Connections, and Software.
 * @param {Date} processTime The date-time that the row is being processed.
 */
class AnswerProcessor {
    counts
    constructor(interact, scanConfig, session, tags, processTime) {
        this.interact = interact
        this.config = {
            allowDelete: false,
            allowInsert: true,
            allowUpdate: true,
            populateIDs: true,
            deletableTables: {},
            modifiableTables: updateTables,
            checkExistingTables: updateTables,
            session,
        }
        this.tags = tags
        this.processTime = processTime
        this.scanConfig = scanConfig
        this.counts = {
            answers: 0,
            successes: 0,
            errors: 0,
            warnings:0,
        }
        this.warnings = []
        this.versions = new Set()
    }
    /**
     * Ingests row and updates summary.
     * @param {Object} scanResults The Results object for the running scan.
     * @param {Array} answer The Tanium data row to process.
     * @param {Function} ingestorFunction Update the database.
     * @param {String} recordId Identifies the row being processed.
     * @param {Object} device Identify the endpoint being processed.
     */
    async process(scanResults, answer, ingestorFunction, recordId, device) {
        try {
            this.counts.answers++
            this.versions.add(await ingestorFunction(this.config, answer, this.tags, this.processTime, device))
            this.counts.successes++
        } catch(error) {
            this.counts.errors++
            const errorMessage = error.message || JSON.stringify(error)
            await reportResultDetail(scanResults, errorMessage, recordId, 'Tanium Row', answer.rowData)
        }
    }
}

/**
 * Built-in-sensors: Ingests a Tanium data row into the database.
 * @param {Object} apiParameters Parameters controlling the Tanium server API poll and cache behaviour
 * @param {AnswerProcessor} answerProcessor Controller for ingesting a single Tanium answer
 * @param {Object} scanResults The Results object for the running scan.
 * @param {SensorGroup} sensorGroup The built-in sensors we want answers for.
 * @param {Number} iterations Number of times the request should be tried for.
 * @param {Function} ingestorFunction Update the database.
 */
async function processSimpleSensors(apiParameters, answerProcessor, scanResults, sensorGroup, ingestorFunction) {
    const question = await answerProcessor.interact.getQuestion(
        sensorGroup.sensorNames.map(n => answerProcessor.interact.getSensor(n)),
        answerProcessor.scanConfig.computer_group,
        answerProcessor.scanConfig.filter
    )
    let session = answerProcessor.config.session
    let answerCache = (await question.ask(
        new PollLimiter(
            apiParameters,
            async function(rowCount, estimatedTotalCount) {
                let percentage = Math.round(rowCount / estimatedTotalCount * 100)
                await updateScanResultSummary(scanResults, `Querying ${sensorGroup.name}: ${percentage <= 100 ? percentage: 100}%`, session)
            }).isDone
    ))(apiParameters.pageSize)
    let answer = await answerCache.next()
    if (!answer) {
        throw new Error('Tanium query returned no results')
    }
    do {
        let deviceName = answer.getColumnText('Computer Name') || answer.getColumnText('Short Hostname') || ''
        await answerProcessor.process(scanResults, answer, ingestorFunction, deviceName)
        answer = await answerCache.next()
    } while (answer != null)
}

/**
 * ISARA Advance Sensor: Ingests a Tanium data row into the database.
 * @param {Object} apiParameters Parameters controlling the Tanium server API poll and cache behaviour
 * @param {AnswerProcessor} answerProcessor Controller for ingesting a single Tanium answer
 * @param {Object} scanResults The Results object for the running scan.
 * @param {Object} computerIdDevices Built in sensors we want answer for.
 * @param {Function} ingestorFunction Update the database.
 */
async function processAdvanceSensor(apiParameters, answerProcessor, scanResults, computerIdDevices, ingestorFunction) {
    let percentage = parseInt(answerProcessor.scanConfig.partition_percent.value)
    let delaySeconds = parseInt(answerProcessor.scanConfig.partition_delay_seconds)
    const count = Math.round(100 / Math.min(Math.max(0, (percentage > 1 ? percentage : 1)), 100))
    const advanceSensor = new AdvanceSensor(ISARA_ADVANCE_SENSOR, count)
    let answerCache
    let session = answerProcessor.config.session
    for (let sensor = advanceSensor.next(); sensor != null; sensor = advanceSensor.next()) {
        answerCache = (await (await answerProcessor.interact.getQuestion(
            [sensor, ...IP_SENSORS.map(s => answerProcessor.interact.getSensor(s))],
            answerProcessor.scanConfig.computer_group,
            answerProcessor.scanConfig.filter
        )).ask(
            new PollLimiter(
                apiParameters,
                async function(rowCount, estimatedTotalCount) {
                    let percentage = Math.round(rowCount / estimatedTotalCount * 100)
                    await updateScanResultSummary(
                        scanResults,
                        `Querying software partition ${advanceSensor.index} of ${advanceSensor.count}: ${percentage <= 100 ? percentage: 100}%`,
                        session)
                }).isDone
        ))(apiParameters.pageSize)
        let answer = await answerCache.next()
        if(!answer) {
            throw new Error('Tanium query returned no results')
        }
        do {
            for (const key in answer.rowData[ISARA_ADVANCE_SENSOR]) {
                if (key.startsWith(ISARA_ADVANCE_SENSOR)) {
                    const result = answer.rowData[ISARA_ADVANCE_SENSOR][key]
                    if (Sensor.isResult(result)) {
                        let responseObject
                        try {
                            responseObject = JSON.parse(zlib.gunzipSync(Buffer.from(result[0], 'base64')).toString('utf-8'))
                        } catch (e) {
                            const errorMessage = `Failure decoding response from Advance Sensor: ${e}`
                            log.e(errorMessage)
                            answerProcessor.counts.warnings++
                            answerProcessor.warnings.push(errorMessage)
                        }
                        // const device = computerIdDevices[String(responseObject?.selection?.id)] || undefined
                        if (responseObject?.data) {
                            let deviceName = answer.getColumnText('Computer Name') || answer.getColumnText('Short Hostname') || ''
                            answer.rowData[ISARA_ADVANCE_SENSOR][key] = responseObject
                            await answerProcessor.process(scanResults, answer, ingestorFunction, deviceName)
                        }
                    }
                    break
                }
            }
            answer = await answerCache.next()
        } while (answer != null)

        let buildDelaySummary = function (seconds) {
            let totalMinutes = Math.floor(seconds / 60)
            let hours = Math.floor(totalMinutes / 60)
            let minutes = totalMinutes % 60
            return `plus ${hours.toString().padStart(2, '0')}:${minutes.toString().padStart(2, '0')}:00 delay`
        }

        if (advanceSensor.index < advanceSensor.count && delaySeconds > 0) {
            let remaining = delaySeconds
            do {
                let partitionSummary = `Querying software partition ${advanceSensor.index} of ${advanceSensor.count}`
                await updateScanResultSummary(scanResults, `${partitionSummary} ${buildDelaySummary(remaining)}`, session)
                let duration = remaining > 60 ? 60 : remaining
                await sleep(duration)
                remaining -= duration
            } while (remaining > 0)
        }
    }
}

async function getServerAPIParameters() {
    let parameterSpecifications = {
        'pauseSeconds': { 'min': 0, 'default': 10, 'max': 600 },
        'limitSeconds': { 'min': 0, 'default': 600, 'max': 3600 },
        'limitPercent': { 'min': 0, 'default': 95, 'max': 100 },
        'pageSize': { 'min': 0, 'default': 256, 'max': 4096 }
    }
    let parameters = (await systemPreferences())?.ingestion?.tanium?.serverAPI || {}
    for (const property in parameterSpecifications) {
        let parameter = parameters[property]
        if (parameters[property] === undefined || typeof parameters[property] !== 'number') {
            log.w(`Using default value ingestion.tanium.serverAPI.${property}=${parameterSpecifications[property].default} instead of ${parameter}`)
            parameters[property] = parameterSpecifications[property].default
        }
        parameters[property] = Math.max(parameterSpecifications[property].min, Math.min(parameterSpecifications[property].max, parameters[property]))
        if (parameters[property] == parameterSpecifications[property].max) {
            log.w(`Using maximum value ingestion.tanium.serverAPI.${property}=${parameters[property]} instead of ${parameter}`)
        }
        if (parameters[property] < parameterSpecifications[property].default) {
            log.w(`Using ingestion.tanium.serverAPI.${property}=${parameters[property]} less than default value ${parameterSpecifications[property].default}`)
        }
    }
    return parameters
}

/**
 * Verifies connectivity and authentication against the remote Tanium server.
 * @param {Object} dataSource The Data Source to Test.
 */
async function taniumTest(dataSource) {
    let config = JSON.parse(dataSource.configuration)
    await createTaniumSession(dataSource.softwareVersion.name, config.url, '/api/v2', config.token, {
        timeout: 10000
    })
}

/**
 * Performs a Tanium Ingestion Scan for the specified Data Source Scan.
 * @param {Object} dataSourceScan The Data Source Scan to run.
 * @param {Object} scanResults The results object for the running scan.
 */
async function taniumScan(dataSourceScan, scanResults, onFulfilled, onRejected, onFinally) {
    try {
        const serverAPIParameters = await getServerAPIParameters()
        let session = new Session()
        let dataSourceConfig = JSON.parse(dataSourceScan.dataSource.configuration)
        let scanConfig = JSON.parse(dataSourceScan.configuration)
        let taniumSession = await createTaniumSession(
            dataSourceScan.dataSource.softwareVersion.name,
            dataSourceConfig.url,
            '/api/v2',
            dataSourceConfig.token,
            { timeout: 10000 },
        )
        log.d('Getting list of available sensors')
        let interact = await new Interact(taniumSession).init()

        let tags = dataSourceScan.dataSourceScanTags ? dataSourceScan.dataSourceScanTags : null
        let processTime = getRoundedObservationTime(new Date())
        let computerIdDevices = {}
        let answerProcessor = new AnswerProcessor(interact, scanConfig, session, tags, processTime)

        let deviceUpserter = new BatchManager(
            session,
            'Device',
            [
                'observedAt',
                'taniumName',
                'ipAddress',
                'ipVersion',
                'macAddress',
                'osType',
                'hostnames',
            ],
            [
                'ipAddress'
            ],
            {
                'observedAt': n => n,
                'taniumName':  n => n,
                'macAddress': n => n,
                'osType': n => n,
            }
        )
        let deviceMacToIp = {}
        await processSimpleSensors(serverAPIParameters, answerProcessor, scanResults, DEVICE_SENSOR_GROUP, async (config, row, tags, processTime) => {
            let deviceEntries = processDevice(row, processTime)
            for (let deviceEntry of deviceEntries) {
                deviceMacToIp[deviceEntry.ipAddress] = deviceEntry.macAddress
                deviceUpserter.push(deviceEntry)
            }
        })
        await deviceUpserter.commit()

        let softwareUpserter = new BatchManager(
            session,
            'DeviceSoftware',
            [
                'observedAt',
                'path',
                'user',
                'device',
                'sortableVersion',
                'version',
                'name',
                'port',
                'macAddress',
            ],
            [
                'device',
                'port',
            ],
            {
                'observedAt': n => n,
                'path': n => n,
                'user': n => n,
                'sortableVersion': n => n,
                'version': n => n,
                'name': n => n,
                'macAddress': n => n,
            }
        )
        await processAdvanceSensor(serverAPIParameters, answerProcessor, scanResults, computerIdDevices, async (config, row, tags, processTime/*, device*/) => {
            let { softwares, version } = processPrograms(row, processTime)
            for (let softwareEntry of softwares) {
                softwareEntry.macAddress = deviceMacToIp[softwareEntry.device]
                softwareUpserter.push(softwareEntry)
            }
            return version
        })
        await softwareUpserter.commit()

        const { answers, successes, errors, warnings } = answerProcessor.counts

        let status = IngestionStatus.SUCCESS
        let summary = `Processed ${Number(answers).toLocaleString()} Tanium records`
        if (errors > 0) {
            status = successes > 0 ? IngestionStatus.PARTIAL_SUCCESS : IngestionStatus.FAILED
            summary += `; ${errors} error${errors > 1 ? 's' : ''} occurred`
        }
        if(warnings > 0 && status == IngestionStatus.SUCCESS){
            status = IngestionStatus.PARTIAL_SUCCESS
            summary += `; ${warnings} warning${warnings > 1 ? 's' : ''} occurred`
            if(warnings < 3){
                summary += `; ${answerProcessor.warnings.map(w=>`warning: ${w}`).join('; ')} `
            }
        }
        let versions = [...answerProcessor.versions].filter(x => x != undefined)
        if (versions.length > 0) {
            summary += `; Detected sensor versions: ${versions.sort().join(',')}`
        }
        await updateScanResultSummary(scanResults, summary, session)
        await onFulfilled(status)
    } catch(e) {
        await onRejected(e)
    } finally {
        await onFinally()
    }
}

module.exports = {
    name: 'Tanium',
    test: taniumTest,
    scan: taniumScan,
}
