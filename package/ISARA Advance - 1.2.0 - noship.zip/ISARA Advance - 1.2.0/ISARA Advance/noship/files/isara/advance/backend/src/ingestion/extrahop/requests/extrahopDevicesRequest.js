/**
 * @file extrahopDevicesRequest.js - 1.2.0 - 3826bc12533e078a8e37cfe70ee04d9e85c8530e
 * 
 * @copyright Copyright (C) 2016-2023, ISARA Corporation, All Rights Reserved.
 * 
 * @license The code and other content set out herein is not in the public
 * domain, is considered a trade secret and is confidential to ISARA
 * Corporation. Use, reproduction or distribution, in whole or in part, of such
 * code or other content is strictly prohibited except by express written
 * permission of ISARA Corporation. Please contact ISARA Corporation at
 * info@isara.com for more information.
 */

// /**
//  * Request extrahop device list. Needed in order to associate metadata with
//  * network map and/or recordstore.
//  *
//  * @module extrahop/requests/ExtrahopDevicesRequest
//  */

// const { ExtrahopRequest } = require('./extrahopRequest')

// class ExtrahopDevicesRequest extends ExtrahopRequest {
//     constructor(baseURL, token, parameters) {
//         // TODO: GAP1625 - may need an additional parameter to indicate the timestamp to query from, since we only want activity
//         // since last query.
//         parameters.limit = 100
//         parameters.offset = 0
//         super(baseURL, '/api/v1/devices', token, 'GET', '', parameters)
//     }

//     async checkComplete(response) {
//         if (response.length < this.parameters.limit) {
//             this.complete = true
//         } else {
//             this.parameters.offset += this.parameters.limit
//         }
//     }
// }

// exports.ExtrahopDevicesRequest = ExtrahopDevicesRequest