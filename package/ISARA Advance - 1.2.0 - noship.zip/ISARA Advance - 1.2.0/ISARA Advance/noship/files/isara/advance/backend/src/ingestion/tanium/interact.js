/**
 * @file interact.js - 1.2.0 - 3826bc12533e078a8e37cfe70ee04d9e85c8530e
 * 
 * @copyright Copyright (C) 2016-2023, ISARA Corporation, All Rights Reserved.
 * 
 * @license The code and other content set out herein is not in the public
 * domain, is considered a trade secret and is confidential to ISARA
 * Corporation. Use, reproduction or distribution, in whole or in part, of such
 * code or other content is strictly prohibited except by express written
 * permission of ISARA Corporation. Please contact ISARA Corporation at
 * info@isara.com for more information.
 */

/**
 * API classes modeling the Interact module in the Tanium user interface.
 * @module ingestion/tanium/interact
 */

const log = require('../../util/log')(module)

/**
 * Interact module to get questions comprised of sensors.
 */
class Interact {

    /**
     * @param {*} session Tanium API session
     */
    constructor(session) {
        this.session = session
    }

    async init() {
        let response = await this.session.request({
            method: 'GET',
            url: '/sensors'
        })

        this.sensorsByHash = response.data.reduce((a, s) => ({
            ...a,
            [s.hash]: s.name
        }), {})

        this.sensorsByName = response.data.reduce((a, s) => ({
            ...a,
            [s.name]: s
        }), {})

        this.sensorColumns = response.data.reduce((a, s) => ({
            ...a,
            [s.name]: (s.subcolumns || [s]).map(c => c.name)
        }), {})
        return this
    }

    /**
     * Get a Tanium sensor.
     * @param {string} name The Tanium sensor name
     * @param {strings} parameters Optional parameters to the sensor
     */
    getSensor(name, parameters) {
        if (!(name in this.sensorsByName)) {
            throw {
                message: `Tanium missing sensor, "${name}"`,
                sensor: name
            }
        }
        return new Sensor(name, parameters)
    }

    /**
     * Get a Tanium question.
     * @param {array} sensors An array of Tanium sensors to comprise the question
     * @param {string} computerGroup The Tanium computer group to apply the question to
     * @param {string} filter The Tanium filter to apply to the answers
     */
    async getQuestion(sensors, computerGroup, filter) {
        let questionText = `Get ${sensors.map(s => s.qtext).join(' and ')} from ${computerGroup}`
        log.d(`Asking: ${questionText}`)
        if (filter) {
            questionText += ` with ${filter}`
        }
        let questionResponse
        try {
            questionResponse= await this.session.request({
                method: 'POST',
                url: '/questions',
                data: {
                    query_text: questionText
                }
            })
        } catch (e) {
            if (e.message.includes('InvalidQuestionQueryText')) {
                throw { message: `Invalid Tanium Computer Group (${computerGroup}) or Filter (${filter}).` }
            }
            throw e
        }
        return new Question(this, sensors, questionResponse.data.id)
    }
}

/**
 * Tanium sensor
 */
class Sensor {
    name
    text
    qtext
    /**
     * @param {string} name The Tanium name of the sensor
     * @param {strings} parameters The optional object to apply as parameters
     */
    constructor(name, parameters) {
        this.name = name
        this.text = name
        this.qtext = name
        if (parameters) {
            this.text += `["${JSON.stringify(parameters)}"]`
            this.qtext += `["${JSON.stringify(parameters).replace(/"/g, '""')}"]`
        }
    }
    static isResult(rawValues) {
        // Some columns report 'N/A on Linux' (or other platforms)
        // Some columns report '[no results]'
        // Some columns report '[current result unavailable]'
        // Some columns report 'TSE-Error: No Sensor Definition for this Platform' if a sensor isn't supported
        return (rawValues && (rawValues.length > 1 ||
            !rawValues[0].match(/(^N\/A on .*|^\[no results\]$|(^\[current result unavailable\]$)|(^TSE-Error))/g)))
    }
}

/**
 * Tanium question
 */
class Question {
    /**
     * @param {object} interact The Interact module object
     * @param {objects} sensors The sensors comprising the question
     * @param {int} id The Tanium question id
     */
    constructor(interact, sensors, id) {
        this.interact = interact
        this.sensors = sensors
        this.id = id
    }

    /**
     * @param {object} interact The Interact module object
     * @param {objects} sensors The sensors comprising the question
     * @param {function} isDone An async function that both incurs a delay as a poll interval, and returns true when polling is done
     */
    async ask(isDone) {
        let info
        do {
            let infoResponse = await this.interact.session.request({
                url: `/result_info/question/${this.id}`
            })
            info = infoResponse.data.result_infos[0]
        } while (!await isDone(info.mr_tested, info.estimated_total))
        return (size) => { return new Cache(this, size) }
    }
}

/**
 * Helper class that constructs an isDone function for determining that polling to a question is done.
 */
class PollLimiter {
    isDone

    /**
     * @param {Object} parameters Control the Tanium server API poll and cache behaviour
     *  - limitSeconds The maximum time spent polling
     *  - pauseSeconds The time interval between successive polls
     *  - limitPercent The percentage of actual count over total count that terminates polling
     * @param {function} callback A async function for updating a progress summary
     */
    constructor (parameters, callback) {
        let limitSeconds = parameters?.limitSeconds || Number.MAX_SAFE_INTEGER
        let pauseSeconds = parameters?.pauseSeconds || 1
        let limitPercent = parameters?.limitPercent || 100
        this.msNow = Date.now()
        this.isDone = async (rowCount, rowLimit) => {
            await new Promise(resolve => setTimeout(resolve, pauseSeconds * 1000)) // milliseconds
            let msNow = Date.now()
            limitSeconds -= parseInt((msNow - this.msNow) / 1000)
            this.msNow = msNow
            await callback(rowCount, rowLimit)
            return limitSeconds <= 0 || limitPercent <= (rowCount / rowLimit * 100)
        }
    }
}

/**
 * Fetch answers from a Tanium question, and return each one-at-a-time.
 */
class Cache {

    constructor(question, size) {
        this.question = question
        this.size = size || 100
        this.rows = []
        this.start = 0
    }

    /**
     * @returns The next available answer, or null.
     */
    async next() {
        if (this.rows.length === 0) {
            let response = await this.question.interact.session.request({
                url: `/result_data/question/${this.question.id}?row_start=${this.start}&row_count=${this.size}`
            })
            if (response.data.result_sets[0].rows && response.data.result_sets[0].rows.length) {
                log.d(`Page Start: ${this.start}   Page Size: ${this.size}   ` +
                `Returned: ${response.data.result_sets[0].row_count}`)
                this.start += response.data.result_sets[0].rows.length
                this.rows = response.data.result_sets[0].rows
            }
            if (response.data.result_sets[0].columns) {
                this.columns = response.data.result_sets[0].columns
            }

        }
        return this.rows.length ? new Answer(this.question, this.rows.pop().data, this.columns) : null
    }
}

/**
 * Encapsulate a row response from asking Tanium a question.
 */
class Answer {
    /**
     * Creates an Answer from data returned from Tanium.
     * @param {object} question The question object - contains map of sensor hashes
     * @param {object} answerRow The raw row object returned from Tanium.
     * @param {object[]} columns The columns array returned from Tanium.
     */
    constructor(question, answerRow, columns) {
        this.question = question
        this.rowData = {}
        for (let i in answerRow) {
            let value = answerRow[i]
            let column = columns[i]
            let sensorName = (
                this.question.interact.sensorsByHash[column.hash]
                ||
                this.question.sensors[0].name
            )
            this.rowData[sensorName] = this.rowData[sensorName] || {}
            this.rowData[sensorName][column.name] = value.map(v => v.text)
        }
    }

    /**
     * Get an array of values for a sensor-column
     * @param {*} sensorName The sensor to get the column from.
     * @param {string} [columnName] The column to get from the sensor.
     * @returns An array of values from the sensor-column.
     */
    getColumnMultipleText(sensorName, columnName) {
        columnName = columnName || sensorName
        if (!this.rowData[sensorName] || !this.rowData[sensorName][columnName]) {
            return []
        }
        let rawValues = this.rowData[sensorName][columnName]
        if (Sensor.isResult(rawValues)) {
            return rawValues
        }
        return []
    }

    /**
     * Get a single value for a sensor column.
     * @param {string} sensorName The sensor to get the column from.
     * @param {string} [columnName] The column to get from the sensor.
     * @returns The first value from the sensor-column.
     */
    getColumnText(sensorName, columnName) {
        let textValues = this.getColumnMultipleText(sensorName, columnName)
        if (textValues.length > 0) {
            return textValues[0]
        }
        return null
    }

    /**
     * Get an array of objects that represents a sensor's sub-rows
     * @param {string} sensorName The sensor to get the columns from.
     * @returns An array of objects that represent the sensor rows.
     */
    getSensorRows(sensorName) {
        let sensorRows = []
        let firstColumn = true
        for (let columnName in this.rowData[sensorName]) {
            let columnValues = this.getColumnMultipleText(sensorName, columnName)
            for (let i = 0; i < this.rowData[sensorName][columnName].length; ++i) {
                if (firstColumn) {
                    sensorRows[i] = {}
                }
                sensorRows[i][columnName] = columnValues[i]
            }
            firstColumn = false
        }
        return sensorRows
    }
}

/**
 * Generate each partition in the ISARA Advance sensor
 */
class AdvanceSensor {

    /**
     * @param {string} name The Tanium sensor name
     * @param {int} count The number of partitions
     * @param {int} seed Changing the seed changes the specific set of Tanium endpoints that include data in each partition.
     */
    constructor (name, count, seed) {
        this.name = name
        this.count = count === undefined ? 1 : count
        this.seed = seed === undefined ? 0 : seed
        this.index = 0
    }

    /**
     * @returns The next sensor in the partition, or null.
     */
    next() {
        if (this.index < this.count) {
            const sensor = new Sensor(this.name, { partition: { 'count': this.count, 'seed': this.seed, 'index': this.index } })
            this.index += 1
            return sensor
        }
        return null
    }
}

module.exports = { Interact, Sensor, PollLimiter, AdvanceSensor }
