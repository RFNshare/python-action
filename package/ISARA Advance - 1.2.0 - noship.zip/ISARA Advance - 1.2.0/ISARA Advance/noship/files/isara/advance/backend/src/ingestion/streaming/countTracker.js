/**
 * @file countTracker.js - 1.2.0 - 3826bc12533e078a8e37cfe70ee04d9e85c8530e
 * 
 * @copyright Copyright (C) 2016-2023, ISARA Corporation, All Rights Reserved.
 * 
 * @license The code and other content set out herein is not in the public
 * domain, is considered a trade secret and is confidential to ISARA
 * Corporation. Use, reproduction or distribution, in whole or in part, of such
 * code or other content is strictly prohibited except by express written
 * permission of ISARA Corporation. Please contact ISARA Corporation at
 * info@isara.com for more information.
 */

class IntKeyedCounter {
    #keys = []
    #values = {}
    #maxLength

    constructor(maxLength) {
        if (typeof maxLength !== 'number') {
            throw new Error('maxLength must be a number')
        }
        this.#maxLength = maxLength
    }

    bump(which) {
        while (this.#keys.length > 0 && which - this.#keys[0] >= this.#maxLength) {
            const deleteKey = this.#keys[0]
            delete this.#values[deleteKey]
            this.#keys.splice(0, 1)
        }
        if (!(which in this.#values)) {
            this.#keys.push(which)
            this.#values[which] = 1
        } else {
            this.#values[which]++
        }
    }

    toJSON() {
        const recent = []
        if (this.#keys.length === 0) {
            return recent
        }

        let total = 0

        const newest = this.#keys[this.#keys.length - 1]
        for (let i = 0; i < this.#keys.length; ++i) {
            const which = this.#keys[this.#keys.length - 1 - i]
            const ago = newest - which
            if (ago > this.#maxLength) {
                break
            }
            total += recent[ago] = this.#values[which]
        }

        return { total, recent }
    }
}

const MINUTE_DIV = 1000 * 60
const HOUR_DIV = 1000 * 60 * 60
const DAY_DIV = 1000 * 60 * 60 * 24

class CountTracker {
    #lastActivity = -1
    #startTime

    #minutes = new IntKeyedCounter(60)
    #hours = new IntKeyedCounter(24)
    #days = new IntKeyedCounter(7)

    constructor() {
        this.#startTime = Date.now()
    }

    bump() {
        // const now = this.#lastActivity = override ?? Date.now()
        const nowMinute = Math.floor(this.#startTime/ MINUTE_DIV)
        const nowHour = Math.floor(this.#startTime/ HOUR_DIV)
        const nowDay = Math.floor(this.#startTime/ DAY_DIV)

        this.#minutes.bump(nowMinute)
        this.#hours.bump(nowHour)
        this.#days.bump(nowDay)
    }

    toJSON() {
        return {
            minutes: this.#minutes,
            hours: this.#hours,
            days: this.#days,
            lastActivity: this.#lastActivity,
            startTime: this.#startTime,
        }
    }
}

exports.CountTracker = CountTracker