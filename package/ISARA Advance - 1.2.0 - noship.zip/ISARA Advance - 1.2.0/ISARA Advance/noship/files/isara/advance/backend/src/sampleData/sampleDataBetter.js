/**
 * @file sampleDataBetter.js - 1.2.0 - 3826bc12533e078a8e37cfe70ee04d9e85c8530e
 * 
 * @copyright Copyright (C) 2016-2023, ISARA Corporation, All Rights Reserved.
 * 
 * @license The code and other content set out herein is not in the public
 * domain, is considered a trade secret and is confidential to ISARA
 * Corporation. Use, reproduction or distribution, in whole or in part, of such
 * code or other content is strictly prohibited except by express written
 * permission of ISARA Corporation. Please contact ISARA Corporation at
 * info@isara.com for more information.
 */

var randomWords = require('random-words')
var lodash = require('lodash')
const minimist = require('minimist')

const {
    dumpObjectTimingStats,
    initDbConnection,
    insertObject,
    resetObjectTimingStats,
    bulkInsertRecords,
} = require('./dbHelpers')

const {
    Session
} = require('../isaraql/session')

const {
    pickOne,
    randomBelow,
    randomCompany,
} = require('./sampleHelpers')

const {
    loadDatabaseTypes,
} = require('./dbTypeHelpers')

const {
    allStrongCryptoPrimitives,
    allWeakCryptoPrimitives,
    strongProtocolVariants,
    weakProtocolVariants,
    roles,
    softwareTypes,
    tagTypes,
    users
} = require('./dbTypes')

var {
    hashPassword
} = require('../util/passwordUtils')

const { updateCryptoScoresForDevice, updateCryptoScoresForConnection } = require('../util/scoreHelpers')

const { rebuildAllFlatFacetTables } = require('../util/flatFacetHelpers')

const facets = require('../filterql/facets')

const { Mutex } = require('async-mutex')

const {
    allTypes,
    discoverSchema
} = require('../isaraql/schemaDiscovery')

const {
    Agent,
    AgentCertificate,
    CAIssuedCertificate,
    Certificate,
    CertificateCryptoPrimitive,
    CertificationAuthority,
    Connection,
    ConnectionCertificate,
    ConnectionCipherSuite,
    ConnectionCryptoPrimitive,
    ConnectionProtocolVariant,
    ConnectionProtocolVariantCertificate,
    ConnectionTag,
    Device,
    DeviceAddress,
    DeviceAddressMACAddress,
    DeviceAddressPort,
    DeviceCertificate,
    DeviceMACAddress,
    DeviceSoftware,
    DeviceSoftwareConnection,
    DeviceTag,
    KeyStore,
    KeyStoreKey,
    OneTimeKey,
    Netmask,
    Notification,
    NotificationAction,
    Software,
    SoftwareVersion,
    SoftwareVersionTag,
    Tag,
    User,
    UserRole,
} = require('./dbObjects')

var log = require('../util/log')(module)

var connection = null
let session = new Session()

var allConnections = []
var allDevices = []
var allDeviceSoftware = {}
var allSoftware = {}
var allSoftwareVersions = {}
var allTags = []
var notifications = []
var connectionTags = []
var connectionTagAssociations = []
var softwareVersionTags = []
var softwareVersionTagAssociations = []

const sampleSoftware = {
    'OS': ['Windows', 'macOS', 'Linux'],
    'SERVER': ['Apache', 'Nginx', 'Mongoose'],
    'APP': ['AngryBirds', 'Outlook', 'Sublime Text'],
    'WEB_SERVER': ['Tomcat', 'Apache'],
    'DATABASE': ['MongoDB', 'SQLite', 'Oracle', 'Redis', 'MariaDB', 'Couchbase'],
    'ARCHIVE': ['Winzip', 'WinRAR', '7-Zip', 'Zip Archiver'],
    'FINANCIAL': ['QuickBooks', 'Xero', 'FreshBooks', 'Sage', 'Zoho Books'],
    'BROWSER': ['Firefox', 'Chrome', 'Internet Explorer', 'Safari', 'Brave'],
    'CMS': ['WordPress', 'Drupal', 'Joomla', 'SharePoint', 'Magneto'],
    'CRYPTOGRAPHIC': ['LastPass', 'BitLocker', 'VeraCrypt', 'FileVault', 'DiskCryptor'],
    'OTHER': ['REAPER', 'Random', 'Other']
}

const tagTypeValuesMap = {
    EXCEPTION: ['OK', 'NOT OK'],
    ZONE: ['York', 'Waterloo', 'Kitchener', 'Vancouver', 'Berlin', 'London', 'New York', 'Montréal'],
    PRIORITY: ['HIGH', 'LOW'],
    DEVICE_PURPOSE: ['Finance Dept Machine', 'Print Checks', 'Jenkins Server', 'CI Machine', 'Student Services Server'],
    CPU_FAMILY: ['Intel', 'ARM'],
    HOSTNAME: ['alice', 'bob', 'charlie123', 'alice.isara.com', 'bob.isara.com', 'charlie123.uwaterloo.ca'],
    DOMAIN: ['isara.com', 'uwaterloo.ca', 'google.com', 'aws.amazon.com'],
    NORMAL_ADDRESS: ['1234 Physical St', '567 Mylocation Ave Unit 123', '890 YetAnotherPlace Rd']
}

async function populateSoftware() {
    for (let typeName of Object.keys(softwareTypes)) {
        if (sampleSoftware[typeName]) {
            for (let softwareName of sampleSoftware[typeName]) {
                if (!(softwareName in Object.keys(allSoftware))) {
                    let software = new Software(softwareName, randomCompany(), softwareTypes[typeName].id)
                    await insertObject(software)
                    allSoftware[softwareName] = software
                    let versionsCount = randomBelow(7, 1)
                    for (let k = 0; k < versionsCount; ++k) {
                        let softwareVersion = new SoftwareVersion(software.id, softwareName, k)
                        await insertObject(softwareVersion)
                        if (!Object.keys(allSoftwareVersions).includes(typeName)) {
                            allSoftwareVersions[typeName] = []
                        }
                        allSoftwareVersions[typeName].push(softwareVersion)
                    }
                }
            }
        }
    }
}

async function insertUsers(password) {
    var names = [
        { name: 'callum', fullName: 'Callum Craig' },
        { name: 'fred', fullName: 'Fred Ferguson' },
        { name: 'sara', fullName: 'Sara Smith' }
    ]

    let usersArray = []
    for (var name of names) {
        var user = new User(name.name, name.fullName, await hashPassword(password))
        usersArray.push(user.nameValues)
    }
    let results = await bulkInsertRecords('User', usersArray, session)
    users.push(...results.rows)
    usersArray = []
}

async function insertUserRoles() {
    var roleIndex = 0
    let userRoleArray = []
    for (var user of users) {
        var roleNames = Object.keys(roles)
        var roleName = roleNames[roleIndex++]
        if (roleIndex == roleNames.length) {
            roleIndex = 0
        }
        var role = roles[roleName]
        var userRole = new UserRole(user.id, role.id)
        userRoleArray.push(userRole.nameValues)
    }
    await bulkInsertRecords('UserRole', userRoleArray, session)
    userRoleArray = []
}

async function insertNotifications() {
    let notificationArray = []
    for (var i = 0; i < 100; ++i) {
        var notification = new Notification()
        notificationArray.push(notification.nameValues)
    }
    let results = await bulkInsertRecords('Notification', notificationArray, session)
    notifications.push(...results.rows)
}

async function insertNotificationActions() {
    let notificationActionArray = []
    for (var notification of notifications) {
        for (var user of users) {
            if (Math.random() < 0.1) {
                var notificationAction = new NotificationAction(notification, user)
                notificationActionArray.push(notificationAction.nameValues)
            }
        }
    }
    await bulkInsertRecords('NotificationAction', notificationActionArray, session)
}

async function insertNetmasks() {
    let netmaskArray = []
    for (var i = 0; i < 20; ++i) {
        var netmask = new Netmask()
        netmaskArray.push(netmask.nameValues)
    }
    await bulkInsertRecords('Netmask', netmaskArray, session)
}

function tagType() {
    var types = Object.keys(tagTypes)
    var which = Math.floor(Math.random() * types.length)
    return tagTypes[types[which]]
}

async function tidyOldRecords() {
    // Do not tidy Enum tables.
    const tables = {
        'Netmask': `netmask != ''`,
        'AgentCertificate': null,
        'Agent': null,
        'DataSourceScanResultDetail': null,
        'DataSourceScanResult': null,
        'DataSourceScanSchedule': null,
        'DataSourceScanTag': null,
        'DataSourceScan': null,
        'DataSource': null,
        'NotificationAction': null,
        'Notification': null,
        'ConnectionCertificate': null,
        'ConnectionCipherSuite': null,
        'ConnectionCryptoPrimitive': null,
        'DeviceSoftwareConnection': null,
        'ConnectionProtocolVariantCertificate': null,
        'ConnectionProtocolVariant': null,
        'ConnectionScore': null,
        'ConnectionTag': null,
        'Connection': null,
        'DeviceAddressMACAddress': null,
        'DeviceAttribute': null,
        'DeviceMACAddress': null,
        'DeviceAddressPort': null,
        'DeviceAddress': null,
        'DeviceScore': null,
        'DeviceTag': null,
        'DeviceCertificate': null,
        'CAIssuedCertificate': null,
        'CertificateCryptoPrimitive': null,
        'ConfigurationFileCipherSuite': null,
        'ConfigurationFileCertificate': null,
        'ConfigurationFile': null,
        'Certificate': null,
        'OneTimeKey': null,
        'CertificationAuthority': null,
        'KeyStoreKey': null,
        'KeyStore': null,
        'DeviceSoftware': null,
        'Device': null,
        'SoftwareVersionTag': null,
        'Tag': null,
        'SoftwareVersion': `software NOT IN (select id FROM "Software" WHERE "softwareType" = ${allTypes['SoftwareType']._enum.idByName['DATA']})`,
        'Software': `"softwareType" != ${allTypes['SoftwareType']._enum.idByName['DATA']}`,
        'View': null,
        'UserPreference': null,
        'UserRole': null,
        'User': null
    }
    for (var table in tables) {
        let where = ''
        if (tables[table]) {
            where = `where ${tables[table]}`
        }
        await connection.query(`delete from "${table}" ${where}`)
        await connection.query(`delete from history."${table}" ${where}`)
    }
}

async function insertTag(tag) {
    let index = allTags.findIndex((x) => x.tagType === tag.tagType && x.value === tag.value)
    if (index < 0) {
        await insertObject(tag)
        allTags.push(tag)
    } else {
        tag = allTags[index]
    }

    return tag.id
}

const SoftwareVersionTagsText = ['STABLE', 'ALPHA1', 'ALPHA2', 'BETA1', 'BETA2']

async function generateAndInsertSoftwareVersionTags() {
    var custom_id = tagTypes['CUSTOM'].id
    let softwareVersionTagsArray = []
    for (var i = 0; i < SoftwareVersionTagsText.length; i++) {
        let tag = new Tag(SoftwareVersionTagsText[i], custom_id)
        softwareVersionTagsArray.push(tag.nameValues)
    }
    let results = await bulkInsertRecords('Tag', softwareVersionTagsArray, session)
    softwareVersionTags.push(...results.rows)
}

let softwareVersionTagArray=[]
function insertSoftwareVersionTag(version) {
    var randomVersionTag = pickOne(softwareVersionTags)

    if (softwareVersionTagAssociations.findIndex((x) => x.softwareVersion == version.id && x.tag == randomVersionTag.id) == -1) {
        let softwareVersionTag = new SoftwareVersionTag(version.id, randomVersionTag.id)
        softwareVersionTagArray.push(softwareVersionTag.nameValues)
        softwareVersionTagAssociations.push(softwareVersionTag)
    }
}

const ConnectionTagsText = [`Tunneled`, `VPN`, `Timed_Out`, `Error_Detected`]

async function generateAndInsertConnectionTags() {
    var custom_id = tagTypes['CUSTOM'].id
    let connectionTagsArray = []
    for (var i = 0; i < ConnectionTagsText.length; i++) {
        let tag = new Tag(ConnectionTagsText[i], custom_id)
        connectionTagsArray.push(tag.nameValues)
    }
    let results = await bulkInsertRecords('Tag', connectionTagsArray, session)
    connectionTags.push(...results.rows)
}

let connectionsTags =[]
function insertConnectionTag(connection) {
    var randomConnectionTag = pickOne(connectionTags)

    if (connectionTagAssociations.findIndex((x) => x.connection == connection.id && x.tag == randomConnectionTag.id) == -1) {
        let connectionTag = new ConnectionTag(connection.id, randomConnectionTag.id)
        connectionsTags.push(connectionTag.nameValues)
        connectionTagAssociations.push(connectionTag)
    }
}

async function generateTag(tagType) {
    var tagValue = ''
    // Map tag type to generate a new random tag
    if (tagType.isNumeric) {
        var numericValue = -1
        switch (tagType.name) {
        case 'RAM_SIZE': {
        // Reasonable RAM size in Bytes: 1 GB to 1 TB?
            var sizeInGB = 1 << randomBelow(11)
            numericValue = sizeInGB * Math.pow(10, 9)
            break
        }
        case 'CPU_SPEED': {
        // CPU Speed: 500 MHz to 5 GHz
            let sizeInMHz = randomBelow(5000, 500)
            numericValue = sizeInMHz * Math.pow(10, 6)
            break
        }
        default:
            throw `Unknown numeric tag type`
        }
        tagValue = `${numericValue}`
    } else {
    // Non-numeric
        var mapValue = tagTypeValuesMap[tagType.name]
        if (!mapValue || !mapValue.length) {
            switch (tagType.name) {
            case 'COORDINATE':
                tagValue = `${randomBelow(90)} ${pickOne(['N', 'S'])} ${randomBelow(180)} ${pickOne(['W', 'E'])}`
                break
            case 'CPU_SERIAL_NUMBER':
            case 'SERVER_ROOM_NUMBER':
            case 'RACK_ADDRESS':
            case 'MACHINE_SERIAL_NUMBER':
            case 'OS_SERIAL_NUMBER':
            case 'CORPORATE_ASSET_TAG_TRACKING_NUMBER':
                break
            default:
                // randomWords can return an array of length 1 *or* a raw string ; make sure to catch this.
                tagValue = randomWords(1)
                if (Array.isArray(tagValue)) {
                    tagValue = tagValue[0]
                }
                break
            }
        } else {
            tagValue = pickOne(mapValue)
        }
    }

    return new Tag(tagValue, tagType.id)
}


const deviceTypes = {
    BAD_SERVER : 'BAD_SERVER',
    GOOD_SERVER: 'GOOD_SERVER',
    CLIENT: 'CLIENT'
}

const badServerReasons = {
    WEAK_CRYPTO_PRIMITIVE : 'WEAK_CRYPTO_PRIMITIVE',
    WEAK_VERSION_TLS : 'WEAK_VERSION_TLS',
    WEAK_CIPHER_SUITE : 'WEAK_CIPHER_SUITE',
}

const badServerReasonsArray = ['WEAK_CRYPTO_PRIMITIVE', 'WEAK_VERSION_TLS', 'WEAK_CIPHER_SUITE']

const popularStrongCipherSuite = [
    'TLS_CHACHA20_POLY1305_SHA256',
    'TLS_AES_128_CCM_8_SHA256',
    'TLS_SM4_GCM_SM3',
    'TLS_AES_128_GCM_SHA256',
    'TLS_SM4_GCM_SM3'
]

const popularBadCipherSuite = [
    'TLS_ECDHE_ECDSA_WITH_AES_256_CCM',
    'TLS_ECDHE_SIDH_RSA_WITH_AES_256_GCM_SHA384',
    'TLS_ECDHE_KYBER_ECDSA_WITH_AES_256_GCM_SHA384',
    'TLS_DHE_DSS_WITH_AES_128_CBC_SHA',
    'TLS_GOSTR341112_256_WITH_28147_CNT_IMIT',
    'TLS_PSK_WITH_AES_128_CCM',
]

const optionalArguments = {
    help: 'Display this insightful message.',
    baselineOnly: 'Only provision user objects and minimal required data.',
    goodServerPorts: 'Ports and number of ports count for good servers e.g. [{ \\"port\\":443, \\"count\\":2}].',
    badServerPorts: 'Ports and number of ports count for bad servers e.g. [{ \\"port\\":443, \\"count\\":2}].',
    numGoodServers: 'Number of good servers.',
    numBadServers: 'Number of bad servers.',
    numClients: 'Number of clients.',
    pocGoodServers: 'Probability of connecting to a good server.',
    minGoodConnections: 'Minimum number of good connections.',
    minBadConnections: 'Minimum number of bad connections.',
    pocBadServers: 'Probability of connecting to a bad server.',
    maxCertificates: 'Maximum number of certificates.',
    userPassword: "Password to assign default users, instead of 'password'"
}

function usage() {
    console.log(`Usage: node ${process.argv[1]}`)
    console.log('\n')
    console.log('Optional arguments:\n\n')
    for(let arg of Object.keys(optionalArguments)) {
        console.log(`\t--${arg}${arg !== 'help' && arg !== 'baselineOnly' ? '=<val>' : ''}: ${optionalArguments[arg]}`)
    }
    console.log('\n')
    process.exit(0)
}

async function main() {
    log.log('Entered main')

    connection = await initDbConnection()
    await discoverSchema()
    const myArgs = minimist(process.argv.slice(2))
    for(let arg of Object.keys(myArgs)){
    // The first argument is always _ which returns an array of arguments without dashes
        if(arg !== '_' && !Object.keys(optionalArguments).includes(arg)) {
            console.log(`Unsupported argument: ${arg}`)
            usage()
        }
    }

    if (myArgs.help) {
        usage()
    }

    let bulkSize = 100
    let createBaselineOnly = myArgs?.baselineOnly || false

    let numGoodServerCount = Number(myArgs?.numGoodServers) || 20
    let numBadServerCount = Number(myArgs?.numBadServers) || 25
    let numClients = Number(myArgs?.numClients) || 200

    let pocGoodServers = Number(myArgs?.pocGoodServers) || 0.9
    let minGoodConnections = Number(myArgs?.minGoodConnections) || 500

    let pocBadServers = Number(myArgs?.pocBadServers) || .01
    let minBadConnections = Number(myArgs?.minBadConnections) || 100

    let maxCertificateCount = Number(myArgs?.maxCertificates) || 5

    let userPassword = myArgs?.userPassword || 'password'

    let goodServerPorts =[
        {port:443, count:3000},
        {port:8080,count:4000},
        {port:80,count:500},
        {port:22,count:300},
        {port:23,count:400}
    ]

    let badServerPorts = [
        {port:443, count:2000},
        {port:8080, count:1000},
        {port:80, count:3000},
        {port:22, count:4000},
        {port:23, count:600}
    ]

    try {
        goodServerPorts = JSON.parse(myArgs?.goodServerPorts)
        badServerPorts = JSON.parse(myArgs?.badServerPorts)
    } catch {
        // do nothing
    }

    let listeningGoodServerAddressPorts = []
    let listeningBadServerAddressPorts = []
    let listeningClientAddressPorts = []
    let existingCertificates = []
    let CertsWithPrimitives = []

    log.log('Purging database...')
    await tidyOldRecords()

    log.log('Discovering schema...')
    await discoverSchema()
    await facets.discoverPaths()

    log.log('Loading database types...')
    await loadDatabaseTypes()

    log.log('Adding users...')
    await insertUsers(userPassword)
    await insertUserRoles()

    if (createBaselineOnly) {
        await connection.end()
        return
    }

    let startTime = new Date()

    log.log('Adding software version tags...')
    await generateAndInsertSoftwareVersionTags()

    log.log('Adding connection tags...')
    await generateAndInsertConnectionTags()

    log.log('Adding notifications...')
    await insertNotifications()
    await insertNotificationActions()

    log.log('Adding network masks...')
    await insertNetmasks()

    log.log('Adding software...')
    await populateSoftware()

    dumpObjectTimingStats()
    resetObjectTimingStats()

    let addOneTimeKey = async function (certificationAuthorities){
        let oneTimeKeyArray = []
        for(let certificationAuthority of certificationAuthorities){
            let oneTimeKey = new OneTimeKey(certificationAuthority)
            await oneTimeKey.populate()
            oneTimeKeyArray.push(oneTimeKey.nameValues)
        }
        await bulkInsertRecords('OneTimeKey', oneTimeKeyArray, session)
    }

    let addCertificationAuthority = async function (keyStoreKeys, certAuthorities){
        let certificationAuthorityArray =[]
        for(let keyStoreKey of keyStoreKeys){
            let certificationAuthority = new CertificationAuthority(keyStoreKey)
            certificationAuthorityArray.push(certificationAuthority.nameValues)
        }
        let results = await bulkInsertRecords('CertificationAuthority', certificationAuthorityArray, session)
        for(let certificationAuthority of results.rows){
            certAuthorities.push(certificationAuthority)
        }
        await addOneTimeKey(results.rows)
    }

    let addKeyStoreKey = async function(keyStores,certAuthorities){
        let keyStoreKeyArray = []
        for(let keyStore of keyStores){
            let keyStoreKey = new KeyStoreKey(keyStore)
            await keyStoreKey.populate()
            keyStoreKeyArray.push(keyStoreKey.nameValues)
        }
        let result = await bulkInsertRecords('KeyStoreKey', keyStoreKeyArray, session)
        await addCertificationAuthority(result.rows, certAuthorities)
    }

    let addKeyStore= async function(certAuthorities){
        let caCount = Math.floor(Math.random() * 10 + 1)
        let keyStoreArray =[]
        for (let i = 0; i < caCount; i++) {
            let keyStore = new KeyStore()
            keyStoreArray.push(keyStore.nameValues)
        }
        let results = await bulkInsertRecords('KeyStore', keyStoreArray, session, true)
        await addKeyStoreKey(results.rows, certAuthorities)
    }

    let bulkInsertDeviceAddressPort = async function(){
        if(bulkDeviceAddressPort.length > 0){
            let result = await bulkInsertRecords('DeviceAddressPort', bulkDeviceAddressPort, session)
            let index = 0
            for(let devPort of result.rows){
                let devType = bulkDeviceAddressPortType[index]
                devType.port = devPort
                if(devType.deviceType === deviceTypes.GOOD_SERVER){
                    delete devType.deviceType
                    listeningGoodServerAddressPorts.push(devType)
                }
                if(devType.deviceType === deviceTypes.BAD_SERVER){
                    delete devType.deviceType
                    listeningBadServerAddressPorts.push(devType)
                }
                if(devType.deviceType === deviceTypes.CLIENT){
                    delete devType.deviceType
                    listeningClientAddressPorts.push(devType)
                }
                index++
            }
            bulkDeviceAddressPort = []
            bulkDeviceAddressPortType = []
        }
    }

    let bulkDeviceAddressPort = []
    let bulkDeviceAddressPortType = []
    let addDeviceAddressPort = async function(deviceAddress, device, deviceType, serverPorts){
        try {
            if(bulkDeviceAddressPort.length >= bulkSize){
                await bulkInsertDeviceAddressPort()
            }
            if(deviceType === deviceTypes.GOOD_SERVER || deviceType === deviceTypes.BAD_SERVER){
                let existingPorts = []
                for(var k = 0; k < serverPorts.length; ++k){
                    if(serverPorts[k].count > 0){
                        let deviceAddressPort = new DeviceAddressPort(deviceAddress, existingPorts, serverPorts[k].port )
                        serverPorts[k].count -= 1
                        await deviceAddressPort.populate()
                        bulkDeviceAddressPort.push(deviceAddressPort.nameValues)
                        existingPorts.push(serverPorts[k].port)
                        bulkDeviceAddressPortType.push({deviceType:deviceType, device: device, address: deviceAddress})
                    }
                }
            }
            let deviceAddressPort = new DeviceAddressPort(deviceAddress)
            deviceAddressPort.port = -1
            await deviceAddressPort.populate()
            bulkDeviceAddressPort.push(deviceAddressPort.nameValues)
            bulkDeviceAddressPortType.push({deviceType:deviceType, device: device, address: deviceAddress})
        } catch (error) {
            console.log('Failed to create port', error)
        }
    }

    let deviceAgents = {}

    let addDeviceAgents = async function (devices) {
        let deviceAgentsArray = []
        for(let device of devices){
            // TODO: GAP1629 - this should probably be further narrowed down to only include an agent on devices which can actually install one
            // e.g. servers/workstations/VMs
            if (pickOne([true, false])) {
                let agent = new Agent(device.id)
                deviceAgentsArray.push(agent.nameValues)
            }
        }
        let results =  await bulkInsertRecords('Agent', deviceAgentsArray, session)
        for(let agent of results.rows){
            let device = devices.find(dev => dev.id === agent.device)
            deviceAgents[device.id] = agent
        }
    }

    let addDeviceAddress = async function (devices){
        let deviceAddressArray = []
        let deviceMACAddressArray = []
        for(let device of devices){
            let addressCount = Math.random() > 0.7 ? 2 : 1
            for (var j = 0; j < addressCount; ++j) {
                let deviceAddress = new DeviceAddress(device)
                await deviceAddress.populate()
                deviceAddressArray.push(deviceAddress.nameValues)

                let deviceMACAddress = new DeviceMACAddress(device)
                deviceMACAddressArray.push(deviceMACAddress.nameValues)

            }
        }

        let deviceAddressResults =  await bulkInsertRecords('DeviceAddress', deviceAddressArray, session)
        let deviceMACAddressResults =  await bulkInsertRecords('DeviceMACAddress', deviceMACAddressArray, session)

        let deviceIndex = 0
        let deviceAddressMACAddressArray = []
        for(let deviceAddress of deviceAddressResults.rows){
            let deviceAddressMACAddress = new DeviceAddressMACAddress(deviceAddress, deviceMACAddressResults.rows[deviceIndex])
            deviceAddressMACAddressArray.push(deviceAddressMACAddress.nameValues)
            deviceIndex ++
        }

        await bulkInsertRecords('DeviceAddressMACAddress', deviceAddressMACAddressArray, session)
        await callDeviceAddressPort(devices, deviceAddressResults.rows)

    }

    let callDeviceAddressPort = async function(devices, deviceAddressArray){
        let index = 0
        for(let device of devices){
            let deviceType = deviceTypeArray[index]
            let devAddresses = deviceAddressArray.filter( address => address.device === device.id)
            for(let devAddress of devAddresses){
                if(deviceType === deviceTypes.GOOD_SERVER){
                    if(index === 0){
                        await bulkInsertDeviceAddressPort()
                    }
                    await addDeviceAddressPort(devAddress, device, deviceType, goodServerPorts)
                }
                if(deviceType === deviceTypes.BAD_SERVER){
                    if(index === 0){
                        await bulkInsertDeviceAddressPort()
                    }
                    await addDeviceAddressPort(devAddress, device, deviceType, badServerPorts)
                }
                if(deviceType === deviceTypes.CLIENT){
                    if(index === 0){
                        await bulkInsertDeviceAddressPort()
                    }
                    await addDeviceAddressPort(devAddress, device, deviceType, null)
                }
            }
            index++
        }
    }

    const mutex = new Mutex()
    let addDeviceTags = async function (devices){
        let deviceTags = []
        for(let device of devices){
            let tagCount = Math.floor(Math.random() * 10)
            let usedTags = []
            await mutex.runExclusive(async () => {
                for (let j = 0; j < tagCount; ++j) {
                    // Add random tags
                    let randomTagType = tagType()
                    let randomTag = await generateTag(randomTagType)
                    let result = await insertTag(randomTag)
                    if (usedTags.includes(result)) {
                        continue
                    }
                    usedTags.push(result)
                    var deviceTag = new DeviceTag(device.id, result)
                    deviceTags.push(deviceTag.nameValues)
                }
            })
        }
        await bulkInsertRecords('DeviceTag', deviceTags, session)
    }


    let addDeviceSoftware = async function(devices){
        let deviceSoftwareArray = []
        //add random software
        for(let device of devices){
            if (Math.random() > 0.2) {
                let softwareCount = randomBelow(20, 1)
                let hasOS = false
                for (let i = 0; i < softwareCount; ++i) {
                    let softwareType = pickOne(Object.keys(allSoftwareVersions))
                    if (hasOS && softwareType == 'OS') {
                        continue
                    } else {
                        hasOS = true
                    }

                    let versions = allSoftwareVersions[softwareType]
                    let software = pickOne(versions)
                    let deviceSoftware = new DeviceSoftware(device, software)
                    deviceSoftwareArray.push(deviceSoftware.nameValues)
                }
            }
        }
        let results  = await bulkInsertRecords('DeviceSoftware',deviceSoftwareArray,session)
        for(let software of results.rows){
            if (!allDeviceSoftware[software.device]) {
                allDeviceSoftware[software.device] = []
            }
            allDeviceSoftware[software.device].push(software.id)
        }
    }

    let bulkUpdateDevice = []
    let addDevice = async function () {
        let device = new Device()
        await device.populate()
        bulkUpdateDevice.push(device.nameValues)
    }

    let deviceTypeArray = []
    let callAddDevice = async function(deviceType, deviceCount, message){
        try {
            for (let i = 0; i < deviceCount; ++i) {
                deviceTypeArray.push(deviceType)
                await addDevice()
                if (bulkUpdateDevice.length >= bulkSize) {
                    let results =  await bulkInsertRecords('Device', bulkUpdateDevice, session)
                    allDevices.push(...results.rows)
                    await addDeviceAgents(results.rows)
                    await addDeviceAddress(results.rows)
                    await addDeviceTags(results.rows)
                    await addDeviceSoftware(results.rows)
                    bulkUpdateDevice = []
                    deviceTypeArray = []
                }
                showCount(message, i + 1, deviceCount)
            }
            if(bulkUpdateDevice.length > 0){
                let results =  await bulkInsertRecords('Device', bulkUpdateDevice, session)
                allDevices.push(...results.rows)
                await addDeviceAgents(results.rows)
                await addDeviceAddress(results.rows)
                await addDeviceTags(results.rows)
                await addDeviceSoftware(results.rows)
                bulkUpdateDevice = []
                deviceTypeArray = []
            }

            if(bulkDeviceAddressPort.length > 0){
                await bulkInsertDeviceAddressPort()
            }
        } catch (error) {
            console.log('Error in call add device', error)
        }
    }

    let certAuthorities = []
    await addKeyStore(certAuthorities)

    resetObjectTimingStats()
    let allCipherSuites = (await connection.query(`select * from "CipherSuite"`)).rows
    let strongCipherSuites = popularStrongCipherSuite.map(name => allCipherSuites.find(ciphersuite => ciphersuite.name === name))
    let badCipherSuites = popularBadCipherSuite.map(name => allCipherSuites.find(ciphersuite => ciphersuite.name === name))

    let bulkInsertConnectionProtocolVariant = async function(bulkProtocolVariants,bulkProtocolVariantsCerts){
        try {
            let connProtVarCerts = []
            let index = 0
            let results =  await bulkInsertRecords('ConnectionProtocolVariant', bulkProtocolVariants, session)
            for(let protocolVariant of results.rows){
                let connItem = bulkProtocolVariantsCerts[index]
                let connProtVarCert = new ConnectionProtocolVariantCertificate(
                    protocolVariant.id, connItem.certificateType, connItem.id)
                connProtVarCerts.push(connProtVarCert.nameValues)
                index++
            }
            await bulkInsertRecords('ConnectionProtocolVariantCertificate', connProtVarCerts, session)
        } catch (error) {
            log.log(`bulkInsertConnectionProtocolVariant ${error}`)
        }
    }

    let addConnectionProtocolVariant = async function(connections){
        try {
            let bulkProtocolVariants =[]
            let bulkProtocolVariantsCerts = []
            let connCertificates = []
            let index = 0
            for(let connection of connections){
                let connItem = connectionsItems[index]
                if (connItem.certificate) {
                    let protocolVariantCount = pickOne([1, 1, 2, 3])
                    let addedProtocolVariants = {}
                    for (let k = 0; k < protocolVariantCount; ++k) {
                        let isStrongProtocolVariant = connItem.serverType == deviceTypes.GOOD_SERVER || connItem.badReason != badServerReasons.WEAK_VERSION_TLS
                        let protocolVariant = isStrongProtocolVariant ? pickOne(strongProtocolVariants) :  pickOne(weakProtocolVariants)
                        if (!addedProtocolVariants[protocolVariant.id]) {
                            let connProtVar = new ConnectionProtocolVariant(connection.id, protocolVariant.id)
                            bulkProtocolVariants.push(connProtVar.nameValues)
                            bulkProtocolVariantsCerts.push(connItem.certificate)
                            addedProtocolVariants[protocolVariant.id] = connProtVar
                        }
                    }
                    let connCert = new ConnectionCertificate(connection.id, connItem.certificate.id)
                    connCertificates.push(connCert.nameValues)
                }
                index++
            }
            if(bulkProtocolVariants.length > 0){
                await bulkInsertConnectionProtocolVariant(bulkProtocolVariants,bulkProtocolVariantsCerts)
            }
            if(connCertificates.length > 0){
                await bulkInsertRecords('ConnectionCertificate', connCertificates, session)
            }
        } catch (error) {
            log.log(`addConnectionProtocolVariant ${error}`)
        }

    }

    let addConnectionCryptoPrimitives = async function(connections){
        let bulkConnectionCryptoPrimitives = []
        let index = 0
        try {
            for(let connection of connections){
                let connItem = connectionsItems[index].badReason
                if(connItem === badServerReasons.WEAK_CRYPTO_PRIMITIVE){
                    let connectionCryptoPrim = new ConnectionCryptoPrimitive(connection,pickOne(allWeakCryptoPrimitives))
                    bulkConnectionCryptoPrimitives.push(connectionCryptoPrim.nameValues)
                }
                index ++
            }
            if(bulkConnectionCryptoPrimitives.length > 0){
                await bulkInsertRecords('ConnectionCryptoPrimitive', bulkConnectionCryptoPrimitives, session)
            }
        } catch (error) {
            log.log(`addConnectionCryptoPrimitives ${error}`)
        }

    }

    let addConnectionCipherSuites = async function(connections){
        try {
            let cipherSuites = []
            let index = 0
            for(let connection of connections){
                let connItem = connectionsItems[index]
                let numCipherSuites = pickOne([1, 1, 1, 2, 1, 3, 2])
                let usedCipherSuites = []

                //not all Connections will have a CipherSuite but enforce it if the badReason === WEAK_CIPHER_SUITE
                let isCipherSuite = connItem.badReason == badServerReasons.WEAK_CIPHER_SUITE ? true : pickOne([true, false])
                if (isCipherSuite) {
                    let isStrongCipherSuites = connItem.serverType == deviceTypes.GOOD_SERVER || connItem.badReason != badServerReasons.WEAK_CIPHER_SUITE
                    while (usedCipherSuites.length < numCipherSuites) {
                        let connectionCipherSuite = new ConnectionCipherSuite(connection, isStrongCipherSuites ? pickOne(strongCipherSuites) : pickOne(badCipherSuites))
                        if (usedCipherSuites.includes(connectionCipherSuite.cipherSuite)) {
                            continue
                        }
                        cipherSuites.push(connectionCipherSuite.nameValues)
                        usedCipherSuites.push(connectionCipherSuite.cipherSuite)
                    }
                }
                index++
            }
            await bulkInsertRecords('ConnectionCipherSuite', cipherSuites, session)
        } catch (error) {
            log.log(`addConnectionCipherSuites ${error}`)
        }
    }

    let addDeviceSoftwareConnection = async function(connections){
        try {
            let deviceSoftwareConnection = []
            let index = 0
            for(let connection of connections){
                let connItem = connectionsItems[index]
                // Not all connections will have detected software on both ends
                if (pickOne([true, false]) && allDeviceSoftware[connItem.server.device.id]) {
                    let serverSoftware = pickOne(allDeviceSoftware[connItem.server.device.id])
                    let softwareConnection = new DeviceSoftwareConnection(serverSoftware, connection)
                    deviceSoftwareConnection.push(softwareConnection.nameValues)
                }
                if (connItem.client && pickOne([true, false]) && allDeviceSoftware[connItem.client.device.id]) {
                    let clientSoftware = pickOne(allDeviceSoftware[connItem.client.device.id])
                    let softwareConnection = new DeviceSoftwareConnection(clientSoftware, connection)
                    deviceSoftwareConnection.push(softwareConnection.nameValues)
                }
                index ++
            }
            if(deviceSoftwareConnection.length > 0){
                await bulkInsertRecords('DeviceSoftwareConnection', deviceSoftwareConnection, session)
            }
        } catch (error) {
            log.log(`addDeviceSoftwareConnection ${error}`)
        }
    }



    let bulkAddConnections = async function(){
        try {
            if(bulkAddConnectionsArray.length > 0){
                let results =  await bulkInsertRecords('Connection', bulkAddConnectionsArray, session)
                allConnections.push(...results.rows)
                await addConnectionProtocolVariant(results.rows)
                await addConnectionCryptoPrimitives(results.rows)
                await addConnectionCipherSuites(results.rows)
                await addDeviceSoftwareConnection(results.rows)
            }
            bulkAddConnectionsArray = []
            connectionsItems = []

        } catch (error) {
            log.log(`bulkAddConnections ${error}`)
        }

    }

    let bulkAddConnectionsArray = []
    let connectionsItems = []
    let addConnection = async function (addServerOnlyConnection, candidate, server, certificate, serverType, badReason) {
        try {
            const newConnection = new Connection()
            let client
            if (addServerOnlyConnection) {
                addServerOnlyConnection = false
            } else {
                client = candidate
                newConnection.clientDeviceAddressPort = client.port.id
            }
            newConnection.serverDeviceAddressPort = server.port.id
            if (Math.random() > .7) {
                newConnection.addedBy = pickOne(users).id
            }

            let clientAddress = (client) ? client.address.address : '\u2015'
            let serverAddress = server.address.address
            let serverPort = server.port.port
            newConnection.friendlyName = clientAddress + ' \u2192 ' + serverAddress + ' : ' + serverPort
            if(bulkAddConnectionsArray.length >= bulkSize){
                await bulkAddConnections()
            }
            bulkAddConnectionsArray.push(newConnection.nameValues)
            connectionsItems.push({server: server, certificate:certificate, serverType:serverType, badReason:badReason, client:client})
        } catch (error) {
            console.log('Failed to create connection', error)
        }
    }

    let callAddConnection = async function (serverType, server, client, badReason){
        try {
            let certificate = null
            let iscertificate = (serverType == deviceTypes.GOOD_SERVER || badReason == badServerReasons.WEAK_CRYPTO_PRIMITIVE || badReason == badServerReasons.WEAK_VERSION_TLS) ? true : pickOne([true, false])
            // not all Servers will have a Certificate but should enforce if the badReason is a WEAK_CRYPTO_PRIMITIVE
            if (iscertificate) {
                if (maxCertificateCount > 0) {
                    certificate = new Certificate(pickOne(certAuthorities))
                    await certificate.populate()
                    await insertObject(certificate)
                    existingCertificates.push(certificate)
                    maxCertificateCount --
                } else {
                    certificate = pickOne(lodash.shuffle(existingCertificates))
                }

                let deviceCertificate = new DeviceCertificate(server.device.id, certificate.id)
                await insertObject(deviceCertificate)

                let certPrimitiveCount = randomBelow(4, 1)
                let certPrimitives = []
                for (let k = 0; k < certPrimitiveCount; ++k) {
                    let isStrongCryptoPrimitives = serverType == deviceTypes.GOOD_SERVER || badReason != badServerReasons.WEAK_CRYPTO_PRIMITIVE
                    let primitive = isStrongCryptoPrimitives ? pickOne(allStrongCryptoPrimitives) : pickOne(allWeakCryptoPrimitives)
                    let primitiveId = primitive.id
                    let keyLength = null
                    let upperLimit = null
                    let nameSplit = primitive.name.split('_')
                    let standardRSA = [512, 1024, 2048, 3072, 4096, 6000]
                    let standardDSA = [1024, 2048, 3072, 7680, 15360, 16000]
                    if (primitive.name.includes('RSA')) {
                        if (randomBelow(3)) {
                            let roundDown = parseInt(nameSplit[nameSplit.length - 1])
                            upperLimit = standardRSA[standardRSA.indexOf(roundDown) + 1]
                            keyLength = randomBelow(upperLimit, roundDown + 1)
                        }
                    }
                    if (primitive.name.includes('DSA_DSS')) {
                        if (randomBelow(3)) {
                            let roundDown = parseInt(nameSplit[nameSplit.length - 2])
                            upperLimit = standardDSA[standardDSA.indexOf(roundDown) + 1]
                            keyLength = randomBelow(upperLimit, roundDown + 1)
                        }
                    }
                    if (!certPrimitives.includes(primitiveId) && !CertsWithPrimitives.includes(certificate.id)){
                        certPrimitives.push(primitiveId)
                        CertsWithPrimitives.push(certificate.id)
                        await insertObject(new CertificateCryptoPrimitive(certificate.id, primitiveId, keyLength))
                    }
                }
                let caIssuedCertificate = new CAIssuedCertificate(pickOne(certAuthorities), certificate)
                await insertObject(caIssuedCertificate)

                if (deviceAgents[server.device.id]) {
                    let agent = deviceAgents[server.device.id]
                    let agentCertificate = new AgentCertificate(agent, certificate)
                    await insertObject(agentCertificate)

                }
            }

            let addServerOnlyConnection = Math.random() < 0.01
            await addConnection(addServerOnlyConnection, client, server, certificate, serverType, badReason)

        } catch (error) {
            console.log('Failed to call addConnection', error)
        }
    }

    await callAddDevice(deviceTypes.GOOD_SERVER, numGoodServerCount, 'Good Server')
    await callAddDevice(deviceTypes.CLIENT, numClients, 'Clients')

    let goodServerClients = lodash.shuffle(listeningClientAddressPorts)
    let currentGoodServerClientPorts = []
    for (let s = 0; s < (goodServerClients.length + minGoodConnections) ; ++s) {
        const connectionsForThisClient = Math.floor(Math.random() * 20)+1
        for (let tt = 0; tt < connectionsForThisClient; ++tt) {
            if ((minGoodConnections > 0 ) || (Math.random() < pocGoodServers)) {
                let portForServer = pickOne(lodash.shuffle(listeningGoodServerAddressPorts))
                minGoodConnections --
                let client = goodServerClients[Math.floor(Math.random() * goodServerClients.length)]
                let portPair = {clientPort: client.port.id, serverPort: portForServer.port.id}
                let itemNotFound = currentGoodServerClientPorts.find( item => item.clientPort === client.port.id && item.serverPort === portForServer.port.id ) ? false : true
                while(!itemNotFound){
                    client = goodServerClients[Math.floor(Math.random() * goodServerClients.length)]
                    itemNotFound = currentGoodServerClientPorts.find( item => item.clientPort === client.port.id && item.serverPort === portForServer.port.id ) ? false : true
                }
                if(itemNotFound){
                    log.log('Adding a Good Connection ...')
                    await callAddConnection(deviceTypes.GOOD_SERVER, portForServer, client)
                    currentGoodServerClientPorts.push(portPair)
                }
            }
        }
    }
    await bulkAddConnections()
    currentGoodServerClientPorts = []
    listeningGoodServerAddressPorts = []

    await callAddDevice(deviceTypes.BAD_SERVER, numBadServerCount, 'Bad Server' )

    let badServerClients = lodash.shuffle(listeningClientAddressPorts)
    let currentBadServerClientPorts = []
    for (let s = 0; s < (badServerClients.length + minBadConnections) ; ++s) {
        const connectionsForThisClient = Math.floor(Math.random() * 20) + 1
        for (let tt = 0; tt < connectionsForThisClient; ++tt) {
            if ((minBadConnections > 0 ) || (Math.random() < pocBadServers) ) {
                let portForServer = pickOne(lodash.shuffle(listeningBadServerAddressPorts))
                let client = badServerClients[Math.floor(Math.random() * badServerClients.length)]
                let badReason = pickOne(lodash.shuffle(badServerReasonsArray))
                let portPair = {clientPort: client.port.id, serverPort: portForServer.port.id}
                let itemNotFound = currentBadServerClientPorts.find( item => item.clientPort === client.port.id && item.serverPort === portForServer.port.id ) ? false : true
                while(!itemNotFound){
                    client = badServerClients[Math.floor(Math.random() * badServerClients.length)]
                    itemNotFound = currentBadServerClientPorts.find( item => item.clientPort === client.port.id && item.serverPort === portForServer.port.id ) ? false : true
                }
                minBadConnections --
                if(itemNotFound){
                    log.log('Adding a Bad Connection ...')
                    await callAddConnection(deviceTypes.BAD_SERVER, portForServer, client , badReason)
                    currentBadServerClientPorts.push(portPair)
                }
            }
        }
    }
    await bulkAddConnections()

    const clientCount = (await connection.query(`select count("id") from (select d.id,count(*) FROM "Device" d JOIN "DeviceAddress" da ON da.device = d.id JOIN "DeviceAddressPort" dap ON dap."deviceAddress" = da.id JOIN "Connection" c on c."clientDeviceAddressPort" = dap.id GROUP BY 1 ORDER BY  1 ASC) AS derived`)).rows[0].count
    let offsetClient = 0
    while(offsetClient <= clientCount){
        const clients = (await connection.query(
            `select d.id,count(*) FROM "Device" d JOIN "DeviceAddress" da ON da.device = d.id JOIN "DeviceAddressPort" dap ON dap."deviceAddress" = da.id JOIN "Connection" c on c."clientDeviceAddressPort" = dap.id GROUP BY 1 ORDER BY  1 ASC LIMIT ${bulkSize} offset ${offsetClient}`,
        )).rows
        let outgoingConnectionCounts = []
        if (clients.length > 0) {
            let i = 0
            for (let client of clients) {
                outgoingConnectionCounts.push(`(${client.count},${client.id})`)
                showCount('Update Client Connection Counts', i, clients.length)
                i++
            }
            showCount('Update Client Connection Counts', i, clients.length)
            await connection.query(`UPDATE "Device" as t SET "outgoingConnectionCount"=c.outgoingConnectionCount from (values ${outgoingConnectionCounts.join(',')} ) as c(outgoingConnectionCount, id) WHERE c.id=t.id`)
        }
        offsetClient = offsetClient + bulkSize
    }

    const serverCount = (await connection.query(`select count("id") from (select d.id,count(*) FROM "Device" d JOIN "DeviceAddress" da ON da.device = d.id JOIN "DeviceAddressPort" dap ON dap."deviceAddress" = da.id JOIN "Connection" c on c."serverDeviceAddressPort" = dap.id GROUP BY 1 ORDER BY  1 ASC) AS derived`)).rows[0].count
    let offsetServer= 0
    while(offsetServer <= serverCount){
        const servers = (await connection.query(
            `select d.id,count(*) FROM "Device" d JOIN "DeviceAddress" da ON da.device = d.id JOIN "DeviceAddressPort" dap ON dap."deviceAddress" = da.id JOIN "Connection" c on c."serverDeviceAddressPort" = dap.id GROUP BY 1 ORDER BY  1 ASC LIMIT ${bulkSize} offset ${offsetServer}`,
        )).rows
        let incomingConnectionCount = []
        if (servers.length > 0) {
            let i = 0
            for (let server of servers) {
                incomingConnectionCount.push(`(${server.count},${server.id})`)
                showCount('Update Server Connection Counts', i, servers.length)
                i++
            }
            showCount('Update Server Connection Counts', i, servers.length)
            await connection.query(`UPDATE "Device" as t SET "incomingConnectionCount"=c.incomingConnectionCount from (values ${incomingConnectionCount.join(',')} ) as c(incomingConnectionCount, id) WHERE c.id=t.id`)
        }
        offsetServer= offsetServer + bulkSize
    }

    console.log('Adding software version tags...')
    let versionCount = Math.floor(Math.random() * 100)
    for (let j = 0; j < versionCount; ++j) {
    // Add random version tags
        var randomVersion = pickOne(pickOne(allSoftwareVersions))
        insertSoftwareVersionTag(randomVersion)
        showCount('SoftwareVersionTag', j + 1, versionCount)
    }

    await bulkInsertRecords('SoftwareVersionTag', softwareVersionTagArray, session)
    softwareVersionTagArray =[]

    console.log('Adding connection tags...')
    let connectionCount = Math.floor(Math.random() * 100)
    for (let j = 0; j < connectionCount; ++j) {
    // Add random version tags
        let randomConnection = pickOne(allConnections)
        insertConnectionTag(randomConnection)
        showCount('ConnectionTag', j + 1, connectionCount)
    }

    await bulkInsertRecords('ConnectionTag', connectionsTags, session)
    connectionsTags = []

    console.log('Calculating crypto scores...')
    let j = 0
    let promises = []
    for (let connection of allConnections) {
        promises.push(updateCryptoScoresForConnection(connection.id))
        if (promises.length >= 10) {
            await Promise.allSettled(promises)
            promises = []
        }

        showCount('Connection Score', ++j, allConnections.length)
    }

    await Promise.allSettled(promises)
    promises = []

    j = 0
    for (let device of allDevices) {
        promises.push(updateCryptoScoresForDevice(device.id))
        if (promises.length >= 10) {
            await Promise.allSettled(promises)
            promises = []
        }

        showCount('Device Score', ++j, allDevices.length)
    }

    await Promise.allSettled(promises)

    await rebuildAllFlatFacetTables(true)
    dumpObjectTimingStats(true)
    await connection.end()
    let endTime = new Date()
    log.log(`Run Time in milliseconds ${endTime.getTime()-startTime.getTime()}`)
}

function showCount(title, number, total) {
    var lastPercentage = showCount.last[title]
    var percentage = Math.round(number / total * 1000) / 10
    if (lastPercentage === undefined || (percentage === 100 && lastPercentage != 100) || (percentage - lastPercentage > 1)) {
        log.log(`${title}: Created ${number} of ${total} (${percentage}%)`)
        showCount.last[title] = percentage
    }
}
showCount.last = {}

main().then(() => {
    log.log('Done!')
}).catch(e => {
    log.e('Sad now. :(', e)
    process.exit(1)
})
