/**
 * @file dbHelpers.js - 1.2.0 - 3826bc12533e078a8e37cfe70ee04d9e85c8530e
 * 
 * @copyright Copyright (C) 2016-2023, ISARA Corporation, All Rights Reserved.
 * 
 * @license The code and other content set out herein is not in the public
 * domain, is considered a trade secret and is confidential to ISARA
 * Corporation. Use, reproduction or distribution, in whole or in part, of such
 * code or other content is strictly prohibited except by express written
 * permission of ISARA Corporation. Please contact ISARA Corporation at
 * info@isara.com for more information.
 */

const { Session } = require('../isaraql/session')

var log = require('../util/log')(module)


var connection = null

let currentObjectTimings = {}
let currentStartTime = new Date()
let totalObjectTimings = {}
let totalStartTime = new Date()

function dumpObjectTimingStats(all) {
    let timings = (all) ? totalObjectTimings : currentObjectTimings
    log.log('------------------------------------------------------------')
    for (var key of Object.keys(timings).sort()) {
        let obj = timings[key]
        log.log(`${key}: Count: ${obj.count}, total time: ${obj.totalTime}, min: ${obj.min}, max: ${obj.max}, `
            + `avg: ${obj.totalTime / obj.count}`)
    }

    let startTime = all ? totalStartTime : currentStartTime
    log.log('------------------------------------------------------------')
    log.log(`Elapsed time for ${all ? 'total' : 'current'} stats: ${Math.abs(new Date() - startTime)} msec.`)
    log.log('------------------------------------------------------------')
}

function resetObjectTimingStats(all) {
    if (all) {
        totalObjectTimings = {}
        totalStartTime = new Date()
    } else {
        currentObjectTimings = {}
        currentStartTime = new Date()
    }
}

function addTimingInfo(timings, table, timeSpent) {
    if (!(table in timings)) {
        timings[table] = {
            totalTime: 0,
            min: Number.MAX_SAFE_INTEGER,
            max: 0,
            count: 0
        }
    }

    var timingInfo = timings[table]
    timingInfo.totalTime += timeSpent
    timingInfo.count++
    if (timingInfo.max < timeSpent) {
        timingInfo.max = timeSpent
    }
    if (timingInfo.min > timeSpent) {
        timingInfo.min = timeSpent
    }
}

async function insertObject(value) {
    var questions = value.names.map(() => '?').join(',')
    let names = value.names.map(x => `"${x}"`)
    var query = `insert into "${value.table}"`
    if (names.length > 0) {
        query += `(${names}) values(${questions}) `
    } else {
        query += ' DEFAULT VALUES '
    }
    query += ' RETURNING id'
    let index = 1
    query = query.replace(/\?/g, () => `$${index++}`)
    var start = new Date()
    var result = await connection.query(query, value.values)
    var timeSpent = Math.abs(new Date() - start)
    for (var timing of [currentObjectTimings, totalObjectTimings]) {
        addTimingInfo(timing, value.table, timeSpent)
    }
    value.id = result.rows[0].id
    return result
}

async function bulkInsertRecords(table, values, session, isDefault) {
    if (!session) {
        session = new Session()
    }
    let insertColumns = []
    let insertParams = []

    if (!Array.isArray(values)) {
        values = [values]
    }

    if (values.length === 0) {
        throw `No values provided for upsertRecord into ${table}`
    }

    for (let column in values[0]) {
        insertColumns.push(column)
    }

    let keys = []
    for (let record of values) {
        for (let column of insertColumns) {
            const toPush = record[column]
            if (toPush === undefined) {
                insertParams.push(null)
            } else {
                insertParams.push(toPush)
                keys.push(`"${column}"`)
            }
        }
    }

    let questionMarks = `(${Array(insertColumns.length).fill('?').join(',')})`
    let allQuestionMarks = Array(values.length).fill(questionMarks).join(',')

    let insertStatement
    if(isDefault){
        let defaultStr = []
        for(let val of values){
            log.d(val)
            defaultStr.push('(default)')
        }
        insertStatement = `insert into "${table}" VALUES ${defaultStr.join(',')} ON CONFLICT DO NOTHING RETURNING id`
    }
    else{
        insertStatement = `insert into "${table}" ("${insertColumns.join('","')}") values ${allQuestionMarks} ON CONFLICT DO NOTHING RETURNING id, "${insertColumns.join('","')}";`
    }
    let result = isDefault ? await session.query(insertStatement) : await session.query(insertStatement, [...insertParams])
    log.d('Result', result)
    return {
        affectedRows: result.rowCount,
        id: result.rows[0].id,
        rows: result.rows
    }
}



async function initDbConnection(session) {
    if(session){
        connection = session;
        return session
    }
    if (!connection) {
        connection = await require('../isaraql/dbPool').getPool()
        if (connection === null) {
            throw 'Could not create connection!'
        }
    }

    return connection
}

exports.dumpObjectTimingStats = dumpObjectTimingStats
exports.initDbConnection = initDbConnection
exports.insertObject = insertObject
exports.bulkInsertRecords = bulkInsertRecords
exports.resetObjectTimingStats = resetObjectTimingStats
