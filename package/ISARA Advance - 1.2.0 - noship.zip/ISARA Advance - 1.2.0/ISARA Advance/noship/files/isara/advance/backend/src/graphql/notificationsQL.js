/**
 * @file notificationsQL.js - 1.2.0 - 3826bc12533e078a8e37cfe70ee04d9e85c8530e
 * 
 * @copyright Copyright (C) 2016-2023, ISARA Corporation, All Rights Reserved.
 * 
 * @license The code and other content set out herein is not in the public
 * domain, is considered a trade secret and is confidential to ISARA
 * Corporation. Use, reproduction or distribution, in whole or in part, of such
 * code or other content is strictly prohibited except by express written
 * permission of ISARA Corporation. Please contact ISARA Corporation at
 * info@isara.com for more information.
 */

/**
 * This module contains Notification related queries.
 * @module graphql/notificationsQL
 */

const {
    Session
} = require('../isaraql/session')
var {
    fetchForColumns, store, insertRecord, fetchWanted
} = require('../isaraql/fetch')

var {
    roles
} = require('./commonQL')

var {
    dateTimeComparisonToWhere
} = require('../isaraql/whereUtil')

var { allTypes } = require('../isaraql/schemaDiscovery')

var { buildTableWhereEquals } = require('../isaraql/whereUtil')

var { graphQLStateToWanted } = require('../isaraql/wantedUtil')

function buildNotificationWPCS(fields) {
    var wpcs = {
        Notification: { where: { and: [] }, sort: ['addedAt desc'] },
        NotificationAction: { where: { and: [] } }
    }

    var fieldsWhere = fields['where']
    if (fieldsWhere) {
        if (fieldsWhere.type) {
            wpcs['Notification'].where.and.push({ equals: { column: 'type', value: fieldsWhere.type } })
        }
        if (fieldsWhere.actionedAt) {
            wpcs['Notification'].join = { type: 'inner', column: 'notificationActions' }
            wpcs['NotificationAction'].where.and.push(dateTimeComparisonToWhere('actionedAt', fieldsWhere.actionedAt))
        }
        if (fieldsWhere.ids && fieldsWhere.ids.length > 0) {
            wpcs['Notification'].where.and.push({ in: { column: 'id', value: fieldsWhere.ids } })
        }
    }

    return wpcs
}

/**
 * @param {Object} fields Unused
 * @param {Object} request Unused
 * @param {Object} graphQLState GraphQL state holding selected fields.
 */
async function allNotificationsTEMP(fields, request, graphQLState) {
    var wanted = graphQLStateToWanted(graphQLState)
    var toReturn = await fetchWanted('Notification', wanted.allNotificationsTEMP)
    return toReturn
}

/**
 * Find unread notification ids for the implicit user.
 * @param {Object} fields GraphQL query parameters.
 * @param {Object} request Used to find current user.
 * @param {int} request.user.uid The current user's id.
 * @param {Session} session Database session.
 * @returns {number[]} Array of notification IDs.
 */
async function findUnreadNotifications(fields, request, session) {
    if (fields.where.ids) {
        throw 'Cannot double filter by ID'
    }
    var params = [request.user.uid]
    var typeClause = ''
    if (fields.where.type) {
        typeClause = ' and N.type = ? '
        params.push(allTypes['NotificationType']._enum.idByName[fields.where.type])
    }
    var pagingClause = ''
    if (fields.paging) {
        pagingClause = ' limit ? OFFSET ? '
        params.push(fields.paging.limit)
        params.push(fields.paging.offset)
    }
    var select = `select distinct N.id as id, N."addedAt"
                    from "Notification" N
                    left outer join "NotificationAction" NA on
                        N.id = NA.notification and
                        NA.user = ?
                    where
                        NA.user is null
                        ${typeClause}
                    order by N."addedAt" desc
                        ${pagingClause}`
    var unreadIDs = await session.query(select, params)
    return unreadIDs.rows.map(row => row.id)
}

/**
 * Query to expose notifications.
 * @param {*} fields
 * @param {*} request
 * @param {*} graphQLState
 * @param {Session} session optional session (used by mutation)
 */
async function notificationsQuery(fields, request, graphQLState, session) {
    if (!session) {
        session = new Session()
    }

    if (fields.where && fields.where.actionedAt === null) {
        fields.where.ids = await findUnreadNotifications(fields, request, session)
    }

    var wpcs = buildNotificationWPCS(fields)

    var wanted = graphQLStateToWanted(graphQLState)

    if (wanted.markNotificationsAsActioned) {
        // Copy wanted from the mutation.
        wanted.notifications = wanted.markNotificationsAsActioned
    }
    if (!wanted.notifications.notifications) {
        wanted.notifications.notifications = { id: true }
    }

    wpcs['NotificationAction'].where.and.push({ equals: { column: 'user', value: request.user.uid } })

    if (fields.paging) {
        wpcs['Notification'].paging = fields.paging
    }

    if (wanted.notifications.paging) {
        wpcs['Notification'].count = true
    }

    var notifications = await fetchWanted('Notification', wanted.notifications.notifications, wpcs, session)

    var toReturn = { notifications }
    if (wanted.notifications.paging) {
        toReturn.paging = { count: wpcs['Notification'].count[0] }
    }
    return toReturn
}

async function markNotificationsAsActionedMutation(fields, request, response) {
    var wpcs = buildNotificationWPCS(fields)
    var session = new Session()
    return await session.asTransaction(async () => {
        var matching = await fetchForColumns('Notification', ['id'], wpcs, session)
        var now = new Date()
        for (var match of matching) {
            var key = { user: request.user.uid, notification: match.id }
            var update = { actionedAt: now }
            await store('NotificationAction', key, update, session)
        }
        return await notificationsQuery(fields, request, response, session)
    })
}

/**
 * Attempt to insert a new notification.
 * @param {object} fields
 * @param {String} fields.type A NotificationType.
 * @param {String} fields.title A title for the new notification.
 * @param {String} fields.description A description for the new notification.
 * @param {String} [fields.url] An optional URL for the notification.
 * @param {object} request GraphQL request
 * @param {object} graphQLState GraphQL state
 * @param {Session} [session] Database session
 */
async function createNotificationMutation(fields, request, graphQLState, session) {
    var newNotification = {
        type: allTypes['NotificationType']._enum.idByName[fields.type],
        title: fields.title,
        description: fields.description,
        url: fields.url,
        addedAt: new Date(),
        originatedBy: request.user.uid
    }

    var result = await insertRecord('Notification', newNotification, session)
    var id = result.id

    var wpcs = buildTableWhereEquals('Notification', { id })

    var wanted = graphQLStateToWanted(graphQLState).createNotificationTEMP

    var toReturn = await fetchWanted('Notification', wanted, wpcs, session)

    return toReturn[0]
}

exports.graphQL = {
    types: `
        input NotificationWhere {
            ids: [BigInt!]
            type: NotificationType
            actionedAt: DateTimeComparison
        }

        type PagedNotifications {
            paging: Paging
            notifications: [Notification!]!
        }
    `,
    queries: `
        allNotificationsTEMP : [Notification]!

        notifications(
            where: NotificationWhere
            paging: PagingInput
        ): PagedNotifications!
    `,
    mutations: `
        markNotificationsAsActioned(paging: PagingInput, where: NotificationWhere): PagedNotifications
        createNotificationTEMP(type: NotificationType!, title: String!, description: String!, url: String) : Notification
    `,
    root: {
        allNotificationsTEMP,
        notifications: notificationsQuery,
        markNotificationsAsActioned: markNotificationsAsActionedMutation,
        createNotificationTEMP: createNotificationMutation,
    },
    restrictions: {
        allNotificationsTEMP: [roles.ADMIN],
        notifications: [roles.AUTHENTICATED],
        markNotificationsAsActioned: [roles.AUTHENTICATED],
        createNotificationTEMP: [roles.AUTHENTICATED]
    }
}
