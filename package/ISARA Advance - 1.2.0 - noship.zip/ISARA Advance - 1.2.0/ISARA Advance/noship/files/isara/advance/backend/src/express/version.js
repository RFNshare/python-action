/**
 * @file version.js - 1.2.0 - 3826bc12533e078a8e37cfe70ee04d9e85c8530e
 * 
 * @copyright Copyright (C) 2016-2023, ISARA Corporation, All Rights Reserved.
 * 
 * @license The code and other content set out herein is not in the public
 * domain, is considered a trade secret and is confidential to ISARA
 * Corporation. Use, reproduction or distribution, in whole or in part, of such
 * code or other content is strictly prohibited except by express written
 * permission of ISARA Corporation. Please contact ISARA Corporation at
 * info@isara.com for more information.
 */

/**
 * This module defines a simple version API.
 */

exports.endpoint = {
    path: '/service/version',
    get: {
        handler: async function (request, response) {
            response.setHeader('Content-type', 'application/json')
            response.send(JSON.stringify({ timeStamp: '2023-02-13T21:15:22.411Z', version: '1.2.0', gitVersion: '3826bc12533e078a8e37cfe70ee04d9e85c8530e' }))
            response.status(200).end()
        }
    }
}

/**
 * The version check is bypassing security and logging wrappers. 
 */
exports.bypassWrappers = true
