/**
 * @file softwareQL.js - 1.2.0 - 3826bc12533e078a8e37cfe70ee04d9e85c8530e
 * 
 * @copyright Copyright (C) 2016-2023, ISARA Corporation, All Rights Reserved.
 * 
 * @license The code and other content set out herein is not in the public
 * domain, is considered a trade secret and is confidential to ISARA
 * Corporation. Use, reproduction or distribution, in whole or in part, of such
 * code or other content is strictly prohibited except by express written
 * permission of ISARA Corporation. Please contact ISARA Corporation at
 * info@isara.com for more information.
 */

/**
 * This module contains software focused queries.
 * @module graphql/softwareQL
 */

var {
    getSort, roles, postureModifiableTables, postureCheckExistingTables, populateAddedBy,
    updateTagUsedDate
} = require('./commonQL')

var {
    postureCategories
} = require('./categoryConstants')

const { paths, allTypes } = require('../isaraql/schemaDiscovery')
const { filterQuery } = require('./filterQL')
const { AdvancedSort, generatePlaceholders, fetchWanted } = require('../isaraql/fetch')
const { createUpdateDelete, registerHook, CUD_OP_INSERT, CUD_OP_UPDATE, CUD_OP_PRE } = require('../isaraql/cud')
const { getCptForRequest } = require('../util/cptHelpers')

var {
    makeFilterCategories
} = require('../util/filterCategoryHelpers')
const { getRequestState } = require('../util/requestState')

async function softwareQuery(fields, request, graphQLState) {
    fields.filter = `softwareid=${fields.id}`
    return await softwareFilterQuery(fields, request, graphQLState)
}


/**
 * Main query to see softwares.
 * @param {Object} fields Fields from GraphQL Query
 * @param {string} [fields.asOf] When the data should be reported on. If not provided the counts will be as of now.
 * @param {Object} request GraphQL request
 * @param {Object} graphQLState GraphQL State
 * @param {number[]} [ids] Set of IDs to run query for (instead of filter)
 */
async function softwareFilterQuery(fields, request, graphQLState, ids) {
    if (!('paging' in fields)) {
        fields.paging = { offset: 0n, limit: 5n }
    }
    if (!('deviceSoftwarePaging' in fields)) {
        fields.deviceSoftwarePaging = { offset: 0n, limit: 5n }
    }

    var wpcs = {
        Software: {
            where:
                {
                    and: [
                        {
                            ne: {
                                column: 'softwareType',
                                value: 'DATA'
                            }
                        }
                    ]
                }
        },
        SoftwareVersion: {
            join: {
                type: 'inner',
                column: 'software'
            },
            paging: fields.paging
        },
        DeviceSoftware: { paging: fields.deviceSoftwarePaging },
    }

    if (ids && ids.length > 0) {
        wpcs.SoftwareVersion.where = { in: { column: 'id', value: ids } }
    }
    if ('sorting' in fields) {
        wpcs.SoftwareVersion.sort = await getSort(sortDictionary, fields.sorting)
    }

    return filterQuery('SoftwareVersion', 'softwareVersions', fields.filter, graphQLState, wpcs, fields.asOf, fields.cryptoPostureTemplate, makeMetaAndSoftwareSummaries)
}

async function makeMetaAndSoftwareSummaries(graphQLResult, wanted, session) {

    let activeCpt = await getCptForRequest()

    if (wanted.meta) {
        await makeSoftwareMeta(graphQLResult, wanted, session)
    }

    if (wanted.softwareSummaries) {
        await makeSoftwareSummaries(graphQLResult, wanted, session)
    }

    if (wanted.filterCategories) {
        await makeFilterCategories(graphQLResult, postureCategories.SOFTWARE, wanted, session, activeCpt)
    }
}

async function makeSoftwareMeta(graphQLResult, wanted, session) {
    let state = getRequestState()
    let filterTable = state.filterTable

    let query = `SELECT st.name AS name, count(*) AS count FROM "SoftwareVersion" sv
    Join "Software" s ON sv."software" = s."id" JOIN "SoftwareType" st ON s."softwareType" = st.id `
    if (filterTable !== undefined) {
        query += `WHERE sv.id IN (SELECT id FROM "${filterTable.table}") `
    }
    query += ' GROUP BY 1 ORDER BY 1'
    let results = await session.query(query)
    graphQLResult.meta = []
    for (let result of results.rows) {
        graphQLResult.meta.push({
            key: result.name,
            value: result.count,
            name: result.name // TODO: GAP1598 - this needs to pull a human friendly name, probably in a way that can eventually be i18n'd.
        })
    }
}

async function pathsToCounts(softwareIDs, cryptoCategoryName, targetTable, table, paths, session) {
    let additionalCondition
    if (cryptoCategoryName) {
        additionalCondition = ` and "${table}"."cryptoScoreCoarse" = ${allTypes['CryptoScoreCoarse']._enum.idByName[cryptoCategoryName]}`
    } else {
        additionalCondition = ''
    }
    var Paths = paths.map(path => ` (select "SoftwareVersion".id as id, "${targetTable}".id as thingtocount ${path} where "SoftwareVersion".id in (${generatePlaceholders(softwareIDs)}) ${additionalCondition}) `)
    var joinedPaths = Paths.join(' UNION ')
    var params = softwareIDs
    var query = `select id as id , count(distinct thingtocount) as count from (${joinedPaths}) IgnoredName group by id`
    var result = await session.query(query, params)
    return result.rows
}

var thingsToCount = [{ wantedName: 'deviceCount', table: 'Device' },
    { wantedName: 'softwareOS' },
    { wantedName: 'connectionCountTotal', table: 'Connection' },
    { wantedName: 'connectionCountPending', table: 'CryptoScore', include: 'Connection', cryptoCategoryName: 'PENDING' },
    { wantedName: 'connectionCountUnacceptable', table: 'CryptoScore', include: 'Connection', cryptoCategoryName: 'UNACCEPTABLE' },
    { wantedName: 'connectionCountCaution', table: 'CryptoScore', include: 'Connection', cryptoCategoryName: 'CAUTION' },
    { wantedName: 'connectionCountStrongClassic', table: 'CryptoScore', include: 'Connection', cryptoCategoryName: 'STRONG_CLASSIC' },
    { wantedName: 'connectionCountStrongQSC', table: 'CryptoScore', include: 'Connection', cryptoCategoryName: 'STRONG_QSC' }
]

async function makeSoftwareSummaries(graphQLResult, wanted, session) {
    graphQLResult.softwareSummaries = []

    if (graphQLResult.softwareVersions.length === 0) {
        return
    }

    var softwareversionIDs = []
    var resultsBySoftwareID = {}
    var softwareSummary = graphQLResult.softwareSummaries
    graphQLResult.softwareVersions.forEach(softwareversion => {
        softwareversionIDs.push(softwareversion.id)
        var resultForSoftwareVersionID = {
            id: softwareversion.id,
            deviceCount: 0,
            connectionCountTotal: 0,
            connectionCountPending: 0,
            connectionCountUnacceptable: 0,
            connectionCountCaution: 0,
            connectionCountStrongClassic: 0,
            connectionCountStrongQSC: 0,
            softwareOS: ''
        }
        resultsBySoftwareID[softwareversion.id] = resultForSoftwareVersionID
        softwareSummary.push(resultForSoftwareVersionID)
    })

    for (var thingToCount of thingsToCount) {
        // Finds the OS each software running on
        if ([thingToCount.wantedName] == 'softwareOS' && softwareversionIDs.length) {
            var results = (await session.query(`
                SELECT "versionID", osname FROM
                    (
                        SELECT
                            sv.id AS "versionID",
                            sv.name,
                            ds.device AS "deviceID"
                        FROM "SoftwareVersion" sv
                        JOIN "DeviceSoftware" ds ON sv.id = ds."softwareVersion"
                    ) deviceSoftwareVersionTable
                JOIN
                    (
                        SELECT
                            softwareID,
                            softwareVersionID,
                            OSName,
                            ds.device AS "deviceID"
                        FROM
                        (
                            SELECT
                                osSoftwareTable.id AS softwareID,
                                sv.id AS softwareVersionID,
                                sv.name AS OSName
                            FROM
                            (
                                SELECT * FROM "Software" WHERE "softwareType" = ${allTypes['SoftwareType']._enum.idByName['OS']}
                            ) osSoftwareTable
                            JOIN "SoftwareVersion" sv ON osSoftwareTable.id = sv.software
                        ) osSoftwareVersionTable
                        JOIN "DeviceSoftware" ds ON osSoftwareVersionTable.softwareVersionID = ds."softwareVersion"
                    ) osDevices
                ON deviceSoftwareVersionTable."deviceID" = osDevices."deviceID"
                WHERE "versionID" in (${generatePlaceholders(softwareversionIDs)})
                GROUP BY "versionID", osname
                ORDER BY "versionID"`,
            softwareversionIDs)).rows

            results.forEach(result =>
                resultsBySoftwareID[(result.versionID)] != undefined ? resultsBySoftwareID[result.versionID].softwareOS +=
                    resultsBySoftwareID[result.versionID].softwareOS ? ', ' + result.osname :
                        result.osname : ''
            )
        } else {
            var countingPaths = paths({ from: 'SoftwareVersion', to: thingToCount.table })
            countingPaths = countingPaths.filter(path =>
                !(path.includes('Tag')) &&
                !(path.includes('User')) &&
                !(path.includes('CryptoPrimitive')) &&
                !(path.includes('Certificate')) &&
                !(path.includes('DeviceAddressPort')) &&
                !(path.includes('CipherSuite'))
            )
            if (thingToCount.cryptoCategoryName) {
                countingPaths = countingPaths.filter(path =>
                    (path.includes(thingToCount.include)) &&
                    !(path.includes('ProtocolVariant'))
                )
            }
            var tableName = thingToCount.include ? thingToCount.include : thingToCount.table
            results = await pathsToCounts(softwareversionIDs, thingToCount.cryptoCategoryName, tableName, thingToCount.table, countingPaths, session)
            results.forEach(result =>
                resultsBySoftwareID[result.id][thingToCount.wantedName] = result.count
            )
        }
    }
}

const checkExistingTables = (() => {
    var result = Object.assign({}, postureCheckExistingTables)
    result.Software = true
    result.SoftwareVersion = true
    return result
})()

const deletableTables = (() => {
    var result = Object.assign({}, postureModifiableTables)
    // Preventing Device and Connection deletion from Software.
    delete result.Device
    delete result.Connection

    // Preventing Tag deletion as the Tag records are shared.
    delete result.Tag

    result.Agent = true
    result.AgentCertificate = true

    return result
})()

/**
 * Mutation for creating/updating/deleting Softwares and their attributes.
 * @param {Object} fields
 * @param {Object} request
 * @param {Object} graphQLState
 */
async function softwareUpdateMutation(fields, request, graphQLState) {
    var softwareVersions = fields.softwares

    for (let softwareVersion of softwareVersions) {
        if (softwareVersion.software === undefined) {
            continue
        }
        // step 1: prevent either adding new instances or editing existing instances of data types directly.
        if (softwareVersion.software.softwareType === 'DATA') {
            throw 'Ingestion software types may not be modified.'
        } else if (softwareVersion.software.id) {
            // step 2: Ensure that edits of existing software aren't attempting to touch an already existing DATA entry
            // e.g. turning it into a different type.
            let wanted = {
                id: true,
                softwareType: true
            }
            let result = await fetchWanted('Software', wanted, [{
                Software: {
                    where: {
                        equals: { column: 'id', value: softwareVersion.software.id }
                    }
                }
            }])
            if (result.length != 0) {
                if (result[0].softwareType === 'DATA') {
                    throw 'Ingestion software types may not be modified.'
                }
            }
        }
    }
    var config = {
        allowDelete: true,
        allowInsert: true,
        allowUpdate: true,
        checkExistingTables,
        deletableTables,
        modifiableTables: postureModifiableTables
    }
    var ids = await createUpdateDelete('SoftwareVersion', softwareVersions, config)
    return await softwareFilterQuery(fields, request, graphQLState, ids)
}

/**
+ * This dictionary will hold the SQL fragments needed by `fetch.js` to build a table spanning sort query.
 */
const sortDictionary = {}

/**
 * Builds the sorting dictionary showing `fetch` how to sort for named parameters.
 */
function buildSortDictionary() {
    var commonTagSortJoins = `
    left join
        "SoftwareVersion" on "SoftwareVersion".software = Software.id
    left join
        "SoftwareVersionTag" on "SoftwareVersionTag"."softwareVersion" = "SoftwareVersion".id
    left join
        "Tag" on "Tag".id = "SoftwareVersionTag".tag and "Tag"."tagType" = ?`

    var commonTagSortOrderBys = `min("Tag".value) %DIR%`

    var tagTypes = allTypes.TagType._enum

    /* Software has no sortable tags.  But we have this here just in case some
     * get added for software later.
     */
    for (var name of tagTypes.names) {
        sortDictionary[name] = new AdvancedSort(commonTagSortJoins,
            `"SoftwareVersion".id`,
            commonTagSortOrderBys,
            tagTypes.idByName[name]
        )
    }

    // All the simple sorts that use a field which exists ON the Software table.
    sortDictionary['NAME'] = `LOWER("SoftwareVersion"."name") %DIR%`
    sortDictionary['VERSION'] = `version %DIR%`
    sortDictionary['HASH'] = `binaryHash %DIR%`

    // Special sort for VENDOR
    var vendorSortJoin = `
    LEFT JOIN "Software" "SortSoftware" ON "SortSoftware"."id" = "SoftwareVersion"."software"`
    sortDictionary['VENDOR'] = new AdvancedSort(vendorSortJoin,
        [`"SoftwareVersion".id`, `"SortSoftware"."softwareVendor"`],
        `"SortSoftware"."softwareVendor" %DIR%`,
        null
    )

    // Special sort for ADDED_DATE
    var addedDateSortJoin = `
    LEFT JOIN "Software" "SortSoftware" ON "SortSoftware"."id" = "SoftwareVersion"."software"`
    sortDictionary['ADDED_DATE'] = new AdvancedSort(addedDateSortJoin,
        [`"SoftwareVersion".id`, `"SortSoftware"."addedAt"`],
        `"SortSoftware"."addedAt" %DIR%`,
        null
    )


    // Special sort for TYPE...it has a join.
    var typeSortJoin = `
    LEFT JOIN "Software" "SortSoftware" ON "SortSoftware"."id" = "SoftwareVersion"."software"
    left join
        "SoftwareType" on "SoftwareType".id = "SortSoftware"."softwareType"`
    sortDictionary['TYPE'] = new AdvancedSort(typeSortJoin,
        [`"SoftwareVersion".id`, `"SoftwareType".name`],
        `"SoftwareType".name %DIR%`,
        null
    )

    // Special sort for DEVICE
    var deviceSortJoin = `
        LEFT JOIN "DeviceSoftware" ON "DeviceSoftware"."softwareVersion" = "SoftwareVersion".id
        LEFT JOIN "Device" ON "Device".id = "DeviceSoftware"."device"`
    sortDictionary['DEVICE_COUNT'] = new AdvancedSort(deviceSortJoin,
        [`"SoftwareVersion".id`],
        `count(distinct"Device".id) %DIR%`,
        null
    )

    // Special sort for CONNECTION
    var connectionSortJoin = `
        LEFT JOIN "DeviceSoftware" ON "DeviceSoftware"."softwareVersion" = "SoftwareVersion".id
        LEFT JOIN "DeviceSoftwareConnection" ON "DeviceSoftwareConnection"."deviceSoftware" = "DeviceSoftware"."id"
        LEFT JOIN "Connection" ON "Connection".id = "DeviceSoftwareConnection"."connection"
        `
    sortDictionary['CONNECTION_COUNT_TOTAL'] = new AdvancedSort(connectionSortJoin,
        [`"SoftwareVersion".id`],
        `count(distinct"Connection".id) %DIR%`,
        null
    )


    // Special sort for CONNECTION COUNTS BY CRYPTO COARSE CATEGORY
    var countByCategorySortJoin = `
        LEFT JOIN (SELECT sv.id, count(distinct c.id) AS count FROM "SoftwareVersion" sv JOIN "DeviceSoftware" ds ON sv."id" = ds."softwareVersion" JOIN "DeviceSoftwareConnection" dsc on dsc."deviceSoftware" = ds.id JOIN "Connection" c on dsc.connection = c.id  JOIN "CryptoScore" cs on c."cryptoScore" = cs.id WHERE cs."cryptoScoreCoarse" = ? GROUP BY 1) t1 ON t1.id = "SoftwareVersion".id
    `
    sortDictionary['CONNECTION_COUNT_UNACCEPTABLE'] = new AdvancedSort(countByCategorySortJoin,
        [`"SoftwareVersion".id`, `"t1".count`],
        `coalesce("t1".count, 0) %DIR%`,
        [allTypes['CryptoScoreCoarse']._enum.idByName['UNACCEPTABLE']]
    )
    sortDictionary['CONNECTION_COUNT_CAUTION'] = new AdvancedSort(countByCategorySortJoin,
        [`"SoftwareVersion".id`, `"t1".count`],
        `coalesce("t1".count, 0) %DIR%`,
        [allTypes['CryptoScoreCoarse']._enum.idByName['CAUTION']]
    )
    sortDictionary['CONNECTION_COUNT_STRONG_CLASSIC'] = new AdvancedSort(countByCategorySortJoin,
        [`"SoftwareVersion".id`, `"t1".count`],
        `coalesce("t1".count, 0) %DIR%`,
        [allTypes['CryptoScoreCoarse']._enum.idByName['STRONG_CLASSIC']]
    )
    sortDictionary['CONNECTION_COUNT_STRONG_QSC'] = new AdvancedSort(countByCategorySortJoin,
        [`"SoftwareVersion".id`, `"t1".count`],
        `coalesce("t1".count, 0) %DIR%`,
        [allTypes['CryptoScoreCoarse']._enum.idByName['STRONG_QSC']]
    )
}

function initialise() {
    registerHook('Software', CUD_OP_INSERT, CUD_OP_PRE, preInsertUpdateSoftware)
    registerHook('Software', CUD_OP_UPDATE, CUD_OP_PRE, preInsertUpdateSoftware)
    registerHook('SoftwareVersion', CUD_OP_INSERT, CUD_OP_PRE, preInsertSoftwareVersion)
    registerHook('SoftwareVersionTag', CUD_OP_INSERT, CUD_OP_PRE, preWriteSoftwareVersionTag)
    registerHook('SoftwareVersionTag', CUD_OP_UPDATE, CUD_OP_PRE, preWriteSoftwareVersionTag)
    buildSortDictionary()
}

/**
 * This function will be called before a new Software is inserted.
 * @param {CUDHook} params
 */
async function preInsertUpdateSoftware(params) {
    if (!('softwareVendor' in params.record)) {
        params.record.softwareVendor = ''
    }
    populateAddedBy(params)
}

async function preInsertSoftwareVersion(params) {
    if (!params.record.name && params.record.software && params.record.version) {
        let nameLookup = await params.session.query(
            `select name from "Software" where id = ?`,
            [params.record.software])
        if (nameLookup.rows.length > 0) {
            params.record.name = `${nameLookup.rows[0].name} ${params.record.version}`
        }
    }
}

async function preWriteSoftwareVersionTag(params) {
    await updateTagUsedDate(params)
}

exports.graphQL = {
    types: `
        enum SortableSoftwareFields {
            ADDED_DATE
            NAME
            TYPE
            VENDOR
            VERSION
            HASH
            DEVICE_COUNT
            CONNECTION_COUNT_TOTAL
            CONNECTION_COUNT_UNACCEPTABLE
            CONNECTION_COUNT_PENDING
            CONNECTION_COUNT_CAUTION
            CONNECTION_COUNT_STRONG_CLASSIC
            CONNECTION_COUNT_STRONG_QSC
        }

        input SoftwareSortingInput {
            field: SortableSoftwareFields!,
            direction: SortDirection!,
        }

        type SoftwareSummary {
            id: BigInt!
            deviceCount: BigInt!
            softwareOS: String
            connectionCountTotal: BigInt!
            connectionCountPending: BigInt!
            connectionCountUnacceptable: BigInt!
            connectionCountCaution: BigInt!
            connectionCountStrongClassic: BigInt!
            connectionCountStrongQSC: BigInt!
        }

        type FilteredSoftwares {
            paging: Paging!
            softwareVersions: [SoftwareVersion!]!
            softwareSummaries: [SoftwareSummary!]!
            filterCategories: [FilterCategory!]!
            meta: [MetaTag!]!
        }
    `,
    queries: `
        softwareById(
            id: BigInt!
            deviceSoftwareConnectionPaging: PagingInput
            deviceSoftwarePaging: PagingInput
            cryptoPostureTemplate: BigInt
        ): FilteredSoftwares!

        filteredSoftwares(
            filter: String
            paging: PagingInput
            sorting: SoftwareSortingInput
            deviceSoftwarePaging: PagingInput
            asOf: DateTime
            cryptoPostureTemplate: BigInt
        ) : FilteredSoftwares!
    `,
    mutations: `
        softwareUpdate(
            softwares: [SoftwareVersionInput!]!
        ) : FilteredSoftwares!
    `,
    root: {
        softwareById: softwareQuery,
        filteredSoftwares: softwareFilterQuery,
        softwareUpdate: softwareUpdateMutation,
    },
    restrictions: {
        softwareById: [roles.AUTHENTICATED],
        filteredSoftwares: [roles.AUTHENTICATED],
        softwareUpdate: [roles.AUTHENTICATED],
    },
    initialise
}
