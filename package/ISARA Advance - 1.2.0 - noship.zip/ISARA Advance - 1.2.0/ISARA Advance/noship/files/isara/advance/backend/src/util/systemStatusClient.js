/**
 * @file systemStatusClient.js - 1.2.0 - 3826bc12533e078a8e37cfe70ee04d9e85c8530e
 * 
 * @copyright Copyright (C) 2016-2023, ISARA Corporation, All Rights Reserved.
 * 
 * @license The code and other content set out herein is not in the public
 * domain, is considered a trade secret and is confidential to ISARA
 * Corporation. Use, reproduction or distribution, in whole or in part, of such
 * code or other content is strictly prohibited except by express written
 * permission of ISARA Corporation. Please contact ISARA Corporation at
 * info@isara.com for more information.
 */

const { WebSocket } = require('ws')
const { loadCACertificates } = require('../util/certificates')
const { EventEmitter } = require('events')
const { sleep } = require('./sleep')
const log = require('./log')(module)

const INITIAL_DELAY_MS = 5 * 1000 // 5 seconds
const RETRY_DELAY_MS = 2 * 60 * 1000 // 2 minutes

const WS_PROTOCOL = 'wss'
const ADVANCE_PORT = 4000

class SystemStatusClient extends EventEmitter {
    constructor() {
        super()
        this.#establishConnection()
    }

    async #establishConnection() {

        try {
            const caCertificates = await loadCACertificates()

            const tryAgain = () => {
                return new Promise((resolve) => {
                    log.d('Creating web socket')
                    const ws = new WebSocket(`${WS_PROTOCOL}://localhost:${ADVANCE_PORT}/service/systemStatus`, { ca: caCertificates })

                    ws.on('open', () => {
                        log.d('Web socket opened')
                    })
                    ws.on('close', () => {
                        log.d('Web socket was closed')
                        resolve()
                    })
                    ws.on('error', error => {
                        log.e('Web socket received error', error)
                        resolve()
                    })
                    ws.on('message', message => {
                        try {
                            const asObject = JSON.parse(message)
                            if (asObject.name) {
                                log.d('Received message type', asObject.name)
                                this.emit(asObject.name, asObject)
                            } else {
                                log.e('No name in system status event')
                            }
                        } catch (e) {
                            log.e('Failure to process system status event', e)
                        }
                    })
                })
            }

            await sleep(INITIAL_DELAY_MS)

            // eslint-disable-next-line no-constant-condition
            while (true) {
                log.d('Attempting to connect to system status web socket')
                await tryAgain()
                log.d('Waiting to try again')
                await sleep(RETRY_DELAY_MS)
            }
        } catch (e) {
            log.e('Fatal error in system status client', e)
        }
    }
}


const systemStatusClient = new SystemStatusClient()

exports.systemStatusClient = systemStatusClient






