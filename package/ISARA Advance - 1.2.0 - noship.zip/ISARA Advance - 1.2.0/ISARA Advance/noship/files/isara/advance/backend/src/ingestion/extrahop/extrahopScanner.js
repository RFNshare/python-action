/**
 * @file extrahopScanner.js - 1.2.0 - 3826bc12533e078a8e37cfe70ee04d9e85c8530e
 * 
 * @copyright Copyright (C) 2016-2023, ISARA Corporation, All Rights Reserved.
 * 
 * @license The code and other content set out herein is not in the public
 * domain, is considered a trade secret and is confidential to ISARA
 * Corporation. Use, reproduction or distribution, in whole or in part, of such
 * code or other content is strictly prohibited except by express written
 * permission of ISARA Corporation. Please contact ISARA Corporation at
 * info@isara.com for more information.
 */

/**
 * This module is the Extrahop Scanner for pulling data out of Extrahop.
 * @module scanners/extrahopScanner
 */

const { Session } = require('../../isaraql/session')
const log = require('../../util/log')(module)
const { ExtrahopRecordsRequest } = require('./requests/extrahopRecordsRequest')
const { ExtrahopTestRequest } = require('./requests/extrahopTestRequest')

const systemPreferences = require('../../util/systemPreferences')

const { updateScanResultSummary, IngestionStatus } = require('../commonIngestion')

const { ExtraHopBatchProcessor } = require('./extrahopBatchProcessors')
const cryptoDataCache = require('../cryptoDataCache')

const { ChattyTimer } = require('../../util/chattyTimer')

const COMMIT_MAX_DELAY_MS = 2 * 60 * 1000 // two minutes

let extrahopBenchmark = false

/**
 * Verifies connectivity and authentication against the remote Extrahop server.
 * @param {Object} dataSource The Data Source to Test.
 */
async function extrahopTest(dataSource) {
    let config = JSON.parse(dataSource.configuration)
    let testRequest = new ExtrahopTestRequest(config.url, config.token)
    await testRequest.execute()
}

// const extraHopDeviceTypes = {
//     custom: 'OTHER',
//     database: 'DATABASE',
//     dhcp_server: 'DHCP_SERVER',
//     dns_server: 'DNS_SERVER',
//     domain_controller: 'DOMAIN_CONTROLLER',
//     file_server: 'FILE_SERVER',
//     firewall: 'FIREWALL',
//     gateway: 'GATEWAY',
//     ip_camera: 'IP_CAMERA',
//     load_balancer: 'LOAD_BALANCER',
//     medical_device: 'MEDICAL_DEVICE',
//     mobile_device: 'MOBILE_DEVICE',
//     nat_gateway: 'NAT_GATEWAY',
//     pc: 'PC',
//     printer: 'PRINTER',
//     voip_phone: 'VOIP_PHONE',
//     vpn_client: 'VPN_CLIENT',
//     vpn_gateway: 'VPN_GATEWAY',
//     vulnerability_scanner: 'VULNERABILITY_SCANNER',
//     web_proxy_server: 'WEB_PROXY_SERVER',
//     web_server: 'WEB_SERVER',
//     wifi_access_point: 'WIFI_AP'
// }

/**
 * Bundle of timers for benchmarking.
 */
class ExtraHopBenchmarks {
    fetching = new ChattyTimer('ExtraHop Fetching', 'extrahop records')
    connectionProcessing = new ChattyTimer('ExtraHop Processing', 'connections')
    committing = new ChattyTimer('ExtraHop Committing', 'postgres records') //  committing
    elapsed = new ChattyTimer('ExtraHop Elapsed')

    summary() {
        log.log('<== Extrahop benchmarking ==>')
        this.fetching.summary()
        this.connectionProcessing.summary()
        this.committing.summary()
        this.elapsed.summary()
    }
}

/**
 * Performs an Extrahop Ingestion Scan for the specified Data Source Scan.
 * @param {Object} dataSource The Data Source Scan to run.
 */
async function extrahopScan(dataSourceScan, scanResults, onFulfilled, onRejected, onFinally) {
    try {
        let session = new Session()
        let preferences = await systemPreferences()
        extrahopBenchmark = (preferences?.benchmarking?.all ?? false) || (preferences?.benchmarking?.extrahop ?? false)

        await cryptoDataCache.init()

        let sourceConfig = JSON.parse(dataSourceScan.dataSource.configuration)

        if (!('record_start' in sourceConfig)) {
            throw new Error('Inconsistent configuration data - record_start missing')
        }

        let configStart = sourceConfig.record_start
        if (!configStart) {
            configStart = 0
        } else {
            configStart = new Date(configStart).getTime()
        }

        let metaLastScanEnd = undefined
        let metaConfigStart = undefined
        try {
            const metaData = JSON.parse(dataSourceScan.metadata)
            metaLastScanEnd = metaData.lastScanEnd
            metaConfigStart = metaData.configStart
        } catch (toIgnore) {
            // ignore this error - do not care if there's no (or corrupt) meta data.
        }

        let startTimeToUse = configStart
        if (metaConfigStart !== configStart) {
            // Someone has reconfigured the scan - the start date has changed - we should scan from this date, not the end of the last scan.
        } else if (metaLastScanEnd) {
            startTimeToUse = metaLastScanEnd + 1 // Add a ms to prevent duplicates
        }

        const endTimeToUse = Date.now()

        if (startTimeToUse >= endTimeToUse) {
            // This will definitely fail.
            log.e('Start time is after end time')
        }

        let recordParameters = {
            start: startTimeToUse,
            end: endTimeToUse,
            useEXA: sourceConfig.record_source == 0,
            processFlowRecords: false
        }

        log.log('Extrahop date range', new Date(recordParameters.start), 'to', new Date(recordParameters.end))

        // TODO: Old code was doing a device query here - do we still need a device query with the minimal schema? (type? names? os?)

        let recordCount = 0
        let recordTotal = 0

        await updateScanResultSummary(scanResults, 'Processing records...', session)

        let timers

        if (extrahopBenchmark === true) {
            timers = new ExtraHopBenchmarks()
            timers.elapsed.start()
        }

        let ehbp = new ExtraHopBatchProcessor(session, { timer: timers?.committing })

        let recordsQuery = new ExtrahopRecordsRequest(sourceConfig.url, sourceConfig.token, recordParameters, {})

        timers?.fetching?.start()
        // Deliberately NOT calling await. This is to allow the next fetch to start during the previous processing.
        let nextResultPromise = recordsQuery.execute()
        // Will track if the previous query completed the record collection.
        let wasCompleteThisQuery = false

        let timeOfLastCommit = Date.now()
        do {
            let results = await nextResultPromise
            timers?.fetching?.stop(results.recordsRetrieved)
            wasCompleteThisQuery = recordsQuery.complete

            recordTotal = results.total
            recordCount = recordsQuery.recordsRetrieved
            let percentage = (recordTotal > 0) ? (recordCount / recordTotal * 100).toFixed(1) : '0'
            log.log(`Records retrieved: ${recordsQuery.recordsRetrieved}, total: ${results.total} (${percentage}%)`)

            await updateScanResultSummary(scanResults, `Processing records: ${percentage}%`, session)

            if (!wasCompleteThisQuery) {
                timers?.fetching?.start()
                nextResultPromise = recordsQuery.execute()
            }

            // Process the connections we now know about.
            timers?.connectionProcessing?.start()
            let processedCount = ehbp.processConnections(results)
            timers?.connectionProcessing?.stop(processedCount)

            // Check to see if we've got too many records / timing out and should commit.
            if (ehbp.needsCommit() || (Date.now() - timeOfLastCommit > COMMIT_MAX_DELAY_MS)) {
                await ehbp.commit()
                timeOfLastCommit = Date.now()
            }
        } while (!wasCompleteThisQuery)

        // Due to the queue for matching flow IDs, there may be more records left to process.
        timers?.connectionProcessing?.start()
        let processedCount = ehbp.processConnections()
        timers?.connectionProcessing?.stop(processedCount)

        // Due to the previous connectionProcessing, and the behaviour of the batch managers, there may be records to commit.
        await ehbp.commit()

        timers?.elapsed?.stop()
        timers?.summary()

        dataSourceScan.metadata = {
            lastScanEnd: endTimeToUse,
            configStart: configStart
        }

        await updateScanResultSummary(scanResults, `Scan complete. Processed ${Number(recordCount).toLocaleString()} record(s).`)
        await onFulfilled(IngestionStatus.SUCCESS)
    } catch (e) {
        log.e('error in EHScan', e)
        await onRejected(e)
    } finally {
        await onFinally()
    }
}


module.exports = {
    name: 'Discover(x)',
    test: extrahopTest,
    scan: extrahopScan,
}
