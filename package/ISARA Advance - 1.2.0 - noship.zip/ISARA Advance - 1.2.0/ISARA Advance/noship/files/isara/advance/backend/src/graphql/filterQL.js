/**
 * @file filterQL.js - 1.2.0 - 3826bc12533e078a8e37cfe70ee04d9e85c8530e
 * 
 * @copyright Copyright (C) 2016-2023, ISARA Corporation, All Rights Reserved.
 * 
 * @license The code and other content set out herein is not in the public
 * domain, is considered a trade secret and is confidential to ISARA
 * Corporation. Use, reproduction or distribution, in whole or in part, of such
 * code or other content is strictly prohibited except by express written
 * permission of ISARA Corporation. Please contact ISARA Corporation at
 * info@isara.com for more information.
 */

/**
 * This module implements the filtered query functions.
 * @module graphql/filterQL
 */

const { roles } = require('./commonQL')
const { Session } = require('../isaraql/session')
const { fetchWanted, fetchForColumns } = require('../isaraql/fetch')
const { expressionToTempTable } = require('../filterql/filterSQL')
const { graphQLStateToWanted } = require('../isaraql/wantedUtil')
const { parse } = require('../filterql/filterql')
const { facets } = require('../filterql/facets')

const { getCptForRequest } = require('../util/cptHelpers')
const { getRequestState } = require('../util/requestState')

/**
 * Common code to find filtered elements of an arbitrary top level table.
 * @param {string} table Top level table name. eg: `Device`
 * @param {string} resultName Result for elements from the top level table. eg: `devices`
 * @param {string} [filter] Filter to apply to the data
 * @param {object} graphQLState GraphQL State to read wanted information from
 * @param {object} wpcs WPCS set to control paging.
 * @param {string} [asOf] When the data should be reported on. If not provided the counts will be as of now.
 * @param {function} callback Async function to call with the result in progress, the wanted, the filter and the session.
 */
exports.filterQuery = async function (table, resultName, filter, graphQLState, wpcs, asOf, cryptoPostureTemplate, callback) {
    const session = new Session()
    let toReturn = {}
    let wanted = graphQLStateToWanted(graphQLState)

    let activeCPTId = await getCptForRequest(cryptoPostureTemplate)

    wpcs.DeviceScore = {
        where: {
            equals: { column: 'cryptoPostureTemplate', value: activeCPTId }
        }
    }

    wpcs.ConnectionScore = {
        where: {
            equals: { column: 'cryptoPostureTemplate', value: activeCPTId }
        }
    }


    await session.reuseConnection(async () => {
        if (asOf) {
            await session.configureHistory(null, new Date(asOf))
        }

        wanted = wanted[Object.keys(wanted)[0]]

        if (!wanted[resultName]) {
            wanted[resultName] = { id: true }
        }

        let doingCount = false
        if (wanted.paging && wanted.paging.count) {
            wpcs[table].count = []
            doingCount = true
        }

        if (filter && filter.trim() !== '') {
            let tempTable = await expressionToTempTable(table, filter, session)
            wpcs[table].where = { in: { column: 'id', value: tempTable } }

            let store = getRequestState()
            if (store !== undefined) {
                store.filterTable = tempTable
            }
        }

        toReturn[resultName] = await fetchWanted(table, wanted[resultName], wpcs, session)
        if (doingCount) {
            toReturn.paging = { count: wpcs[table].count[0] }
        }

        if (callback) {
            await callback(toReturn, wanted, session)
        }
    })

    return toReturn
}

async function validateFilterQuery(fields/*, request, graphqlState*/) {
    if (!('filter' in fields)) {
        throw 'Required filter parameter missing'
    }

    try {
        parse(fields.filter)
    }
    catch (e) {
        return {
            valid: false,
            error: e.message
        }
    }

    return {
        valid: true
    }
}

const TYPE_DATETIME = 'Date-Time'
const TYPE_INTEGER = 'Integer'
const TYPE_IP = 'IP'
const TYPE_TEXT = 'Text'
const typeNameMap = {
    'string': TYPE_TEXT,
    'integer': TYPE_INTEGER,
    'datetime|string': TYPE_DATETIME,
}

function pad(n, width, z) {
    z = z || '0'
    n = n + ''
    return n.length >= width ? n : new Array(width - n.length + 1).join(z) + n
}

async function getFilterOperators() {
    let date = new Date()
    let exampleDate = `${date.getFullYear()}-${pad(date.getMonth()+1, 2)}-${pad(date.getDate(), 2)}`
    return [
        {
            operator: '=',
            description: 'Case-sensitive whole text match',
            supportedTypes: [
                TYPE_TEXT,
                TYPE_INTEGER,
                TYPE_IP,
            ],
            examples: [
                `devicename='example.company.com'`,
                `port=443`,
                `ip='10.2.0.113'`,
            ]
        },
        {
            operator: ':',
            description: 'Case-insensitive partial text match',
            supportedTypes: [
                TYPE_TEXT,
                TYPE_IP,
            ],
            examples: [
                `devicename:'.company.com'`,
                `ip:'10.2'`,
            ]
        },
        {
            operator: '>',
            description: 'Case-insensitive greater-than match',
            supportedTypes: [
                TYPE_TEXT,
                TYPE_INTEGER,
                TYPE_DATETIME,
                TYPE_IP,
            ],
            examples: [
                `port>1023`,
                `lastonline>'${exampleDate}T00:00:00'`,
                `ip>'10.2.0.0'`,
            ]
        },
        {
            operator: '<',
            description: 'Case-insensitive less-than match',
            supportedTypes: [
                TYPE_TEXT,
                TYPE_INTEGER,
                TYPE_DATETIME,
                TYPE_IP,
            ],
            examples: [
                `port<1024`,
                `lastonline<'today'`,
                `ip<'10.2.255.255'`,
            ]
        },
        {
            operator: '>=',
            description: 'Case-insensitive equal-or-greater-than match',
            supportedTypes: [
                TYPE_TEXT,
                TYPE_INTEGER,
                TYPE_DATETIME,
                TYPE_IP,
            ],
            examples: [
                `port>=1024`,
            ]
        },
        {
            operator: '<=',
            description: 'Case-insensitive equal-or-less-than match',
            supportedTypes: [
                TYPE_TEXT,
                TYPE_INTEGER,
                TYPE_DATETIME,
                TYPE_IP,
            ],
            examples: [
                `port<=1023`,
            ]
        },
        {
            operator: 'NOT',
            description: 'Inverts a match condition',
            supportedTypes: [],
            examples: [
                `NOT devicename:'.company.com'`,
                `NOT port=443`,
            ]
        },
        {
            operator: 'OR',
            description: 'OR operation between multiple match conditions',
            supportedTypes: [],
            examples: [
                `port=80 OR port=443`,
                `ip>='10.2.0.0' OR ip<='10.2.255.255'`,
            ]
        },
        {
            operator: 'AND',
            description: 'AND operation between multiple match conditions',
            supportedTypes: [],
            examples: [
                `port=80 AND NOT port=443`,
                `deviceaddeddate>='${exampleDate}T00:00:00' AND deviceaddeddate<='${exampleDate}T23:59:59'`,
                `ip>='10.2.0.0' AND ip<='10.2.255.255'`,
            ]
        },
        {
            operator: '( )',
            description: 'Allows grouping of multiple match conditions',
            supportedTypes: [],
            examples: [
                `(port=80 OR port=443) AND (devicetype='WEB_SERVER' OR devicetype='WEB_PROXY_SERVER')`,
            ]
        },
    ]
}

async function getAllFacets() {
    let toReturn = []
    let idIndex = 1
    for (const attribute of facets.attributes) {
        let facetInfo = {
            id: idIndex++,
            name: attribute.name,
            type: attribute.type,
            typeName: typeNameMap[attribute.type] | attribute.type,
            description: attribute.description,
        }

        if (['ip', 'peer'].includes(attribute.name)) {
            facetInfo.typeName = TYPE_IP
        }
        toReturn.push(facetInfo)
    }
    toReturn.sort(function (a, b) {
        if ( a.name < b.name ){
            return -1
        }
        if ( a.name > b.name ){
            return 1
        }
        return 0
    })
    return toReturn
}

const listDataDictionary = {
    CIPHERSUITE: 'CipherSuite',
    PROTOCOLVARIANT: 'ProtocolVariant',
    CRYPTOPRIMITIVE: 'CryptoPrimitive',
}

async function getListData(fields/*, request, graphQLState*/) {
    let session = new Session()
    let tableName = listDataDictionary[fields.category]
    let wpcs = {}
    wpcs[tableName] = {}

    if (fields.paging) {
        wpcs[tableName].paging = fields.paging
    }

    let results = await fetchForColumns(tableName, ['id', 'name'], wpcs, session)
    return results
}

exports.graphQL = {
    types: `
        enum ListDataCategory {
            CIPHERSUITE
            PROTOCOLVARIANT
            CRYPTOPRIMITIVE
        }

        type FilterValidationResult {
            valid: Boolean!
            error: String
        }

        type Facet {
            id: Int!
            name: String!
            type: String!
            typeName: String!
            description: String!
            enumValues: [String!]
        }

        type FilterOperator {
            operator: String!
            description: String!
            supportedTypes: [String!]!
            examples: [String!]!
        }

        type ListData {
            id: BigInt!
            name: String!
        }
    `,
    queries: `
        validateFilter(
            filter: String!
        ) : FilterValidationResult!

        """
         Get all the facets that can be used in filter queries.
        """
        getFacets: [Facet!]!

        """
         Get all the operators that can be used in filter queries.
        """
        getFilterOperators: [FilterOperator!]!

        """
         Get all the list data for a given category.
        """
        getListData(
            category: ListDataCategory!
            paging: PagingInput
        ) : [ListData!]!
    `,
    root: {
        validateFilter: validateFilterQuery,
        getFacets: getAllFacets,
        getFilterOperators: getFilterOperators,
        getListData: getListData,
    },
    restrictions: {
        validateFilter: [roles.AUTHENTICATED],
        getFacets: [roles.AUTHENTICATED],
        getFilterOperators: [roles.AUTHENTICATED],
        getListData: [roles.AUTHENTICATED],
    }
}
