/**
 * @file injector.js - 1.2.0 - 3826bc12533e078a8e37cfe70ee04d9e85c8530e
 * 
 * @copyright Copyright (C) 2016-2023, ISARA Corporation, All Rights Reserved.
 * 
 * @license The code and other content set out herein is not in the public
 * domain, is considered a trade secret and is confidential to ISARA
 * Corporation. Use, reproduction or distribution, in whole or in part, of such
 * code or other content is strictly prohibited except by express written
 * permission of ISARA Corporation. Please contact ISARA Corporation at
 * info@isara.com for more information.
 */

const { Session } = require('../isaraql/session')

const log = require('../util/log')(module)
const express = require('express')

const MAX_QUERY_PARAMS = 40000

/**
 * Send a good response to the caller.
 * @param {Express.Response} response
 * @param {Object} toSend
 */
function sendGood(response, toSend) {
    let reallySend = { ...toSend, ok: true }
    send(response, 200, reallySend)
}

/**
 * Send an error response to the caller.
 * @param {Express.Response} response
 * @param {Error} error
 * @param {Object} toSend
 */
function sendError(response, error, toSend) {
    let reallySend = { ...toSend, error: error.message, stack: error.stack, ok: false }
    send(response, 400, reallySend)
}

/**
 * Send a response to the caller. It will be logged with the ISARA request id.
 * @param {Express.Response} response
 * @param {Number} HTTP status code
 * @param {Object} toSend Object to JSON stringify for transmission
 */
function send(response, status, toSend) {
    toSend = { ...toSend, isaraRequestID: response.isaraRequestID }
    log.log('Response', response.isaraRequestID, status, toSend)
    response.status(status)
    response.set('Content-Type', 'application/json')
    response.send(JSON.stringify(toSend, null, 4))
}

/**
 * Attempt to inject records directly to a table.
 * @param {Express.Request} request
 * @param {Express.Response} response
 */
async function injectRecords(request, response) {
    let inserted = 0
    try {
        let table = request?.params?.table
        if (!table) {
            throw new Error('Table is missing from URL')
        }
        let data = request.body
        if (!data) {
            throw new Error('No data was provided')
        }
        if (!data.records) {
            throw new Error('Missing records field')
        }
        let records = data.records
        if (!Array.isArray(records)) {
            throw new Error('Records should be an array')
        }

        if (records.length != 0) {
            let columns = []
            for (let key in records[0]) {
                columns.push(key)
            }

            if (columns.length === 0) {
                throw new Error('No columns in first record')
            }

            let queryPrefix = `insert into "${table}" (${columns.map(c => `"${c}"`).join(`, `)}) values `

            let singleRecord = `(${columns.map(() => '?').join(', ')})`

            let queryParams = []
            let dummyRows = []

            let session = new Session()

            let doInsert = async () => {
                if (queryParams.length === 0) {
                    return
                }

                let query = `${queryPrefix} ${dummyRows.map(() => singleRecord).join(', ')} on conflict do nothing`

                log.log(query)
                log.log(queryParams)

                let result = await session.query(query, queryParams)
                inserted += result.rowCount ?? 0

                queryParams.length = 0
                dummyRows.length = 0
            }


            for (let record of records) {
                dummyRows.push(undefined)
                for (let c of columns) {
                    queryParams.push(record[c])
                }
                if (queryParams.length > MAX_QUERY_PARAMS) {
                    await doInsert()
                }
            }
            await doInsert()
        }

        sendGood(response, { inserted })
    } catch (error) {
        sendError(response, error, { inserted })
    }
}

/**
 * Attempt to delete _ALL_ records from a table.
 * @param {Express.Request} request
 * @param {Express.Response} response
 */
async function deleteRecords(request, response) {
    let deleted = 0
    try {
        let table = request?.params?.table
        if (!table) {
            throw new Error('Table missing')
        }
        let session = new Session()
        let result = await session.query(`delete from "${table}"`)
        deleted = result.rowCount

        sendGood(response, { deleted })
    } catch (error) {
        sendError(response, error, { deleted })
    }
}

/**
 * Make a fairly unique ID to help trace logs.
 */
let requestID = Math.floor(Math.random() * 10000000000)

/**
 * Log an incoming request and add the ISARA request id to the request and response.
 * @param {Express.Request} request
 * @param {Express.Response} response
 * @param {function} next
 */
function logRequests(request, response, next) {
    let id = `isaraRequestID:${requestID}`
    request.isaraRequestID = id
    response.isaraRequestID = id
    requestID++

    log.log('Request', request.isaraRequestID, request.method, request.url)

    next()
}

/**
 * Log an error and kill the process.
 * @param {Error} error
 */
function quit(error) {
    log.e('Quitting in 200ms', error)
    setTimeout(() => process.exit(1), 200)
}

async function main() {
    try {
        let tablePath = '/injector/postgres/:table'
        const app = express()

        // JSON decoding of requests.
        app.use(express.json())

        // Log and add ISARA request ID
        app.use(logRequests)

        // Table operations
        app.post(tablePath, injectRecords)
        app.delete(tablePath, deleteRecords)


        const server = app.listen(8000)
        server.on('error', error => {
            quit(error)
        })

        let session = new Session()
        let result = await session.query('select now()')
        log.log('Database connection worked. Database says it is', result.rows[0])
    } catch (error) {
        quit(error)
    }
}

if (require.main === module) {
    main()
} else {
    throw new Error('Do not require/import this module')
}
