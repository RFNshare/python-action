/**
 * @file featureQL.js - 1.2.0 - 3826bc12533e078a8e37cfe70ee04d9e85c8530e
 * 
 * @copyright Copyright (C) 2016-2023, ISARA Corporation, All Rights Reserved.
 * 
 * @license The code and other content set out herein is not in the public
 * domain, is considered a trade secret and is confidential to ISARA
 * Corporation. Use, reproduction or distribution, in whole or in part, of such
 * code or other content is strictly prohibited except by express written
 * permission of ISARA Corporation. Please contact ISARA Corporation at
 * info@isara.com for more information.
 */

/**
 * This module contains the feature flag query.
 * @module graphql/featureQL
 */
const systemPreferences = require('../util/systemPreferences')
const { roles } = require('./commonQL')

/**
 * List of all the minimal names that are supported.
 */
const minimalFeatureNames = [
    'AGILITY',
    'ALLOW_MANUAL_EDIT',
    'ALLOW_MANUAL_ADD',
    'DASHBOARD',
    'FILTER_TAGS_TAB',
    'GRAPHIQL',
    'NOTIFICATIONS',
    'REPORTS',
    'SHOW_USER_ACTIVITY',
    'TEMPORAL_WIDGETS',
    'VIEWS',
    'VISUALIZATION_BACK_BTN',
    'VISUALIZATION_SUBGROUP',
    'SHOW_BYTESTRANSFERRED',
    'CRYPTOGRAPHIC_POSTURE_TEMPLATE',
    'CONNECTIONS_POSTURE',
    'DEVICES_POSTURE',
    'SOFTWARE_POSTURE',
    'CONNECTIONS_VISUALIZATION',
    'DEVICES_VISUALIZATION',
].sort()

/**
 * Holds the known feature flags.
 */
const featureFlags = {
    DASHBOARD: true,
    FILTER_TAGS_TAB: true,
    REPORTS: true,
    TEMPORAL_WIDGETS: true,
    VIEWS: true,
    VISUALIZATION_BACK_BTN: true,
    VISUALIZATION_SUBGROUP: true,
    SHOW_BYTESTRANSFERRED: false,
    ALLOW_MANUAL_ADD: false,
    CRYPTOGRAPHIC_POSTURE_TEMPLATE: false,
    CONNECTIONS_POSTURE: true,
    DEVICES_POSTURE: true,
    SOFTWARE_POSTURE: true,
    CONNECTIONS_VISUALIZATION: true,
    DEVICES_VISUALIZATION: true,
}

/**
 * Get the current feature flags.
 */
async function featureFlagsQuery() {
    return Object.keys(featureFlags).map(key => ({ feature: key, enabled: featureFlags[key] }))
}

/**
 * Build a set of features from the properties file.
 */
async function initialise() {
    minimalFeatureNames.forEach(value => {
        if (!(value in featureFlags)) {
            featureFlags[value] = false
        }
    })

    var preferences = await systemPreferences()
    if (preferences && preferences.featureFlags) {
        var fromPreferences = preferences.featureFlags
        for (let key in fromPreferences) {
            featureFlags[key] = fromPreferences[key] === true
        }
    }
}

exports.graphQL = {
    // Types is using a getter as the final list is not known when this file is loaded.
    get types() {
        return `
        enum Feature {
            ${Object.keys(featureFlags).sort().join('\n')}
        }

        type FeatureFlag {
            feature: Feature!
            enabled: Boolean!
        }
        `
    },
    queries: `
        featureFlags: [FeatureFlag!]!
    `,
    root: {
        featureFlags: featureFlagsQuery,
    },
    restrictions: {
        featureFlags: [roles.UNAUTHENTICATED],
    },
    initialise
}
