--
-- @file 0-1.sql - 1.2.0 - 3826bc12533e078a8e37cfe70ee04d9e85c8530e
-- 
-- @copyright Copyright (C) 2016-2023, ISARA Corporation, All Rights Reserved.
-- 
-- @license The code and other content set out herein is not in the public
-- domain, is considered a trade secret and is confidential to ISARA
-- Corporation. Use, reproduction or distribution, in whole or in part, of such
-- code or other content is strictly prohibited except by express written
-- permission of ISARA Corporation. Please contact ISARA Corporation at
-- info@isara.com for more information.
--

    /* 
    * 
    *    SCHEMA - FORWARDS 
    *    MIGRATION 0 to 1
    *    ORIGIN GIT HASH:bfb8c1ca8944d88b169866fb5471cd67a1cf0bf8
    *
    *    CREATED ON 2022-07-26T04:17:00.000Z
    *
    *
    *   NOTE: THIS IS A STARTING POINT FOR MIGRATIONS - release/0.82.1
    *   DEST GIT HASH IS ALSO bfb8c1ca8944d88b169866fb5471cd67a1cf0bf8
    *
    */

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

CREATE SCHEMA IF NOT EXISTS "advance";
ALTER SCHEMA "advance" OWNER TO "postgres";

CREATE EXTENSION IF NOT EXISTS "btree_gist" WITH SCHEMA "public";
COMMENT ON EXTENSION "btree_gist" IS 'support for indexing common datatypes in GiST';


SET default_tablespace = '';
SET default_table_access_method = "heap";

-- Independent tables
CREATE TABLE "advance"."CertificateType" (
    "id" bigserial PRIMARY KEY,
    "name" varchar(80) NOT NULL,
    CONSTRAINT "uniqueCertificateTypeName" UNIQUE("name")
);

ALTER TABLE "advance"."CertificateType" OWNER TO "postgres";
COMMENT ON TABLE "advance"."CertificateType" IS '@graphQL.enum';

CREATE TABLE "advance"."Protocol" (
    "id" bigserial PRIMARY KEY,
    "name" varchar(1024) NOT NULL,
    CONSTRAINT "uniqueProtocolName" UNIQUE("name"));

ALTER TABLE "advance"."Protocol" OWNER TO "postgres";
COMMENT ON TABLE "advance"."Protocol" IS '@graphQL.enum';
COMMENT ON COLUMN "advance"."Protocol"."id" IS 'The primary key.';
COMMENT ON COLUMN "advance"."Protocol"."name" IS 'The translation of the protocol’s name.';

CREATE TABLE "advance"."CipherSuite" (
    "id" bigserial PRIMARY KEY,
    "protocol" bigint NOT NULL REFERENCES "advance"."Protocol",
    "name" varchar(1024) NOT NULL,
    "codePoint" int
);

ALTER TABLE "advance"."CipherSuite" OWNER TO "postgres";
COMMENT ON COLUMN "advance"."CipherSuite"."id" IS 'The primary key.';
COMMENT ON COLUMN "advance"."CipherSuite"."protocol" IS 'The protocol in which the cipher suite is used.';
COMMENT ON COLUMN "advance"."CipherSuite"."name" IS 'The translation of the cipher suite name.';
COMMENT ON COLUMN "advance"."CipherSuite"."codePoint" IS 'The value that identifies the ciphersuite.';

CREATE TABLE "advance"."ConnectionCertificateType" (
    "id" bigserial PRIMARY KEY,
    "name" varchar(80) NOT NULL
);

ALTER TABLE "advance"."ConnectionCertificateType" OWNER TO "postgres";
COMMENT ON TABLE "advance"."ConnectionCertificateType" IS '@graphQL.enum';

CREATE TABLE "advance"."ConnectionRatingScale" (
    "id" bigserial PRIMARY KEY,
    "name" varchar(45) NOT NULL,
    CONSTRAINT "uniqueConnectionRatingScaleName" UNIQUE("name")
);

ALTER TABLE "advance"."ConnectionRatingScale" OWNER TO "postgres";
COMMENT ON TABLE "advance"."ConnectionRatingScale" IS '@graphQL.enum';

CREATE TABLE "advance"."CryptoAlgorithm" (
    "id" bigserial PRIMARY KEY,
    "name" varchar(40) NOT NULL,
    CONSTRAINT "uniqueCryptoAlgorithmName" UNIQUE("name")
);

ALTER TABLE "advance"."CryptoAlgorithm" OWNER TO "postgres";
COMMENT ON TABLE "advance"."CryptoAlgorithm" IS 'Enum for grouping algorithms
@graphQL.enum';
COMMENT ON COLUMN "advance"."CryptoAlgorithm"."id" IS 'Primary key.';
COMMENT ON COLUMN "advance"."CryptoAlgorithm"."name" IS 'The name of the algorithm. eg: RSA or ECDH';


CREATE TABLE "advance"."DataSourceScanResultStatus" (
    "id" bigserial PRIMARY KEY,
    "name" varchar(45) NOT NULL,
    CONSTRAINT "uniqueScanResultStatusName" UNIQUE("name")
);

ALTER TABLE "advance"."DataSourceScanResultStatus" OWNER TO "postgres";
COMMENT ON TABLE "advance"."DataSourceScanResultStatus" IS '@graphQL.enum';

CREATE TABLE "advance"."DataSourceStatus" (
    "id" bigserial PRIMARY KEY,
    "name" varchar(45) NOT NULL,
    CONSTRAINT "uniqueDataSourceStatusName" UNIQUE("name")
);

ALTER TABLE "advance"."DataSourceStatus" OWNER TO "postgres";
COMMENT ON TABLE "advance"."DataSourceStatus" IS '@graphQL.enum';

CREATE TABLE "advance"."DeviceType" (
    "id" bigserial PRIMARY KEY,
    "name" varchar(45) NOT NULL,
    CONSTRAINT "uniqueDeviceTypeName" UNIQUE("name")
);

ALTER TABLE "advance"."DeviceType" OWNER TO "postgres";
COMMENT ON TABLE "advance"."DeviceType" IS '@graphQL.enum';

CREATE TABLE "advance"."KeyStore" (
    "id" bigserial PRIMARY KEY
);

ALTER TABLE "advance"."KeyStore" OWNER TO "postgres";

CREATE TABLE "advance"."IgnoredPort" (
    "id" bigserial PRIMARY KEY,
    "name" varchar(1024) NOT NULL,
    "port" integer NOT NULL,
    CONSTRAINT "uniqueIgnoredPortName" UNIQUE("name"),
    CONSTRAINT "uniqueIgnoredPort" UNIQUE("port")
);

ALTER TABLE "advance"."IgnoredPort" OWNER TO "postgres";
COMMENT ON TABLE "advance"."IgnoredPort" IS 'Global configuration of connection ports to ignore for score calculation';
COMMENT ON COLUMN "advance"."IgnoredPort"."id" IS 'The primary key.';
COMMENT ON COLUMN "advance"."IgnoredPort"."name" IS 'Name of the port';
COMMENT ON COLUMN "advance"."IgnoredPort"."port" IS 'Between 1 and 65535. e.g. 111';

CREATE TABLE "advance"."Netmask" (
    "id" bigserial PRIMARY KEY,
    "name"  varchar(1024) NOT NULL,
    "netmask" varchar(1024) NOT NULL,
    "description" varchar(1024) DEFAULT '' NOT NULL,
    "forClients" boolean DEFAULT true NOT NULL,
    "forServers" boolean DEFAULT true NOT NULL,
    "squashAddresses" boolean DEFAULT true NOT NULL,
    "storeName" boolean DEFAULT false NOT NULL,
    "enabled" boolean DEFAULT true NOT NULL,
    "sortOrder" integer NOT NULL,
    CONSTRAINT "uniqueName" UNIQUE("name"),
    CONSTRAINT "uniqueSortOrder" UNIQUE("sortOrder")
);

ALTER TABLE "advance"."Netmask" OWNER TO "postgres";
COMMENT ON TABLE "advance"."Netmask" IS 'Netmasks for classifying devices by IP Addresses.';
COMMENT ON COLUMN "advance"."Netmask"."id" IS 'The primary key.';
COMMENT ON COLUMN "advance"."Netmask"."name" IS 'The name of this netmask.';
COMMENT ON COLUMN "advance"."Netmask"."netmask" IS 'A comma-separated list of netmasks.';
COMMENT ON COLUMN "advance"."Netmask"."forClients" IS 'True means this mask applies to client addresses';
COMMENT ON COLUMN "advance"."Netmask"."forServers" IS 'True means this mask applies to server addresses';
COMMENT on COLUMN "advance"."Netmask"."storeName" IS 'True means the netmask NAME will be stored as the address, False means the netmask pattern (eg: 192/8) will be stored as the address';
COMMENT on COLUMN "advance"."Netmask"."enabled" IS 'True means this rule is enabled and should be respected by ingestors';

CREATE TABLE "advance"."NotificationType" (
    "id" bigserial PRIMARY KEY,
    "name" varchar(45) NOT NULL,
    CONSTRAINT "uniqueNotificationTypeName" UNIQUE("name")
);

ALTER TABLE "advance"."NotificationType" OWNER TO "postgres";
COMMENT ON TABLE "advance"."NotificationType" IS '@graphQL.enum';

CREATE TABLE "advance"."SoftwareType" (
    "id" bigserial PRIMARY KEY,
    "name" varchar(1024) NOT NULL,
    CONSTRAINT "uniqueSoftwareTypeName" UNIQUE("name")
);

ALTER TABLE "advance"."SoftwareType" OWNER TO "postgres";
COMMENT ON TABLE "advance"."SoftwareType" IS 'The type of software can be operating system, crypto library, proxy agent, etc
@graphQL.enum';
COMMENT ON COLUMN "advance"."SoftwareType"."id" IS 'The primary key.';
COMMENT ON COLUMN "advance"."SoftwareType"."name" IS 'e.g. OS, Server, App';

CREATE TABLE "advance"."TagType" (
    "id" bigserial PRIMARY KEY,
    "name" varchar(40) NOT NULL,
    "expressionKey" varchar(40) NOT NULL,
    "isNumeric" boolean DEFAULT false NOT NULL,
    "unit" varchar(16),
    CONSTRAINT "uniqueTagTypeExpressionKey" UNIQUE("expressionKey"),
    CONSTRAINT "uniqueTagTypeName" UNIQUE("name")
);

ALTER TABLE "advance"."TagType" OWNER TO "postgres";
COMMENT ON TABLE "advance"."TagType" IS '@graphQL.enum';

CREATE TABLE "advance"."Tag" (
    "id" bigserial PRIMARY KEY,
    "value" varchar(1024) NOT NULL,
    "tagType" bigint NOT NULL REFERENCES "advance"."TagType",
    "lastUsed" timestamp with time zone NOT NULL,
    CONSTRAINT "uniqueTagPerType" UNIQUE("value", "tagType")
);

ALTER TABLE "advance"."Tag" OWNER TO "postgres";

CREATE TABLE "advance"."Layer4Protocol" (
    "id" bigserial PRIMARY KEY,
    "name" varchar(40) NOT NULL
);

ALTER TABLE "advance"."Layer4Protocol" OWNER TO "postgres";
COMMENT ON TABLE "advance"."Layer4Protocol" IS '@graphQL.enum';

CREATE TABLE "advance"."User" (
    "id" bigserial PRIMARY KEY,
    "userName" varchar(64) NOT NULL,
    "humanName" varchar(128) NOT NULL,
    "passwordExpiry" timestamp with time zone NOT NULL,
    "lockedOut" boolean NOT NULL,
    "hidden" boolean DEFAULT false NOT NULL,
    "passwordHash" varchar(128) NOT NULL,
    "addedDate" timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "cryptoPostureTemplate" bigint,
    CONSTRAINT "uniqueUserName" UNIQUE("userName")
);

-- Tables with foreign keys
ALTER TABLE "advance"."User" OWNER TO "postgres";
COMMENT ON COLUMN "advance"."User"."id" IS 'The primary key.';
COMMENT ON COLUMN "advance"."User"."userName" IS 'The computer user name.';
COMMENT ON COLUMN "advance"."User"."humanName" IS 'The human user name.';
COMMENT ON COLUMN "advance"."User"."passwordExpiry" IS 'The expiry date of the user’s password.';
COMMENT ON COLUMN "advance"."User"."lockedOut" IS 'True if the user has its password expired.';
COMMENT ON COLUMN "advance"."User"."hidden" IS 'Users are not deleted, only hidden. This field has value true if the user was hidden, and false otherwise.';
COMMENT ON COLUMN "advance"."User"."passwordHash" IS 'The user`s password hash. Contains the generating algorithm, parameters, salt, and final hash.
@graphQL.hide';
COMMENT ON COLUMN "advance"."User"."cryptoPostureTemplate" IS 'The selected template for this user.';

CREATE TABLE "advance"."CryptoPostureTemplate" (
    "id" bigserial PRIMARY KEY,
    "name" varchar(256) NOT NULL,
    "description" varchar(1024) NOT NULL,
    "system" boolean NOT NULL DEFAULT false,
    "addedBy" bigint REFERENCES "advance"."User",
    "addedDate" timestamptz DEFAULT CURRENT_TIMESTAMP NOT NULL
);

ALTER TABLE "advance"."CryptoPostureTemplate" OWNER TO "postgres";
COMMENT ON TABLE "advance"."CryptoPostureTemplate" IS 'Security posture template definitions.';
COMMENT ON COLUMN "advance"."CryptoPostureTemplate"."name" IS 'The short name for the CPT in question.';
COMMENT ON COLUMN "advance"."CryptoPostureTemplate"."description" IS 'A more detailed description of the CPT.';
COMMENT ON COLUMN "advance"."CryptoPostureTemplate"."system" IS 'Indicates that a template is a built-in that is not user-modifiable.
@graphQL.readOnly';
COMMENT ON COLUMN "advance"."CryptoPostureTemplate"."addedBy" IS 'The user who added the template. NULL for built-ins.
@graphQL.readOnly';
COMMENT ON COLUMN "advance"."CryptoPostureTemplate"."addedDate" IS 'The timestamp at which the CPT was added.
@graphQL.readOnly';

-- Due to the 2-way dependency betweek User and CryptoPostureTemplate, this needs to be linked after both are created
ALTER TABLE "advance"."User" ADD FOREIGN KEY ("cryptoPostureTemplate") references "advance"."CryptoPostureTemplate"(id);

CREATE TABLE "advance"."CryptoScoreCoarse" (
    "id" integer PRIMARY KEY,
    "name" varchar(20) NOT NULL,
    "friendlyName" varchar(40) NOT NULL,
    "baseScore" int NOT NULL,
    CONSTRAINT "uniqueCryptoScoreCoarseName" UNIQUE("name"),
    CONSTRAINT "uniqueCryptoScoreCoarsebaseScore" UNIQUE("baseScore")
);

ALTER TABLE "advance"."CryptoScoreCoarse" OWNER TO "postgres";
COMMENT ON TABLE "advance"."CryptoScoreCoarse" IS 'The coarse cryptographic scores
@graphQL.enum
@graphQL.noTraverse';

CREATE TABLE "advance"."CryptoScore" (
    "id" bigserial PRIMARY KEY,
    "name" varchar(40) NOT NULL,
    "friendlyName" varchar(30) NOT NULL,
    "shortName" varchar(30) NOT NULL,
    "score" int NOT NULL,
    "isDefault" boolean NOT NULL DEFAULT false,
    "cryptoScoreCoarse" bigint NOT NULL REFERENCES "advance"."CryptoScoreCoarse",
    "cryptoPostureTemplate" bigint NOT NULL REFERENCES "advance"."CryptoPostureTemplate",
    CONSTRAINT "uniqueCryptoScoreCPTName" UNIQUE("name","cryptoPostureTemplate"),
    CONSTRAINT "uniqueCryptoScoreCPTScore" UNIQUE("score", "cryptoPostureTemplate") INITIALLY DEFERRED
);

-- Ensure that only one default score per CPT is allowed.
CREATE UNIQUE INDEX "uq_advance_CryptoScore_defaultScore"
    on "advance"."CryptoScore"("cryptoPostureTemplate") where "isDefault";

ALTER TABLE "advance"."CryptoScore" OWNER TO "postgres";
COMMENT ON TABLE "advance"."CryptoScore" IS 'The fine grained cryptographic scores
@graphQL.noTraverse';


-- useful to shorten queries when mapping score to cryptoscore hierarchy

CREATE VIEW "advance"."tScore" as select s."friendlyName" as "CryptoScore", sc."friendlyName" as "cryptoScoreCoarse", score
from "advance"."CryptoScore" as s, "advance"."CryptoScoreCoarse" as sc
where (s."cryptoScoreCoarse"=sc.id );

-- ALTER VIEW "advance"."tScore" OWNER TO "postgres";

CREATE TABLE "advance"."CryptoPrimitivePurpose" (
    "id" bigserial PRIMARY KEY,
    "name" varchar(45) NOT NULL,
    CONSTRAINT "uniqueCryptoPrimitivePurposeName" UNIQUE("name")
);

ALTER TABLE "advance"."CryptoPrimitivePurpose" OWNER TO "postgres";
COMMENT ON TABLE "advance"."CryptoPrimitivePurpose" IS '@graphQL.enum';

CREATE TABLE "advance"."CryptoPrimitive" (
    "id" bigserial PRIMARY KEY,
    "name" varchar(1024) NOT NULL,
    "friendlyName" varchar(1024) NOT NULL,
    "cryptoAlgorithm" bigint NOT NULL REFERENCES "advance"."CryptoAlgorithm",
    "oid" varchar(100),
    "variant" varchar(100),
    "isDefault" boolean DEFAULT false NOT NULL,
    "purpose" bigint NOT NULL REFERENCES "advance"."CryptoPrimitivePurpose"
);

ALTER TABLE "advance"."CryptoPrimitive" OWNER TO "postgres";
COMMENT ON TABLE "advance"."CryptoPrimitive" IS 'The cryptographic primitive (and params) used by a device is an important parameter of the crypto agility score of the device.
@graphQL.enum
@graphQL.noTraverse';
COMMENT ON COLUMN "advance"."CryptoPrimitive"."id" IS 'The primary key.';
COMMENT ON COLUMN "advance"."CryptoPrimitive"."name" IS 'The name of the primitive. eg: RSA-512 or ECDSA-secp521r1';
COMMENT ON COLUMN "advance"."CryptoPrimitive"."cryptoAlgorithm" IS 'The algorithm "family" of this primitive';
COMMENT ON COLUMN "advance"."CryptoPrimitive"."oid" IS 'The algorithm oid';
COMMENT ON COLUMN "advance"."CryptoPrimitive"."variant" IS 'The curve oid or the numerical value of the public key size';
COMMENT ON COLUMN "advance"."CryptoPrimitive"."isDefault" IS 'True if the entry represents an indeterminate primitive of a specific family';

CREATE TABLE advance."CryptoPrimitiveDefault" (
    id bigserial PRIMARY KEY,
    "cryptoPrimitive" bigint NOT NULL REFERENCES "advance"."CryptoPrimitive"(id),
    "defaultPrimitive" bigint NOT NULL REFERENCES "advance"."CryptoPrimitive" (id),
    "purpose" bigint NOT NULL REFERENCES "advance"."CryptoPrimitivePurpose" (id),
    CONSTRAINT "uniqueDefaultPrimitive" UNIQUE("cryptoPrimitive")
);

CREATE TABLE "advance"."CryptoPrimitiveScore" (
    "id" bigserial PRIMARY KEY,
    "cryptoPrimitive" bigint NOT NULL REFERENCES "advance"."CryptoPrimitive",
    "cryptoScore" bigint NOT NULL REFERENCES "advance"."CryptoScore",
    UNIQUE("cryptoPrimitive", "cryptoScore")
);

ALTER TABLE "advance"."CryptoPrimitiveScore" OWNER TO "postgres";
COMMENT ON TABLE "advance"."CryptoPrimitiveScore" IS 'Mappings from cryptoprimitives to per-CPT scores.';
COMMENT ON COLUMN "advance"."CryptoPrimitiveScore"."cryptoPrimitive" IS 'The primitive.';
COMMENT ON COLUMN "advance"."CryptoPrimitiveScore"."cryptoScore" IS 'The score mapping. There should only be one per CPT.';

CREATE INDEX ON "advance"."CryptoPrimitiveScore" USING HASH("cryptoPrimitive");
CREATE INDEX ON "advance"."CryptoPrimitiveScore" USING HASH("cryptoScore");

CREATE TABLE "advance"."KeyStoreKey" (
    "id" bigserial PRIMARY KEY,
    "keyStore" bigint NOT NULL REFERENCES "advance"."KeyStore",
    "keyHandle" varchar(45) NOT NULL
);

ALTER TABLE "advance"."KeyStoreKey" OWNER TO "postgres";
COMMENT ON COLUMN "advance"."KeyStoreKey"."id" IS 'The primary key of the linking table between KeyStore and Key tables.';
COMMENT ON COLUMN "advance"."KeyStoreKey"."keyStore" IS 'One of the key stores that has the key handle.';
COMMENT ON COLUMN "advance"."KeyStoreKey"."keyHandle" IS 'One of the key handles that belong to the key store.';

CREATE TABLE "advance"."CertificationAuthority" (
    "id" bigserial PRIMARY KEY,
    "name" varchar(20) NOT NULL,
    "serialNumber" varchar(45) NOT NULL,
    "keyStoreKey" bigint NOT NULL REFERENCES "advance"."KeyStoreKey"
);

ALTER TABLE "advance"."CertificationAuthority" OWNER TO "postgres";
COMMENT ON COLUMN "advance"."CertificationAuthority"."id" IS 'The primary key.';
COMMENT ON COLUMN "advance"."CertificationAuthority"."name" IS 'The name of the certification authority.';
COMMENT ON COLUMN "advance"."CertificationAuthority"."serialNumber" IS 'The serial number of the certification authority.';
COMMENT ON COLUMN "advance"."CertificationAuthority"."keyStoreKey" IS 'The key store containing the handle.';

-- TODO (#1514): Remove "publicKeyType" and "publicKeyParameter" which are replaced
-- by the new "publicKeyCryptoPrimitive" and "publicKeyCryptoPrimitiveParameter",
-- respectively (#2274) once ExtraHop has moved to the new field.
CREATE TABLE "advance"."Certificate" (
    "fingerprint" varchar(120) PRIMARY KEY,
    "certificateType" varchar(50) NOT NULL DEFAULT 'X509',
    "certificateContent" "text",
    "subject" varchar(2048) NOT NULL,
    "issuer" varchar(2048) NOT NULL,
    "issuerCertificate" bigint ,
    "internalIssuer" bigint ,
    "notBefore" timestamp with time zone,
    "notAfter" timestamp with time zone,
    "publicKeyType" varchar(50)  NULL,
    "publicKeyParameter" varchar(100)  NULL,
    "publicKeyCryptoPrimitive" varchar(50)  NULL,
    "publicKeyCryptoPrimitiveParameter" integer  NULL,
    "issuerSigAndHash" varchar(100)  NULL,
    "serial" varchar(200),
    "alternateNames" text,
    "manuallyAdded" boolean NOT NULL DEFAULT true,
    "observedAt" timestamp with time zone NOT NULL default now(),
    CONSTRAINT "uniqueCertfingerprint" UNIQUE("fingerprint")
);

ALTER TABLE "advance"."Certificate" OWNER TO "postgres";
COMMENT ON COLUMN "advance"."Certificate"."certificateType" IS 'The type of the certificate: X509 or CATALYST';
COMMENT ON COLUMN "advance"."Certificate"."certificateContent" IS 'The raw content of the certificate, if available';
COMMENT ON COLUMN "advance"."Certificate"."subject" IS 'The certificate subject FDN.';
COMMENT ON COLUMN "advance"."Certificate"."issuer" IS 'The certificate authority that issued the certificate';
COMMENT ON COLUMN "advance"."Certificate"."issuerCertificate" IS 'The certificate of the issuer';
COMMENT ON COLUMN "advance"."Certificate"."internalIssuer" IS 'The internal certificate authority who signed certificate';
COMMENT ON COLUMN "advance"."Certificate"."notBefore" IS 'The earliest validity timestamp of the certificate';
COMMENT ON COLUMN "advance"."Certificate"."notAfter" IS 'The expiration timestamp of the certificate';
COMMENT ON COLUMN "advance"."Certificate"."serial" IS 'The serial number of the certificate';
COMMENT ON COLUMN "advance"."Certificate"."alternateNames" IS 'A comma-separated list of SANs, if applicable';
COMMENT ON COLUMN "advance"."Certificate"."fingerprint" IS 'SHA1 hash of the certificate content, when content is available';
COMMENT ON COLUMN "advance"."Certificate"."manuallyAdded" IS 'Manually added/edited certificate vs from ingestion source.
@graphQL.hide';
COMMENT ON COLUMN "advance"."Certificate"."observedAt" IS 'Last observation time of certificate.
@graphQL.hide';

CREATE TABLE advance."Device" (
  "id" bigserial NOT NULL primary key,
  "observedAt" timestamp with time zone NOT NULL,
  "taniumName" character varying(1024) NULL, --could be array or Jsonb
  "ipAddress" character varying(50) NOT NULL,
  "ipVersion" bigint NOT NULL, -- information purposes only
  "deviceType" character varying(100)  NULL,  -- populated from Extrahop??, inferred from connections
  "macAddress" character varying(50) NULL, -- information purposes only
  "osType" character varying(100), -- from Tanium, Unknown otherwise,
  "hostnames" character varying,
  "taniumID" character varying,
  "extrahopDiscoveryID" character varying,
  UNIQUE("ipAddress")

 -- Do we need AddressHex??
);

ALTER TABLE "advance"."Device" OWNER TO "postgres";

CREATE TABLE advance."DeviceScore" (
  "ipAddress" character varying(50) NOT NULL,
  "cryptoPostureTemplate" bigint  ,
  "cryptoScore" bigint,
  UNIQUE("ipAddress")
);

ALTER TABLE "advance"."DeviceScore" OWNER TO "postgres";

COMMENT ON TABLE "advance"."DeviceScore" IS 'Mappings from devices to per-CPT scores.';
COMMENT ON COLUMN "advance"."DeviceScore"."cryptoScore" IS 'The score mapping. There should only be one per CPT.';


CREATE TABLE "advance"."Agent" (
    "id" bigserial PRIMARY KEY
    --"device" bigint NOT NULL REFERENCES "advance"."Device"
);

ALTER TABLE "advance"."Agent" OWNER TO "postgres";
COMMENT ON TABLE "advance"."Agent" IS 'The agent installed on a device.';
COMMENT ON COLUMN "advance"."Agent"."id" IS 'The primary key.';
--COMMENT ON COLUMN "advance"."Agent"."device" IS 'The device on which the agent is installed.';


CREATE TABLE "advance"."AgentCertificate" (
    "id" bigserial PRIMARY KEY,
    "agent" bigint NOT NULL REFERENCES "advance"."Agent",
    "certificate" bigint NOT NULL
);

ALTER TABLE "advance"."AgentCertificate" OWNER TO "postgres";
COMMENT ON TABLE "advance"."AgentCertificate" IS 'The linking table between Agent and Certificate tables.';
COMMENT ON COLUMN "advance"."AgentCertificate"."id" IS 'The primary key.';
COMMENT ON COLUMN "advance"."AgentCertificate"."agent" IS 'One of the agents that uses the certificate.';
COMMENT ON COLUMN "advance"."AgentCertificate"."certificate" IS 'One of the certificates that is used by the agent.';


CREATE TABLE "advance"."CAIssuedCertificate" (
    "id" bigserial PRIMARY KEY,
    "certificationAuthority" bigint NOT NULL REFERENCES "advance"."CertificationAuthority",
    "certificate" bigint NOT NULL,
    "whenIssued" timestamp with time zone NOT NULL,
    "whenRevoked" timestamp with time zone,
    "whenExpired" timestamp with time zone NOT NULL
);

ALTER TABLE "advance"."CAIssuedCertificate" OWNER TO "postgres";
COMMENT ON TABLE "advance"."CAIssuedCertificate" IS 'Linking table between Certificate and CertificateAuthority tables. ';
COMMENT ON COLUMN "advance"."CAIssuedCertificate"."id" IS 'The primary key.';
COMMENT ON COLUMN "advance"."CAIssuedCertificate"."certificationAuthority" IS 'The certificate authority that issued the certificate.';
COMMENT ON COLUMN "advance"."CAIssuedCertificate"."certificate" IS 'The certificate issued by the certificate authority.';
COMMENT ON COLUMN "advance"."CAIssuedCertificate"."whenIssued" IS 'The time when the certificate was issued.';
COMMENT ON COLUMN "advance"."CAIssuedCertificate"."whenRevoked" IS 'The time when the certificate was revoked. In the case where the certificate is not yet revoked this field is null.';
COMMENT ON COLUMN "advance"."CAIssuedCertificate"."whenExpired" IS 'The expiry date of the certificate.';

CREATE TABLE "advance"."CertificateCryptoPrimitive" (
    "id" bigserial PRIMARY KEY,
  "certificate" bigint NOT NULL ,
    "fingerprint" varchar(120),
    "cryptoPrimitive" varchar(1024) NOT NULL,
    "keyLength" varchar(1024),
    UNIQUE ("fingerprint","cryptoPrimitive")
);

ALTER TABLE "advance"."CertificateCryptoPrimitive" OWNER TO "postgres";
COMMENT ON TABLE "advance"."CertificateCryptoPrimitive" IS 'Linking table between Certificate and CryptoPrimitive tables.';
COMMENT ON COLUMN "advance"."CertificateCryptoPrimitive"."fingerprint" IS ' maps to fingerprint on certificate table';
COMMENT ON COLUMN "advance"."CertificateCryptoPrimitive"."certificate" IS 'Is this a redundant column for fingerprint';
COMMENT ON COLUMN "advance"."CertificateCryptoPrimitive"."cryptoPrimitive" IS ' maps to name column on cryptoprimitive table';
COMMENT ON COLUMN "advance"."CertificateCryptoPrimitive"."keyLength" IS 'Length of the key used in algorithm.';



CREATE TABLE "advance"."CipherSuiteCryptoPrimitive" (
    "id" bigserial PRIMARY KEY,
    "cipherSuite" bigint NOT NULL REFERENCES "advance"."CipherSuite",
    "cryptoPrimitive" bigint NOT NULL REFERENCES "advance"."CryptoPrimitive"
);

ALTER TABLE "advance"."CipherSuiteCryptoPrimitive" OWNER TO "postgres";
COMMENT ON TABLE "advance"."CipherSuiteCryptoPrimitive" IS 'Linking table between CipherSuite and CryptoPrimitive keys.';
COMMENT ON COLUMN "advance"."CipherSuiteCryptoPrimitive"."id" IS 'The primary key.';
COMMENT ON COLUMN "advance"."CipherSuiteCryptoPrimitive"."cipherSuite" IS 'One of the cipher suites that contains the crypto primitive.';
COMMENT ON COLUMN "advance"."CipherSuiteCryptoPrimitive"."cryptoPrimitive" IS 'One of the crypto primitives used in the cipher suite.';

CREATE TABLE "advance"."Software" (
    "id" bigserial PRIMARY KEY,
    "name" varchar(1024) NOT NULL,
    "softwareVendor" varchar(1024) NOT NULL,
    "softwareType" bigint NOT NULL REFERENCES "advance"."SoftwareType",
    "addedBy" bigint REFERENCES "advance"."User",
    "addedAt" timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);

ALTER TABLE "advance"."Software" OWNER TO "postgres";
COMMENT ON TABLE "advance"."Software" IS 'A set of programs running on the device machine. It can be an operational system, a crypto library or a network security software.
The type of software, it’s upgradability, the used cipher suites, etc, influences the crypto-agility score of the device.';
COMMENT ON COLUMN "advance"."Software"."id" IS 'The primary key.';
COMMENT ON COLUMN "advance"."Software"."name" IS 'The name of the software.';
COMMENT ON COLUMN "advance"."Software"."softwareVendor" IS 'The vendor of the software.';
COMMENT ON COLUMN "advance"."Software"."softwareType" IS 'The type of software.';
COMMENT ON COLUMN "advance"."Software"."addedBy" IS 'The user that added the software.
@graphQL.readOnly';
COMMENT ON COLUMN "advance"."Software"."addedAt" IS 'The time the software was first added to the database.
@graphQL.readOnly';

CREATE TABLE "advance"."SoftwareVersion" (
    "id" bigserial PRIMARY KEY,
    "software" bigint NOT NULL REFERENCES "advance"."Software",
    "name" varchar(1024) NOT NULL,
    "version" varchar(50) NOT NULL,
    "sortableVersion" integer NOT NULL,
    "score" integer,
    "binaryHash" character(64)
);

ALTER TABLE "advance"."SoftwareVersion" OWNER TO "postgres";
COMMENT ON TABLE "advance"."SoftwareVersion" IS 'In order to calculate the crypto-agility score, the system needs to be able to extract the information about the upgradability of relevant applications, such as the version of the software and check for its latest updates.';
COMMENT ON COLUMN "advance"."SoftwareVersion"."id" IS 'The primary key.';
COMMENT ON COLUMN "advance"."SoftwareVersion"."software" IS 'The software used on a device.';
COMMENT ON COLUMN "advance"."SoftwareVersion"."name" IS 'The translation of the software name.';
COMMENT ON COLUMN "advance"."SoftwareVersion"."version" IS 'The version of the software.';
COMMENT ON COLUMN "advance"."SoftwareVersion"."sortableVersion" IS 'If sortable, e.g. ..< Windows 7 < Windows 8 < Windows 10';
COMMENT ON COLUMN "advance"."SoftwareVersion"."score" IS 'The score assigned to the version of the software. This score is a parameter of the agility score of the device (see formula in the Device table description).
@graphQL.readOnly';
COMMENT ON COLUMN "advance"."SoftwareVersion"."binaryHash" IS 'The sha256 hash of the application binary.';

CREATE TABLE "advance"."SoftwareLibrary" (
    "id" bigserial PRIMARY KEY,
    "name" varchar(1024) NOT NULL,
    "version" varchar(50) NOT NULL,
    "sortableVersion" integer NOT NULL,
    "libraryHash" character(64)
);

ALTER TABLE "advance"."SoftwareLibrary" OWNER TO "postgres";
COMMENT ON TABLE "advance"."SoftwareLibrary" IS 'In order to calculate the crypto-agility score, the system needs to be able to extract the information about the upgradability of relevant software dependencies.';
COMMENT ON COLUMN "advance"."SoftwareLibrary"."id" IS 'The primary key.';
COMMENT ON COLUMN "advance"."SoftwareLibrary"."name" IS 'The name of the library.';
COMMENT ON COLUMN "advance"."SoftwareLibrary"."libraryHash" IS 'The sha256 hash of the library binary.';

CREATE TABLE "advance"."DeviceSoftwareVersionLibrary" (
    "id" bigserial PRIMARY KEY,
    --"device" bigint NOT NULL REFERENCES "advance"."Device",
    "softwareVersion" bigint NOT NULL REFERENCES "advance"."SoftwareVersion",
    "softwareLibrary" bigint NOT NULL REFERENCES "advance"."SoftwareLibrary",
    "path" varchar(1024) NOT NULL
);

ALTER TABLE "advance"."DeviceSoftwareVersionLibrary" OWNER TO "postgres";
COMMENT ON TABLE "advance"."DeviceSoftwareVersionLibrary" IS 'Linking table between Device, Software Version, and SoftwareLibrary tables.';
COMMENT ON COLUMN "advance"."DeviceSoftwareVersionLibrary"."id" IS 'The primary key.';
--COMMENT ON COLUMN "advance"."DeviceSoftwareVersionLibrary"."device" IS 'The name of the library.';
COMMENT ON COLUMN "advance"."DeviceSoftwareVersionLibrary"."softwareVersion" IS 'The name of the library.';
COMMENT ON COLUMN "advance"."DeviceSoftwareVersionLibrary"."softwareLibrary" IS 'The path of the library.';
COMMENT ON COLUMN "advance"."DeviceSoftwareVersionLibrary"."path" IS 'The path of the library being linked by the software running on the device.';

CREATE TABLE advance."DeviceSoftware" (
    "id" bigserial NOT NULL primary key,
    "observedAt" timestamp with time zone NOT NULL,
    "path" character varying(1024) NULL,
    "user" character varying(1024) NULL,
    "device" character varying(50) NOT NULL,
    "binaryHash" character varying  NULL,
    "sortableVersion" integer NULL,  
    "version" character varying(50) NULL,
    "name" character varying(1024) NOT NULL, -- Human readable Software name
    "type" character varying(1024)  NULL,  -- Do we get Software Type?
    "port" integer NULL, -- Port software was seen running
    UNIQUE("device", "port")
);

ALTER TABLE "advance"."DeviceSoftware" OWNER TO "postgres";

CREATE TABLE "advance"."ConfigurationFile" (
    "id" bigserial PRIMARY KEY,
    "date" timestamp with time zone NOT NULL,
    "hidden" boolean DEFAULT false NOT NULL,
    "path" varchar(45) NOT NULL,
    "deviceSoftware" bigint NOT NULL
);

ALTER TABLE "advance"."ConfigurationFile" OWNER TO "postgres";
COMMENT ON TABLE "advance"."ConfigurationFile" IS 'The file used to configure the parameters and initial settings for a device software.';
COMMENT ON COLUMN "advance"."ConfigurationFile"."id" IS 'The primary key.';
COMMENT ON COLUMN "advance"."ConfigurationFile"."date" IS 'The time the configuration file was created/modified.';
COMMENT ON COLUMN "advance"."ConfigurationFile"."hidden" IS 'True is the configuration file is hidden (we do not delete it), and fall otherwise.';
COMMENT ON COLUMN "advance"."ConfigurationFile"."path" IS 'The path to the location of the configuration file.';
COMMENT ON COLUMN "advance"."ConfigurationFile"."deviceSoftware" IS 'The device software.';


CREATE TABLE "advance"."ConfigurationFileCertificate" (
    "id" bigserial PRIMARY KEY,
    "configurationFile" bigint NOT NULL REFERENCES "advance"."ConfigurationFile",
    "certificate" bigint NULL
);

ALTER TABLE "advance"."ConfigurationFileCertificate" OWNER TO "postgres";
COMMENT ON TABLE "advance"."ConfigurationFileCertificate" IS '?? Needs more description…
Linking table between ConfigurationFile and Certificate tables.
';
COMMENT ON COLUMN "advance"."ConfigurationFileCertificate"."id" IS 'The primary key.';

CREATE TABLE "advance"."ConfigurationFileCipherSuite" (
    "id" bigserial PRIMARY KEY,
    "configurationFile" bigint NOT NULL REFERENCES "advance"."ConfigurationFile",
    "cipherSuite" bigint NOT NULL REFERENCES "advance"."CipherSuite"
);

ALTER TABLE "advance"."ConfigurationFileCipherSuite" OWNER TO "postgres";
COMMENT ON TABLE "advance"."ConfigurationFileCipherSuite" IS 'Linking table between ConfigurationFile and CipherSuite tables. ';
COMMENT ON COLUMN "advance"."ConfigurationFileCipherSuite"."id" IS 'The primary key.';
COMMENT ON COLUMN "advance"."ConfigurationFileCipherSuite"."configurationFile" IS 'The configuration file.';
COMMENT ON COLUMN "advance"."ConfigurationFileCipherSuite"."cipherSuite" IS 'The cipher suite.';

CREATE TABLE advance."Connection" (
    "id" bigserial primary key,
    "observedAt" timestamp with time zone NOT NULL,
    "friendlyName" character varying(1024) NULL,  -- keep, collector is source
    "custom" character varying(1024) NULL, -- Leaving in as a placeholder
    "serverAddress" varchar(50) NOT NULL,
    "port" integer NOT NULL,
    "l4Protocol" character varying(40) NULL,
    "clientAddress" varchar(50) NOT NULL, --Could apply netmask to aggregate the internet
    "connectionCount" bigint NOT NULL default 1,
    UNIQUE("serverAddress", "port", "clientAddress", "l4Protocol")
);

ALTER TABLE "advance"."Connection" OWNER TO "postgres";

CREATE TABLE advance."ConnectionScore" (
  "l4Protocol" character varying(40) NULL,
  "clientAddress" character varying(50) NOT NULL,
  port integer NOT NULL,
  "serverAddress" character varying(50) NOT NULL,
  "cryptoPostureTemplate" bigint,
  "cryptoScore" bigint,
  "signature" character varying(2000) NULL,
  "bulkencryption" character varying(2000) NULL,
  "hash" character varying(2000) NULL,
  "key_exchange" character varying(2000) NULL,
  "mac" character varying(2000) NULL,
  "mode_of_operation" character varying(2000) NULL,
  id bigint ,
  UNIQUE("serverAddress", "port", "clientAddress", "l4Protocol")
);

ALTER TABLE "advance"."ConnectionScore" OWNER TO "postgres";
COMMENT ON TABLE "advance"."ConnectionScore" IS 'Mappings from connections to per-CPT scores.';
COMMENT ON COLUMN "advance"."ConnectionScore"."cryptoScore" IS 'The score mapping. There should only be one per CPT.';


CREATE TABLE "advance"."DeviceCertificate" (
    "id" bigserial PRIMARY KEY,
    "serverAddress" varchar(50) NOT NULL,
    "port" integer NOT NULL,
    "clientAddress" varchar(50)  NULL,
    "l4Protocol" character varying(40) NULL,
    fingerprint character varying(120) NULL,
    "observedAt" timestamp with time zone NOT NULL,
    "notAfter" timestamp with time zone NULL,
    "notBefore" timestamp with time zone NULL,
    issuer character varying(2048) NOT NULL,
    subject character varying(2048) NOT NULL,
    "certificateContent" text NULL,
    "certificateType" varchar(50) NULL,
    CONSTRAINT "uniqueDeviceCertificate" UNIQUE("serverAddress", "port", "clientAddress", "l4Protocol", fingerprint, "issuer", "subject")
);

ALTER TABLE "advance"."DeviceCertificate" OWNER TO "postgres";
COMMENT ON TABLE "advance"."DeviceCertificate" IS 'Linking table between Device and Certificate. ';
COMMENT ON COLUMN "advance"."DeviceCertificate"."notAfter" IS 'Corresponds to certificate Expiry date ';
COMMENT ON COLUMN "advance"."DeviceCertificate"."notBefore" IS 'Corresponds to certificate Creation date ';


CREATE TABLE "advance"."ConnectionCipherSuite" (
    "id" bigserial primary key,
    "observedAt" timestamp with time zone NOT NULL,
    "cipherSuite" varchar(1024) NOT NULL,
    "serverAddress" varchar(50) NOT NULL,
    "port" integer NOT NULL,
    "clientAddress" varchar(50) NOT NULL,
    "l4Protocol" character varying(40) NULL,
    UNIQUE("serverAddress", "port", "clientAddress", "l4Protocol", "cipherSuite")
);

ALTER TABLE "advance"."ConnectionCipherSuite" OWNER TO "postgres";

CREATE TABLE "advance"."ConnectionCryptoPrimitive" (
    "id" bigserial primary key,
    "observedAt" timestamp with time zone NOT NULL,
    "cryptoPrimitive" varchar(1024) NOT NULL,
    "serverAddress" varchar(50) NOT NULL,
    "port" integer NOT NULL,
    "clientAddress" varchar(50) NOT NULL,
    "l4Protocol" character varying(40) NULL,
    "cryptoPrimitiveParameter" integer NULL,
    UNIQUE("serverAddress", "port", "clientAddress", "l4Protocol", "cryptoPrimitive")
);

ALTER TABLE "advance"."ConnectionCryptoPrimitive" OWNER TO "postgres";

CREATE TABLE "advance"."ProtocolVariant" (
    "id" bigserial PRIMARY KEY,
    "name" varchar(1024) NOT NULL,
    "codePoint" int,
    "protocol" bigint NOT NULL REFERENCES "advance"."Protocol",
    CONSTRAINT "protocolVariantName" UNIQUE("name", "protocol")
);

ALTER TABLE "advance"."ProtocolVariant" OWNER TO "postgres";
COMMENT ON TABLE "advance"."ProtocolVariant" IS 'One of the parameters of the crypto agility score is the protocol used and its version.';
COMMENT ON COLUMN "advance"."ProtocolVariant"."name" IS 'The protocol variant’s translation.';
COMMENT ON COLUMN "advance"."ProtocolVariant"."codePoint" IS 'The variant codepoint, if available. This primarily applies to SSL/TLS.
@graphQL.hide';
COMMENT ON COLUMN "advance"."ProtocolVariant"."protocol" IS 'The protocol.';

CREATE TABLE "advance"."ProtocolVariantScore" (
    "id" bigserial PRIMARY KEY,
    "protocolVariant" bigint NOT NULL REFERENCES "advance"."ProtocolVariant",
    "cryptoScore" bigint NOT NULL REFERENCES "advance"."CryptoScore",
    UNIQUE("protocolVariant", "cryptoScore")
);

ALTER TABLE "advance"."ProtocolVariantScore" OWNER TO "postgres";
COMMENT ON TABLE "advance"."ProtocolVariantScore" IS 'Mappings from protocol variants to per-CPT scores.';
COMMENT ON COLUMN "advance"."ProtocolVariantScore"."protocolVariant" IS 'The protocol variant.';
COMMENT ON COLUMN "advance"."ProtocolVariantScore"."cryptoScore" IS 'The score mapping. There should only be one per CPT.';

CREATE INDEX ON "advance"."ProtocolVariantScore" USING HASH("protocolVariant");
CREATE INDEX ON "advance"."ProtocolVariantScore" USING HASH("cryptoScore");

CREATE TABLE "advance"."ConnectionProtocolVariant" (
    "id" bigserial primary key,
    "observedAt" timestamp with time zone NOT NULL,
    "protocolVariant" varchar(1024) NOT NULL,
    "serverAddress" varchar(50) NOT NULL,
    "port" integer NOT NULL,
    "clientAddress" varchar(50) NOT NULL,
    "l4Protocol" character varying(40) NULL,
    UNIQUE("serverAddress", "port", "clientAddress", "l4Protocol", "protocolVariant")
);

ALTER TABLE "advance"."ConnectionProtocolVariant" OWNER TO "postgres";

CREATE TABLE "advance"."ConnectionProtocolVariantCertificate" (
    "id" bigserial PRIMARY KEY,
    "connectionProtocolVariant" bigint NOT NULL REFERENCES "advance"."ConnectionProtocolVariant",
    "connectionCertificateType" bigint NOT NULL REFERENCES "advance"."ConnectionCertificateType",
    "certificate" bigint NOT NULL ,
    "manuallyAdded" boolean NOT NULL DEFAULT true,
    "observedAt" timestamptz NOT NULL DEFAULT now()
);

ALTER TABLE "advance"."ConnectionProtocolVariantCertificate" OWNER TO "postgres";
COMMENT ON TABLE "advance"."ConnectionProtocolVariantCertificate" IS 'Linking table between ConnectionProtocol and Certificate keys.';
COMMENT ON COLUMN "advance"."ConnectionProtocolVariantCertificate"."id" IS 'The primary key.';
COMMENT ON COLUMN "advance"."ConnectionProtocolVariantCertificate"."manuallyAdded" IS 'Manually added/edited variant certificate vs from ingestion source.
@graphQL.hide';
COMMENT ON COLUMN "advance"."ConnectionProtocolVariantCertificate"."observedAt" IS 'Last observation time of variant certificate.
@graphQL.hide';

CREATE TABLE "advance"."ConnectionTag" (
    "id" bigserial PRIMARY KEY,
    "connection" bigint NOT NULL REFERENCES "advance"."Connection",
    "tag" bigint NOT NULL REFERENCES "advance"."Tag",
    CONSTRAINT "uniqueConnectionTag" UNIQUE("connection","tag")
);

ALTER TABLE "advance"."ConnectionTag" OWNER TO "postgres";

CREATE TABLE "advance"."SearchIndexExportSchedule" (
    "id" bigserial PRIMARY KEY,
    "scheduleActive" boolean NOT NULL,
    "timezone" varchar(45),
    "cronish" varchar(90)
);

CREATE TABLE "advance"."SearchIndexExport" (
    "id" bigserial PRIMARY KEY,
    "addedAt" timestamp with time zone NOT NULL,
    "status" varchar(50) NOT NULL,
    "errorMessage" varchar,
    "summary" varchar NOT NULL
);

ALTER TABLE "advance"."SearchIndexExport" OWNER TO "postgres";
COMMENT ON TABLE "advance"."SearchIndexExport" IS 'The log of Search Index Export jobs';
COMMENT ON COLUMN "advance"."SearchIndexExport"."id" IS 'The primary key.';
COMMENT ON COLUMN "advance"."SearchIndexExport"."addedAt" IS '@graphQL.readOnly';
COMMENT ON COLUMN "advance"."SearchIndexExport"."status" IS 'Running state of this export: ie running, failed, complete';
COMMENT ON COLUMN "advance"."SearchIndexExport"."errorMessage" IS 'An error message that may have come back from the Typesense server.
@graphQL.readOnly';
COMMENT ON COLUMN "advance"."SearchIndexExport"."summary" IS 'Textual summary of actions taken. Eg: 500 +0';


CREATE TABLE "advance"."DataSource" (
    "id" bigserial PRIMARY KEY,
    "friendlyName" varchar(1024) NOT NULL,
    "configuration" text NOT NULL,
    "softwareVersion" bigint NOT NULL REFERENCES "advance"."SoftwareVersion",
    "addedBy" bigint NOT NULL REFERENCES "advance"."User",
    "addedAt" timestamp with time zone NOT NULL,
    "status" bigint NOT NULL REFERENCES "advance"."DataSourceStatus",
    "lastModified" timestamp with time zone NOT NULL,
    "errorMessage" varchar(200),
    "scanCount" int NOT NULL DEFAULT 0
);

ALTER TABLE "advance"."DataSource" OWNER TO "postgres";
COMMENT ON TABLE "advance"."DataSource" IS 'The baseline provider configuration for a given data source (i.e. authentication).';
COMMENT ON COLUMN "advance"."DataSource"."id" IS 'The primary key.';
COMMENT ON COLUMN "advance"."DataSource"."friendlyName" IS 'The friendly name of the provider.';
COMMENT ON COLUMN "advance"."DataSource"."configuration" IS 'The configuration itself as a blob.

eg: { url: “http://tenable.io”, token:”afiaoiejfiejfiajesifjasef” } ';
COMMENT ON COLUMN "advance"."DataSource"."softwareVersion" IS 'The software associated with this provider (e.g. Tanium 7.3).';
COMMENT ON COLUMN "advance"."DataSource"."addedBy" IS '@graphQL.readOnly';
COMMENT ON COLUMN "advance"."DataSource"."addedAt" IS '@graphQL.readOnly';
COMMENT ON COLUMN "advance"."DataSource"."status" IS 'eg: paused/deleted/pending first ever connect/errored/good?
@graphQL.readOnly';
COMMENT ON COLUMN "advance"."DataSource"."lastModified" IS '@graphQL.readOnly';
COMMENT ON COLUMN "advance"."DataSource"."errorMessage" IS 'An error message that may have come back from the 3rd party system.
@graphQL.readOnly';
COMMENT ON COLUMN "advance"."DataSource"."scanCount" IS 'The number of scans associated with this Data Source.
@graphQL.readOnly';

CREATE TABLE "advance"."DataSourceScan" (
    "id" bigserial PRIMARY KEY,
    "friendlyName" varchar(1024) NOT NULL,
    "dataSource" bigint NOT NULL REFERENCES "advance"."DataSource",
    "lastStatus" bigint REFERENCES "advance"."DataSourceScanResultStatus",
    "configuration" text NOT NULL,
    "metadata" text,
    "addedBy" bigint NOT NULL REFERENCES "advance"."User",
    "addedAt" timestamp with time zone NOT NULL,
    "lastModified" timestamp with time zone NOT NULL,
    "scanCount" int NOT NULL DEFAULT 0
);

ALTER TABLE "advance"."DataSourceScan" OWNER TO "postgres";
COMMENT ON TABLE "advance"."DataSourceScan" IS 'Configuration for individual scans tied to a specific datasource, e.g. a specific device group in Tanium.';
COMMENT ON COLUMN "advance"."DataSourceScan"."id" IS 'The primary key.';
COMMENT ON COLUMN "advance"."DataSourceScan"."friendlyName" IS 'The friendly name of the scan configuration';
COMMENT ON COLUMN "advance"."DataSourceScan"."configuration" IS 'The configuration blob providing parameters for this specific scan instance';
COMMENT ON COLUMN "advance"."DataSourceScan"."metadata" IS 'Internal metadata used by the scan itself for maintaining state across runs, such as
the last timestamp range scanned for extrahop.
@graphQL.hide';
COMMENT ON COLUMN "advance"."DataSourceScan"."addedBy" IS '@graphQL.readOnly';
COMMENT ON COLUMN "advance"."DataSourceScan"."addedAt" IS '@graphQL.readOnly';
COMMENT ON COLUMN "advance"."DataSourceScan"."lastModified" IS '@graphQL.readOnly';
COMMENT ON COLUMN "advance"."DataSourceScan"."scanCount" IS 'The number of times this scan instance has been successfully run.
@graphQL.readOnly';

CREATE TABLE "advance"."DataSourceScanTag" (
    "id" bigserial PRIMARY KEY,
    "dataSourceScan" bigint NOT NULL REFERENCES "advance"."DataSourceScan",
    "tag" bigint NOT NULL REFERENCES "advance"."Tag",
    CONSTRAINT "uniqueDataSourceScanTag" UNIQUE("dataSourceScan", "tag")
);

ALTER TABLE "advance"."DataSourceScanTag" OWNER TO "postgres";
COMMENT ON TABLE "advance"."DataSourceScanTag" IS 'The set of tags to apply to ingested objects for a given scan.';
COMMENT ON COLUMN "advance"."DataSourceScanTag"."id" IS 'The primary key.';
COMMENT ON COLUMN "advance"."DataSourceScanTag"."dataSourceScan" IS 'The scan with which the key is associated.';
COMMENT ON COLUMN "advance"."DataSourceScanTag"."tag" IS 'The tag to associate with the target scan.';

CREATE TABLE "advance"."DataSourceScanSchedule" (
    "id" bigserial PRIMARY KEY,
    "dataSourceScan" bigint NOT NULL REFERENCES "advance"."DataSourceScan",
    "friendlyName" varchar(1024) NOT NULL,
    "scheduleActive" boolean NOT NULL,
    "timezone" varchar(45),
    "cronish" varchar(90),
    "start" timestamp with time zone,
    "end" timestamp with time zone,
    "addedBy" bigint NOT NULL REFERENCES "advance"."User",
    "addedAt" timestamp with time zone NOT NULL,
    "lastModified" timestamp with time zone,
    "description" varchar(1024)
);

ALTER TABLE "advance"."DataSourceScanSchedule" OWNER TO "postgres";
COMMENT ON TABLE "advance"."DataSourceScanSchedule" IS 'The scan schedule for a particular scan.';
COMMENT ON COLUMN "advance"."DataSourceScanSchedule"."id" IS 'The primary key.';
COMMENT ON COLUMN "advance"."DataSourceScanSchedule"."dataSourceScan" IS 'The ingestion configuration.';
COMMENT ON COLUMN "advance"."DataSourceScanSchedule"."addedBy" IS '@graphQL.readOnly';
COMMENT ON COLUMN "advance"."DataSourceScanSchedule"."addedAt" IS '@graphQL.readOnly';

CREATE TABLE "advance"."DataSourceScanResult" (
    "id" bigserial PRIMARY KEY,
    "dataSourceScan" bigint NOT NULL REFERENCES "advance"."DataSourceScan",
    "friendlyName" varchar(1024),
    "tag" bigint REFERENCES "advance"."Tag",
    "runBy" bigint REFERENCES "advance"."User",
    "runAt" timestamp with time zone NOT NULL,
    "status" bigint NOT NULL REFERENCES "advance"."DataSourceScanResultStatus",
    "errorMessage" varchar,
    "summary" varchar NOT NULL,
    "duration" integer NOT NULL DEFAULT 0,
    "meta" text
);

ALTER TABLE "advance"."DataSourceScanResult" OWNER TO "postgres";
COMMENT ON TABLE "advance"."DataSourceScanResult" IS '@graphQL.readOnly';
COMMENT ON COLUMN "advance"."DataSourceScanResult"."friendlyName" IS 'The scan name at time of execution.';
COMMENT ON COLUMN "advance"."DataSourceScanResult"."status" IS 'eg: paused / deleted';
COMMENT ON COLUMN "advance"."DataSourceScanResult"."summary" IS 'Textual summary of actions taken. Eg: 500 +0';
COMMENT ON COLUMN "advance"."DataSourceScanResult"."errorMessage" IS 'Error description in the case of a critical failure.';
COMMENT ON COLUMN "advance"."DataSourceScanResult"."duration" IS 'Units: milliseconds';
COMMENT ON COLUMN "advance"."DataSourceScanResult"."meta" IS 'Metadata JSON associated with the Scan Result.';

CREATE TABLE "advance"."DataSourceScanResultDetail" (
    "id" bigserial PRIMARY KEY,
    "dataSourceScanResult" bigint NOT NULL REFERENCES "advance"."DataSourceScanResult",
    "when" timestamp with time zone NOT NULL,
    "recordId" varchar(64) NOT NULL,
    "message" varchar(1024) NOT NULL,
    "recordType" varchar(64),
    "recordData" text NOT NULL
);

ALTER TABLE "advance"."DataSourceScanResultDetail" OWNER TO "postgres";
COMMENT ON TABLE "advance"."DataSourceScanResultDetail" IS '@graphQL.readOnly';
COMMENT ON COLUMN "advance"."DataSourceScanResultDetail"."dataSourceScanResult" IS 'The scan result to which this detail record relates.';
COMMENT ON COLUMN "advance"."DataSourceScanResultDetail"."when" IS 'The timestamp at which this record was processed.';
COMMENT ON COLUMN "advance"."DataSourceScanResultDetail"."recordId" IS 'A unique identifier tying this record back to the scan object which was attempting to be processed.';
COMMENT ON COLUMN "advance"."DataSourceScanResultDetail"."message" IS 'The error message for the record.';
COMMENT ON COLUMN "advance"."DataSourceScanResultDetail"."recordType" IS 'The type of record. Will vary based on Data Source.';
COMMENT ON COLUMN "advance"."DataSourceScanResultDetail"."recordData" IS 'Blob containing the JSON representation of the record.';



CREATE TABLE "advance"."DeviceSoftwareConnection" (
    "id" bigserial PRIMARY KEY,
    "deviceSoftware" bigint NOT NULL REFERENCES "advance"."DeviceSoftware",
    "connection" bigint NOT NULL REFERENCES "advance"."Connection"
);

ALTER TABLE "advance"."DeviceSoftwareConnection" OWNER TO "postgres";

CREATE TABLE "advance"."Notification" (
    "id" bigserial PRIMARY KEY,
    "addedAt" timestamp with time zone NOT NULL,
    "type" bigint NOT NULL REFERENCES "advance"."NotificationType",
    "title" varchar(256) NOT NULL,
    "description" varchar(2048) NOT NULL,
    "url" varchar(256),
    "originatedBy" bigint NOT NULL REFERENCES "advance"."User"
);

ALTER TABLE "advance"."Notification" OWNER TO "postgres";
COMMENT ON COLUMN "advance"."Notification"."addedAt" IS '@graphQL.readOnly';
COMMENT ON COLUMN "advance"."Notification"."originatedBy" IS '@graphQL.readOnly';

CREATE TABLE "advance"."NotificationAction" (
    "id" bigserial PRIMARY KEY,
    "notification" bigint NOT NULL REFERENCES "advance"."Notification",
    "user" bigint NOT NULL REFERENCES "advance"."User",
    "actionedAt" timestamp with time zone NOT NULL,
    CONSTRAINT "uniqueNotificationUserAction" UNIQUE ("notification", "user")
);

ALTER TABLE "advance"."NotificationAction" OWNER TO "postgres";
COMMENT ON COLUMN "advance"."NotificationAction"."user" IS '@graphQL.readOnly';
COMMENT ON COLUMN "advance"."NotificationAction"."actionedAt" IS '@graphQL.readOnly';

CREATE TABLE "advance"."OneTimeKey" (
    "id" bigserial PRIMARY KEY,
    "certificationAuthority" bigint NOT NULL REFERENCES "advance"."CertificationAuthority",
    "keyValue" varchar(45) NOT NULL,
    "remainingUsages" integer NOT NULL
);

ALTER TABLE "advance"."OneTimeKey" OWNER TO "postgres";
COMMENT ON COLUMN "advance"."OneTimeKey"."id" IS 'The primary key.';
COMMENT ON COLUMN "advance"."OneTimeKey"."certificationAuthority" IS 'The certification authority that created the key.';
COMMENT ON COLUMN "advance"."OneTimeKey"."keyValue" IS 'The value of the key.';
COMMENT ON COLUMN "advance"."OneTimeKey"."remainingUsages" IS 'The number of remaining usages.';

CREATE TABLE "advance"."Role" (
    "id" bigserial PRIMARY KEY,
    "name" varchar(1024) NOT NULL
);

ALTER TABLE "advance"."Role" OWNER TO "postgres";
COMMENT ON TABLE "advance"."Role" IS '@graphQL.enum';
COMMENT ON COLUMN "advance"."Role"."id" IS 'The primary key.';
COMMENT ON COLUMN "advance"."Role"."name" IS 'The translation of the user’s role.';

CREATE TABLE "advance"."SoftwareVersionTag" (
    "id" bigserial PRIMARY KEY,
    "softwareVersion" bigint NOT NULL REFERENCES "advance"."SoftwareVersion",
    "tag" bigint NOT NULL REFERENCES "advance"."Tag",
    CONSTRAINT "uniqueSoftwareVersionTag" UNIQUE("softwareVersion", "tag")
);

ALTER TABLE "advance"."SoftwareVersionTag" OWNER TO "postgres";

CREATE TABLE "advance"."UserPreference" (
    "id" bigserial PRIMARY KEY,
    "user" bigint NOT NULL REFERENCES "advance"."User",
    "keyName" varchar(80) NOT NULL,
    "value" character varying NOT NULL,
    CONSTRAINT "uniquePrefKeyPerUser" UNIQUE("user", "keyName")
);

ALTER TABLE "advance"."UserPreference" OWNER TO "postgres";
COMMENT ON TABLE "advance"."UserPreference" IS 'Linking table between the Users and preference key/value pairs.';
COMMENT ON COLUMN "advance"."UserPreference"."id" IS 'The primary key.';
COMMENT ON COLUMN "advance"."UserPreference"."user" IS 'An user that contains this preference.
@graphQL.readOnly';
COMMENT ON COLUMN "advance"."UserPreference"."keyName" IS 'A preference of the user.';
COMMENT ON COLUMN "advance"."UserPreference"."value" IS 'Description of the user’s preference.';

CREATE TABLE "advance"."UserRole" (
    "id" bigserial PRIMARY KEY,
    "user" bigint NOT NULL REFERENCES "advance"."User",
    "role" bigint NOT NULL REFERENCES "advance"."Role"
);

ALTER TABLE "advance"."UserRole" OWNER TO "postgres";
COMMENT ON TABLE "advance"."UserRole" IS 'Linking table between the User and Role tables.';
COMMENT ON COLUMN "advance"."UserRole"."id" IS 'The primary key.';
COMMENT ON COLUMN "advance"."UserRole"."user" IS 'An user with this role.';
COMMENT ON COLUMN "advance"."UserRole"."role" IS 'A role of the user.';

CREATE TABLE "advance"."View" (
    "addedAt" timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "id" bigserial PRIMARY KEY,
    "lastModified" timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "meta" "bytea" NOT NULL,
    "name" varchar(1024) NOT NULL,
    "owner" bigint NOT NULL REFERENCES "advance"."User",
    "shared" boolean DEFAULT false NOT NULL,
    CONSTRAINT "viewUniqueNamePerOwner" UNIQUE ("name", "owner")
);

ALTER TABLE "advance"."View" OWNER TO "postgres";
COMMENT ON TABLE "advance"."View" IS 'Stores Views which a user has created. ';
COMMENT ON COLUMN "advance"."View"."addedAt" IS 'Records the date this View was initially added.
@graphQL.readOnly';
COMMENT ON COLUMN "advance"."View"."id" IS 'The primary key.';
COMMENT ON COLUMN "advance"."View"."lastModified" IS 'The time the View was last modified.
@graphQL.readOnly';
COMMENT ON COLUMN "advance"."View"."meta" IS 'This is a blob containing the view as specified (and understood) by the front end.';
COMMENT ON COLUMN "advance"."View"."name" IS 'The name of the view - may be used in a list or possible on the view. ';
COMMENT ON COLUMN "advance"."View"."owner" IS 'The User who owns this View.
@graphQL.readOnly';
COMMENT ON COLUMN "advance"."View"."shared" IS 'Flag indicating if this view is shared; ie: can other Users see it. ';
COMMENT ON CONSTRAINT "viewUniqueNamePerOwner" ON "advance"."View" IS 'This constraint prevents a user from having views with the same name.';

CREATE TABLE "advance"."Report" (
    "id" bigserial PRIMARY KEY,
    "name" varchar(1024) NOT NULL,
    "addedAt" timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "lastModified" timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "schedule" varchar(1024),
    "documentUrl" varchar(1024) NOT NULL,
    "widgets" "bytea" NOT NULL,
    "owner" bigint NOT NULL REFERENCES "advance"."User",
    "shared" boolean DEFAULT false NOT NULL,
    "cryptoPostureTemplate" BIGINT NOT NULL REFERENCES "advance"."CryptoPostureTemplate",
    CONSTRAINT "reportUniqueNamePerOwner" UNIQUE ("name", "owner")
);

ALTER TABLE "advance"."Report" OWNER TO "postgres";
COMMENT ON TABLE "advance"."Report" IS 'Stores Reports which a user has created. ';
COMMENT ON COLUMN "advance"."Report"."id" IS 'The primary key.';
COMMENT ON COLUMN "advance"."Report"."name" IS 'The name of the report - may be used in a list or possibly on the report. ';
COMMENT ON COLUMN "advance"."Report"."addedAt" IS 'Records the date this Report was initially added.
@graphQL.readOnly';
COMMENT ON COLUMN "advance"."Report"."lastModified" IS 'The time the Report was last modified.
@graphQL.readOnly';
COMMENT ON COLUMN "advance"."Report"."schedule" IS 'The schedule of the Report.';
COMMENT ON COLUMN "advance"."Report"."documentUrl" IS 'The URL to the Report.';
COMMENT ON COLUMN "advance"."Report"."widgets" IS 'This is a JSON blob containing the report as specified (and understood) by the front end.';
COMMENT ON COLUMN "advance"."Report"."owner" IS 'The User who owns this Report.
@graphQL.readOnly';
COMMENT ON COLUMN "advance"."Report"."shared" IS 'Flag indicating if this report is shared; ie: can other Users see it. ';
COMMENT ON CONSTRAINT "reportUniqueNamePerOwner" ON "advance"."Report" IS 'This constraint prevents a user from having reports with the same name.';

CREATE TABLE "advance"."ReportView" (
    "id" bigserial PRIMARY KEY,
    "name" varchar(1024) NOT NULL,
    "report" bigint NOT NULL REFERENCES "advance"."Report",
    "view" bigint NOT NULL REFERENCES "advance"."View"
);

ALTER TABLE "advance"."ReportView" OWNER TO "postgres";
COMMENT ON TABLE "advance"."ReportView" IS 'Linking table between Reports and Views. ';
COMMENT ON COLUMN "advance"."ReportView"."id" IS 'The primary key.';
COMMENT ON COLUMN "advance"."ReportView"."name" IS 'The name of the report view - may be used in a list or possibly on the report. ';
COMMENT ON COLUMN "advance"."ReportView"."report" IS 'The Report that the View is included in.';
COMMENT ON COLUMN "advance"."ReportView"."view" IS 'The View that is included in the Report.';

CREATE TABLE IF NOT EXISTS "advance"."SystemProperty" (
    "id" bigserial PRIMARY KEY,
    "key" varchar(100) UNIQUE NOT NULL,
    "value" text
);
ALTER TABLE "advance"."SystemProperty" OWNER TO "postgres";
COMMENT ON TABLE "advance"."SystemProperty" is 'Advance system property storage, as key value pairs.';
COMMENT ON COLUMN "advance"."SystemProperty"."key" is 'The primary key used to identify properties.';
COMMENT ON COLUMN "advance"."SystemProperty"."value" is 'The value associated with the given key.';

CREATE TABLE "advance"."StreamToken" (
    "id" bigserial PRIMARY KEY,
    "token" varchar(100) UNIQUE NOT NULL,
    "comment" varchar(100) DEFAULT '' NOT NULL,
    "expires" timestamp with time zone
);
ALTER TABLE "advance"."StreamToken" OWNER TO "postgres";
COMMENT ON TABLE "advance"."StreamToken" is 'Tokens that are authorisation for streaming data to/from Advance.';
COMMENT ON COLUMN "advance"."StreamToken"."id" is 'Primary Key';
COMMENT ON COLUMN "advance"."StreamToken"."token" is 'The random token used to allow streaming';
COMMENT ON COLUMN "advance"."StreamToken"."comment" is 'A human comment on what the token is for / why it exists';
COMMENT ON COLUMN "advance"."StreamToken"."expires" is 'An optional date controlling when the token is no longer valid.';

CREATE TABLE "advance"."StreamStatus" (
    "id" bigserial PRIMARY KEY,
    "name" varchar(100) UNIQUE NOT NULL,
    "lastStatus" varchar(16384) NOT NULL DEFAULT '{}',
    "total" bigint NOT NULL DEFAULT 0
);
ALTER TABLE "advance"."StreamStatus" OWNER TO "postgres";
COMMENT ON TABLE "advance"."StreamStatus" is 'StreamStatus lets users see if streams are receiving any data';
COMMENT ON COLUMN "advance"."StreamStatus"."id" is 'Primary Key';
COMMENT ON COLUMN "advance"."StreamStatus"."name" is 'The strea, type these records cover';
COMMENT ON COLUMN "advance"."StreamStatus"."lastStatus" is 'Was the last status received from this stream - JSON encoding';
COMMENT ON COLUMN "advance"."StreamStatus"."total" is 'Is the total number of events received by this stream - is probably not equal to any other entity.';
