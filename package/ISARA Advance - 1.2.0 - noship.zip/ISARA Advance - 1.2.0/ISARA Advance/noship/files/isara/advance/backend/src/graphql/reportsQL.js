/**
 * @file reportsQL.js - 1.2.0 - 3826bc12533e078a8e37cfe70ee04d9e85c8530e
 * 
 * @copyright Copyright (C) 2016-2023, ISARA Corporation, All Rights Reserved.
 * 
 * @license The code and other content set out herein is not in the public
 * domain, is considered a trade secret and is confidential to ISARA
 * Corporation. Use, reproduction or distribution, in whole or in part, of such
 * code or other content is strictly prohibited except by express written
 * permission of ISARA Corporation. Please contact ISARA Corporation at
 * info@isara.com for more information.
 */

/**
 * This file manages user Reports. Note that the backend isn't aware of the meaning of a report.
 * @module graphql/reportQL
 */

const { createUpdateDelete, registerHook, CUD_OP_INSERT, CUD_OP_UPDATE, CUD_OP_DELETE, CUD_OP_PRE, CUD_OP_POST } = require('../isaraql/cud')
const { fetchWanted } = require('../isaraql/fetch')
const { graphQLStateToWanted } = require('../isaraql/wantedUtil')
const { getRequestState } = require('../util/requestState')
const { roles, GraphQLEnum, SORT_DIRECTION_ENUM } = require('./commonQL')
const scheduler = require('../util/scheduler')
const { getInstantSearchConfiguration, getClientAccessKey } = require('../isaraql/instantSearchProvider')
const axios = require('axios')
const { Session } = require('../isaraql/session')

/**
 * Enum for the fields allowed to be sorted on Reports.
 */
const SORTABLE_FIELDS_ENUM = new GraphQLEnum('SortableReportsFields', ['name', 'addedAt', 'lastModified', 'schedule'])

const SCHEDULED_REPORT_PREFIX = 'ScheduleReport-'

/**
 * @typedef ReportsSortingInput Structure to indicate how to sort reports.
 * @property {string} field which field to sort
 * @property {string} direction which direction to sort
 */


/**
 * Query to see reports.
 * @param {Object} fields Fields from the GraphQL query
 * @param {number} [fields.id] An optional ID for retrieving a single Report
 * @param {Paging} [fields.paging] Paging information. Defaults to 5 records.
 * @param {ReportsSortingInput} [fields.orderBy] Sort preference for retrieved reports.
 * @param {Object} request GraphQL request
 * @param {Object} graphQLState GraphQL State
 * @param {number[]} [ids] Set of IDs to run query for.
 */
async function getReportQuery(fields, request, graphQLState, ids) {
    var wanted = graphQLStateToWanted(graphQLState)
    wanted = wanted[Object.keys(wanted)[0]]

    if (!('paging' in fields)) {
        fields.paging = { offset: 0n }
    }
    var wpcs = { CryptoPostureReport: { paging: fields.paging } }
    if (wanted.paging && wanted.paging.count) {
        wpcs.CryptoPostureReport.count = []
    }

    if ('id' in fields) {
        ids = [fields.id]
    }

    var userClause = { equals: { column: 'owner', value: getRequestState().user.uid } }

    if (ids && ids.length !== 0) {
        // Specific reports requested; send them back if they're owned by this user.
        wpcs.CryptoPostureReport.where = {
            and: [{ in: { column: 'id', value: ids } }]
        }
    } else {
        // Limit reports to reports owned by this user.
        wpcs.CryptoPostureReport.where = userClause
    }

    if (fields.orderBy) {
        wpcs.CryptoPostureReport.sort = `"${SORTABLE_FIELDS_ENUM.graphQLToInternal[fields.orderBy.field]}" ${SORT_DIRECTION_ENUM.graphQLToInternal[fields.orderBy.direction]}`
    }

    var reports = await fetchWanted('CryptoPostureReport', wanted.reports, wpcs)

    const getReportOrder = (meta, reportId) =>
        JSON.parse(meta)?.reports?.find(viewReport => String(viewReport?.reportId) === String(reportId))


    for (var report of reports) {
        report?.reportViews?.sort((firstView, secondView) => {
            if (firstView.view && secondView.view) {
                var firstViewReportOrder = getReportOrder(firstView.view.meta, report.id)
                var secondViewReportOrder = getReportOrder(secondView.view.meta, report.id)

                if (firstViewReportOrder && secondViewReportOrder) {
                    return Number(firstViewReportOrder?.order) - Number(secondViewReportOrder?.order)
                }
            }
        })
    }


    var toReturn = { reports }
    if (wpcs.CryptoPostureReport.count) {
        toReturn.paging = { count: wpcs.CryptoPostureReport.count[0] }
    }

    return toReturn
}

const checkExistingTables = {}
const deletableTables = { 'CryptoPostureReport': true, 'ReportSnapshot': true }
const modifiableTables = deletableTables

/**
 * Create/Update/Delete reports.
 * @param {*} fields
 * @param {*} request
 * @param {*} graphQLState
 */
async function reportUpdateMutation(fields, request, graphQLState) {
    var reports = fields.reports
    var config = {
        allowDelete: true,
        allowInsert: true,
        allowUpdate: true,
        checkExistingTables,
        deletableTables,
        modifiableTables
    }
    var ids = await createUpdateDelete('CryptoPostureReport', reports, config)

    return getReportQuery(fields, request, graphQLState, ids)
}

async function reportHook(params) {
    var user = getRequestState().user
    if (!user) {
        throw new Error('User not set when trying to modify Report')
    }
    if (params.operation === CUD_OP_UPDATE || params.operation === CUD_OP_DELETE) {
        // Need to enforce that some user isn't changing other users' reports.
        var existingRecords = (await params.session.query('select owner from "CryptoPostureReport" where id = ?', [params.record.id])).rows
        if (existingRecords.length === 0) {
            throw new Error('Existing record expected for user permission check')
        }
        if (existingRecords[0].owner !== user.uid) {
            throw new Error(`Permission denied - cannot update other user's Reports`)
        }
    }

    if (params.operation !== CUD_OP_DELETE) {
        params.record.owner = user.uid
        const now = new Date()
        params.record.lastModified = now
        if (params.operation === CUD_OP_INSERT) {
            params.record.addedAt = now
        }
    }
}

const reportScheduleHook = async(params) => {
    if (params.operation === CUD_OP_INSERT) {
        await scheduleReport(params.record, params.session)
    }
    if (params.operation === CUD_OP_UPDATE) {
        await unscheduleReport(params.record)
        await scheduleReport(params.record, params.session)
    }
    if (params.operation === CUD_OP_DELETE) {
        await unscheduleReport(params.record)
    }
}

/**
 * List of the facet that is not available in collection
 */
let invalidFacetsByCollection = {
    connections:['osType'],
    devices:['clientos','serveros','zoneIn','zoneOut'],
    deviceSoftware:[]
}
  
/**
   * 
   * this is to check if given facet is valid for colleciton
   * @param collectionName 
   * @param facet 
   * @returns boolean
   */
function isValidCollectionFacet(collectionName,facet) {
    return !invalidFacetsByCollection[collectionName].includes(facet)
}

const scheduleReport = async (reportSchedule, session) => {
    if (!reportSchedule.id) {
        throw new Error(`Cannot schedule report without ID`)
    }
    const cron = getRepeatCronish(Number(reportSchedule.repeat))

    let error = !(await scheduler.scheduleJob(
        `${SCHEDULED_REPORT_PREFIX}${reportSchedule.id}`,
        cron,
        'UTC',
        async function () {
            try {
                const [report] = (
                    await session.query(
                        `SELECT id, metadata from "advance"."CryptoPostureReport" WHERE id = ${Number(reportSchedule.id)};`
                    )
                ).rows

                const parseData = JSON.parse(report?.metadata)
                const searches = []
                const refinement = []
                parseData.map( (_data) => {
                    let {posture, refinementList, currentRefinement} = _data
                    let reversePosture = posture === 'connections' ? 'devices' : 'connections'
                    let refinementQuery = refinementList?.refinementList && refinementList?.refinementList.length > 0 ? refinementList?.refinementList : null 
                    let reverseRefinementQuery = refinementList?.refinementList && refinementList?.refinementList.length > 0 ? refinementList?.refinementList : null

                    //Rid off the facet from filter if it's not a valid facet of collection
                    if(refinementQuery) {
                        let tempQuery = []
                        let tempQuery2 = []
                        refinementQuery.split('&&').map((_facet) => {
                            let attribute = _facet.split(':')[0].trim()
                            if(!isValidCollectionFacet(posture,attribute )) {
                                tempQuery.push(' defaultFacet:=[`d`] ')
                            } else {
                                tempQuery.push(_facet)
                            }
                            if(!isValidCollectionFacet(reversePosture,attribute )) {
                                tempQuery2.push(' defaultFacet:=[`d`] ')
                            } else {
                                tempQuery2.push(_facet)
                            }
                        })
                        if(tempQuery.length > 0) {
                            refinementQuery = tempQuery.join('&&')
                        }
                        if(tempQuery2.length > 0) {
                            reverseRefinementQuery = tempQuery2.join('&&')
                        }
                    }
                    
          
                    let params = {
                        'query_by': 'cryptoScoreCoarse,cryptoScore',
                        'sort_by': '',
                        'highlight_full_fields': 'cryptoScoreCoarse,cryptoScore',
                        'collection': posture,
                        'q': refinementList?.queryString ? refinementList?.queryString : '*',
                        'facet_by': 'cryptoStrength,cryptoScoreCoarse,cryptoScore,protocol,keyExchange,bulkEncryption,modeOfOperation,signature,hash,mac,clientos,serveros,osType,zoneIn,zoneOut',
                        'filter_by': refinementQuery ? refinementQuery : '',
                        'max_facet_values': 25,
                        'page': 1,
                        'per_page': 100
                    }
                
                    let reverseParams = {
                        'query_by': 'cryptoScoreCoarse,cryptoScore',
                        'sort_by': '',
                        'highlight_full_fields': 'cryptoScoreCoarse,cryptoScore',
                        'collection': reversePosture,
                        'q': refinementList?.queryString ? refinementList?.queryString : '*',
                        'facet_by': 'cryptoStrength,cryptoScoreCoarse,cryptoScore,protocol,keyExchange,bulkEncryption,modeOfOperation,signature,hash,mac,clientos,serveros,osType,zoneIn,zoneOut',
                        'filter_by': reverseRefinementQuery ? reverseRefinementQuery : '',
                        'max_facet_values': 25,
                        'page': 1,
                        'per_page': 100
                    }
                    searches.push(params)
                    searches.push(reverseParams)
                    refinement.push(currentRefinement)
                })
                const searchObj = {searches}

                const config = await getInstantSearchConfiguration()
                const { nodes: [typesenseNode] } = config
                const apiKey = await getClientAccessKey()
                const typesenseUrl = `${typesenseNode.protocol}://${typesenseNode.host}:${typesenseNode.port}`
                const path = `${typesenseUrl}/multi_search/?x-typesense-api-key=${apiKey}`
                let { data } = await axios.post(path, JSON.stringify(searchObj))

                let text = 'INSERT INTO  advance."ReportSchedule"("metadata","addedAt","lastModified","cryptoPostureReport","currentRefinement") VALUES($1,$2,$3,$4,$5) RETURNING *'
                let values = [JSON.stringify(data), new Date(), new Date(), report.id, JSON.stringify(refinement)]
                await session.query(text, values)
            } catch (e) {
                let message = e.message || e
                throw new Error(`Exception scheduling report: ${message}`)
            }
        }
    ))

    return !error
}

const unscheduleReport = async(reportSchedule) => {
    if (!reportSchedule.id) {
        throw new Error(`Cannot unschedule report without ID`)
    }

    return await scheduler.cancelJob(`${SCHEDULED_REPORT_PREFIX}${reportSchedule.id}`)
}

const getRepeatCronish = (repeat) => {
    let cronish = ''
    switch(repeat) {
        case 1:
            cronish = '0 0 * * *' // Daily
            break
        case 2:
            cronish = '0 0 * * 0' // Weekly
            break
        case 3:
            cronish = '0 0 1 * *' // Monthly
            break
        default:
            cronish = '0 0 * * *'
            break
    }

    return cronish
}

const initializeReportJobs = async() => {
    let session = new Session()

    let wpcs = { CryptoPostureReport: {} }
    let reportSchedules = await fetchWanted('CryptoPostureReport', { id: true, repeat: true }, wpcs, session)

    // Schedule Reports
    for (let reportSchedule of reportSchedules) {
        await scheduleReport(reportSchedule, session)
    }
}

async function initialise() {
    registerHook('CryptoPostureReport', CUD_OP_INSERT, CUD_OP_PRE, reportHook)
    registerHook('CryptoPostureReport', CUD_OP_UPDATE, CUD_OP_PRE, reportHook)
    registerHook('CryptoPostureReport', CUD_OP_DELETE, CUD_OP_PRE, reportHook)

    registerHook('CryptoPostureReport', CUD_OP_INSERT, CUD_OP_POST, reportScheduleHook)
    registerHook('CryptoPostureReport', CUD_OP_UPDATE, CUD_OP_POST, reportScheduleHook)
    registerHook('CryptoPostureReport', CUD_OP_DELETE, CUD_OP_POST, reportScheduleHook)
}

exports.graphQL = {
    types: `
        type PagedReport {
            paging: Paging!
            reports: [CryptoPostureReport!]!
        }

        ${SORTABLE_FIELDS_ENUM.toGraphQL()}

        input ReportsSortingInput {
            field: SortableReportsFields!,
            direction: SortDirection!,
        }
    `,
    queries: `
        """
            Obtain all of the current User's Reports, or see a specific Report.
        """
        getReports(
            """
                Used to control how many reports are returned. The default (without paging) will be 5.
            """
            paging: PagingInput
            """
                When provided, will attempt to find a single report. The report may not exist, or you may not have access.
            """
            id: BigInt
            """
               Used to set the sort order of the Reports
            """
            orderBy: ReportsSortingInput
        ) : PagedReport!
    `,
    mutations: `
        reportsUpdate(
            reports: [CryptoPostureReportInput!]!
        ) : PagedReport!
    `,
    root: {
        getReports: getReportQuery,
        reportsUpdate: reportUpdateMutation,
    },
    restrictions: {
        getReports: [roles.AUTHENTICATED],
        reportsUpdate: [roles.AUTHENTICATED],
    },
    initialise
}
exports.initializeReportJobs = initializeReportJobs
