/**
 * @file systemPreferences.js - 1.2.0 - 3826bc12533e078a8e37cfe70ee04d9e85c8530e
 * 
 * @copyright Copyright (C) 2016-2023, ISARA Corporation, All Rights Reserved.
 * 
 * @license The code and other content set out herein is not in the public
 * domain, is considered a trade secret and is confidential to ISARA
 * Corporation. Use, reproduction or distribution, in whole or in part, of such
 * code or other content is strictly prohibited except by express written
 * permission of ISARA Corporation. Please contact ISARA Corporation at
 * info@isara.com for more information.
 */

/**
 * This module loads Advance's system preferences.
 * @module util/systemPreferences
 */

const fs = require('fs').promises
const LazySingleton = require('./lazySingleton')
const log = require('./log')(module)

const ENV_VAR_NAME = 'ADVANCE_PREFERENCES_FILE'

const DEFAULT_PREFERENCES = {
    benchmarking: { all: true },
    featureFlags: {
        GRAPHIQL: true,
    }
}

var preferences = new LazySingleton(async () => {

    let preferencesFileName = './systemPreferences.json'

    let toReturn = {...DEFAULT_PREFERENCES}

    if (process.env[ENV_VAR_NAME]) {
        preferencesFileName = process.env[ENV_VAR_NAME]
    } else {
        log.log(`${ENV_VAR_NAME} is not set, will attempting default path`)
    }

    let content
    try {
        content = await fs.readFile(preferencesFileName)
        try {
            let fromFile = JSON.parse(content)
            Object.assign(toReturn, fromFile)
        } catch (e) {
            log.e('Could not PARSE system preferences', preferencesFileName, e)
        }
    } catch (e) {
        log.w('System preferences file could not be loaded', preferencesFileName)
    }

    // Check if debugAll has been requested.
    if (toReturn?.log?.debugAll) {
        log.debugAll = true
        log.d('System preferences enabled debugAll logging')
    }

    return toReturn
})

module.exports = async function () {
    var toReturn = await preferences.get()
    return Object.assign({}, toReturn)
}
