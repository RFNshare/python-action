/**
 * @file widgetsQL.js - 1.2.0 - 3826bc12533e078a8e37cfe70ee04d9e85c8530e
 * 
 * @copyright Copyright (C) 2016-2023, ISARA Corporation, All Rights Reserved.
 * 
 * @license The code and other content set out herein is not in the public
 * domain, is considered a trade secret and is confidential to ISARA
 * Corporation. Use, reproduction or distribution, in whole or in part, of such
 * code or other content is strictly prohibited except by express written
 * permission of ISARA Corporation. Please contact ISARA Corporation at
 * info@isara.com for more information.
 */

/**
 * This module contains Widget focused queries.
 * @module graphql/widgetsQL
 */

const { expressionToQueryAndParams } = require('../filterql/filterSQL')
const { Session } = require('../isaraql/session')
const { getCptForRequest } = require('../util/cptHelpers')

var {
    roles
} = require('./commonQL')

async function queryWidgetOverall(fields, request, graphQLState, session) {
    // Based on Crypto Posture v4 - Proposal 2: Global Score = Weighted Average
    // https://wiki.isaracorp.com/en/RandD/Projects/Guardian_Crypto-Agility_/Ciphersuite_classification

    let filterClause = ''
    let filterParams = []
    if (fields.filter && fields.filter.trim() !== '') {
        let filteredThings = await expressionToQueryAndParams('Device', fields.filter)
        filterClause = `and d.id in ( ${filteredThings.query} )`
        filterParams = filteredThings.params
    }
    let cpt = await getCptForRequest(fields.cryptoPostureTemplate)
    let thresholdParams = [1000]  // threshold is Strong Classical - Quantum Broken
    let scoreParams = thresholdParams.concat([cpt], filterParams, thresholdParams, [cpt], filterParams)

    

    let scoreQuery = `
        select
            count(device)::int as "devices",
            sum(connections)::int as "connections",
            score
        from (
        select
                d.id as device,
                count(c.id) connections,
                case when cs."score" >= ? then 1 else 0 end score
            from "Device" d
                left join "DeviceAddress" da on da.device = d.id
                left join "DeviceAddressPort" dap on dap."deviceAddress" = da.id
                left join "Connection" c on c."serverDeviceAddressPort" = dap.id
                left join "DeviceScore" ds on ds.device = d.id
                left join "CryptoScore" cs ON cs.id = ds."cryptoScore"
            where c."clientDeviceAddressPort" is not null
            and cs."score" > -1
            and ds."cryptoPostureTemplate" = ?
            ${filterClause}
            group by d.id, score
        ) as serverDevices
        group by score

        union

        select
            count(device)::int as "devices",
            sum(connections)::int as "connections",
            score
        from (
            select
                d.id as device,
                count(c.id) connections,
                case when cs."score" >= ? then 1 else 0 end score
            from "Device" d
                left join "DeviceAddress" da on da.device = d.id
                left join "DeviceAddressPort" dap on dap."deviceAddress" = da.id
                left join "Connection" c on c."serverDeviceAddressPort" = dap.id
                left join "DeviceScore" ds on ds.device = d.id
                left join "CryptoScore" cs ON cs.id = ds."cryptoScore"
            and cs."score" > -1
            and ds."cryptoPostureTemplate" = ?
            ${filterClause}
            group by d.id, score
        ) as clientDevices
        group by score
`
    if (!session) {
        session = new Session()
    }

    var score = -1
    var grade = -1

    await session.reuseConnection(async () => {
        if (fields.asOf) {
            await session.configureHistory(null, new Date(fields.asOf))
        }
        let result = await session.query(scoreQuery, scoreParams)

        let sum = 0
        let connectionsCount = 0

        for (let row of result.rows) {
            // aggregation of devices * connections is handled in DB query
            sum += row.connections * row.score
            connectionsCount += row.connections
        }

        if (connectionsCount > 0) {
            // connectionsCount is already equal to 2M, since the connections are counted twice, once for both client and server
            score = (sum / connectionsCount) * 100
            score = Math.round(score)
            if (score > 100) { score = 100 }
            if (score < 0) { score = 0 }

            if (score < 30) {
                grade = 0
            } else if (score < 70) {
                grade = 1
            } else if (score < 90) {
                grade = 2
            } else {
                grade = 3
            }
        }
    })

    return {
        score,
        grade
    }
}

exports.graphQL = {
    types: `
        type SystemCryptoScore {
            # Score is the overall crypto score. It is -1, indicating unknown/invalid, or a value from 1 ~ 100.
            score: Int!
            # Grade is the overall 'grade' for the system. It is either -1, indicating unknown/invalid, or a value from 0 ~ 3.
            grade: Int!
        }
    `,
    queries: `
        widgetOverall(filter: String, asOf: DateTime, cryptoPostureTemplate: BigInt) : SystemCryptoScore!
    `,
    root: {
        widgetOverall: queryWidgetOverall
    },
    restrictions: {
        widgetOverall: [roles.AUTHENTICATED]
    }
}
