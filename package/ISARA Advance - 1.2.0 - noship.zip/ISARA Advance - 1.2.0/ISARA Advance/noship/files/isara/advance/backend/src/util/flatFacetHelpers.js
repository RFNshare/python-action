/**
 * @file flatFacetHelpers.js - 1.2.0 - 3826bc12533e078a8e37cfe70ee04d9e85c8530e
 * 
 * @copyright Copyright (C) 2016-2023, ISARA Corporation, All Rights Reserved.
 * 
 * @license The code and other content set out herein is not in the public
 * domain, is considered a trade secret and is confidential to ISARA
 * Corporation. Use, reproduction or distribution, in whole or in part, of such
 * code or other content is strictly prohibited except by express written
 * permission of ISARA Corporation. Please contact ISARA Corporation at
 * info@isara.com for more information.
 */

const { Session } = require('../isaraql/session')

const {
    facets
} = require('../filterql/facets')

const { allTypes } = require('../isaraql/schemaDiscovery')
const { postureCategories } = require('../graphql/categoryConstants')
const { generatePlaceholders } = require('../isaraql/fetch')
const { registerTreeHook, CUD_OP_POST_CHILDREN } = require('../isaraql/cud')

const log = require('../util/log')(module)
const flatFacetIDMap = {
    devicecryptoscore: 0,
    devicetype: 1,
    concryptoscore: 2,
    protocolvariant: 3,
    cryptoprim: 4,
    os: 5
}

const rebuildCache = {

}

const applicableFacetsPerPosture = {

}

const CACHE_REBUILD_CHECK_INTERVAL = 10000
const MIN_CACHE_REBUILD_TIMEOUT = CACHE_REBUILD_CHECK_INTERVAL
const MAX_CACHE_REBUILD_TIMEOUT = 6 * MIN_CACHE_REBUILD_TIMEOUT

const cacheTablespace = 'flatcache'

exports.flatFacetIDMap = flatFacetIDMap

function getSourceTableForPostureCategory(postureCategory) {
    switch (postureCategory) {
        case postureCategories.CONNECTION:
            return 'Connection'
        case postureCategories.DEVICE:
            return 'Device'
        case postureCategories.SOFTWARE:
            return 'SoftwareVersion'
        default:
            throw `Unknown/unsupported posture category ${postureCategory}`
    }
}

exports.getSourceTableForPostureCategory = getSourceTableForPostureCategory

async function getProtocolVariantsForDevices(deviceIDs, session) {
    if (!deviceIDs || !session) {
        throw 'Invalid arguments'
    }

    let facetQuery = `SELECT flat.object_id, flat.value, variant.name, count(*)
        FROM "flatcache"."DeviceFlat" flat
        JOIN "advance"."ProtocolVariant" variant ON variant.id = flat.value
        WHERE object_id IN (${deviceIDs}) and facet = ${flatFacetIDMap.protocolvariant} GROUP BY variant.name, 1, 2; `

    return (await session.query(facetQuery)).rows
}

exports.getProtocolVariantsForDevices = getProtocolVariantsForDevices

async function updateFlatFacetForObjects(postureCategory, facetName, objectIDs, session) {
    if (!objectIDs) {
        throw 'Missing objectIDs argument'
    }

    if (!Array.isArray(objectIDs)) {
        objectIDs = [objectIDs]
    }

    let facet = facets.attributesByName[facetName]
    let remapColumn = false
    let countingPaths = []
    let currentFacet = allTypes[facet.table][facet.column]
    if (currentFacet.startsWith('String')) {
        remapColumn = true
    }

    let sourceTable = getSourceTableForPostureCategory(postureCategory)

    if (facet.table !== sourceTable) {
        countingPaths = facet.paths[sourceTable]
    } else {
        countingPaths.push(` FROM "${sourceTable}" `)
    }

    if (!countingPaths || countingPaths.length === 0) {
        log.w(`No path found from ${sourceTable} to ${facet.table} for facet ${facet.name}`)
        return
    }

    if (facet.filterCategory?.additionalFlatCacheMapping) {
        await updateLinkedFlatFacetForObjects(facet, sourceTable, objectIDs, countingPaths, remapColumn, session)
        return
    }

    let baseTargetName = `${sourceTable}Flat_${facet.name}`
    let finalTargetTable = `"${cacheTablespace}"."${baseTargetName}"`

    countingPaths = countingPaths.map(p => `SELECT "${sourceTable}".id, "${facet.table}"."${remapColumn ? 'id' : facet.column}" AS value ${p} `)

    let index = 0
    while (index < objectIDs.length) {
        let params = objectIDs.slice(index, index + 100)
        index += params.length
        let filterClause = `"${sourceTable}".id IN (${params.join(',')})`

        let wheres = [filterClause]
        if (facet.matchCondition) {
            wheres.push(facet.matchCondition)
        }

        let finalPaths = countingPaths
        if (wheres.length > 0) {
            finalPaths = countingPaths.map(p => `${p} WHERE ${wheres.join(' AND ')} `)
        }

        await session.query(`DELETE FROM ${finalTargetTable} WHERE object_id IN (${generatePlaceholders(params)})`, params)
        let path = `INSERT INTO ${finalTargetTable} (object_id, facet, value) SELECT t1.id, ${flatFacetIDMap[facet.name]}, value FROM (${finalPaths.join(' UNION ')}) t1`
        await session.query(path)
    }
}

async function updateLinkedFlatFacetForObjects(facet, sourceTable, objectIDs, countingPaths, remapColumn, session) {

    let links = (await session.query(`SELECT id, name FROM advance."${facet.filterCategory.additionalFlatCacheMapping.table}"`)).rows

    for (let i = 0; i < links.length; i++) {
        let link = links[i]
        let baseTargetName = `${sourceTable}${facet.table}Flat_${link.id}`
        let finalTargetTable = `"${cacheTablespace}"."${baseTargetName}"`

        let linkParams = []
        let linkedPaths = countingPaths.map(p => {
            let path = `SELECT "${sourceTable}".id,
            "${facet.table}"."${facet.filterCategory.additionalFlatCacheMapping.column}" AS link,
            "${facet.table}"."${remapColumn ? 'id' : facet.column}" AS value ${p}
                WHERE "${facet.table}"."${facet.filterCategory.additionalFlatCacheMapping.column}" = ?`
            linkParams.push(link.id)
            return path
        })

        let index = 0
        while (index < objectIDs.length) {
            let params = objectIDs.slice(index, index + 100)
            index += params.length
            let filterClause = `"${sourceTable}".id IN (${generatePlaceholders(params, linkParams.length)})`

            let wheres = [filterClause]
            if (facet.matchCondition) {
                wheres.push(facet.matchCondition)
            }

            let finalPaths = linkedPaths
            if (wheres.length > 0) {
                finalPaths = linkedPaths.map(p => `${p} AND ${wheres.join(' AND ')} `)
            }

            await session.query(`DELETE FROM ${finalTargetTable} WHERE link = ? and object_id IN (${generatePlaceholders(params, 1)})`, [link.id, ...params])
            let path = `INSERT INTO ${finalTargetTable} (object_id, link, facet, value) SELECT t1.id, link, ${flatFacetIDMap[facet.name]}, value FROM (${finalPaths.join(' UNION ')}) t1`
            await session.query(path, [...linkParams, ...params])
        }
    }
}

async function cleanupTopLevelLinkedPartitions(facet, parentTable, session) {
    let links = (await session.query(`SELECT id, name FROM advance."${facet.filterCategory.additionalFlatCacheMapping.table}"`)).rows

    // Cleanup old partitions
    for (let i = 0; i < links.length; i++) {
        let link = links[i]
        let baseTargetName = `${parentTable}_${link.id}`
        let finalTargetTable = `"${cacheTablespace}"."${baseTargetName}"`

        let result = await session.query(`SELECT EXISTS (SELECT FROM information_schema.tables
            WHERE table_schema=? AND table_name =?)`, [cacheTablespace, baseTargetName])
        let detachNeeded = result.rows[0].exists
        if (detachNeeded) {
            log.d(`Dropping previous partition ${baseTargetName} on ${parentTable}...`)
            await session.query(`ALTER TABLE "${cacheTablespace}"."${parentTable}" DETACH PARTITION ${finalTargetTable}`)
            await session.query(`DROP TABLE ${finalTargetTable} `)
        }
    }
}

async function attachLinkedPartitions(parentTable, facet, session) {
    let links = (await session.query(`SELECT id, name FROM advance."${facet.filterCategory.additionalFlatCacheMapping.table}"`)).rows

    for (let i = 0; i < links.length; i++) {
        let link = links[i]
        let targetTable = `"${cacheTablespace}"."Temp${parentTable}_${link.id}"`
        let baseTargetName = `${parentTable}_${link.id}`
        let finalTargetTable = `"${cacheTablespace}"."${baseTargetName}"`

        let result = await session.query(`SELECT EXISTS (SELECT FROM information_schema.tables
            WHERE table_schema=? AND table_name =?)`, [cacheTablespace, `Temp${parentTable}_${link.id}`])
        let attachNeeded = result.rows[0].exists
        if (attachNeeded) {
            await session.query(`ALTER TABLE IF EXISTS ${targetTable} RENAME TO "${baseTargetName}"`)
            log.d(`Attaching new partition ${finalTargetTable} on ${parentTable}...`)
            await session.query(`ALTER TABLE "${cacheTablespace}"."${parentTable}" ATTACH PARTITION ${finalTargetTable} FOR VALUES IN (${link.id})`)
            log.d(`Facet ${facet.name} ON ${parentTable} complete.`)
        }
    }
}

async function rebuildLinkedFacetPartition(sourceTable, parentTable, facet, session) {
    if (!session || !session.inTransaction) {
        throw 'rebuildFacetPartition must be called transactionally'
    }

    log.d(`Rebuilding linked facet ${facet.name} ON ${parentTable}...`)
    let remapColumn = false
    let countingPaths = []
    let currentFacet = allTypes[facet.table][facet.column]
    if (currentFacet.startsWith('String')) {
        remapColumn = true
    }

    if (facet.table !== sourceTable) {
        countingPaths = facet.paths[sourceTable]
    } else {
        countingPaths.push(` FROM "${sourceTable}" `)
    }

    if (!countingPaths || countingPaths.length === 0) {
        log.w(`No path found from ${sourceTable} to ${facet.table} for facet ${facet.name}`)
        return
    }

    let links = (await session.query(`SELECT id, name FROM advance."${facet.filterCategory.additionalFlatCacheMapping.table}"`)).rows

    for (let i = 0; i < links.length; i++) {
        let link = links[i]
        let targetTable = `"${cacheTablespace}"."Temp${parentTable}_${link.id}"`

        log.d(`Creating temp table for ${facet.name} ON ${parentTable}...`)
        await session.query(`CREATE TABLE IF NOT EXISTS ${targetTable} (LIKE "${cacheTablespace}"."${parentTable}" INCLUDING ALL)`)

        let linkedPaths = countingPaths.map(p => {
            let path = `SELECT "${sourceTable}".id,
            "${facet.table}"."${facet.filterCategory.additionalFlatCacheMapping.column}" AS link,
            "${facet.table}"."${remapColumn ? 'id' : facet.column}" AS value ${p}
                WHERE "${facet.table}"."${facet.filterCategory.additionalFlatCacheMapping.column}" = ${link.id}`
            return path
        })

        let path = `INSERT INTO ${targetTable}(object_id, link, facet, value) SELECT t1.id, link, ${flatFacetIDMap[facet.name]}, value FROM (${linkedPaths.join(' UNION ')}) t1`
        log.d(`Populating temp table for ${facet.name} ON ${parentTable}...`)
        await session.query(path)
    }
}

async function rebuildFacetPartition(sourceTable, parentTable, facet, session) {
    if (!session || !session.inTransaction) {
        throw 'rebuildFacetPartition must be called transactionally'
    }

    log.d(`Rebuilding facet ${facet.name} ON ${parentTable}...`)
    let remapColumn = false
    let countingPaths = []
    let currentFacet = allTypes[facet.table][facet.column]
    if (currentFacet.startsWith('String')) {
        remapColumn = true
    }

    if (facet.table !== sourceTable) {
        countingPaths = facet.paths[sourceTable]
    } else {
        countingPaths.push(` FROM "${sourceTable}" `)
    }

    if (!countingPaths || countingPaths.length === 0) {
        log.w(`No path found from ${sourceTable} to ${facet.table} for facet ${facet.name}`)
        return
    }

    let targetTable = `"${cacheTablespace}"."Temp${parentTable}_${facet.name}"`
    let baseTargetName = `${parentTable}_${facet.name}`
    let finalTargetTable = `"${cacheTablespace}"."${baseTargetName}"`

    let result = await session.query(`SELECT EXISTS (SELECT FROM information_schema.tables
            WHERE table_schema=? AND table_name =?)`, [cacheTablespace, baseTargetName])

    let detachNeeded = result.rows[0].exists
    await session.query(`DROP TABLE IF EXISTS ${targetTable}`)
    log.d(`Creating temp table for ${facet.name} ON ${parentTable}...`)
    await session.query(`CREATE TABLE ${targetTable} (LIKE "${cacheTablespace}"."${parentTable}" INCLUDING ALL)`)

    countingPaths = countingPaths.map(p => `SELECT "${sourceTable}".id, "${facet.table}"."${remapColumn ? 'id' : facet.column}" AS value ${p} `)

    let path = `INSERT INTO ${targetTable}(object_id, facet, value) SELECT t1.id, ${flatFacetIDMap[facet.name]}, value FROM (${countingPaths.join(' UNION ')}) t1`

    log.d(`Populating temp table for ${facet.name} ON ${parentTable}...`)
    await session.query(path)

    if (detachNeeded) {
        log.d(`Dropping previous partition ${baseTargetName} on ${parentTable}...`)
        await session.query(`ALTER TABLE "${cacheTablespace}"."${parentTable}" DETACH PARTITION ${finalTargetTable}`)
        await session.query(`DROP TABLE ${finalTargetTable} `)
    }
    await session.query(`ALTER TABLE ${targetTable} RENAME TO "${baseTargetName}"`)
    log.d(`Attaching new partition ${finalTargetTable} on ${parentTable}...`)
    await session.query(`ALTER TABLE "${cacheTablespace}"."${parentTable}" ATTACH PARTITION ${finalTargetTable} FOR VALUES IN (${flatFacetIDMap[facet.name]})`)
    log.d(`Facet ${facet.name} ON ${parentTable} complete.`)
}

async function rebuildFlatFacetTable(postureCategory, force) {
    let session = new Session()

    await session.asTransaction(async () => {
        let sourceTable = getSourceTableForPostureCategory(postureCategory)
        let targetTable = `${sourceTable}Flat`

        let start = new Date()
        log.log(`Rebuilding flat facets table ${targetTable}`)
        await recreateFlatFacetTableRoot(session, force, postureCategory)

        let linkedFacets = []

        for (let facet of facets.attributes) {
            if (!('filterCategory' in facet)) {
                continue
            }

            if (facet.filterCategory.appliesTo && !facet.filterCategory.appliesTo.includes(postureCategory)) {
                continue
            }

            if (facet.filterCategory.additionalFlatCacheMapping) {
                // This facet has a Linked top-level flat cache
                linkedFacets.push(facet)
            } else {
                await rebuildFacetPartition(sourceTable, targetTable, facet, session)
            }
        }

        // Rebuild linked facets
        for (let i = 0; i < linkedFacets.length; i++) {
            let parent = await recreateFlatLinkedFacetTableRoot(session, force, postureCategory, linkedFacets[i])
            await cleanupTopLevelLinkedPartitions(linkedFacets[i], parent, session)
        }
        for (let i = 0; i < linkedFacets.length; i++) {
            let parent = `${getSourceTableForPostureCategory(postureCategory)}${linkedFacets[i].table}Flat`
            await rebuildLinkedFacetPartition(sourceTable, parent, linkedFacets[i], session)
        }
        for (let i = 0; i < linkedFacets.length; i++) {
            let parent = `${getSourceTableForPostureCategory(postureCategory)}${linkedFacets[i].table}Flat`
            await attachLinkedPartitions(parent, linkedFacets[i], session)
        }


        log.log(`Rebuilt ${targetTable} in ${new Date() - start} msec`)
    })
}

async function recreateFlatFacetTableRoot(session, force, postureCategory) {
    let baseTableName = `${getSourceTableForPostureCategory(postureCategory)}Flat`


    if (force) {
        await session.query(`DROP TABLE IF EXISTS "${cacheTablespace}"."${baseTableName}"`)
    }

    // create base table to serve as the partition root
    await session.query(`CREATE TABLE IF NOT EXISTS "${cacheTablespace}"."${baseTableName}" (
        object_id bigint NOT NULL,
        facet int NOT NULL,
        value bigint
    ) PARTITION BY LIST(facet)`)
    await session.query(`CREATE INDEX IF NOT EXISTS "${baseTableName}_object_id_idx" ON "${cacheTablespace}"."${baseTableName}" (object_id)`)
    // might need separate flat table for each special attr.  map dynamic attr to specific table
}

async function recreateFlatLinkedFacetTableRoot(session, force, postureCategory, facet) {
    let baseTableName = `${getSourceTableForPostureCategory(postureCategory)}${facet.table}Flat`

    if (force) {
        await session.query(`DROP TABLE IF EXISTS "${cacheTablespace}"."${baseTableName}"`)
    }

    // create base table to serve as the partition root
    await session.query(`CREATE TABLE IF NOT EXISTS "${cacheTablespace}"."${baseTableName}" (
        object_id bigint NOT NULL,  -- the connection
		facet int NOT NULL,         -- the facet
        link bigint NOT NULL,        -- the cpt
        value bigint                -- the score value
    ) PARTITION BY LIST(link)`)
    await session.query(`CREATE INDEX IF NOT EXISTS "${baseTableName}_object_id_idx" ON "${cacheTablespace}"."${baseTableName}" (link, object_id)`)

    return baseTableName
}

async function rebuildAllFlatFacetTables(force) {
    await Promise.all([rebuildFlatFacetTable(postureCategories.CONNECTION, force),
        rebuildFlatFacetTable(postureCategories.DEVICE, force),
        rebuildFlatFacetTable(postureCategories.SOFTWARE, force)])
}

function pushPendingEntry(postureCategory, id) {
    if (rebuildCache[postureCategory].lastBatchStartTime === undefined) {
        rebuildCache[postureCategory].lastBatchStartTime = Date.now()
    }

    rebuildCache[postureCategory].lastModificationTime = Date.now()
    rebuildCache[postureCategory].ids.add(id)
}

/**
 * This function is called after a device-impacting a flat facet is altered
 * @param {CUDHook} params
 */
async function postModifyConnection(params) {
    if (params.record.id) {
        pushPendingEntry(postureCategories.CONNECTION, params.record.id)
    }
}

/**
 * This function is called after a connection-impacting a flat facet is altered
 * @param {CUDHook} params
 */
async function postModifyDevice(params) {
    if (params.record.id) {
        pushPendingEntry(postureCategories.DEVICE, params.record.id)
    }
}

/**
 * This function is called after a software-impacting a flat facet is altered
 * @param {CUDHook} params
 */
async function postModifySoftware(params) {
    if (params.record.id) {
        pushPendingEntry(postureCategories.SOFTWARE, params.record.id)
    }
}

async function monitorObjectsForRebuild() {
    log.d('Checking for stale cache objects...')
    for (let category of Object.values(postureCategories)) {
        let promises = []
        if (rebuildCache[category].ids.size === 0) {
            continue
        }

        // We try to aggregate object changes into as large of a batch as possible to avoid repeated rebuilds (and/or the same
        // object being repeatedly touched by an ingestion). However, to ensure that the panel continues to be updated throughout
        // ingestion, we put an upper bound on how long we will wait before forcing rebuilds on stale objects.
        let now = Date.now()
        if (now - rebuildCache[category].lastBatchStartTime >= MAX_CACHE_REBUILD_TIMEOUT) {
            log.d(`Forcing cache update due to maximum aggregation timeout (${MAX_CACHE_REBUILD_TIMEOUT / 1000})`)
        } else if (now - rebuildCache[category].lastModificationTime >= MIN_CACHE_REBUILD_TIMEOUT) {
            log.d(`No new stale objects after (${MIN_CACHE_REBUILD_TIMEOUT / 1000}), issuing rebuild.`)
        } else {
            continue
        }

        let session = new Session()
        let ids = Array.from(rebuildCache[category].ids)
        log.log(`Found ${ids.length} stale objects for posture ${category}, rebuilding...`)
        rebuildCache[category].ids.clear()

        let rebuildStart = Date.now()
        await session.asTransaction(async () => {
            for (let facet of applicableFacetsPerPosture[category]) {
                promises.push(updateFlatFacetForObjects(category, facet, ids, session))
            }

            await Promise.all(promises)
        })

        log.log(`Rebuild for posture ${category} complete in ${Date.now() - rebuildStart} msec.`)
        rebuildCache[category].lastBatchStartTime = undefined
    }
}

async function initialise() {
    for (let category of Object.keys(postureCategories)) {
        rebuildCache[postureCategories[category]] = {
            lastBatchStartTime: undefined,
            lastModificationTime: Date.now(),
            ids: new Set()
        }
    }

    applicableFacetsPerPosture[postureCategories.CONNECTION] = []
    applicableFacetsPerPosture[postureCategories.DEVICE] = []
    applicableFacetsPerPosture[postureCategories.SOFTWARE] = []

    for (let facet of facets.attributes) {
        if (!('filterCategory' in facet)) {
            continue
        }

        let appliesTo = facet.filterCategory.appliesTo
        if (appliesTo === undefined) {
            appliesTo = [postureCategories.CONNECTION, postureCategories.DEVICE, postureCategories.SOFTWARE]
        }

        for (let category of appliesTo) {
            applicableFacetsPerPosture[category].push(facet.name)
        }
    }


    registerPanelCacheHooks()
    setInterval(async () => {
        await monitorObjectsForRebuild()
    }, CACHE_REBUILD_CHECK_INTERVAL)
}

async function registerPanelCacheHooks() {
    // NB: Currently this relies on the fact that we only expose front end mutations to make changes starting from
    // the top level. If this ever changes, we need to rethink how we handle these hooks to detect objects that need
    // to be refreshed.
    registerTreeHook('Connection', CUD_OP_POST_CHILDREN, postModifyConnection)
    registerTreeHook('Device', CUD_OP_POST_CHILDREN, postModifyDevice)
    registerTreeHook('SoftwareVersion', CUD_OP_POST_CHILDREN, postModifySoftware)
}

exports.rebuildAllFlatFacetTables = rebuildAllFlatFacetTables
exports.rebuildFlatFacetTable = rebuildFlatFacetTable
exports.cacheTablespace = cacheTablespace
exports.initialise = initialise
