/**
 * @file netscoutIngestionScanner.js - 1.2.0 - 3826bc12533e078a8e37cfe70ee04d9e85c8530e
 * 
 * @copyright Copyright (C) 2016-2023, ISARA Corporation, All Rights Reserved.
 * 
 * @license The code and other content set out herein is not in the public
 * domain, is considered a trade secret and is confidential to ISARA
 * Corporation. Use, reproduction or distribution, in whole or in part, of such
 * code or other content is strictly prohibited except by express written
 * permission of ISARA Corporation. Please contact ISARA Corporation at
 * info@isara.com for more information.
 */

/**
 * This module makes the configurations needed for netscout ingestion and then feeds them to CSV ingestion.
 * @module ingestion/netscout/netscoutIngestionScanner
 */

const fs = require('fs')
const log = require('../../util/log')(module)

const { streamZipFile, getField, processCsvStream } = require('../csvIngestionHelper')
const { IngestionStatus, inspectIPAddress, updateScanResultSummary } = require('../commonIngestion')
const { Session } = require('../../isaraql/session')
const { CommonUpserters } = require('../commonUpserters')
const netscoutCrypto = require('./netscoutCryptoMapping')
const { ChattyTimer } = require('../../util/chattyTimer')
const SystemPreferences = require('../../util/systemPreferences')
const { NetmaskMatchModes } = require('../netmaskMatching')

const STATUS_UPDATE_PERIOD = 1000
const NETSCOUT_TLS_RECORD = 65
const NETSCOUT_CERT_RECORD = 92

function processRow(row) {
    let recordTypeStr = getField(row, 'xdr_type')
    if (recordTypeStr === null) {
        throw `Record type must be specified.`
    }
    let recordType = parseInt(recordTypeStr)
    if (recordType !== NETSCOUT_TLS_RECORD && recordType !== NETSCOUT_CERT_RECORD) {
        throw `The record type cannot be recognized.`
    }

    let serverPort = null
    if (recordType === NETSCOUT_TLS_RECORD) {
        serverPort = getField(row, 'server_port')
    } else {
        // For NetScout cert CSV, we assume that the port is 443. This is
        // used to match records in NetScout TLS CSV, which contains just
        // HTTPS connections based on the samples NetScout have provided
        // (and hence with port 443).
        serverPort = '443'
    }

    let serverPortNumber = parseInt(serverPort)
    if (isNaN(serverPortNumber) || serverPortNumber <= 0 || serverPortNumber > 65535) {
        // Create a new error type for the case where the port number is 0,
        // so that it can be filtered out and ignored, as it may appear
        // quite frequently in NetScout's data. This is likely the result
        // of failed handshake.
        if (serverPortNumber === 0) {
            return {
                connection: null,
                server: null,
                client: null,
                cryptoPrimitives: null,
                cipherSuite: null,
                protocolVariant: null,
                certificate: null,
            }
        }

        throw `Server port must be an integer between 1 and 65535.`
    }

    // Get record time.
    // TODO: GAP2042 - make use of connection timestamp.
    // let recordTimestamp = getField(row, 'session_start_time')
    // Getting record time was changed as per #2220
    // expected the same current UTC date and time for all the uploaded connections,
    // regardless the input provided in the session_start_time
    let observerAtTime = new Date()

    // Get server info.
    let serverAddress = getField(row, 'server_addr')
    if (!serverAddress || !serverPort) {
        throw `Server address and port must both be specified.`
    }

    // let serverHostname = getField(row, 'sni', s => s ? s.toLowerCase() : '')

    // Process server info.
    let serverAddressInfo = inspectIPAddress(serverAddress, NetmaskMatchModes.SERVER)
    if (!serverAddressInfo.isIngestible) {
        throw `Invalid server address specified '${serverAddress}' of type '${serverAddressInfo.addressType}'.`
    }

    // Get client info.
    let clientAddress = getField(row, 'client_addr')
    if (!clientAddress) {
        throw `Client address must be specified.`
    }

    // Process client info.
    let clientAddressInfo = inspectIPAddress(clientAddress, NetmaskMatchModes.CLIENT)
    if (!clientAddressInfo.isIngestible) {
        throw `Invalid client address specified '${clientAddress}' of type '${clientAddressInfo.addressType}'.`
    }

    const l4Protocol = 'TCP'
    let cryptoPrimitives = []
    let cipherSuite = null
    let certificate = null
    let protocolVariant = null

    switch (recordType) {
        case NETSCOUT_TLS_RECORD: {
            let tlsInfo = processTLSRecord(
                serverAddressInfo.address,
                serverPortNumber,
                clientAddressInfo.address,
                l4Protocol,
                observerAtTime,
                row)
            cryptoPrimitives = tlsInfo.cryptoPrimitives
            cipherSuite = tlsInfo.cipherSuite
            protocolVariant = tlsInfo.protocolVariant
            break
        }
        case NETSCOUT_CERT_RECORD:
            certificate = processCertificateRecord(
                serverAddressInfo.address,
                serverPortNumber,
                clientAddressInfo.address,
                l4Protocol,
                observerAtTime,
                row)
            break
        default:
            throw `Unexpected Record Type '${recordType}'. This should be unreachable.`
    }

    return {
        connection: {
            observedAt: observerAtTime,
            friendlyName: `${clientAddressInfo.address} \u2192 ${serverAddressInfo.address}:${serverPortNumber}`,
            serverAddress: serverAddressInfo.address,
            port: serverPortNumber,
            l4Protocol: l4Protocol,
            clientAddress: clientAddressInfo.address,
            connectionCount: 1
        },
        server: {
            observedAt: observerAtTime,
            ipAddress: serverAddressInfo.address,
            ipVersion: serverAddressInfo.version,
        },
        client: {
            observedAt: observerAtTime,
            ipAddress: clientAddressInfo.address,
            ipVersion: clientAddressInfo.version,
        },
        cryptoPrimitives,
        cipherSuite,
        protocolVariant,
        certificate,
    }
}

/**
 * Process Crypto Primitives from a NetScout TLS CSV record.
 * @param {*} serverAddress The server address of the connection.
 * @param {*} port The server port of the connection.
 * @param {*} clientAddress The client address of the connection.
 * @param {*} l4Protocol The layer 4 protocol of the connection.
 * @param {*} observedAt The record date.
 * @param {*} row The record row being processed.
 * @returns An array of cryptoPrimitive entries to be upserted to the database.
 */
function processTLSRecord(serverAddress, port, clientAddress, l4Protocol, observedAt, row) {
    const primitiveEntries = []

    // Get key exchange algorithm.
    let kexAlgo = getField(row, 'cipher_exch_algo')

    // Get authentication algorithm.
    let authAlgo = getField(row, 'cipher_auth_algo')

    // Get bulk encryption algorithm.
    let encAlgo = getField(row, 'cipher_enc_algo')

    // Get MAC algorithm.
    let macAlgo = getField(row, 'cipher_mac_algo')

    if (kexAlgo) {
        let kexAlgoPrimitive = netscoutCrypto.getKeyExchangePrimitive(Number(kexAlgo))
        if (kexAlgoPrimitive) {
            primitiveEntries.push(kexAlgoPrimitive)
        }
    }

    if (authAlgo) {
        let authAlgoPrimitive = netscoutCrypto.getAuthenticationPrimitive(Number(authAlgo))
        if (authAlgoPrimitive) {
            primitiveEntries.push(authAlgoPrimitive)
        }
    }

    if (encAlgo) {
        let encAlgoPrimitive = netscoutCrypto.getEncryptionPrimitive(Number(encAlgo))
        if (encAlgoPrimitive) {
            primitiveEntries.push(encAlgoPrimitive)
        }
    }

    if (macAlgo) {
        let macAlgoPrimitive = netscoutCrypto.getMACPrimitive(Number(macAlgo))
        if (macAlgoPrimitive) {
            primitiveEntries.push(macAlgoPrimitive)
        }
    }

    let {
        cipherSuite,
        protocolVariant
    } = netscoutCrypto.calculateCipherSuiteAndPrimitives(primitiveEntries)

    let uniqueIds = {
        serverAddress,
        port,
        clientAddress,
        l4Protocol,
        observedAt,
    }

    // create a Crypto Primitive record
    let createPrimitive = (cryptoPrimitive) => {
        return {
            ...uniqueIds,
            cryptoPrimitive,
        }
    }

    let cipherSuiteEntry = null
    if (cipherSuite) {
        cipherSuiteEntry = {
            ...uniqueIds,
            cipherSuite
        }
    }

    let protocolVariantEntry = null
    if (protocolVariant) {
        protocolVariantEntry = {
            ...uniqueIds,
            protocolVariant,
        }
    }

    return {
        cryptoPrimitives: primitiveEntries.map(p => createPrimitive(p)),
        cipherSuite: cipherSuiteEntry,
        protocolVariant: protocolVariantEntry,
    }
}

/**
 * Process Crypto Primitives from a NetScout Cert CSV record.
 * @param {*} serverAddress The server address of the connection.
 * @param {*} port The server port of the connection.
 * @param {*} clientAddress The client address of the connection.
 * @param {*} l4Protocol The layer 4 protocol of the connection.
 * @param {*} observedAt The record date.
 * @param {*} row The record row being processed.
 * @returns An array of cryptoPrimitive entries to be upserted to the database.
 */
function processCertificateRecord(/*serverAddress, port, clientAddress, l4Protocol, observedAt, row*/) {
    // As per our conversation with NetScout, certificate records are
    // sampled mainly for the purpose of tracking certs' expiry dates.
    // Certs info are not saved/sampled for every TLS connection.
    // This means that we will not be able to correlate every cert
    // record to a connection record, or every connection record to a
    // cert record. Nevertheless, our implementation tries its best to
    // establish a correlation based on SNI, client IP, and server IP
    // matching. In order to carry out correlation, we also assume the
    // server port for cert records is "443", given that all TLS connection
    // records are from HTTPS so far.
    //
    // We create a connection even if a cert record cannot be correlated
    // to an existing connection. The new connection would contain only
    // cert info. This allows the user to ingest NetScout CSV files in
    // any order, such as cert files followed by connection files, or
    // vice versa.
    // const primitiveEntries = []

    throw `TODO: make this work`

    // create a Crypto Primitive record
    // let createPrimitive = (cryptoPrimitive) => {
    //     return {
    //         serverAddress,
    //         port,
    //         clientAddress,
    //         l4Protocol,
    //         observedAt,
    //         cryptoPrimitive,
    //     }
    // }

    // // Get server cert subject name.
    // let serverCertSubjectName = getField(row, 'sub_name')
    // if (serverCertSubjectName === null) {
    //     throw `No server cert subject name available.`
    // }

    // // Get server cert issuer name.
    // let serverCertIssuerName = getField(row, 'issuer_name')
    // if (serverCertIssuerName === null) {
    //     throw `No server cert issuer name available.`
    // }

    // // Get cert creation date.
    // let serverCertCreationTimestamp = getField(row, 'activation')
    // let serverCertNotBefore = null
    // if (serverCertCreationTimestamp !== null) {
    //     serverCertNotBefore = new Date(serverCertCreationTimestamp * 1000)
    // }

    // // Get cert expiry date.
    // let serverCertExpiryTimestamp = getField(row, 'expiry')
    // let serverCertNotAfter = null
    // if (serverCertExpiryTimestamp !== null) {
    //     serverCertNotAfter = new Date(serverCertExpiryTimestamp * 1000)
    // }

    // let serverCertificate = {
    //     subject: serverCertSubjectName,
    //     issuer: serverCertIssuerName,
    //     certificateType: allTypes['CertificateType']._enum.idByName['X509'],
    //     notBefore: serverCertNotBefore,
    //     notAfter: serverCertNotAfter,
    //     manuallyAdded: new SQLUpdateOp('=', false, false),
    //     observedAt: new SQLUpdateOp('=', recordDate, recordDate)
    // }

    // connection.connectionCertificates.push({
    //     certificate: serverCertificate
    // })

    // connection.serverDeviceAddressPort.deviceAddress.device.deviceCertificates.push({
    //     certificate: serverCertificate
    // })

    // return primitiveEntries
}

class NetscoutBenchMarking {
    processing = new ChattyTimer('NetScout Processing', 'rows')
    committing = new ChattyTimer('NetScout Committing', 'postgres records')
    elapsed = new ChattyTimer('NetScout Elapsed')

    summary() {
        log.log('<= NetScout Benchmark =>')
        this.processing.summary()
        this.committing.summary()
        this.elapsed.summary()
    }
}

async function processNetscoutCSV(stream, scanResults) {
    let session = new Session()
    let preferences = await SystemPreferences()
    /**
     * @type NetscoutBenchMarking
     */
    let benchMark
    if ((preferences?.benchmarking?.all ?? false) || (preferences?.benchmarking?.netscout ?? false)) {
        benchMark = new NetscoutBenchMarking()
    }


    let commonUpserters = new CommonUpserters(session, { timer: benchMark?.committing, allowParallelCommits: true })

    let waitForCommits = false

    let { cipherSuiteUpserter, connectionUpserter, cryptoUpserter, deviceUpserter, protocolVariantUpserter } = commonUpserters

    let processed = 0

    benchMark?.elapsed?.start()

    let lastCommitPromise = undefined

    let logT = log.throttled()

    await processCsvStream(stream,
        /**
         * @param {FIFOQueue} queue
         */
        async (queue) => {
            benchMark?.processing?.start()
            let howMany = queue.length
            while (!queue.empty) {
                let row = queue.dequeue()
                if (!row) { continue }
                try {
                    let constructed = processRow(row)
                    if (!constructed) { continue }
                    let {
                        connection,
                        server,
                        client,
                        cryptoPrimitives,
                        cipherSuite,
                        protocolVariant,
                    } = constructed
                    processed++
                    if (processed % STATUS_UPDATE_PERIOD === 0) {
                        await updateScanResultSummary(scanResults, `Processed ${processed.toLocaleString()} rows...`)
                    }

                    connectionUpserter.push(connection)
                    deviceUpserter.push(server)
                    deviceUpserter.push(client)
                    cipherSuiteUpserter.push(cipherSuite)
                    protocolVariantUpserter.push(protocolVariant)

                    for (let crypto of (cryptoPrimitives || [])) {
                        cryptoUpserter.push(crypto)
                    }
                }
                catch (error) {
                    logT.e(error)
                }
            }
            benchMark?.processing?.stop(howMany)

            if (commonUpserters.needsCommit() /* TODO: or time based */) {
                if (lastCommitPromise) await lastCommitPromise
                let commitPromise = commonUpserters.commit()
                if (waitForCommits) {
                    await commitPromise
                } else {
                    lastCommitPromise = commitPromise
                }
            }
        }
    )

    if (lastCommitPromise) await lastCommitPromise
    await commonUpserters.commit()
    benchMark?.elapsed?.stop()

    benchMark?.summary()

    return processed
}

async function ingestNetscout(dataSourceScan, scanResults, onFulfilled, onRejected, onFinally) {
    const parsedConfiguration = JSON.parse(dataSourceScan.dataSource.configuration)
    const netscoutFilesConfig = parsedConfiguration.file_path.map(path => ({
        mimeType: /\.csv$/.test(path) ? 'csv' : 'zip',
        tmpFile: path
    }))

    try {
        let processedRows = 0
        for (const fileConfig of netscoutFilesConfig) {
            switch (fileConfig.mimeType) {
                case 'csv': {
                    const stream = fs.createReadStream(fileConfig.tmpFile)
                    try {
                        processedRows += await processNetscoutCSV(stream, scanResults)
                    } finally {
                        stream.close()
                    }
                    break
                }
                case 'zip': {
                    let zipRows = await streamZipFile(
                        fileConfig.tmpFile,
                        entry => !entry.name.toLowerCase().includes('__macosx') && entry.name.toLowerCase().endsWith('.csv'),
                        s => processNetscoutCSV(s, scanResults)
                    )
                    processedRows += zipRows.reduce((p, v) => p = v, 0)
                    break
                }
                default:
                    log.e(`Unexpected MIME Type '${fileConfig.mimeType}'. How did I get here?`)
            }
        }
        await updateScanResultSummary(scanResults, `Processed ${processedRows.toLocaleString()} rows.`)
        await onFulfilled(IngestionStatus.SUCCESS)
    } catch (e) {
        log.e('Failure during Netscout ingestion', e)
        await onRejected(e)
    } finally {
        await onFinally()
    }
}

module.exports = {
    name: 'NETSCOUT CSV',
    test: async () => { },
    scan: ingestNetscout,
}
