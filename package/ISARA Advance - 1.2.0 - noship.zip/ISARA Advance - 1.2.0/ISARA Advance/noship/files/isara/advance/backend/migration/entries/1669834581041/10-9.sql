--
-- @file 10-9.sql - 1.2.0 - 3826bc12533e078a8e37cfe70ee04d9e85c8530e
-- 
-- @copyright Copyright (C) 2016-2023, ISARA Corporation, All Rights Reserved.
-- 
-- @license The code and other content set out herein is not in the public
-- domain, is considered a trade secret and is confidential to ISARA
-- Corporation. Use, reproduction or distribution, in whole or in part, of such
-- code or other content is strictly prohibited except by express written
-- permission of ISARA Corporation. Please contact ISARA Corporation at
-- info@isara.com for more information.
--

    /* 
    * 
    *    DATA - BACKWARDS 
    *    MIGRATION 10 TO 9 
    *    >FOR RELEASE 0.91.0
    *    ORIGIN GIT HASH:36911e55aab42e62306b2c69392cc84b1ba3b46e
    * 
    *    CREATED ON 2022-11-30T18:56:21.219Z
    * 
    */





