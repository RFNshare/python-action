/**
 * @file dbTypes.js - 1.2.0 - 3826bc12533e078a8e37cfe70ee04d9e85c8530e
 * 
 * @copyright Copyright (C) 2016-2023, ISARA Corporation, All Rights Reserved.
 * 
 * @license The code and other content set out herein is not in the public
 * domain, is considered a trade secret and is confidential to ISARA
 * Corporation. Use, reproduction or distribution, in whole or in part, of such
 * code or other content is strictly prohibited except by express written
 * permission of ISARA Corporation. Please contact ISARA Corporation at
 * info@isara.com for more information.
 */


exports.allCryptoPrimitives = {}
exports.allStrongCryptoPrimitives = {}
exports.allWeakCryptoPrimitives = {}
exports.certificateTypes = {}
exports.connectionCertificateTypes = {}
exports.connectionRatings = {}
exports.deviceTypes = {}
exports.notificationTypes = {}
exports.protocols = {}
exports.protocolVariants = {}
exports.strongProtocolVariants = {}
exports.weakProtocolVariants = {}
exports.roles = {}
exports.softwareTypes = {}
exports.tagTypes = {}
exports.layer4Protocols = {}
exports.users = []