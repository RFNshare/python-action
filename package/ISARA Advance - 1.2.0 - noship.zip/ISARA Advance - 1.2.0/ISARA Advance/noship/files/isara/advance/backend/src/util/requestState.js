/**
 * @file requestState.js - 1.2.0 - 3826bc12533e078a8e37cfe70ee04d9e85c8530e
 * 
 * @copyright Copyright (C) 2016-2023, ISARA Corporation, All Rights Reserved.
 * 
 * @license The code and other content set out herein is not in the public
 * domain, is considered a trade secret and is confidential to ISARA
 * Corporation. Use, reproduction or distribution, in whole or in part, of such
 * code or other content is strictly prohibited except by express written
 * permission of ISARA Corporation. Please contact ISARA Corporation at
 * info@isara.com for more information.
 */

/**
 * Add state to each request that can be retrieved without passing this state around. Uses
 * `AsyncLocalStorage` which has the goal of being similar to a `ThreadLocal`.
 * @module util/requestState
 */

const { AsyncLocalStorage } = require('async_hooks')

/**
 * This `AsyncLocalStorage` will be used to manage all requests.
 */
const asyncLocal = new AsyncLocalStorage()

/**
 * A 'unique' state or session identifier to log different flows.
 */
var stateId = Math.floor(Math.random() * Number.MAX_SAFE_INTEGER/2)

function requestStateHandling(userArgNumber) {
    /**
     * Wrap the request handler function with a uniquely-numbered state.
     * If 'user' is present in the arguments, then add the authenticated user to the state.
     *
     * @param {function} asyncFunc An async function that should be a user request handler.
     * @return {function} An async function that can be called to process user requests.
     */
    return function (asyncFunc) {
        var funcToReturn = async function () {
            var args = arguments
            return new Promise((accept, reject) => {
                var user
                if (typeof args[userArgNumber] === 'object' && 'user' in args[userArgNumber]) {
                    user = args[userArgNumber]['user']
                }
                ++stateId
                if (stateId >= Number.MAX_SAFE_INTEGER) {
                    stateId = 0
                }
                var state = { stateId }
                if (user) {
                    state.user = user
                }
                asyncLocal.run(state, () => {
                    asyncFunc(...args).then((value) => {
                        accept(value)
                    }).catch((e) => {
                        reject(e)
                    })
                })
            })
        }
        Object.assign(funcToReturn, asyncFunc)
        return funcToReturn
    }
}

/*
 * Wrap an async function to handle GraphQL user requests.
 */
exports.addRequestStateHandlingForGraphQL = requestStateHandling(1)
/*
 * Wrap an async function to handle other user requests.
 */
exports.addRequestStateHandling = requestStateHandling(0)

/**
 * @typedef RequestState
 * @property {number} stateId A relatively unique id per request.
 * @property {Object} [user] User information (if available)
 * @property {number} user.uid User ID from the database.
 * @property {string} user.userName User name from the database.
 * @property {string} user.fullName User's human name from the database.
 */

/**
 * Get the state for the current request.
 * @returns {(RequestState|undefined)} There may be no state for the current request / or the current call
 *          may not be inside of a request.
 */
exports.getRequestState = function () {
    return asyncLocal.getStore()
}

/**
 * Temporarily disable the request state.
 *
 */
exports.suspendRequestState = function () {
    asyncLocal.disable()
}

/**
 * Re-enable request state after a previous call to suspend.
 *
 * @param {any} store The store to resume the request state with.
 *
*/
exports.resumeRequestState = function (store) {
    asyncLocal.enterWith(store)
}
