/**
 * @file dbObjects.js - 1.2.0 - 3826bc12533e078a8e37cfe70ee04d9e85c8530e
 * 
 * @copyright Copyright (C) 2016-2023, ISARA Corporation, All Rights Reserved.
 * 
 * @license The code and other content set out herein is not in the public
 * domain, is considered a trade secret and is confidential to ISARA
 * Corporation. Use, reproduction or distribution, in whole or in part, of such
 * code or other content is strictly prohibited except by express written
 * permission of ISARA Corporation. Please contact ISARA Corporation at
 * info@isara.com for more information.
 */

var crypto = require('crypto')
var log = require('../util/log')(module)
var {
    notificationTypes,
    users,
    connectionRatings
} = require('./dbTypes')

const {
    certificateType,
    deviceType,
    generateHostName,
    ipAddress,
    l4Protocol,
    macAddress,
    pickOne,
    port,
    randomBelow,
    randomDate,
    randomPastDate
} = require('./sampleHelpers')

var randomWords = require('random-words')

var {
    allTypes
} = require('../isaraql/schemaDiscovery')

require('json-bigint-patch')

class IDPK {
    constructor(table) {
        this._names = []
        this.addField('id', null)
        this._table = table
    }

    addField(name, value) {
        this._names.push(name)
        this[name] = value
    }

    get nameValues(){
        var toReturn ={}
        for (var name of this._names) {
            if(name !== 'id'){
                toReturn[name] = this[name]
            }
        }
        return toReturn
    }

    get allValues() {
        var toReturn = []
        for (var name of this._names) {
            toReturn.push(this[name])
        }
        return toReturn
    }

    get allNames() {
        return this._names
    }

    get values() {
        return this.allValues.slice(1)
    }

    get names() {
        return this.allNames.slice(1)
    }

    get table() {
        return this._table
    }

    async populate() { }
}

class ENUM extends IDPK {
    constructor(table, name) {
        super(table)
        this.addField('name', name)
        this.id = allTypes[this._table]._enum.idByName[name]
    }
}

class Agent extends IDPK {
    constructor(device) {
        super('Agent')
        this.addField('device', device)
    }
}

class AgentCertificate extends IDPK {
    constructor(agent, certificate) {
        super('AgentCertificate')
        this.addField('agent', agent.id)
        this.addField('certificate', certificate.id)
    }

    async populate() {
    }
}

class CAIssuedCertificate extends IDPK {
    constructor(certificationAuthority, certificate) {
        super('CAIssuedCertificate')
        this.addField('certificationAuthority', certificationAuthority.id)
        this.addField('certificate', certificate.id)
        this.addField('whenIssued', randomDate())
        this.addField('whenRevoked', randomDate())
        this.addField('whenExpired', randomDate())
    }

    async populate() {
    }
}

class Certificate extends IDPK {
    constructor(certificationAuthority) {
        super('Certificate')
        log.d(certificationAuthority)
        this.addField('certificateType', certificateType().id)
        // TODO: GAP1630 - trustAnchor
        this.addField('subject', `CN=${generateHostName()}`)
        this.addField('issuer', `CN=${generateHostName()}, OU=engineering`)
        this.addField('certificateContent', randomWords(3).join(' '))
    }

    async populate() {
        let hash = crypto.createHash('sha256')
        hash.update(this.subject)
        hash.update(this.issuer)
        hash.update(this.certificateContent)

        this.addField('contentHash', hash.digest().toString('hex'))
    }
}

class CertificateCryptoPrimitive extends IDPK {
    constructor(certificate, cryptoPrimitive, keyLength) {
        super('CertificateCryptoPrimitive')
        this.addField('certificate', certificate)
        this.addField('cryptoPrimitive', cryptoPrimitive)
        this.addField('keyLength', keyLength)
    }

    async populate() {
    }
}

class CertificateType extends ENUM {
    constructor(name) {
        super('CertificateType', name)
    }
}

class CertificationAuthority extends IDPK {
    constructor(keyStoreKey) {
        super('CertificationAuthority')
        this.addField('keyStoreKey', keyStoreKey.id)
        this.addField('name', `FakeAuthority-${keyStoreKey.id}`)
        this.addField('serialNumber', '')
    }

    async populate() {
        this.name = 'cert-' + Math.random()
        this.serialNumber = 'CT-' + Math.random()
    }
}

class Connection extends IDPK {
    constructor() {
        super('Connection')
        const sampleConnectionRatings = [{id:1,name:"HIGH"},{id:2,name:"MEDIUM"},{id:3,name:"LOW"}]
        this.addField('connectionCount', randomBelow(256, 1))
        this.addField('clientDeviceAddressPort', null)
        this.addField('serverDeviceAddressPort', -1)
        this.addField('sensitivity', pickOne([null, pickOne(sampleConnectionRatings).id]))
        this.addField('importance', pickOne([null, pickOne(sampleConnectionRatings).id]))
        this.addField('friendlyName', null)
        this.addField('bytesTransferred', randomBelow(1000) * 10 ** randomBelow(6))
        this.addField('addedAt', randomPastDate(120))
        this.addField('addedBy', null)
    }

}

class ConnectionCertificate extends IDPK {
    constructor(connection, certificate) {
        super('ConnectionCertificate')
        this.addField('connection', connection)
        this.addField('certificate', certificate)
    }
}
class ConnectionCertificateType extends ENUM {
    constructor(name) {
        super('ConnectionCertificateType', name)
    }
}

class ConnectionCipherSuite extends IDPK {
    constructor(connection, cipherSuite) {
        super('ConnectionCipherSuite')
        this.addField('connection', connection.id)
        this.addField('cipherSuite', cipherSuite.id)
    }

    async populate() {
    }
}

class ConnectionCryptoPrimitive extends IDPK {
    constructor(connection, cryptoPrimitive) {
        super('ConnectionCryptoPrimitive')
        this.addField('connection', connection.id)
        this.addField('cryptoPrimitive', cryptoPrimitive.id)
    }
}

class ConnectionProtocolVariant extends IDPK {
    constructor(connection, protocolVariant) {
        super('ConnectionProtocolVariant')
        this.addField('connection', connection)
        this.addField('protocolVariant', protocolVariant)
    }

    async populate() { }
}

class ConnectionProtocolVariantCertificate extends IDPK {
    constructor(connectionProtocolVariant, connectionCertificateType, certificate) {
        super('ConnectionProtocolVariantCertificate')
        this.addField('connectionProtocolVariant', connectionProtocolVariant)
        this.addField('connectionCertificateType', connectionCertificateType)
        this.addField('certificate', certificate)
    }

    async populate() { }
}

class ConnectionRatingScale extends ENUM {
    constructor(name) {
        super('ConnectionRatingScale', name)
    }
}

class ConnectionTag extends IDPK {
    constructor(connection, tag) {
        super('ConnectionTag')
        this.addField('connection', connection)
        this.addField('tag', tag)
    }
}

class CryptoPrimitive extends ENUM {
    constructor(id, name, friendlyName, cryptoScore, cryptoAlgorithm) {
        super('CryptoPrimitive')
        this.id = id
        this.addField('name', name)
        this.addField('friendlyName', friendlyName)
        this.addField('cryptoScore', cryptoScore)
        this.addField('cryptoAlgorithm', cryptoAlgorithm)
    }

    async populate() {
    }
}

class Device extends IDPK {
    constructor() {
        super('Device')
        let randomDeviceType = deviceType()
        this.addField('deviceType', randomDeviceType.id)
        this.addField('lastTimeOnline', randomPastDate(72))
        this.addField('addedDate', randomPastDate(24, 72))
        this.addField('addedBy', pickOne([null, pickOne(users).id]))
        this.addField('friendlyName', this.generateFriendlyName(randomDeviceType))
    }

    generateFriendlyName(randomDeviceType) {
        switch (pickOne([0, 1, 2])) {
        case 0:
            // null and empty-string are both allowed by the DB schema
            return pickOne(['', null])

        case 1: {
            // random device name
            let name = randomDeviceType.name.toLowerCase().replace(/_/g, '-')
            let suffix = `${randomBelow(99, 1)}`.padStart(2, '0')
            return `${name}-${suffix}`
        }
        case 2:
            return generateHostName()
        }
    }

    async populate() {
    }
}

function ipVersion(addr) {
    if (addr.includes('.')) {
        return 4
    } else {
        return 6
    }
}
class DeviceAddress extends IDPK {
    constructor(device) {
        super('DeviceAddress')
        this.addField('address', ipAddress())
        this.addField('addressIPVersion', ipVersion(this.address))
        this.addField('device', device.id)
        this.addField('friendlyName', null)
    }

    async populate() {
        this.friendlyName = 'device-address-' + Math.random()
    }
}

class DeviceAddressMACAddress extends IDPK {
    constructor(deviceAddress, deviceMACAddress) {
        super('DeviceAddressMACAddress')
        this.addField('deviceAddress', deviceAddress.id)
        this.addField('deviceMACAddress', deviceMACAddress.id)
    }
}

class DeviceAddressPort extends IDPK {
    constructor(deviceAddress, unusablePorts, devicePort, layer4Protocol) {
        super('DeviceAddressPort')
        if (unusablePorts === undefined) {
            unusablePorts = []
        }
        if (layer4Protocol === undefined) {
            layer4Protocol = l4Protocol().id
        }
        let tempPort
        if(devicePort){
            tempPort = devicePort
        }else{
            tempPort = port(unusablePorts)
        }
        this.addField('l4Protocol', layer4Protocol)
        this.addField('deviceAddress', deviceAddress.id)
        this.addField('port', tempPort)
        this.addField('isGuardian', Math.random() > 0.9 ? true : false)
        this.addField('friendlyName', null)
    }

    async populate() {
        this.friendlyName = 'dap-' + Math.random()
    }
}

class DeviceCertificate extends IDPK {
    constructor(device, certificate) {
        super('DeviceCertificate')
        this.addField('device', device)
        this.addField('certificate', certificate)
    }

    async populate() {

    }
}

class DeviceMACAddress extends IDPK {
    constructor(device) {
        super('DeviceMACAddress')
        this.addField('device', device.id)
        this.addField('mac', macAddress())
    }
}

class DeviceSoftware extends IDPK {
    constructor(device, software) {
        super('DeviceSoftware')
        this.addField('device', device.id)
        this.addField('softwareVersion', software.id)
    }
}

class DeviceSoftwareConnection extends IDPK {
    constructor(deviceSoftware, connection) {
        super('DeviceSoftwareConnection')
        this.addField('deviceSoftware', deviceSoftware)
        this.addField('connection', connection.id)
    }
}

class DeviceTag extends IDPK {
    constructor(device, tag) {
        super('DeviceTag')
        this.addField('device', device)
        this.addField('tag', tag)
    }
}

class DeviceType extends ENUM {
    constructor(name) {
        super('DeviceType', name)
    }
}

class KeyStore extends IDPK {
    constructor() {
        super('KeyStore')
    }

    get nameValues(){
        var toReturn ={}
        for (var name of this._names) {
            if(name === 'id'){
                toReturn[name] = this[name]
            }
        }
        return toReturn
    }

    async populate() {
    }
}

class KeyStoreKey extends IDPK {
    constructor(keyStore) {
        super('KeyStoreKey')
        this.addField('keyStore', keyStore.id)
        this.addField('keyHandle', null)
    }

    async populate() {
        this.keyHandle = Math.random()
    }
}

class Layer4Protocol extends ENUM {
    constructor(name) {
        super('Layer4Protocol', name)
    }
}
class Netmask extends IDPK {
    constructor() {
        super('Netmask')
        this.addField('netmask', ipAddress() + '/' + (Math.floor(Math.random() * 24) + 1))
       this.addField('name', "generated_"+(Math.random() > 0.1 ? randomWords(2).join(' ') : null))
       this.addField('sortOrder', 1 )
       // this.addField('tagInScansEnabled', this.tag ? pickOne([true, false]) : false)
    }
}

class Notification extends IDPK {
    constructor(data) {
        super('Notification')
        log.log(Object.keys(data))
        this.addField('addedAt', randomDate())
        const types = data.notificationTypes;
        const pickedType = pickOne(types)
        this.addField('type', pickedType.id)
        this.addField('title', randomWords(3).join(' '))
        this.addField('description', randomWords(60).join(' '))
        this.addField('originatedBy', pickOne(data.users).id)
    }
}

class NotificationAction extends IDPK {
    constructor(notification, user) {
        super('NotificationAction')
        this.addField('notification', notification.id)
        this.addField('user', user.id)
        this.addField('actionedAt', randomDate(notification.addedAt.getTime()))
    }
}

class NotificationType extends ENUM {
    constructor(name) {
        super('NotificationType', name)
    }
}

class OneTimeKey extends IDPK {
    constructor(certificationAuthority) {
        super('OneTimeKey')
        this.addField('certificationAuthority', certificationAuthority.id)
        this.addField('keyValue', '')
        this.addField('remainingUsages', Math.floor(Math.random() * 10))
    }

    async populate() {
        this.keyValue = 'key-' + Math.random()
    }
}

class Protocol extends ENUM {
    constructor(name) {
        super('Protocol', name)
    }
}

class ProtocolVariant extends IDPK {
    constructor(id, name, protocol) {
        super('ProtocolVariant')
        this.id = id
        this.addField('name', name)
        this.addField('protocol', protocol)
    }

    async populate() { }
}

class Role extends ENUM {
    constructor(name) {
        super('Role', name)
    }
}

class Software extends IDPK {
    constructor(name, vendor, softwareType, data) {
        super('Software')
        this.addField('name', name)
        this.addField('softwareVendor', vendor)
        this.addField('softwareType', softwareType)
        this.addField('addedBy', pickOne([null, pickOne(data.users).id]))
        this.addField('addedAt', randomPastDate(120))
    }
}

class SoftwareType extends ENUM {
    constructor(name) {
        super('SoftwareType', name)
    }
}

class SoftwareVersion extends IDPK {
    constructor(softwareId, name, sortableVersion) {
        super('SoftwareVersion')
        let version = `v${sortableVersion + 1}.${randomBelow(10)}`
        this.addField('software', softwareId)
        this.addField('name', `${name}-${version}`)
        this.addField('version', version)
        this.addField('sortableVersion', sortableVersion)
        this.addField('score', randomBelow(100, 1))
    }

    async populate() {
    }
}

class SoftwareVersionTag extends IDPK {
    constructor(softwareVersion, tag) {
        super('SoftwareVersionTag')
        this.addField('softwareVersion', softwareVersion)
        this.addField('tag', tag)
    }
}

class Tag extends IDPK {
    constructor(value, tagType) {
        super('Tag')
        this.addField('value', value)
        this.addField('tagType', tagType)
        this.addField('lastUsed', new Date())
    }
}

class TagType extends ENUM {
    constructor(name, isNumeric, unit) {
        super('TagType', name)
        this.addField('isNumeric', isNumeric ? true : false)
        this.addField('unit', unit ? unit : null)
    }
}

class User extends IDPK {
    constructor(userName, humanName, passwordHash) {
        super('User')
        this.addField('userName', userName)
        this.addField('humanName', humanName)
        this.addField('passwordExpiry', new Date())
        this.addField('lockedOut', false)
        this.addField('hidden', false)
        this.addField('passwordHash', passwordHash)
    }
}

class UserRole extends IDPK {
    constructor(user, role) {
        super('UserRole')
        this.addField('user', user)
        this.addField('role', role)
    }
}

exports.IDPK = IDPK
exports.ENUM = ENUM
exports.Agent = Agent
exports.AgentCertificate = AgentCertificate
exports.CAIssuedCertificate = CAIssuedCertificate
exports.Certificate = Certificate
exports.CertificateCryptoPrimitive = CertificateCryptoPrimitive
exports.CertificateType = CertificateType
exports.CertificationAuthority = CertificationAuthority
exports.Connection = Connection
exports.ConnectionCertificate = ConnectionCertificate
exports.ConnectionCertificateType = ConnectionCertificateType
exports.ConnectionCipherSuite = ConnectionCipherSuite
exports.ConnectionProtocolVariant = ConnectionProtocolVariant
exports.ConnectionProtocolVariantCertificate = ConnectionProtocolVariantCertificate
exports.ConnectionRatingScale = ConnectionRatingScale
exports.ConnectionTag = ConnectionTag
exports.CryptoPrimitive = CryptoPrimitive
exports.Device = Device
exports.DeviceAddress = DeviceAddress
exports.DeviceAddressMACAddress = DeviceAddressMACAddress
exports.DeviceAddressPort = DeviceAddressPort
exports.DeviceCertificate = DeviceCertificate
exports.DeviceMACAddress = DeviceMACAddress
exports.DeviceSoftware = DeviceSoftware
exports.DeviceSoftwareConnection = DeviceSoftwareConnection
exports.DeviceTag = DeviceTag
exports.DeviceType = DeviceType
exports.KeyStore = KeyStore
exports.KeyStoreKey = KeyStoreKey
exports.Layer4Protocol = Layer4Protocol
exports.Netmask = Netmask
exports.Notification = Notification
exports.NotificationAction = NotificationAction
exports.NotificationType = NotificationType
exports.OneTimeKey = OneTimeKey
exports.Protocol = Protocol
exports.ProtocolVariant = ProtocolVariant
exports.Role = Role
exports.Software = Software
exports.SoftwareType = SoftwareType
exports.SoftwareVersion = SoftwareVersion
exports.SoftwareVersionTag = SoftwareVersionTag
exports.Tag = Tag
exports.TagType = TagType
exports.User = User
exports.UserRole = UserRole
exports.ConnectionCryptoPrimitive = ConnectionCryptoPrimitive
