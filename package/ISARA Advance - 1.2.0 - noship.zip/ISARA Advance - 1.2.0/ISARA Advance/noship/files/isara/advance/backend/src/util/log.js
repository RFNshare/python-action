/**
 * @file log.js - 1.2.0 - 3826bc12533e078a8e37cfe70ee04d9e85c8530e
 * 
 * @copyright Copyright (C) 2016-2023, ISARA Corporation, All Rights Reserved.
 * 
 * @license The code and other content set out herein is not in the public
 * domain, is considered a trade secret and is confidential to ISARA
 * Corporation. Use, reproduction or distribution, in whole or in part, of such
 * code or other content is strictly prohibited except by express written
 * permission of ISARA Corporation. Please contact ISARA Corporation at
 * info@isara.com for more information.
 */

/**
 * This module manages logging. (Application logging - not user activity in the database)
 * @module util/log
 */

const fs = require('fs').promises
var path = require('path')
const { getRequestState } = require('./requestState')
const util = require('util')
const { parentPort, isMainThread, threadId } = require('worker_threads')

const THROTTLED_COUNT = 100

/**
 * The delay between re-opening the log file.
 * 
 * The file is re-opened to prevent strange behaviour with log rotation.
 */
const REOPEN_LOG_FILE_INTERVAL_MS = 10 * 1000 * 60

/**
 * This is the file that all logging will be written to.
 */
let logFileName = null

/**
 * Values indicating how to log request state.
 */
const STATE_LOGGING_OPTIONS = Object.freeze({
    /**
     * Don't log any state.
     */
    NONE: 0,
    /**
     * Just log the user name if available.
     */
    USERNAME: 1,
    /**
     * Log all available state info.
     */
    FULL_STATE: 2
})

/**
 * @typedef ThrottledLogger 
 * @property {Function} w Warning logger
 * @property {Function} e Error logger
 * @property {Function} d Debug logger
 * @property {Function} log Log level logger
 */

/**
 * Indicate the level of state logging.
 */
const defaultStateLogging = STATE_LOGGING_OPTIONS.USERNAME

/**
 * @class Log Writes formatted and timestamped messages to the console.
 */
class Log {
    /**
     * Build a Log to be used by a specific module.
     * @param {Module} [otherModule] The module instantiating the log.
     */
    constructor(otherModule) {
        this.module = otherModule
        this.id = otherModule.id
        if (this.id) {
            const slash = this.id.lastIndexOf('/')
            if (slash != -1) {
                this.id = this.id.substring(slash + 1)
            }
        }
        this._debug = false
        this._warn = true
        this._error = true
        this._logLineNumbers = true
        this._stateLogging = defaultStateLogging
        this.STATE_LOGGING_OPTIONS = STATE_LOGGING_OPTIONS
    }

    /**
     * @property logLineNumbers {boolean} When `true`, line numbers will be printed for each log entry, instead of just a module name. This comes at the expense of more work to print a log entry.
     */

    set logLineNumbers(allow) {
        this._logLineNumbers = allow === true
    }

    get logLineNumbers() {
        return this._logLineNumbers
    }

    /**
     * Sets the global log file name.
     */
    set logFile(fileName) {
        if (logFileName !== null && fileName !== logFileName) {
            throw new Error('Log file name being set twice')
        }
        logFileName = fileName
    }

    /**
     * Set request state should be logging.
     * @param {(number|string)} stateLogging A key or value from `STATE_LOGGING_OPTIONS`.
     */
    set stateLogging(stateLogging) {
        for (var key of STATE_LOGGING_OPTIONS) {
            if (key === stateLogging) {
                this._stateLogging = STATE_LOGGING_OPTIONS[key]
                return
            }
            if (STATE_LOGGING_OPTIONS[key] === stateLogging) {
                this._stateLogging = stateLogging
                return
            }
        }
        throw new Error(`Not a valid state logging option: ${stateLogging}`)
    }

    /**
     * Get the current state of request state logging.
     */
    get stateLogging() {
        return this._stateLogging
    }

    /**
     * Controls if debug level messages will be displayed.
     * @type {boolean}
     */
    set debug(allow) {
        this._debug = allow === true
    }

    get debug() {
        return this._debug || Log._debugAll
    }

    /**
     * Controls if ALL Log instances should log debug messages.
     */
    set debugAll(allow) {
        Log._debugAll = allow === true
    }

    get debugAll() {
        return Log._debugAll
    }


    /**
     * Controls if warning level messages should be displayed.
     * @type {boolean}
     */
    set warn(allow) {
        this._warn = allow === true
    }

    get warn() {
        return this._warn
    }

    /**
     * Indicates if error level messages should be displayed.
     * @type {boolean}
     */
    set error(allow) {
        this._error = allow === true
    }

    get error() {
        return this._error
    }

    /**
     * Log a debug level message.
     * @param {...any} message Message details.
     */
    d() {
        if (this._debug || Log._debugAll) {
            this._log('Debug', arguments)
        }
    }

    /**
     * Log an error level message.
     * @param {...any} message Message details.
     */
    e() {
        if (this._error) {
            this._log('Error', arguments)
        }
    }

    /**
     * Log a warning level message.
     * @param {...any} message Message details.
     */
    w() {
        if (this._warn) {
            this._log('Warn ', arguments)
        }
    }

    /**
     * Log a message. This will always be entered in the log, you cannot turn off `log` messages.
     * @param {...any} message Message details.
     */
    log() {
        this._log('Log  ', arguments)
    }

    /**
     * Get a throttled logger. It will only log a certain number of messages before
     * preventing future messages. The default number per type of event is 
     * `THROTTLED_COUNT`. 
     * @param {[Object]} params
     * @param {[Number]} params.warnings The number of warnings to log.
     * @param {[Number]} params.errors The number of errors to log.
     * @param {[Number]} params.logs  The number of log level items to log.
     * @param {[Number]} params.debug The number of debugs to log.
     * @returns {ThrottledLogger}
     */
    throttled({ warnings, errors, logs, debugs } = {}) {
        const self = this
        function wrap(count, funcName) {
            return function () {
                if (count > 0) {
                    --count
                    self[funcName](...arguments)
                    if (count === 0) {
                        self[funcName](`[log] Further '${funcName}' throttled.`)
                    }
                }
            }
        }
        return {
            d: wrap(debugs ?? THROTTLED_COUNT, 'd'),
            w: wrap(warnings ?? THROTTLED_COUNT, 'w'),
            log: wrap(logs ?? THROTTLED_COUNT, 'log'),
            e: wrap(errors ?? THROTTLED_COUNT, 'e')
        }
    }

    /**
     * Actually do the logging.
     * @private
     * @param {string} level The level. (eg: debug)
     * @param {...any} message The message details.
     */
    _log(level, message) {
        var trace = new Error()
        var lines = trace.stack.split('\n')
        var caller = this.id
        var requestState
        if (this._stateLogging !== STATE_LOGGING_OPTIONS.NONE) {
            requestState = getRequestState()
            if (requestState) {
                if (this._stateLogging === STATE_LOGGING_OPTIONS.USERNAME) {
                    if ('user' in requestState && 'userName' in requestState['user']) {
                        requestState = requestState['user']['userName']
                    } else {
                        requestState = 'unknown'
                    }
                } else {
                    requestState = JSON.stringify(requestState)
                }
            }
        }
        if (!requestState) {
            requestState = '.'
        }
        if (!isMainThread) {
            requestState = `${requestState} [#${threadId}]`
        }
        if (!caller || this._logLineNumbers) {
            for (var i = 2; i < lines.length; ++i) {
                var file = path.basename(lines[i])
                if (!file.startsWith('log.js')) {
                    caller = file.substring(0, file.lastIndexOf(':'))
                    break
                }
            }
        }
        logFile.log(new Date().toISOString(), level, requestState, caller, ...message)
    }

    /**
     * Send a preformatted message to the log. You probably don't want to call this.
     * 
     * @param {String} message 
     */
    raw(message) {
        logFile.raw(message)
    }
}

/**
 * Options used to inspect objects for log.
 */
const INSPECT_OPTIONS = { depth: Infinity }

/**
 * Class managing writing to the console, and a log file.
 */
class LogFile {
    constructor() {
        this.logQueue = ''
        this.file = null
        this.fileOpenedAt = null
    }

    /**
     * Convert 'anything' to a string.
     * @param {any} thing The thing to convert
     * @returns A string representing the thing.
     */
    thingToString(thing) {
        if (thing === null) {
            return 'null'
        }
        if (thing === undefined) {
            return 'undefined'
        }
        if (thing instanceof Date) {
            return thing.toISOString()
        }
        const type = typeof (thing)
        if (type === 'object') {
            return util.inspect(
                thing, INSPECT_OPTIONS
            )
        }
        return thing.toString()
    }

    /**
     * Write a log entry to the console, and to a file.
     */
    log() {
        let logMessage = [...arguments].map(this.thingToString).join(' ')
        if (logMessage.indexOf('\n') !== -1) {
            logMessage = logMessage.replace(/\n/g, '\n' + arguments[0] + '       ')
        }

        if (!isMainThread) {
            parentPort.postMessage({ logMessage })
        } else {
            this.raw(logMessage)
        }
    }

    raw(logMessage) {
        console.log(logMessage)

        if (logFileName === null) {
            return
        }

        this.logQueue += logMessage
        this.logQueue += '\n'

        this.startWriting() // Deliberately not awaited
    }

    /**
     * Start writing to the file.
     */
    async startWriting() {
        if (this.writing) {
            return
        }
        this.writing = true
        try {
            await this.refreshFile()

            if (this.file === null) {
                this.logQueue = ''
            }

            while (this.logQueue.length !== 0) {
                const toWrite = this.logQueue
                this.logQueue = ''
                await this.file.write(toWrite)
            }
        }
        catch (error) {
            console.log(error)
        }
        finally {
            this.writing = false
        }
    }

    /**
     * Try and open the file, and if it's been open to long, re-open it.
     */
    async refreshFile() {
        if (this.file !== null) {
            if (Date.now() - this.fileOpenedAt > REOPEN_LOG_FILE_INTERVAL_MS) {
                try {
                    await this.file.close()
                    this.file = null
                } catch (e) {
                    console.log(e)
                }
            }
        }

        if (this.file === null) {
            try {
                this.file = await fs.open(logFileName, 'a')
                this.fileOpenedAt = Date.now()
            } catch (e) {
                // consume - don't log that we can't log to the log file repeatedly
            }
        }
    }
}

Log._debugAll = false

/**
 * Instance to log to.
 */
const logFile = new LogFile()

module.exports = function (otherModule) {
    return new Log(otherModule)
}
