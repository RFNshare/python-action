/**
 * @file reportQL.js - 1.2.0 - 3826bc12533e078a8e37cfe70ee04d9e85c8530e
 * 
 * @copyright Copyright (C) 2016-2023, ISARA Corporation, All Rights Reserved.
 * 
 * @license The code and other content set out herein is not in the public
 * domain, is considered a trade secret and is confidential to ISARA
 * Corporation. Use, reproduction or distribution, in whole or in part, of such
 * code or other content is strictly prohibited except by express written
 * permission of ISARA Corporation. Please contact ISARA Corporation at
 * info@isara.com for more information.
 */

/**
 * This file manages user Reports. Note that the backend isn't aware of the meaning of a report.
 * @module graphql/reportQL
 */

const { createUpdateDelete, registerHook, CUD_OP_INSERT, CUD_OP_UPDATE, CUD_OP_DELETE, CUD_OP_PRE } = require('../isaraql/cud')
const { fetchWanted } = require('../isaraql/fetch')
const { graphQLStateToWanted } = require('../isaraql/wantedUtil')
const { getRequestState } = require('../util/requestState')
const { roles, GraphQLEnum, SORT_DIRECTION_ENUM } = require('./commonQL')

/**
 * Enum for the fields allowed to be sorted on Reports.
 */
const SORTABLE_FIELDS_ENUM = new GraphQLEnum('SortableReportFields', ['name', 'addedAt', 'lastModified', 'schedule'])

/**
 * @typedef ReportSortingInput Structure to indicate how to sort reports.
 * @property {string} field which field to sort
 * @property {string} direction which direction to sort
 */


/**
 * Query to see reports.
 * @param {Object} fields Fields from the GraphQL query
 * @param {number} [fields.id] An optional ID for retrieving a single (probably shared?) Report
 * @param {Paging} [fields.paging] Paging information. Defaults to 5 records.
 * @param {ReportSortingInput} [fields.orderBy] Sort preference for retrieved reports.
 * @param {Object} request GraphQL request
 * @param {Object} graphQLState GraphQL State
 * @param {number[]} [ids] Set of IDs to run query for.
 */
async function reportQuery(fields, request, graphQLState, ids) {
    var wanted = graphQLStateToWanted(graphQLState)
    wanted = wanted[Object.keys(wanted)[0]]

    if (!('paging' in fields)) {
        fields.paging = { offset: 0n, limit: 5n }
    }
    var wpcs = { Report: { paging: fields.paging } }
    if (wanted.paging && wanted.paging.count) {
        wpcs.Report.count = []
    }

    if ('id' in fields) {
        ids = [fields.id]
    }

    var userClause = { equals: { column: 'owner', value: getRequestState().user.uid } }

    if (ids && ids.length !== 0) {
        // Specific reports requested; send them back if they're shared or owned by this user.
        wpcs.Report.where = {
            and: [{ in: { column: 'id', value: ids } }, {
                or: [
                    userClause,
                    { equals: { column: 'shared', value: true } }
                ]
            }]
        }
    } else {
        // Limit reports to reports owned by this user.
        wpcs.Report.where = userClause
    }

    if (fields.orderBy) {
        wpcs.Report.sort = `"${SORTABLE_FIELDS_ENUM.graphQLToInternal[fields.orderBy.field]}" ${SORT_DIRECTION_ENUM.graphQLToInternal[fields.orderBy.direction]}`
    }

    var reports = await fetchWanted('Report', wanted.reports, wpcs)

    const getReportOrder = (meta, reportId) =>
        JSON.parse(meta)?.reports?.find(viewReport => String(viewReport?.reportId) === String(reportId))


    for (var report of reports) {
        report?.reportViews?.sort((firstView, secondView) => {
            if (firstView.view && secondView.view) {
                var firstViewReportOrder = getReportOrder(firstView.view.meta, report.id)
                var secondViewReportOrder = getReportOrder(secondView.view.meta, report.id)

                if (firstViewReportOrder && secondViewReportOrder) {
                    return Number(firstViewReportOrder?.order) - Number(secondViewReportOrder?.order)
                }
            }
        })
    }


    var toReturn = { reports }
    if (wpcs.Report.count) {
        toReturn.paging = { count: wpcs.Report.count[0] }
    }

    return toReturn
}

const checkExistingTables = {}
const deletableTables = { 'Report': true, 'ReportView': true }
const modifiableTables = deletableTables

/**
 * Create/Update/Delete reports.
 * @param {*} fields
 * @param {*} request
 * @param {*} graphQLState
 */
async function reportUpdateMutation(fields, request, graphQLState) {
    var reports = fields.reports
    var config = {
        allowDelete: true,
        allowInsert: true,
        allowUpdate: true,
        checkExistingTables,
        deletableTables,
        modifiableTables
    }
    var ids = await createUpdateDelete('Report', reports, config)
    return reportQuery(fields, request, graphQLState, ids)
}

async function reportHook(params) {
    var user = getRequestState().user
    if (!user) {
        throw new Error('User not set when trying to modify Report')
    }
    if (params.operation === CUD_OP_UPDATE || params.operation === CUD_OP_DELETE) {
        // Need to enforce that some user isn't changing other users' reports.
        var existingRecords = (await params.session.query('select owner from "Report" where id = ?', [params.record.id])).rows
        if (existingRecords.length === 0) {
            throw new Error('Existing record expected for user permission check')
        }
        if (existingRecords[0].owner !== user.uid) {
            throw new Error(`Permission denied - cannot update other user's Reports`)
        }
    }

    if (params.operation !== CUD_OP_DELETE) {
        params.record.owner = user.uid
        const now = new Date()
        params.record.lastModified = now
        if (params.operation === CUD_OP_INSERT) {
            params.record.addedAt = now
        }
    }
}

async function initialise() {
    registerHook('Report', CUD_OP_INSERT, CUD_OP_PRE, reportHook)
    registerHook('Report', CUD_OP_UPDATE, CUD_OP_PRE, reportHook)
    registerHook('Report', CUD_OP_DELETE, CUD_OP_PRE, reportHook)
}

exports.graphQL = {
    types: `
        type PagedReports {
            paging: Paging!
            reports: [Report!]!
        }

        ${SORTABLE_FIELDS_ENUM.toGraphQL()}

        input ReportSortingInput {
            field: SortableReportFields!,
            direction: SortDirection!,
        }
    `,
    queries: `
        """
            Obtain all of the current User's Reports, or see a specific shared Report.
        """
        reports(
            """
                Used to control how many reports are returned. The default (without paging) will be 5.
            """
            paging: PagingInput
            """
                When provided, will attempt to find a single report. The report may not exist, or you may not have access.
            """
            id: BigInt
            """
               Used to set the sort order of the Reports
            """
            orderBy: ReportSortingInput
        ) : PagedReports!
    `,
    mutations: `
        reportUpdate(
            reports: [ReportInput!]!
        ) : PagedReports!
    `,
    root: {
        reports: reportQuery,
        reportUpdate: reportUpdateMutation,
    },
    restrictions: {
        reports: [roles.AUTHENTICATED],
        reportUpdate: [roles.AUTHENTICATED],
    },
    initialise
}
