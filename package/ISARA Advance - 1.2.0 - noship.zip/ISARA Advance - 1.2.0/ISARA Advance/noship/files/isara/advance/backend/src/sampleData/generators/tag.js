/**
 * @file tag.js - 1.2.0 - 3826bc12533e078a8e37cfe70ee04d9e85c8530e
 * 
 * @copyright Copyright (C) 2016-2023, ISARA Corporation, All Rights Reserved.
 * 
 * @license The code and other content set out herein is not in the public
 * domain, is considered a trade secret and is confidential to ISARA
 * Corporation. Use, reproduction or distribution, in whole or in part, of such
 * code or other content is strictly prohibited except by express written
 * permission of ISARA Corporation. Please contact ISARA Corporation at
 * info@isara.com for more information.
 */

const {
    dumpObjectTimingStats,
    initDbConnection,
    insertObject,
    resetObjectTimingStats,
    bulkInsertRecords,
} = require('../dbHelpers')
const {
    allCryptoPrimitives,
    protocolVariants,
    roles,
    softwareTypes,
    tagTypes,
    users
} = require('../dbTypes')
const {
    Agent,
    AgentCertificate,
    CAIssuedCertificate,
    Certificate,
    CertificateCryptoPrimitive,
    CertificationAuthority,
    Connection,
    ConnectionCertificate,
    ConnectionCipherSuite,
    ConnectionCryptoPrimitive,
    ConnectionProtocolVariant,
    ConnectionProtocolVariantCertificate,
    ConnectionTag,
    Device,
    DeviceAddress,
    DeviceAddressMACAddress,
    DeviceAddressPort,
    DeviceCertificate,
    DeviceMACAddress,
    DeviceSoftware,
    DeviceSoftwareConnection,
    DeviceTag,
    KeyStore,
    KeyStoreKey,
    OneTimeKey,
    Netmask,
    Notification,
    NotificationAction,
    Software,
    SoftwareVersion,
    SoftwareVersionTag,
    Tag,
    User,
    UserRole,
} = require('../dbObjects')
var log = require('../../util/log')(module)
function tagType() {
    var types = Object.keys(tagTypes)
    var which = Math.floor(Math.random() * types.length)
    return tagTypes[types[which]]
}


let addDeviceTags = async function (devices) {
    let deviceTags = []
    for (let device of devices) {
        let tagCount = Math.floor(Math.random() * 10)
        let usedTags = []
        await mutex.runExclusive(async () => {
            for (let j = 0; j < tagCount; ++j) {
                // Add random tags
                let randomTagType = tagType()
                let randomTag = await generateTag(randomTagType)
                let result = await insertTag(randomTag)
                if (usedTags.includes(result)) {
                    continue
                }
                usedTags.push(result)
                var deviceTag = new DeviceTag(device.id, result)
                deviceTags.push(deviceTag.nameValues)
            }
        })
    }
    await bulkInsertRecords('DeviceTag', deviceTags, session)
}


async function insertTag(tag) {
    let index = allTags.findIndex((x) => x.tagType === tag.tagType && x.value === tag.value)
    if (index < 0) {
        await insertObject(tag)
        allTags.push(tag)
    } else {
        tag = allTags[index]
    }

    return tag.id
}

//const SoftwareVersionTagsText = ['STABLE', 'ALPHA1', 'ALPHA2', 'BETA1', 'BETA2']

exports.generateAndInsertSoftwareVersionTags = async function (session, SoftwareVersionTagsText, data) {
    log.log(SoftwareVersionTagsText)
    var custom_id = data.tagTypes['CUSTOM'].id
    let softwareVersionTagsArray = []
    for (var i = 0; i < SoftwareVersionTagsText.length; i++) {
        let tag = new Tag(SoftwareVersionTagsText[i], custom_id)
        softwareVersionTagsArray.push(tag.nameValues)
    }
    let results = await bulkInsertRecords('Tag', softwareVersionTagsArray, session)
    if (!data) data.softwareVersionTags = [];
    data.softwareVersionTags.push(...results.rows)
}

let softwareVersionTagArray = []
function insertSoftwareVersionTag(version) {
    var randomVersionTag = pickOne(softwareVersionTags)

    if (softwareVersionTagAssociations.findIndex((x) => x.softwareVersion == version.id && x.tag == randomVersionTag.id) == -1) {
        let softwareVersionTag = new SoftwareVersionTag(version.id, randomVersionTag.id)
        softwareVersionTagArray.push(softwareVersionTag.nameValues)
        softwareVersionTagAssociations.push(softwareVersionTag)
    }
}

//const ConnectionTagsText = [`Tunneled`, `VPN`, `Timed_Out`, `Error_Detected`]

exports.generateAndInsertConnectionTags = async function (session, ConnectionTagsText, data) {
    var custom_id = data.tagTypes['CUSTOM'].id
    let connectionTagsArray = []
    for (var i = 0; i < ConnectionTagsText.length; i++) {
        let tag = new Tag(ConnectionTagsText[i], custom_id)
        connectionTagsArray.push(tag.nameValues)
    }
    let results 
    try{
        results= await bulkInsertRecords('Tag', connectionTagsArray, session)
    }catch(e){console.log(e)}
    if (!data.connectionTags) data.connectionTags = [];
    data.connectionTags.push(...results.rows)
}

let connectionsTags = []
function insertConnectionTag(connection) {
    var randomConnectionTag = pickOne(connectionTags)

    if (connectionTagAssociations.findIndex((x) => x.connection == connection.id && x.tag == randomConnectionTag.id) == -1) {
        let connectionTag = new ConnectionTag(connection.id, randomConnectionTag.id)
        connectionsTags.push(connectionTag.nameValues)
        connectionTagAssociations.push(connectionTag)
    }
}

async function generateTag(tagType) {
    var tagValue = ''
    // Map tag type to generate a new random tag
    if (tagType.isNumeric) {
        var numericValue = -1
        switch (tagType.name) {
            case 'RAM_SIZE': {
                // Reasonable RAM size in Bytes: 1 GB to 1 TB?
                var sizeInGB = 1 << randomBelow(11)
                numericValue = sizeInGB * Math.pow(10, 9)
                break
            }
            case 'CPU_SPEED': {
                // CPU Speed: 500 MHz to 5 GHz
                let sizeInMHz = randomBelow(5000, 500)
                numericValue = sizeInMHz * Math.pow(10, 6)
                break
            }
            default:
                throw `Unknown numeric tag type`
        }
        tagValue = `${numericValue}`
    } else {
        // Non-numeric
        var mapValue = tagTypeValuesMap[tagType.name]
        if (!mapValue || !mapValue.length) {
            switch (tagType.name) {
                case 'COORDINATE':
                    tagValue = `${randomBelow(90)} ${pickOne(['N', 'S'])} ${randomBelow(180)} ${pickOne(['W', 'E'])}`
                    break
                case 'CPU_SERIAL_NUMBER':
                case 'SERVER_ROOM_NUMBER':
                case 'RACK_ADDRESS':
                case 'MACHINE_SERIAL_NUMBER':
                case 'OS_SERIAL_NUMBER':
                case 'CORPORATE_ASSET_TAG_TRACKING_NUMBER':
                    break
                default:
                    // randomWords can return an array of length 1 *or* a raw string ; make sure to catch this.
                    tagValue = randomWords(1)
                    if (Array.isArray(tagValue)) {
                        tagValue = tagValue[0]
                    }
                    break
            }
        } else {
            tagValue = pickOne(mapValue)
        }
    }

    return new Tag(tagValue, tagType.id)
}


