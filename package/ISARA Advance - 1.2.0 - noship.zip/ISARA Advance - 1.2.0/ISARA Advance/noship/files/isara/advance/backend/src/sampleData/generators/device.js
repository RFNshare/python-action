/**
 * @file device.js - 1.2.0 - 3826bc12533e078a8e37cfe70ee04d9e85c8530e
 * 
 * @copyright Copyright (C) 2016-2023, ISARA Corporation, All Rights Reserved.
 * 
 * @license The code and other content set out herein is not in the public
 * domain, is considered a trade secret and is confidential to ISARA
 * Corporation. Use, reproduction or distribution, in whole or in part, of such
 * code or other content is strictly prohibited except by express written
 * permission of ISARA Corporation. Please contact ISARA Corporation at
 * info@isara.com for more information.
 */


const {
    Agent,
    AgentCertificate,
    CAIssuedCertificate,
    Certificate,
    CertificateCryptoPrimitive,
    CertificationAuthority,
    Connection,
    ConnectionCertificate,
    ConnectionCipherSuite,
    ConnectionCryptoPrimitive,
    ConnectionProtocolVariant,
    ConnectionProtocolVariantCertificate,
    ConnectionTag,
    Device,
    DeviceAddress,
    DeviceAddressMACAddress,
    DeviceAddressPort,
    DeviceCertificate,
    DeviceMACAddress,
    DeviceSoftware,
    DeviceSoftwareConnection,
    DeviceTag,
    KeyStore,
    KeyStoreKey,
    OneTimeKey,
    Netmask,
    Notification,
    NotificationAction,
    Software,
    SoftwareVersion,
    SoftwareVersionTag,
    Tag,
    User,
    UserRole,
} = require('../dbObjects')
var log = require('../../util/log')(module)
const { generateIp4Addr, generateMac } = require('../utils')
exports.generateDevice = () => {
    return {
        "observedAt": new Date(),
        "ipAddress": generateIp4Addr(),
        "ipVersion": 4,
        "macAddress": generateMac()
    }
}
let callAddDevice = async function (deviceType, deviceCount, message) {
    try {
        for (let i = 0; i < deviceCount; ++i) {
            deviceTypeArray.push(deviceType)
            await addDevice()
            if (bulkUpdateDevice.length >= bulkSize) {
                let results = await bulkInsertRecords('Device', bulkUpdateDevice, session)
                allDevices.push(...results.rows)
                await addDeviceAgents(results.rows)
                await addDeviceAddress(results.rows)
                await addDeviceTags(results.rows)
                await addDeviceSoftware(results.rows)
                bulkUpdateDevice = []
                deviceTypeArray = []
            }
            showCount(message, i + 1, deviceCount)
        }
        if (bulkUpdateDevice.length > 0) {
            let results = await bulkInsertRecords('Device', bulkUpdateDevice, session)
            allDevices.push(...results.rows)
            await addDeviceAgents(results.rows)
            await addDeviceAddress(results.rows)
            await addDeviceTags(results.rows)
            await addDeviceSoftware(results.rows)
            bulkUpdateDevice = []
            deviceTypeArray = []
        }

        if (bulkDeviceAddressPort.length > 0) {
            await bulkInsertDeviceAddressPort()
        }
    } catch (error) {
        console.log('Error in call add device', error)
    }
}


let addDeviceSoftware = async function (devices) {
    let deviceSoftwareArray = []
    //add random software
    for (let device of devices) {
        if (Math.random() > 0.2) {
            let softwareCount = randomBelow(20, 1)
            let hasOS = false
            for (let i = 0; i < softwareCount; ++i) {
                let softwareType = pickOne(Object.keys(allSoftwareVersions))
                if (hasOS && softwareType == 'OS') {
                    continue
                } else {
                    hasOS = true
                }

                let versions = allSoftwareVersions[softwareType]
                let software = pickOne(versions)
                let deviceSoftware = new DeviceSoftware(device, software)
                deviceSoftwareArray.push(deviceSoftware.nameValues)
            }
        }
    }
    let results = await bulkInsertRecords('DeviceSoftware', deviceSoftwareArray, session)
    for (let software of results.rows) {
        if (!allDeviceSoftware[software.device]) {
            allDeviceSoftware[software.device] = []
        }
        allDeviceSoftware[software.device].push(software.id)
    }
}


let addDeviceAgents = async function (devices) {
    let deviceAgentsArray = []
    for (let device of devices) {
        // TODO: GAP1629 - this should probably be further narrowed down to only include an agent on devices which can actually install one
        // e.g. servers/workstations/VMs
        if (pickOne([true, false])) {
            let agent = new Agent(device.id)
            deviceAgentsArray.push(agent.nameValues)
        }
    }
    let results = await bulkInsertRecords('Agent', deviceAgentsArray, session)
    for (let agent of results.rows) {
        let device = devices.find(dev => dev.id === agent.device)
        deviceAgents[device.id] = agent
    }
}

let addDeviceAddress = async function (devices) {
    let deviceAddressArray = []
    let deviceMACAddressArray = []
    for (let device of devices) {
        let addressCount = Math.random() > 0.7 ? 2 : 1
        for (var j = 0; j < addressCount; ++j) {
            let deviceAddress = new DeviceAddress(device)
            await deviceAddress.populate()
            deviceAddressArray.push(deviceAddress.nameValues)

            let deviceMACAddress = new DeviceMACAddress(device)
            deviceMACAddressArray.push(deviceMACAddress.nameValues)

        }
    }

    let deviceAddressResults = await bulkInsertRecords('DeviceAddress', deviceAddressArray, session)
    let deviceMACAddressResults = await bulkInsertRecords('DeviceMACAddress', deviceMACAddressArray, session)

    let deviceIndex = 0
    let deviceAddressMACAddressArray = []
    for (let deviceAddress of deviceAddressResults.rows) {
        let deviceAddressMACAddress = new DeviceAddressMACAddress(deviceAddress, deviceMACAddressResults.rows[deviceIndex])
        deviceAddressMACAddressArray.push(deviceAddressMACAddress.nameValues)
        deviceIndex++
    }

    await bulkInsertRecords('DeviceAddressMACAddress', deviceAddressMACAddressArray, session)
    await callDeviceAddressPort(devices, deviceAddressResults.rows)

}

let callDeviceAddressPort = async function (devices, deviceAddressArray) {
    let index = 0
    for (let device of devices) {
        let deviceType = deviceTypeArray[index]
        let devAddresses = deviceAddressArray.filter(address => address.device === device.id)
        for (let devAddress of devAddresses) {
            if (deviceType === deviceTypes.GOOD_SERVER) {
                if (index === 0) {
                    await bulkInsertDeviceAddressPort()
                }
                await addDeviceAddressPort(devAddress, device, deviceType, goodServerPorts)
            }
            if (deviceType === deviceTypes.BAD_SERVER) {
                if (index === 0) {
                    await bulkInsertDeviceAddressPort()
                }
                await addDeviceAddressPort(devAddress, device, deviceType, badServerPorts)
            }
            if (deviceType === deviceTypes.CLIENT) {
                if (index === 0) {
                    await bulkInsertDeviceAddressPort()
                }
                await addDeviceAddressPort(devAddress, device, deviceType, null)
            }
        }
        index++
    }
}



let bulkInsertDeviceAddressPort = async function () {
    if (bulkDeviceAddressPort.length > 0) {
        let result = await bulkInsertRecords('DeviceAddressPort', bulkDeviceAddressPort, session)
        let index = 0
        for (let devPort of result.rows) {
            let devType = bulkDeviceAddressPortType[index]
            devType.port = devPort
            if (devType.deviceType === deviceTypes.GOOD_SERVER) {
                delete devType.deviceType
                listeningGoodServerAddressPorts.push(devType)
            }
            if (devType.deviceType === deviceTypes.BAD_SERVER) {
                delete devType.deviceType
                listeningBadServerAddressPorts.push(devType)
            }
            if (devType.deviceType === deviceTypes.CLIENT) {
                delete devType.deviceType
                listeningClientAddressPorts.push(devType)
            }
            index++
        }
        bulkDeviceAddressPort = []
        bulkDeviceAddressPortType = []
    }
}


let addDeviceAddressPort = async function (deviceAddress, device, deviceType, serverPorts) {
    try {
        if (bulkDeviceAddressPort.length >= bulkSize) {
            await bulkInsertDeviceAddressPort()
        }
        if (deviceType === deviceTypes.GOOD_SERVER || deviceType === deviceTypes.BAD_SERVER) {
            let existingPorts = []
            for (var k = 0; k < serverPorts.length; ++k) {
                if (serverPorts[k].count > 0) {
                    let deviceAddressPort = new DeviceAddressPort(deviceAddress, existingPorts, serverPorts[k].port)
                    serverPorts[k].count -= 1
                    await deviceAddressPort.populate()
                    bulkDeviceAddressPort.push(deviceAddressPort.nameValues)
                    existingPorts.push(serverPorts[k].port)
                    bulkDeviceAddressPortType.push({ deviceType: deviceType, device: device, address: deviceAddress })
                }
            }
        }
        let deviceAddressPort = new DeviceAddressPort(deviceAddress)
        deviceAddressPort.port = -1
        await deviceAddressPort.populate()
        bulkDeviceAddressPort.push(deviceAddressPort.nameValues)
        bulkDeviceAddressPortType.push({ deviceType: deviceType, device: device, address: deviceAddress })
    } catch (error) {
        console.log('Failed to create port', error)
    }
}

let addDevice = async function () {
    let device = new Device()
    await device.populate()
    bulkUpdateDevice.push(device.nameValues)
}



