/**
 * @file worker.js - 1.2.0 - 3826bc12533e078a8e37cfe70ee04d9e85c8530e
 * 
 * @copyright Copyright (C) 2016-2023, ISARA Corporation, All Rights Reserved.
 * 
 * @license The code and other content set out herein is not in the public
 * domain, is considered a trade secret and is confidential to ISARA
 * Corporation. Use, reproduction or distribution, in whole or in part, of such
 * code or other content is strictly prohibited except by express written
 * permission of ISARA Corporation. Please contact ISARA Corporation at
 * info@isara.com for more information.
 */

/**
 * This module adds (minimal) wrapping to worker_threads, including log management. 
 * @module util/worker
 */
const { parentPort, workerData, isMainThread, Worker } = require('worker_threads')
const log = require('./log')(module)

/**
 * Attempt to load a module and call a function in that module from a worker thread. This function returns immediately.
 * @param {Object} params
 * @param {String} params.requireName The name of the module to attempt to require and then call a function from
 * @param {String} params.functionName The name of the exported async function in the loaded module to call.
 * @param {Object} params.args The arguments object that will be serialised and sent to the function call.
 * @param {Function} [params.errorHandler] A function to call when there is a fatal error with the worker.
 * @returns {undefined}
 */
async function runInWorker({ requireName, functionName, args, errorHandler }) {
    if (isMainThread) {
        let worker = new Worker(__filename, { workerData: { requireName, functionName, args } })
        const tid = `[#${worker.threadId}]`
        worker.on('error', error => {
            log.e('Worker thread error', tid, error)
            if (errorHandler) {
                errorHandler(error)
            } else {
                log.log('Ho handler for this error')
            }
        })
        worker.on('exit', exitCode => {
            log.d('Worker thread exited', tid, exitCode)
        })
        worker.on('message', message => {
            if (message?.terminate) {
                worker.terminate()
                log.d('Worker termination requested', tid)
            } else if (message?.logMessage) {
                log.raw(message.logMessage)
            } else {
                log.e('Unhandled message from child', tid, message)
            }
        })
        worker.on('messageerror', error => {
            log.e('Worker thread messaging error', tid, error)
            if (errorHandler) {
                errorHandler(error)
            } else {
                log.log('No handler for this error')
            }
        })
    } else {
        // There's no real reason this cannot be done - but it's not expected at this time.
        throw new Error('Not expecting call to start new thread from child thread')
    }
}

// When started in a worker thread, this block will execute at file load time.
if (!isMainThread) {
    require('json-bigint-patch')
    log.log('Executing in worker', workerData)

    const process = async function() {
        const targetFile = require(workerData.requireName)
        const targetFunction = targetFile[workerData.functionName]
        if (!targetFunction) {
            log.e('Function does not exist in requested module', workerData)
        }
        await targetFunction(workerData.args)
    }

    process().then(() => {
        log.log('Worker call finished')
    }).catch(error => {
        log.e('Caught error in worker', error)
    }).finally(() => {
        parentPort.postMessage({ terminate: true })
    })
}

exports.runInWorker = runInWorker
