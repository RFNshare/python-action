/**
 * @file dbTypeHelpers.js - 1.2.0 - 3826bc12533e078a8e37cfe70ee04d9e85c8530e
 * 
 * @copyright Copyright (C) 2016-2023, ISARA Corporation, All Rights Reserved.
 * 
 * @license The code and other content set out herein is not in the public
 * domain, is considered a trade secret and is confidential to ISARA
 * Corporation. Use, reproduction or distribution, in whole or in part, of such
 * code or other content is strictly prohibited except by express written
 * permission of ISARA Corporation. Please contact ISARA Corporation at
 * info@isara.com for more information.
 */

const {
    CryptoPrimitive,
    NotificationType,
    Protocol,
    ProtocolVariant,
    Role,
    SoftwareType,
    TagType
} = require('./dbObjects')

var log = require('../util/log')(module)
var {
    allCryptoPrimitives,
    allStrongCryptoPrimitives,
    allWeakCryptoPrimitives,
    notificationTypes,
    protocols,
    protocolVariants,
    strongProtocolVariants,
    weakProtocolVariants,
    roles,
    softwareTypes,
    tagTypes
} = require('./dbTypes')

const {
    initDbConnection
} = require('./dbHelpers')

const {
    allTypes
} = require('../isaraql/schemaDiscovery')

var connection = null

const STRONG_CLASSIC_SCORE = 1000

async function loadEnum(table, type) {
    var enums = {}
    for (var name in allTypes[table]._enum.idByName) {
        enums[name] = new type(name)
    }
    return enums
}
exports.loadEnum = loadEnum
async function loadTagTypeEnum(connection) {
    var enums = {}
    var results = await connection.query(`SELECT id,name,"isNumeric",unit FROM "TagType"`)
    for (let result of results.rows) {
        enums[result.name] = new TagType(result.name, result.isNumeric, result.unit)
        enums[result.name].id = result.id
    }
    return enums
}

async function loadCryptoPrimitives(connection, data) {
    var result = await connection.query(`SELECT cp.*,cs.score FROM "CryptoPrimitive" cp JOIN "CryptoPrimitiveScore" cps ON cps."cryptoPrimitive" = cp.id JOIN "CryptoScore" cs on cps."cryptoScore" = cs.id`)
    data.allCryptoPrimitives = {}
    data.allStrongCryptoPrimitives = {}
    data.allWeakCryptoPrimitives = {}
    for (let row of result.rows) {
        data.allCryptoPrimitives[row.name] = new CryptoPrimitive(row.id, row.name, row.friendlyName, row.score, row.cryptoAlgorithm)
        if (row.score >= STRONG_CLASSIC_SCORE) {
            data.allStrongCryptoPrimitives[row.name] = new CryptoPrimitive(row.id, row.name, row.friendlyName, row.score, row.cryptoAlgorithm)
        }
        if (row.score < STRONG_CLASSIC_SCORE) {
            data.allWeakCryptoPrimitives[row.name] = new CryptoPrimitive(row.id, row.name, row.friendlyName, row.score, row.cryptoAlgorithm)
        }
    }
}

async function loadProtocolVariants(session, data) {
    var result = await session.query(`SELECT pv.*, cs.score FROM "ProtocolVariant" pv JOIN "ProtocolVariantScore" pvsc on pvsc."protocolVariant" = pv.id JOIN "CryptoScore" cs ON pvsc."cryptoScore" = cs.id`)
    data.protocolVariants = {}
    data.strongProtocolVariants = {}
    data.weakProtocolVariants = {}
    for (let row of result.rows) {
        data.protocolVariants[row.name] = new ProtocolVariant(row.id, row.name, row.protocol)
        if (row.score >= STRONG_CLASSIC_SCORE) {
            data.strongProtocolVariants[row.name] = new ProtocolVariant(row.id, row.name, row.protocol)
        }
        if (row.score < STRONG_CLASSIC_SCORE) {
            data.weakProtocolVariants[row.name] = new ProtocolVariant(row.id, row.name, row.protocol)
        }
    }
}

async function loadDatabaseTypes(session, data ={}) {
    //connection = await initDbConnection()
    log.log(data)
    data.notificationTypes = Object.assign(data.notificationTypes || {}, await loadEnum('NotificationType', NotificationType))
    data.roles = Object.assign(data.roles, await loadEnum('Role', Role))
    data.protocols = Object.assign(data.protocols, await loadEnum('Protocol', Protocol))
    data.softwareTypes = Object.assign(data.softwareTypes, await loadEnum('SoftwareType', SoftwareType))
    data.tagTypes = Object.assign(data.tagTypes, await loadTagTypeEnum(session))
    await loadCryptoPrimitives(session, data)
    await loadProtocolVariants(session, data)
}

exports.loadDatabaseTypes = loadDatabaseTypes
