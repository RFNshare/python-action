/**
 * @file asn1Validator.js - 1.2.0 - 3826bc12533e078a8e37cfe70ee04d9e85c8530e
 * 
 * @copyright Copyright (C) 2016-2023, ISARA Corporation, All Rights Reserved.
 * 
 * @license The code and other content set out herein is not in the public
 * domain, is considered a trade secret and is confidential to ISARA
 * Corporation. Use, reproduction or distribution, in whole or in part, of such
 * code or other content is strictly prohibited except by express written
 * permission of ISARA Corporation. Please contact ISARA Corporation at
 * info@isara.com for more information.
 */

const log = require('./log')(module)

class MyBuffer {
    constructor(buffer) {
        this.buffer = buffer
        this.offset = 0
        this.rootOffset = 0
        this.depth = 0
    }

    readUint8() {
        let toReturn = this.buffer.readUint8(this.offset)
        this.offset++
        this.rootOffset++

        return toReturn
    }

    get length() {
        return this.buffer.length
    }

    get remain() {
        return this.buffer.length - this.offset
    }

    payload(length) {
        let subBuffer = this.buffer.subarray(this.offset, this.offset + length)
        let toReturn = new MyBuffer(subBuffer)
        toReturn.rootOffset = this.rootOffset
        toReturn.depth = this.depth + 1
        this.offset += length
        this.rootOffset += length
        return toReturn
    }

    dump(maxLength) {
        if (maxLength === undefined) {
            maxLength = 15
        }

        let toReturn = ''
        for (let i = 0; i < maxLength && i < this.buffer.length - this.offset; ++i) {
            if (i != 0) {
                toReturn += ':'
            }
            toReturn += this.buffer[i + this.offset].toString(16).padStart(2, '0000000000')
        }
        if (maxLength < this.buffer.length - this.offset) {
            toReturn += '...'
        }
        return toReturn
    }
}

const types = {
    3: 'BIT STRING',
    30: 'BMPString',
    1: 'BOOLEAN',
    29: 'CHARACTER STRING',
    31: 'DATE',
    33: 'DATE-TIME',
    34: 'DURATION',
    11: 'EMBEDDED PDV',
    10: 'ENUMERATED',
    8: 'EXTERNAL',
    27: 'GeneralString',
    24: 'GeneralizedTime',
    25: 'GraphicString',
    22: 'IA5String',
    2: 'INTEGER',
    5: 'NULL',
    18: 'NumericString',
    7: 'ObjectDescriptor',
    6: 'OBJECT IDENTIFIER',
    4: 'OCTET STRING',
    19: 'PrintableString',
    9: 'REAL',
    13: 'RELATIVE-OID',
    0x30: 'SEQUENCE',
    16: 'SEQUENCE OF',
    0x31: 'SET',
    17: 'SET OF',
    20: 'TeletexString',
    14: 'TIME',
    32: 'TIME-OF-DAY',
    28: 'UniversalString',
    23: 'UTCTime',
    12: 'UTF8String',
    21: 'VideotexString',
    26: 'VisibleString',
}

/**
 * Lookup table for converting bytes to readable types
 */
const process = {
    12: data => data.toString('utf8'),
    19: data => data.toString('ascii'),
    6: data => {
        let result = `${Math.floor(data[0] / 40)}.${data[0] % 40}`
        let carry = 0
        for (let i = 1; i < data.length; ++i) {
            if (data[i] > 128) {
                carry |= data[i] & 0x7f
                carry <<= 7
            } else {
                result += `.${data[i] + carry}`
                carry = 0
            }
        }
        return result
    },
}

/**
 * 
 * @param {MyBuffer} buffer 
 * @param {Object} parsed
 * @param {String} parsed.parsed
 */
function recurseASN1(buffer, parsed) {
    let indent = new Array(buffer.depth).fill('    ').join('')
    let tag = buffer.readUint8()
    let length = buffer.readUint8()
    if ((length & 128) == 128) {
        let count = length ^= 128
        if (count >= 4) {
            throw new Error(`Unexpectedly large length byte length ${count}`)
        }
        length = 0
        for (let i = 0; i < count; ++i) {
            length <<= 8
            length |= buffer.readUint8()
        }
    }

    if (length > buffer.remain) {
        throw new Error(`Length wrong ${length} ${buffer.remain}`)
    }

    let typeName = types[tag]
    if (tag >= 0xa0) {
        typeName = `[${tag & 0xf}]`
    }

    if (typeName === undefined) {
        throw new Error(`Unexpected ASN.1 tag type: ${tag} at ${buffer.rootOffset}`)
    }

    const payload = buffer.payload(length)
    if (parsed) {
        const toAdd = `${indent}${typeName} tag:${tag.toString(16)} length:${length.toString(16)} ${length > 0 ? `value:${process[tag] ? process[tag](payload.buffer) : payload.dump()}` : ''}`
        parsed.output.push(toAdd)
        parsed.rootOffset = buffer.rootOffset
    }

    while (tag >= 0x30 && payload.remain > 0) {
        recurseASN1(payload, parsed)
    }
}

/**
 * Cursory validation of hopefully DER encoded ASN.1
 * @param {Buffer} buffer 
 * @param {Object} [parsed] Object to receive parsing output
 * @param {Array.<String>} parsed.output Array that will receive parsing output
 * @returns {Boolean} true on success, throws exception with an appended parsed object otherwise.
 */
function validateBinaryASN1(buffer, parsed) {
    if (!parsed) {
        parsed = {}
    }
    if (!('output' in parsed)) {
        parsed.output = []
    }
    if (!buffer || buffer.length === 0) {
        throw new Error('Empty or invalid buffer')
    }
    try {
        recurseASN1(new MyBuffer(buffer), parsed)
        return true
    } catch (e) {
        log.e('Failed to parse ASN.1',e,parsed.output.join('\n'))
        e.parsed = parsed
        throw e
    }
}

/**
 * Cursory validation of ASN.1 encoding.
 * @param {Buffer|String} buffer containing PEM encoded ASN.1 (eg: --- begin certificate ---\n.....)
 * @returns {boolean} true iff the validation is successful.
 * @throws {Exception} if the buffer does not contain valid ASN.1
 */
function validatePEMASN1(buffer) {
    let all = buffer.toString()
    let lines = all.split('\n').filter(line => line.length > 0 && line.substring(0, 3) != '---')
    let data = lines.join('')
    return validateBinaryASN1(new Buffer.from(data, 'base64'))
}

exports.validateBinaryASN1 = validateBinaryASN1
exports.validatePEMASN1 = validatePEMASN1

// validatePEMASN1(`
// -----BEGIN CERTIFICATE-----
// MIIGQzCCBSugAwIBAgIQCF7MXfvv5ig8bSu8ofl5tzANBgkqhkiG9w0BAQsFADBNMQswCQYDVQQGEwJVUzEVMBMGA1UEChMMRGlnaUNlcnQgSW5jMScwJQYDVQQDEx5EaWdpQ2VydCBTSEEyIFNlY3VyZSBTZXJ2ZXIgQ0EwHhcNMTgwOTE0MDAwMDAwWhcNMTkwNDIyMTIwMDAwWjB9MQswCQYDVQQGEwJDQTEQMA4GA1UECBMHT250YXJpbzERMA8GA1UEBxMIV2F0ZXJsb28xGjAYBgNVBAoTEUlzYXJhIENvcnBvcmF0aW9uMRMwEQYDVQQLEwpPcGVyYXRpb25zMRgwFgYDVQQDDA8qLmlzYXJhY29ycC5jb20wggEiMA0GCSqGSIb3DQEBAQUAA4IBDwAwggEKAoIBAQD356IPqB80yC4jJZ0VtQVS2LYAlhcuBBqdTD3UXKf4mtTwzzG4M0FWVpdRYBP9jlEQ/++vA+oBYW4J+GrQpr2Ha+Iamxj79OIlgHvmY4DRs8Lz+0FqrYBVcSCJBm7ZgJAH1okaI6f8LAknSMy3ApVg0EZHyJucHoaUvhvKwX4KnQB+YIv0m56mXT/MoIOwh/g/c7uJZyDR4jTazkKDEux8cUnbhNm2qp9dLak6onHF/mQoJ6fGSJjBPDv/uvuHgqsiTFOwVvJ6+Ycj79wavTrcKDPHSWJ/xo53PMoomo3vnbx2kmJarJhLpiHXwW89jhRxQ+McUHQGOWnRynXrQgEdAgMBAAGjggLtMIIC6TAfBgNVHSMEGDAWgBQPgGEcgjFh1S8o541GOLQs4cbZ4jAdBgNVHQ4EFgQUGstyCASv2emBV7rNM8BXT+sWvY8wKQYDVR0RBCIwIIIPKi5pc2FyYWNvcnAuY29tgg1pc2FyYWNvcnAuY29tMA4GA1UdDwEB/wQEAwIFoDAdBgNVHSUEFjAUBggrBgEFBQcDAQYIKwYBBQUHAwIwawYDVR0fBGQwYjAvoC2gK4YpaHR0cDovL2NybDMuZGlnaWNlcnQuY29tL3NzY2Etc2hhMi1nNi5jcmwwL6AtoCuGKWh0dHA6Ly9jcmw0LmRpZ2ljZXJ0LmNvbS9zc2NhLXNoYTItZzYuY3JsMEwGA1UdIARFMEMwNwYJYIZIAYb9bAEBMCowKAYIKwYBBQUHAgEWHGh0dHBzOi8vd3d3LmRpZ2ljZXJ0LmNvbS9DUFMwCAYGZ4EMAQICMHwGCCsGAQUFBwEBBHAwbjAkBggrBgEFBQcwAYYYaHR0cDovL29jc3AuZGlnaWNlcnQuY29tMEYGCCsGAQUFBzAChjpodHRwOi8vY2FjZXJ0cy5kaWdpY2VydC5jb20vRGlnaUNlcnRTSEEyU2VjdXJlU2VydmVyQ0EuY3J0MAwGA1UdEwEB/wQCMAAwggEEBgorBgEEAdZ5AgQCBIH1BIHyAPAAdwCkuQmQtBhYFIe7E6LMZ3AKPDWYBPkb37jjd80OyA3cEAAAAWXZ8dDnAAAEAwBIMEYCIQC9Kw1W5g27cXbS1WwbQDrmnVph33RimfoMsL6XIry4CwIhAI8sOC/JkY6040hRTAnpBStWOKok74G0/FXpiDRyJsBEAHUAh3W/51l8+IxDmV+9827/Vo1HVjb/SrVgwbTq/16ggw8AAAFl2fHR0QAABAMARjBEAiBYvTrmRhidBa+tPq/7wpbQ4BrCWc+UEcXs+kkb0IxWNgIgFG3U5IBJl9Lbb8k1gLkYWe6UJxXrhpQAAAAAAAAAAAwAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAACJg0UvKgzAXm6UrL17/y09PjTshj1vtseBqHpjs3qnDop0CaY7WdiD5ylleq59zRGcCVos09PfubQh5+3BsxXefVmBMY+TWV55/CIhbum0EYQFbkx/awGPFmtewftNSuiz3/tus+npejJMs8EaqgXnbUdEI1hX7V5WlagL49xj8/O/lxJTr14mDh62Ya89aMcScTR8T0sFlBZVtOWIZyPX1kytooM0cBnyF+M7bXrTTllx01ZEBeuQpUIjliLbkdCEtsWjbQJ5VI+cmjOq001W1kMASADidkExNXVG4robPzJwa7cnQwFu02M0X2cT2CME7PI=
// -----END CERTIFICATE-----
// `)
