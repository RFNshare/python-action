/**
 * @file dataSourcesQL.js - 1.2.0 - 3826bc12533e078a8e37cfe70ee04d9e85c8530e
 * 
 * @copyright Copyright (C) 2016-2023, ISARA Corporation, All Rights Reserved.
 * 
 * @license The code and other content set out herein is not in the public
 * domain, is considered a trade secret and is confidential to ISARA
 * Corporation. Use, reproduction or distribution, in whole or in part, of such
 * code or other content is strictly prohibited except by express written
 * permission of ISARA Corporation. Please contact ISARA Corporation at
 * info@isara.com for more information.
 */

/**
 * This module contains DataSource (ingestion) related queries.
 * @module graphql/dataSourcesQL
 */

const fs = require('fs')
const path = require('path')
const urlJoin = require('url-join')
const { graphQLStateToWanted } = require('../isaraql/wantedUtil')
const { fetchWanted, registerFetchHook } = require('../isaraql/fetch')
const { registerCleanupTask } = require('../util/cleanupTask')
const { roles, populateAddedBy, getSort } = require('./commonQL')
const { allTypes } = require('../isaraql/schemaDiscovery')
const {
    createUpdateDelete,
    registerHook,
    CUD_OP_INSERT,
    CUD_OP_UPDATE,
    CUD_OP_DELETE,
    CUD_OP_PRE,
    CUD_OP_POST
} = require('../isaraql/cud')
const { AdvancedSort } = require('../isaraql/fetch')
const { filterQuery } = require('./filterQL')
const log = require('../util/log')(module)
const ingestionJob = require('../ingestion/ingestionJob')
const { Session } = require('../isaraql/session')
const staticData = require('../express/staticData')


/**
 * The "fields" structure tells the front end how to present the configuration options. The following are currently supported:
 * type: string|password|radio|select|checkbox|list
 *
 * All:
 *  Additional key "optional" indicates if a field is required or not.
 *  Additional key "defaultValue" indicates the value to supply for the target field if not being loaded from existing data.
 *
 * Details:
 *   string - additional key "regex" indicates how to validate the input.
 *   password - Like string, but with the input value hidden (IOW <input type="password" />)
 *   radio|select|checkbox - additional field "options" provides an array of objects to indicate potential options, e.g.
 *     options: [ { id: "EXA", value: 0}, { id: "Splunk", value: 1} ]
 *   date - Display a date picker for the field in question
 *   partition - Displays a Select for percent and Two dropdowns for Hours and Minutes
 *
 *   In the case of "radio" and "select", these are mutually exclusive, while "checkbox" allows multiple options to be returned.
 */
const EXTRAHOP_SOURCE_META = {
    fields: [
        { name: 'url', description: 'URL', type: 'string', regex: '.*' },
        { name: 'token', description: 'API Token', type: 'password', regex: '.*' },
        { name: 'record_source', description: 'Record Source', type: 'radio', options: [{ id: 'EXA', value: 0 }, { id: 'Third Party', value: 1 }] }
    ]
}

const EXTRAHOP_SCAN_META = {
    fields: [
        { name: 'record_start', description: 'Ignore Records Before', type: 'date', optional: true }
    ]
}

const TANIUM_SOURCE_META = {
    fields: [
        { name: 'url', description: 'URL', type: 'string', regex: '.*' },
        { name: 'token', description: 'API Token', type: 'password', regex: '.*' },
    ]
}

const optionsPercent = [
    { id: '1%', value: '1' },
    { id: '2%', value: '2' },
    { id: '5%', value: '5' },
    { id: '10%', value: '10' },
    { id: '20%', value: '20' },
    { id: '50%', value: '50' },
    { id: '100%', value: '100' },
]

const TANIUM_SCAN_META = {
    fields: [
        { name: 'computer_group', description: 'Computer Group', type: 'string', regex: '.*', isScan:true, defaultValue: 'all machines' },
        { name: 'filter', description: 'With Filter', type: 'string', regex: '.*', optional: true, isScan:true },
        { name: 'partition_percent', description: 'Percentage', type: 'partition', regex: '.*', optional: true,  options: optionsPercent, isScan:true , defaultValue: '20', },
        { name: 'partition_delay_seconds', description: 'Partition Delay', type: 'time', regex: '.*', optional: true, isScan:true, defaultValue: '0'},
    ]
}

const NETSCOUT_CSV_SOURCE_META = {
    fields: [
        { name: 'file_path', description: 'CSVs to ingest', type: 'list', regex: '.*', defaultValue: '' },
    ]
}

const NETSCOUT_CSV_SCAN_META = {
    fields: [
        { name: 'type', description: 'NETSCOUT CSV type', type: 'hidden', regex: '.*', defaultValue: 'netscout_tls' },
    ]
}

const DATA_SOURCE_META = {
    'CSV Upload': {},
    'NETSCOUT CSV': NETSCOUT_CSV_SOURCE_META,
    'Tanium 7': TANIUM_SOURCE_META,
    'Discover(x) 8': EXTRAHOP_SOURCE_META
}

const DATA_SCAN_META = {
    'CSV Upload': {},
    'NETSCOUT CSV': NETSCOUT_CSV_SCAN_META,
    'Tanium 7': TANIUM_SCAN_META,
    'Discover(x) 8': EXTRAHOP_SCAN_META
}

const META_SANITIZED_VALUE = '**********'
const CSV_SOFTWARE_NAME = 'CSV'
const CSV_SOFTWARE_VERSION_NAME = 'CSV Upload'
const CSV_SOFTWARE_VENDOR = 'ISARA'
const NETSCOUT_CSV_SOFTWARE_NAME = 'NETSCOUT CSV'
const NETSCOUT_CSV_SOFTWARE_VERSION_NAME = 'NETSCOUT CSV Upload'
const NETSCOUT_CSV_SOFTWARE_VENDOR = 'ISARA'
const CNS_SOFTWARE_NAME = 'ISARA Cryptographic Network Sensor'
const CNS_SOFTWARE_VERSION_NAME = 'ISARA Cryptographic Network Sensor'
const CNS_SOFTWARE_VENDOR = 'ISARA'

const NETSCOUT_ALLOWED_EXTENSIONS = ['.csv', '.zip']


exports.CSV_SOFTWARE_NAME = CSV_SOFTWARE_NAME
exports.CSV_SOFTWARE_VERSION_NAME = CSV_SOFTWARE_VERSION_NAME
exports.CSV_SOFTWARE_VENDOR = CSV_SOFTWARE_VENDOR
exports.NETSCOUT_CSV_SOFTWARE_NAME = NETSCOUT_CSV_SOFTWARE_NAME
exports.NETSCOUT_CSV_SOFTWARE_VERSION_NAME = NETSCOUT_CSV_SOFTWARE_VERSION_NAME
exports.NETSCOUT_CSV_SOFTWARE_VENDOR = NETSCOUT_CSV_SOFTWARE_VENDOR
exports.CNS_SOFTWARE_NAME = CNS_SOFTWARE_NAME
exports.CNS_SOFTWARE_VERSION_NAME = CNS_SOFTWARE_VERSION_NAME
exports.CNS_SOFTWARE_VENDOR = CNS_SOFTWARE_VENDOR

/**
 * Removes sensitive meta-field values from a json text.
 * @param {String} json The json blob to sanitize.
 * @param {Object} meta The meta fields definition.
 * @returns {String} A sanitized json blob.
 */
function scrubMetaField(json, meta) {
    try {
        let metaObj = JSON.parse(json)
        for (const field of meta.fields) {
            if (field.type === 'password') {
                metaObj[field.name] = META_SANITIZED_VALUE
            }
        }
        return JSON.stringify(metaObj)
    } catch (e) {
        // if not valid json, return original value
        return json
    }
}

/**
 * Calculates the scanCount column on the Data Source object.
 * @param {object} dataSource The Data Source to transform.
 * @param {Session} session The database session being used.
 */
async function calculateDataSourceScanCount(dataSource, session) {
    if (dataSource.scanCount !== undefined) {
        const countResults = await session.query(
            `select count(*) as "count" from "DataSourceScan" dss where dss."dataSource" = ?`,
            [dataSource.id]
        )
        dataSource.scanCount = parseInt(countResults.rows[0].count)
    }
}

/**
 * Sanitizes the Data Source Scan configuration column.
 * @param {object} dataSourceScan The Data Source Scan to transform.
 * @param {Session} session The database session being used.
 */
async function sanitizeDataSourceScanMeta(dataSourceScan, session) {
    if (dataSourceScan.configuration) {
        const nameResults = await session.query(`
            select sv."name" from "DataSourceScan" dss
            join "DataSource" ds on dss."dataSource" = ds.id
            join "SoftwareVersion" sv on ds."softwareVersion" = sv.id
            where dss.id = ?`,
        [dataSourceScan.id]
        )
        let softwareVersionName = nameResults.rows[0].name
        let meta = DATA_SCAN_META[softwareVersionName]
        if (meta) {
            dataSourceScan.configuration = scrubMetaField(dataSourceScan.configuration, meta)
        }
    }
}

/**
 * Adds an access token to the error report file name.
 * @param {object} dataSourceScanResult The Data Source Scan to Result transform.
 */
async function addErrorReportAccessToken(dataSourceScanResult) {
    if (dataSourceScanResult.meta) {
        let meta = JSON.parse(dataSourceScanResult.meta)
        if (meta.errorReport) {
            const token = await staticData.requestAccessToken(meta.errorReport)
            meta.errorReport = urlJoin('data', meta.errorReport, `?access=${token}`)

            dataSourceScanResult.meta = JSON.stringify(meta)
        }
    }
}

/**
 * Cleans up orphaned error report files for scan results that have been deleted.
 */
async function cleanupDeletedResultReports() {
    const session = new Session()
    const csvResults = await session.query(
        `select dssr.id as id, dssr.meta as meta from "DataSourceScanResult" dssr
        join "DataSourceScan" dss on dss.id = dssr."dataSourceScan"
        join "DataSource" ds on ds.id = dss."dataSource"
        join "SoftwareVersion" sv on sv.id = ds."softwareVersion"
        where dssr.meta is not null and
        sv.software in (select id from "Software" s where s.name in (?,?))`,
        [CSV_SOFTWARE_NAME, NETSCOUT_CSV_SOFTWARE_NAME])
    const csvRegex = /\.csv$/i
    const knownReports = csvResults.rows
        .map(r => JSON.parse(r.meta).errorReport)
        .filter(r => r)
        .map(r => path.join(staticData.dataDirectory, r))
    const csvErrorsDir = path.join(staticData.dataDirectory, 'csv/errors')
    if (fs.existsSync(csvErrorsDir)) {
        const existingReports = fs.readdirSync(csvErrorsDir)
            .filter(f => csvRegex.test(f))
            .map(f => path.join(csvErrorsDir, f))
        const orphanedReports = existingReports.filter(r => !knownReports.includes(r))
        for (let file of orphanedReports) {
            log.d(`Deleting orphaned report file '${file}'`)
            try {
                fs.unlinkSync(file)
            } catch (e) {
                log.e(`Orphaned report file '${file}' could not be deleted: ${e}`)
            }
        }
    }
}

/**
 * Updates existing Meta field values, to not overwrite unmodified protected fields.
 * @param {string} existingMetaJson The existing configuration json.
 * @param {*} updatedMetaJson The updated configuration json.
 * @returns The merged configuration json.
 */
function updateMeta(existingMetaJson, updatedMetaJson) {
    let existingMeta = JSON.parse(existingMetaJson)
    let updatedMeta = JSON.parse(updatedMetaJson)

    for (let field in updatedMeta) {
        // If a field is the sanitized value, then it was unmodified.
        if (updatedMeta[field] !== META_SANITIZED_VALUE) {
            existingMeta[field] = updatedMeta[field]
        }
    }

    return JSON.stringify(existingMeta)
}

let dataSourceCredentialsMetaQuery = async function (fields/*, request, response*/) {
    let wpcs = {
        SoftwareVersion: {
            where: { equals: { column: 'id', value: fields.softwareVersionId } }
        }
    }
    let wanted = {
        id: true,
        name: true,
    }

    let softwareVersions = await fetchWanted('SoftwareVersion', wanted, wpcs)

    if (softwareVersions.length === 0) {
        throw `Software Version '${fields.softwareVersionId}' not found.`
    }

    let softwareVersion = softwareVersions[0]
    let meta = DATA_SOURCE_META[softwareVersion.name]

    if (!meta) {
        throw `Credentials Meta not found for '${softwareVersion.name}'`
    }

    let scanMeta = DATA_SCAN_META[softwareVersion.name]

    if (!scanMeta) {
        throw `Scan Meta not found for '${softwareVersion.name}'`
    }
    meta =  {fields: [...meta.fields, ...scanMeta.fields]}
    return {
        id: fields.softwareVersionId,
        credentialsMeta: [JSON.stringify(meta)]
    }
}

let dataSourceScanMetaQuery = async function (fields/*, request, response*/) {
    let wpcs = {
        SoftwareVersion: {
            where: { equals: { column: 'id', value: fields.softwareVersionId } }
        }
    }
    let wanted = {
        id: true,
        name: true,
    }

    let softwareVersions = await fetchWanted('SoftwareVersion', wanted, wpcs)

    if (softwareVersions.length === 0) {
        throw `Software Version '${fields.softwareVersionId}' not found.`
    }

    let softwareVersion = softwareVersions[0]
    let meta = DATA_SCAN_META[softwareVersion.name]

    if (!meta) {
        throw `Scan Meta not found for '${softwareVersion.name}'`
    }

    return {
        id: fields.softwareVersionId,
        scanMeta: [JSON.stringify(meta)]
    }
}

async function dataSourceScansQuery(fields, request, response) {
    try {
        var tableName = 'DataSourceScan'
        let wpcs = {
            DataSourceScan: {
                where: {
                    and: []
                },
                sort: ['id asc']
            }
        }

        if (fields.ids && fields.ids.length !== 0) {
            wpcs[tableName].where.and.push({ in: { column: 'id', value: fields.ids } })
        }

        if (fields.dataSourceId) {
            wpcs[tableName].where.and.push({ equals: { column: 'dataSource', value: fields.dataSourceId } })
        }

        if (fields.paging) {
            wpcs[tableName].paging = fields.paging
        } else {
            wpcs[tableName].paging = { offset: 0n, limit: 5n }
        }

        var wanted = graphQLStateToWanted(response)
        wanted = wanted[Object.keys(wanted)[0]]
        if (wanted.paging && wanted.paging.count) {
            wpcs[tableName].count = true
        }

        var dataSourceScans = await fetchWanted(tableName, wanted.dataSourceScans, wpcs)

        var toReturn = { dataSourceScans }
        if (wanted.paging) {
            toReturn.paging = { count: wpcs[tableName].count[0] }
        }

        return toReturn
    } catch (error) {
        log.e(error)
    }
}

/**
 * Resolver function to query for dataSources objects.
 *
 * @param {object} fields The GraphQL fields structure dictating what parameters to query by.
 * @param {object} request HTTP request headers object.
 * @param {object} response The GraphQL response structure dictating the desired field selections.
 *
 * @returns {object[]} An array of record structures containing matching dataSources.
 * @throws An exception is thrown if an error occurs while querying.
 */
async function dataSourcesQuery(fields, request, response) {
    try {
        const tableName = 'DataSource'
        let session = new Session()
        let wpcs = {
            DataSource: {
                where: {
                    and: []
                },
                sort: ['id asc']
            }
        }

        if (fields.ids && fields.ids.length !== 0) {
            wpcs[tableName].where.and.push({ in: { column: 'id', value: fields.ids } })
        }

        if (fields.paging) {
            wpcs[tableName].paging = fields.paging
        } else {
            wpcs[tableName].paging = { offset: 0n, limit: 5n }
        }

        if (fields.sorting) {
            wpcs[tableName].sort = await getSort(sortDataSourcesDictionary, fields.sorting)
        }

        if (fields.filter) {
            if (fields.filter.status) {
                let filterStatusId = allTypes['DataSourceStatus']._enum.idByName[fields.filter.status]
                wpcs[tableName].where.and.push({ equals: { column: 'status', value: filterStatusId } })
            }
            if (fields.filter.friendlyName) {
                wpcs[tableName].where.and.push({ like: { column: 'friendlyName', value: `%${fields.filter.friendlyName}%` } })
            }
        }

        var wanted = graphQLStateToWanted(response)
        wanted = wanted[Object.keys(wanted)[0]]

        if (wanted.paging && wanted.paging.count) {
            wpcs[tableName].count = true
        }

        var dataSources = await fetchWanted(tableName, wanted.dataSources, wpcs, session)

        var toReturn = { dataSources }
        if (wanted.paging) {
            toReturn.paging = { count: wpcs[tableName].count[0] }
        }

        if (wanted.dataSourceSummary) {
            toReturn.dataSourceSummary = {}
            if (wanted.dataSourceSummary.status) {
                let statusQuery = `
                    select "name", count("DataSource".id) from "DataSourceStatus"
                    left join "DataSource" on "DataSourceStatus".id = "DataSource".status
                    group by "name"`
                let statusResults = await session.query(statusQuery)
                toReturn.dataSourceSummary.status = statusResults.rows
            }
        }

        return toReturn
    } catch (error) {
        log.e(error)
    }
}

/**
 * Resolver function to query for dataSourceScanSchedules objects.
 *
 * @param {object} fields The GraphQL fields structure dictating what parameters to query by.
 * @param {object} request HTTP request headers object.
 * @param {object} graphQLState The GraphQL response structure dictating the desired field selections.
 *
 * @returns {object[]} An array of record structures containing matching dataSourceScanSchedules.
 * @throws An exception is thrown if an error occurs while querying.
 */
async function dataSourceScanSchedulesQuery(fields, request, response) {
    try {
        let tableName = 'DataSourceScanSchedule'
        let wpcs = {
            DataSourceScanSchedule: {
                where: {
                    and: []
                },
                sort: ['id asc']
            }
        }

        if (fields.ids && fields.ids.length !== 0) {
            wpcs[tableName].where.and.push({ in: { column: 'id', value: fields.ids } })
        }

        if (fields.dataSourceScanID) {
            wpcs[tableName].where.and.push({ equals: { column: 'dataSourceScan', value: fields.dataSourceScanID } })
        }

        if (fields.paging) {
            wpcs[tableName].paging = fields.paging
        } else {
            wpcs[tableName].paging = { offset: 0n, limit: 5n }
        }

        var wanted = graphQLStateToWanted(response)
        wanted = wanted[Object.keys(wanted)[0]]
        if (wanted.paging && wanted.paging.count) {
            wpcs[tableName].count = true
        }

        var dataSourceScanSchedules = await fetchWanted(tableName, wanted.dataSourceScanSchedules, wpcs)

        var toReturn = { dataSourceScanSchedules }
        if (wanted.paging) {
            toReturn.paging = { count: wpcs[tableName].count[0] }
        }

        return toReturn
    } catch (error) {
        log.e(error)
    }
}

/**
 * Resolver function to query for dataSourceSoftware objects.
 *
 * @param {object} fields The GraphQL fields structure dictating what parameters to query by.
 * @param {object} request HTTP request headers object.
 * @param {object} response The GraphQL response structure dictating the desired field selections.
 *
 * @returns {object[]} An array of record structures containing matching dataSourceSoftware.
 * @throws An exception is thrown if an error occurs while querying.
 */
async function dataSourceSoftwareQuery(fields, request, response) {
    try {
        if (!('paging' in fields)) {
            fields.paging = { offset: 0n, limit: 50n }
        }
        var wpcs = {
            Software: {
                where: { equals: { column: 'softwareType', value: 'DATA' } },
                sort: ['name asc'],
                paging: fields.paging
            },
            SoftwareVersion: {
                sort: ['sortableVersion desc']
            }
        }

        return await filterQuery('Software', 'softwares', fields.filter, response, wpcs)
    } catch (error) {
        log.e(error)
    }
}

/**
 * Resolver function to query for dataSourceScanResults objects.
 *
 * @param {object} fields The GraphQL fields structure dictating what parameters to query by.
 * @param {object} request HTTP request headers object.
 * @param {object} response The GraphQL response structure dictating the desired field selections.
 *
 * @returns {object[]} An array of record structures containing matching dataSourceScanResults.
 * @throws An exception is thrown if an error occurs while querying.
 */
async function dataSourceScanResultsQuery(fields, request, response) {
    try {
        const tableName = 'DataSourceScanResult'
        const detailTableName = 'DataSourceScanResultDetail'
        let session = new Session()
        var wpcs = {
            DataSourceScanResult: {
                where: {
                    and: []
                },
                sort: ['runAt desc']
            },
            DataSourceScanResultDetail: {
                where: {
                    and: []
                },
                sort: ['when desc']
            }
        }

        if (fields.ids && fields.ids.length !== 0) {
            wpcs[tableName].where.and.push({ in: { column: 'id', value: fields.ids } })
        }

        if (fields.dataSourceScanID) {
            wpcs[tableName].where.and.push({ equals: { column: 'dataSourceScan', value: fields.dataSourceScanID } })
        }


        if (fields.paging) {
            wpcs[tableName].paging = fields.paging
        } else {
            wpcs[tableName].paging = { offset: 0n, limit: 5n }
        }

        if (fields.detailPaging) {
            wpcs[detailTableName].paging = fields.detailPaging
        } else {
            wpcs[detailTableName].paging = { offset: 0n, limit: 5n }
        }

        var wanted = graphQLStateToWanted(response)
        wanted = wanted[Object.keys(wanted)[0]]

        if (wanted.paging && wanted.paging.count) {
            wpcs[tableName].count = true
        }

        if (wanted.detailPaging && wanted.detailPaging.count) {
            wpcs[detailTableName].count = true
        }

        if (fields.sorting) {
            wpcs[tableName].sort = await getSort(sortScanResultsDictionary, fields.sorting)
        }

        if (fields.filter) {
            if (fields.filter.status) {
                let filterStatusId = allTypes['DataSourceScanResultStatus']._enum.idByName[fields.filter.status]
                wpcs[tableName].where.and.push({ equals: { column: 'status', value: filterStatusId } })
            }
            if (fields.filter.friendlyName) {
                wpcs[tableName].where.and.push({ like: { column: 'friendlyName', value: `%${fields.filter.friendlyName}%` } })
            }
        }

        var dataSourceScanResults = await fetchWanted(tableName, wanted.dataSourceScanResults, wpcs, session)

        var toReturn = { dataSourceScanResults }
        if (wanted.paging) {
            toReturn.paging = { count: wpcs[tableName].count[0] }
        }

        if (wanted.detailPaging) {
            toReturn.detailPaging = { count: wpcs[detailTableName].count[0] }
        }

        if (wanted.dataSourceScanResultSummary) {
            toReturn.dataSourceScanResultSummary = {}
            if (wanted.dataSourceScanResultSummary.status) {
                let statusQuery = `
                    select "DataSourceScanResultStatus"."name", count("DataSourceScanResult".id) from "DataSourceScanResultStatus"
                    left join "DataSourceScanResult" on "DataSourceScanResultStatus".id = "DataSourceScanResult".status
                    group by "DataSourceScanResultStatus"."name"`
                let statusResults = await session.query(statusQuery)
                toReturn.dataSourceScanResultSummary.status = statusResults.rows
            }
        }

        return toReturn
    } catch (error) {
        log.e(error)
    }
}

async function dataSourceDirectoryListingQuery(fields/*, request, response*/) {
    let subDirectory
    if (fields.subDirectory) {
        subDirectory = fields.subDirectory
    }
    const directory = path.join(staticData.dataDirectory, `netscout${subDirectory ? '/' + subDirectory : ''}`)
    if (fs.existsSync(directory)) {
        const [files, maxDepth] = await getFiles(directory, NETSCOUT_ALLOWED_EXTENSIONS)
        return {items: files, maxDepth}
    }
    return []
}

function getFiles(directory, allowedExts, depth = 0) {
    const directoryChildren = fs.readdirSync(directory)

    const files = directoryChildren.reduce((acc, candidate) => {
        const resolved = path.resolve(directory, candidate)
        const isDirectory = fs.statSync(resolved).isDirectory()
        const allowed = allowedExts.includes(path.extname(candidate)) || isDirectory

        if (!allowed) {
            return acc
        }

        if (isDirectory) {
            const [children, depthAcc] = getFiles(resolved, allowedExts, depth + 1)
            depth += depthAcc
            acc.push({
                filename: candidate,
                path: resolved,
                children,
                isLeaf: false
            })
        } else {
            acc.push({
                filename: candidate,
                path: resolved,
                isLeaf: true
            })
        }
        return acc.sort((a, b) => a.isLeaf - b.isLeaf)
    }, [])
    return [files, depth]
}

const deletableTables = {
    DataSource: true,
    DataSourceScan: true,
    DataSourceScanTag: true,
    DataSourceScanSchedule: true,
    DataSourceScanResult: true,
    DataSourceScanResultDetail: true
}

const modifiableTables = (() => {
    let result = Object.assign({}, deletableTables)
    result.Tag = true
    return result
})()

const checkExistingTables = (() => {
    let result = Object.assign({}, modifiableTables)
    result.Software = true
    result.SoftwareVersion = true
    return result
})()

async function dataSourceUpdateMutation(fields, request, graphQLState) {
    let sources = fields.sources
    let config = {
        allowDelete: true,
        allowInsert: true,
        allowUpdate: true,
        checkExistingTables,
        deletableTables,
        modifiableTables
    }
    let ids = await createUpdateDelete('DataSource', sources, config)
    for (let id of ids) {
        // test new/updated data sources
        await ingestionJob.runDataSourceTest(id)
    }
    return dataSourcesQuery({ ids: ids }, request, graphQLState)
}

async function dataSourceScanUpdateMutation(fields, request, graphQLState) {

    let scans = fields.scans
    let config = {
        allowDelete: true,
        allowInsert: true,
        allowUpdate: true,
        checkExistingTables,
        deletableTables,
        modifiableTables
    }
    let ids = await createUpdateDelete('DataSourceScan', scans, config)
    return dataSourceScansQuery({ ids: ids }, request, graphQLState)
}

async function dataSourceScanScheduleUpdateMutation(fields, request, graphQLState) {
    let schedules = fields.schedules
    let config = {
        allowDelete: true,
        allowInsert: true,
        allowUpdate: true,
        checkExistingTables,
        deletableTables,
        modifiableTables
    }
    let ids = await createUpdateDelete('DataSourceScanSchedule', schedules, config)
    return dataSourceScanSchedulesQuery({ ids: ids }, request, graphQLState)
}

async function dataSourceScanResultDeleteMutation(fields/*, request, graphQLState*/) {
    let scanResult = {
        id: fields.dataSourceScanResultId,
        DELETE: true
    }
    let config = {
        allowDelete: true,
        deletableTables: {
            DataSourceScanResult: true,
            DataSourceScanResultDetail: true
        }
    }
    await createUpdateDelete('DataSourceScanResult', [scanResult], config)
    return true
}

async function dataSourceScanResultUpdateMutation(fields, request, graphQLState) {
    let [scanResult] = fields.scanResult
    let config = {
        allowInsert: true,
        allowUpdate: true,
        checkExistingTables,
        deletableTables,
        modifiableTables
    }
    let ids = await createUpdateDelete('DataSourceScanResult', [scanResult], config)
    await createUpdateDelete('DataSourceScan', [{id: scanResult.dataSourceScan.id, lastStatus: scanResult.status}], config)
    return dataSourceScanResultsQuery({ ids: ids }, request, graphQLState)
}

async function dataSourceScanTriggerMutation(fields, request, graphQLState) {
    let scanResultId = await ingestionJob.runDataSourceScan(fields.dataSourceScanId)
    return dataSourceScanResultsQuery({ ids: [scanResultId] }, request, graphQLState)
}

function initialise() {
    registerHook('DataSource', CUD_OP_INSERT, CUD_OP_PRE, preModifyDataSource)
    registerHook('DataSourceScan', CUD_OP_INSERT, CUD_OP_PRE, preModifyDataSourceScan)
    registerHook('DataSourceScanSchedule', CUD_OP_INSERT, CUD_OP_PRE, preModifyDataSourceScanSchedule)
    registerHook('DataSource', CUD_OP_UPDATE, CUD_OP_PRE, preModifyDataSource)
    registerHook('DataSourceScan', CUD_OP_UPDATE, CUD_OP_PRE, preModifyDataSourceScan)
    registerHook('DataSourceScanSchedule', CUD_OP_UPDATE, CUD_OP_PRE, preModifyDataSourceScanSchedule)

    registerHook('DataSourceScanSchedule', CUD_OP_INSERT, CUD_OP_POST, postModifyDataSourceScanSchedule)
    registerHook('DataSourceScanSchedule', CUD_OP_UPDATE, CUD_OP_POST, postModifyDataSourceScanSchedule)
    registerHook('DataSourceScanSchedule', CUD_OP_DELETE, CUD_OP_POST, postDeleteDataSourceScanSchedule)

    // registerFetchHook('DataSource', sanitizeDataSourceMeta)
    registerFetchHook('DataSource', calculateDataSourceScanCount)
    registerFetchHook('DataSourceScan', sanitizeDataSourceScanMeta)
    registerFetchHook('DataSourceScanResult', addErrorReportAccessToken)

    registerCleanupTask('ScanResultReportCleanup', cleanupDeletedResultReports)

    buildDataSourcesSortDictionary()
    buildScanResultsSortDictionary()
}

/**
 * This function will be called before a new DataSource is inserted.
 * @param {CUDHook} params
 */
async function preModifyDataSource(params) {
    if (params.operation === CUD_OP_INSERT) {
        params.record.addedAt = new Date()
        params.record.status = allTypes['DataSourceStatus']._enum.idByName['ENABLED']
    }

    params.record.lastModified = new Date()
    populateAddedBy(params)

    if (params.operation === CUD_OP_UPDATE && params.record.configuration) {
        let existingConfigJson = await params.session.query(
            `select "configuration" from "DataSource" where id = ?`,
            [params.record.id]
        )

        params.record.configuration = updateMeta(existingConfigJson.rows[0].configuration, params.record.configuration)
    }
}

/**
 * This function will be called before a new DataSourceScan is inserted.
 * @param {CUDHook} params
 */
async function preModifyDataSourceScan(params) {
    if (params.operation === CUD_OP_INSERT) {
        params.record.addedAt = new Date()
    }
    params.record.lastModified = new Date()
    populateAddedBy(params)

    if (params.operation === CUD_OP_UPDATE && params.record.configuration) {
        let existingConfigJson = await params.session.query(
            `select "configuration" from "DataSourceScan" where id = ?`,
            [params.record.id]
        )

        params.record.configuration = updateMeta(existingConfigJson.rows[0].configuration, params.record.configuration)
    }
}

/**
 * This function will be called before a new DataSourceScanSchedule is inserted.
 * @param {CUDHook} params
 */
async function preModifyDataSourceScanSchedule(params) {
    if (params.operation === CUD_OP_INSERT) {
        params.record.addedAt = new Date()
    }
    params.record.lastModified = new Date()
    populateAddedBy(params)
}

/**
 * This function will be called after a DataSourceScanSchedule is inserted or modified.
 * @param {CUDHook} params
 */
async function postModifyDataSourceScanSchedule(params) {
    await ingestionJob.unscheduleScan(params.record)
    await ingestionJob.scheduleScan(params.record, params.session)
}

/**
 * This function will be called after a DataSourceScanSchedule is deleted.
 * @param {CUDHook} params
 */
async function postDeleteDataSourceScanSchedule(params) {
    ingestionJob.unscheduleScan(params.record)
}

/**
 * This dictionary will hold the SQL fragments needed by `fetch.js` to build a table spanning sort query for Data Sources.
 */
const sortDataSourcesDictionary = {}

/**
 * This dictionary will hold the SQL fragments needed by `fetch.js` to build a table spanning sort query for Scan Results.
 */
const sortScanResultsDictionary = {}

/**
 * Builds the sorting dictionary showing `fetch` how to sort Data Sources for named parameters.
 */
function buildDataSourcesSortDictionary() {
    // Simple filters
    sortDataSourcesDictionary['ID'] = `"id" %DIR%`
    sortDataSourcesDictionary['ADDED_DATE'] = `"addedAt" %DIR%`
    sortDataSourcesDictionary['LAST_MODIFIED'] = `"lastModified" %DIR%`
    sortDataSourcesDictionary['NICKNAME'] = `"friendlyName" %DIR%`

    // Complex filters
    sortDataSourcesDictionary['PROVIDER'] = new AdvancedSort(`
        left join "SoftwareVersion" on "SoftwareVersion".id = "DataSource"."softwareVersion"
        left join "Software" on "Software".id = "SoftwareVersion"."software"`,
    [],
    [`"Software"."name" %DIR%`, `"SoftwareVersion"."sortableVersion" %DIR%`],
    null
    )

    sortDataSourcesDictionary['SCAN_COUNT'] = new AdvancedSort(`
        left join "DataSourceScan" on "DataSource".id = "DataSourceScan"."dataSource"`,
    [`"DataSource".id`],
    `count("DataSourceScan".id) %DIR%`,
    null
    )

    sortDataSourcesDictionary['STATUS'] = new AdvancedSort(`
        left join "DataSourceStatus" on "DataSourceStatus".id = "DataSource"."status"`,
    [],
    `"DataSourceStatus"."name" %DIR%`,
    null
    )

    sortDataSourcesDictionary['USER'] = new AdvancedSort(`
        left join "User" on "User".id = "DataSource"."addedBy"`,
    [],
    `"User"."humanName" %DIR%`,
    null
    )
}

/**
 * Builds the sorting dictionary showing `fetch` how to sort Data Source Scan Results for named parameters.
 */
function buildScanResultsSortDictionary() {
    // Simple filters
    sortScanResultsDictionary['ID'] = `"id" %DIR%`
    sortScanResultsDictionary['NICKNAME'] = `"friendlyName" %DIR%`
    sortScanResultsDictionary['RUN_DATE'] = `"runAt" %DIR%`

    // Complex filters
    sortScanResultsDictionary['PROVIDER'] = new AdvancedSort(`
        left join "DataSourceScan" on "DataSourceScan".id = "DataSourceScanResult"."dataSourceScan"
        left join "DataSource" on "DataSource".id = "DataSourceScan"."dataSource"
        left join "SoftwareVersion" on "SoftwareVersion".id = "DataSource"."softwareVersion"
        left join "Software" on "Software".id = "SoftwareVersion"."software"`,
    [],
    [`"Software"."name" %DIR%`, `"SoftwareVersion"."sortableVersion" %DIR%`],
    null
    )

    sortScanResultsDictionary['STATUS'] = new AdvancedSort(`
        left join "DataSourceScanResultStatus" on "DataSourceScanResultStatus".id = "DataSourceScanResult"."status"`,
    [],
    `"DataSourceScanResultStatus"."name" %DIR%`,
    null
    )

    sortScanResultsDictionary['USER'] = new AdvancedSort(`
        left join "User" on "User".id = "DataSourceScanResult"."runBy"`,
    [],
    `"User"."humanName" %DIR%`,
    null
    )
}

exports.graphQL = {
    types: `
        enum SortableDataSourceFields {
            ADDED_DATE
            ID
            LAST_MODIFIED
            NICKNAME
            PROVIDER
            SCAN_COUNT
            STATUS
            USER
        }

        enum SortableDataSourceScanResultsFields {
            ID
            NICKNAME
            PROVIDER
            RUN_DATE
            STATUS
            USER
        }

        input DataSourceSortingInput {
            field: SortableDataSourceFields!
            direction: SortDirection!
        }

        input DataSourceScanResultsSortingInput {
            field: SortableDataSourceScanResultsFields!
            direction: SortDirection!
        }

        input DataSourceFilterInput {
            status: DataSourceStatus
            friendlyName: String
        }

        input DataSourceScanResultFilterInput {
            status: DataSourceScanResultStatus
            friendlyName: String
        }

        type DataSourceSummary {
            status: [AttributeSummary!]!
        }

        type DataSourceScanResultSummary {
            status: [AttributeSummary!]!
        }

        type PagedDataSources {
            paging: Paging!
            dataSources: [DataSource!]!
            dataSourceSummary: DataSourceSummary!
        }

        type PagedDataSourceScans {
            paging: Paging!
            dataSourceScans: [DataSourceScan!]!
        }

        type PagedDataSourceScanResults {
            paging: Paging!
            detailPaging: Paging!
            dataSourceScanResults: [DataSourceScanResult!]!
            dataSourceScanResultSummary: DataSourceScanResultSummary!
        }

        type PagedDataSourceScanSchedules {
            paging: Paging!
            dataSourceScanSchedules: [DataSourceScanSchedule!]!
        }

        type SoftwareVersionCredentialsMeta {
            id: BigInt!
            credentialsMeta: [String!]!
        }

        type SoftwareVersionScanMeta {
            id: BigInt!
            scanMeta: [String!]!
        }

        type PagedDataSourceSoftwares {
            paging: Paging!
            softwares: [Software!]!
        }

        type DataSourceDirectoryListing {
            maxDepth: BigInt!
            items: [DataSourceDirectoryListingItem]
        }

        type DataSourceDirectoryListingItem {
            filename: String!
            path: String!
            children: [DataSourceDirectoryListingItem]
            isLeaf: Boolean!
        }
    `,
    queries: `
        dataSourceCredentialsMeta(
            softwareVersionId: BigInt!
        ): SoftwareVersionCredentialsMeta

        dataSourceScanMeta(
            softwareVersionId: BigInt!
        ): SoftwareVersionScanMeta

        dataSourceScans(
            ids: [BigInt!]
            dataSourceId: BigInt
            paging: PagingInput
        ): PagedDataSourceScans!

        dataSources(
            ids: [BigInt!]
            paging: PagingInput
            filter: DataSourceFilterInput
            sorting: DataSourceSortingInput
        ): PagedDataSources!

        dataSourceDirectoryListing (
            subDirectory: String
        ): DataSourceDirectoryListing!

        dataSourceScanResults(
            ids: [BigInt!]
            dataSourceScanId: BigInt
            paging: PagingInput,
            detailPaging: PagingInput,
            filter: DataSourceScanResultFilterInput
            sorting: DataSourceScanResultsSortingInput
        ): PagedDataSourceScanResults!

        dataSourceScanSchedules(
            ids: [BigInt!]
            dataSourceScanId: BigInt
            paging: PagingInput
        ): PagedDataSourceScanSchedules!

        dataSourceSoftware(
            paging: PagingInput
        ): PagedDataSourceSoftwares!
    `,
    mutations: `
        dataSourceUpdate(
            sources: [DataSourceInput!]!
        ): PagedDataSources!

        dataSourceScanUpdate(
            scans: [DataSourceScanInput!]!
        ): PagedDataSourceScans!

        dataSourceScanScheduleUpdate(
            schedules: [DataSourceScanScheduleInput!]!
        ): PagedDataSourceScanSchedules!

        dataSourceScanResultDelete(
            dataSourceScanResultId: BigInt!
        ): Boolean!

        dataSourceScanTrigger(
            dataSourceScanId: BigInt!
        ): PagedDataSourceScanResults!

        dataSourceScanResultUpdate(
            scanResult: [DataSourceScanResultInput!]!
        ): PagedDataSourceScanResults!
    `,
    root: {
        dataSourceUpdate: dataSourceUpdateMutation,
        dataSourceScanUpdate: dataSourceScanUpdateMutation,
        dataSourceScanScheduleUpdate: dataSourceScanScheduleUpdateMutation,
        dataSourceScanResultDelete: dataSourceScanResultDeleteMutation,
        dataSourceScanTrigger: dataSourceScanTriggerMutation,
        dataSourceSoftware: dataSourceSoftwareQuery,
        dataSourceCredentialsMeta: dataSourceCredentialsMetaQuery,
        dataSourceScanMeta: dataSourceScanMetaQuery,
        dataSourceScans: dataSourceScansQuery,
        dataSources: dataSourcesQuery,
        dataSourceScanResults: dataSourceScanResultsQuery,
        dataSourceScanSchedules: dataSourceScanSchedulesQuery,
        dataSourceDirectoryListing: dataSourceDirectoryListingQuery,
        dataSourceScanResultUpdate: dataSourceScanResultUpdateMutation,
    },
    restrictions: {
        dataSourceUpdate: [roles.ADMIN],
        dataSourceScanUpdate: [roles.ADMIN],
        dataSourceScanScheduleUpdate: [roles.ADMIN],
        dataSourceScanResultDelete: [roles.ADMIN],
        dataSourceScanTrigger: [roles.ADMIN],
        dataSourceSoftware: [roles.ADMIN],
        dataSourceCredentialsMeta: [roles.ADMIN],
        dataSourceScanMeta: [roles.ADMIN],
        dataSourceScans: [roles.ADMIN],
        dataSources: [roles.ADMIN],
        dataSourceScanResults: [roles.ADMIN],
        dataSourceScanSchedules: [roles.ADMIN],
        dataSourceDirectoryListing: [roles.ADMIN],
        dataSourceScanResultUpdate: [roles.ADMIN]
    },
    initialise
}
