/**
 * @file cryptoScoreQL.js - 1.2.0 - 3826bc12533e078a8e37cfe70ee04d9e85c8530e
 * 
 * @copyright Copyright (C) 2016-2023, ISARA Corporation, All Rights Reserved.
 * 
 * @license The code and other content set out herein is not in the public
 * domain, is considered a trade secret and is confidential to ISARA
 * Corporation. Use, reproduction or distribution, in whole or in part, of such
 * code or other content is strictly prohibited except by express written
 * permission of ISARA Corporation. Please contact ISARA Corporation at
 * info@isara.com for more information.
 */

/**
 * This module contains crypto score focused queries.
 * @module graphql/cryptoScoreQL
 */
const { filterQuery } = require('./filterQL')
const { getSort, roles } = require('./commonQL')
const { createUpdateDelete } = require('../isaraql/cud')
const {
    Session
} = require('../isaraql/session')
const { getCptFilterQuery, isSystemCPT } = require('./cryptoPostureTemplatesQL')
const {
    generatePlaceholders
} = require('../isaraql/fetch')

/**
 * This dictionary will hold the SQL fragments needed by `fetch.js` to build a table spanning sort query.
 */
const sortDictionary = {}

async function cryptoScoreQuery(fields, request, graphQLState) {
    return cryptoScoreFilterQuery(fields, request, graphQLState, [fields.id])
}

/**
 * Main query to see CPTs.
 * @param {Object} fields Fields from GraphQL Query
 * @param {Object} request GraphQL request
 * @param {Object} graphQLState GraphQL State
 * @param {number[]} [ids] Set of IDs to run query for (instead of filter)
 */
async function cryptoScoreFilterQuery(fields, request, graphQLState, ids) {
    if (!('paging' in fields)) {
        fields.paging = { offset: 0n, limit: 5n }
    }

    let wpcs = { CryptoScore: { paging: fields.paging } }
    if (ids && ids.length !== 0) {
        wpcs.CryptoScore.where = { in: { column: 'id', value: ids } }
    }

    if ('sorting' in fields) {
        wpcs.CryptoScore.sort = await getSort(sortDictionary, fields.sorting)
    }

    return filterQuery('CryptoScore', 'cryptoScore', fields.filter, graphQLState, wpcs, fields.asOf, null, () => {})
}

async function setCryptoScore(cryptoScores, cryptoScoreCoarse/*, session*/){
    for(let cryptoScore of cryptoScores){
        if(!cryptoScore.DELETE){
            cryptoScore.score = cryptoScoreCoarse.score
            cryptoScoreCoarse.score = cryptoScoreCoarse.score+1
        }
    }
}

async function cryptoScoreUpdateMutation(fields, request, graphQLState) {
    let session = new Session()
    let cryptoScores = fields.cryptoScore
    let cryptoScoreCoarses = [
        {name: 'PENDING', score: -1},
        {name: 'UNACCEPTABLE', score: 0},
        {name: 'CAUTION', score: 500},
        {name: 'STRONG_CLASSIC', score: 1000},
        {name: 'STRONG_QSC', score: 1500}
    ]

    let scoreCounts = {}
    cryptoScoreCoarses.forEach(item => scoreCounts[item.name] = 0)
    let requiredFields = ['name', 'friendlyName', 'shortName']
    let deletableScores = []
    let cptTemplateId

    // ensure that we don't overflow a given category.
    for(let scoreItem of cryptoScores) {
        let { DELETE } = scoreItem
        cptTemplateId = scoreItem.cryptoPostureTemplate.id
        let isSystem = await isSystemCPT(cptTemplateId, session)


        if (isSystem){
            throw 'ISARA CPT may not be modified'
        }

        if (DELETE){
            deletableScores.push(scoreItem.id)
        }

        if (!DELETE && (requiredFields.some((field => !scoreItem[field]?.trim())))) {
            throw `Unable to process score with missing required fields: ${requiredFields.filter(field => scoreItem[field]?.trim() === '' || scoreItem[field] === undefined).join(', ')}`
        }

        scoreCounts[scoreItem.cryptoScoreCoarse]++
        if (scoreCounts[scoreItem.cryptoScoreCoarse] > 500) {
            throw `Too many items in category ${scoreItem.cryptoScoreCoarse}`
        }
    }

    if (deletableScores.length) {
        let scoresInUse = (await session.query(`with scores as (
                                                        select cs.id, cs.name,cs."cryptoPostureTemplate" as cpt
                                                        from "CryptoPrimitiveScore" cps
                                                        join "CryptoScore" cs on cs.ID = cps."cryptoScore"
                                                        union
                                                        select cs.id, cs.name,cs."cryptoPostureTemplate" as cpt
                                                        from "ProtocolVariantScore" cvs
                                                        join "CryptoScore" cs on cs.id = cvs."cryptoScore")
                                                        select name from scores where cpt=${cptTemplateId} and id in (${generatePlaceholders(deletableScores)})`, deletableScores)).rows.map(row => row.name)

        if (scoresInUse.length) {
            throw `Cannot delete score, the following score${scoresInUse.length === 1 ? ' is' : 's are'} being used by one or more primitives or protocol variants ${scoresInUse.join(', ')}`
        }
    }



    // step 1: prevent add/editing CPT if more than one default score is provided.
    if(cryptoScores.filter(cryptoScoreitem => cryptoScoreitem.isDefault === true).length > 1){
        throw 'More than one default score is provided.'
    }
    for(let cryptoScoreCoarse of cryptoScoreCoarses){
        await  setCryptoScore(cryptoScores.filter(cryptoScoreitem => cryptoScoreitem.cryptoScoreCoarse === cryptoScoreCoarse.name), cryptoScoreCoarse, session)
    }

    let config = {
        allowDelete: true,
        allowInsert: true,
        allowUpdate: true,
        modifiableTables: {
            CryptoScore: true,
        },
        deletableTables: {
            CryptoScore: true,
            CryptoPrimitiveScore: true,
            ProtocolVariantScore: true,
            DeviceScore: true,
            ConnectionScore: true
        },
        checkExistingTables:{
            CryptoScore: true,
        }
    }

    return await session.asTransaction(async () => {
        // Deferral is necessary due to the scores temporarily being in a conflicting state while they're in the process of being reassigned
        await session.query('SET CONSTRAINTS ALL DEFERRED')
        let ids = await createUpdateDelete('CryptoScore', cryptoScores, config)
        fields.sorting = { field: 'SCORE', direction: 'ASCENDING' }
        return await cryptoScoreFilterQuery(fields, request, graphQLState, ids)
    })

}

async function scoreUpdateMutation(fields, request, graphQLState) {
    let templateId = fields.templateId
    let primitiveScores = fields.primitiveScore
    let protocolVariantScores = fields.protocolVariantScore

    let session = new Session()

    let resultCryptoScore = await session.query('SELECT "id" FROM "advance"."CryptoScore" WHERE "cryptoPostureTemplate" = (?)', [templateId])
    let cryptoScoreIds = resultCryptoScore.rows.map(row => row.id)

    let resultsPrimitiveScores = await session.query(`select cps.id from "CryptoPrimitiveScore" cps
                                                        join "CryptoScore" cs ON cs.id = cps."cryptoScore"
                                                        where cs."cryptoPostureTemplate" = (?)`, [templateId])
    let resultsPrimitiveScoresIds = resultsPrimitiveScores.rows.map(row => row.id)

    let resultsProtocolVariantScores = await session.query(`select cvs.id from "ProtocolVariantScore" cvs
                                                        join "CryptoScore" cs ON cs.id = cvs."cryptoScore"
                                                        where cs."cryptoPostureTemplate" = (?)`, [templateId])
    let resultsProtocolVariantScoresIds = resultsProtocolVariantScores.rows.map(row => row.id)

    for (let primitiveScore of primitiveScores) {
        // step 1: check the crypto scores is belongs to the given template
        if(!cryptoScoreIds.includes(primitiveScore.cryptoScore.id)){
            throw 'Provided crypto score does not belong to the given template'
        }
        // step 2: check the crypto primitive is belongs to the given template
        if(primitiveScore.id && !resultsPrimitiveScoresIds.includes(primitiveScore.id)){
            throw 'Provided crypto primitive does not belong to the given template'
        }
    }

    for (let protocolVariantScore of protocolVariantScores) {
        // step 3: check the crypto scores is belongs to the given template
        if(!cryptoScoreIds.includes(protocolVariantScore.cryptoScore.id)){
            throw 'Provided crypto score does not belong to the given template'
        }
        // step 4: check the crypto primitive is belongs to the given template
        if(protocolVariantScore.id && !resultsProtocolVariantScoresIds.includes(protocolVariantScore.id)){
            throw 'Provided protocol variant does not belong to the given template'
        }
    }

    let config = {
        allowDelete: true,
        allowInsert: true,
        allowUpdate: true,
        modifiableTables: {
            CryptoPrimitiveScore: true,
            ProtocolVariantScore: true,
        },
        checkExistingTables:{
            CryptoPrimitiveScore: true,
            ProtocolVariantScore: true,
        }
    }

    await session.asTransaction(async function () {
        await createUpdateDelete('CryptoPrimitiveScore', primitiveScores, config)
        await createUpdateDelete('ProtocolVariantScore', protocolVariantScores, config)
    })
    return await getCptFilterQuery(fields, request, graphQLState,[templateId])

}

function buildSortDictionary() {
    // All the simple sorts that use a field which exists ON the crypto score table.
    sortDictionary['NAME'] = `NULLIF("name", '') %DIR% %NULLS%`
    sortDictionary['FRIENDLY_NAME'] = `NULLIF("friendlyName", '') %DIR% %NULLS%`
    sortDictionary['SHORT_NAME'] = `NULLIF("shortName", '') %DIR% %NULLS%`
    sortDictionary['SCORE'] = `"score" %DIR%`
}

function initialise() {
    // Hooks
    buildSortDictionary()
}

exports.graphQL = {
    types: `
        enum SortableCryptoScoreFields {
            NAME
            FRIENDLY_NAME
            SHORT_NAME
            SCORE
        }

        type FilteredCryptoScore {
            paging: Paging!
            cryptoScore: [CryptoScore!]!
        }

        input CryptoScoreSortingInput {
            field: SortableCryptoScoreFields!
            direction: SortDirection!
        }
    `,
    queries: `
        cryptoScoreById(
            id: BigInt!
            paging: PagingInput
        ): FilteredCryptoScore!

        filteredcryptoScore(
            filter: String
            paging: PagingInput
            sorting: CryptoScoreSortingInput
        ) : FilteredCryptoScore!

    `,
    mutations: `
        cryptoScoreUpdate(
            cryptoScore: [CryptoScoreInput!]!
        ) : FilteredCryptoScore!

        scoreUpdate(
            templateId : BigInt!
            primitiveScore: [CryptoPrimitiveScoreInput!]
            protocolVariantScore: [ProtocolVariantScoreInput!]
        ): FilteredCryptoPostureTemplates!
    `,
    root: {
        cryptoScoreById: cryptoScoreQuery,
        filteredcryptoScore: cryptoScoreFilterQuery,
        cryptoScoreUpdate : cryptoScoreUpdateMutation,
        scoreUpdate: scoreUpdateMutation,
    },
    restrictions: {
        cryptoScoreById: [roles.AUTHENTICATED],
        filteredcryptoScore: [roles.AUTHENTICATED],
        cryptoScoreUpdate: [roles.AUTHENTICATED],
        scoreUpdate: [roles.AUTHENTICATED],
    },
    initialise
}
