/**
 * @file ignoredPortQL.js - 1.2.0 - 3826bc12533e078a8e37cfe70ee04d9e85c8530e
 * 
 * @copyright Copyright (C) 2016-2023, ISARA Corporation, All Rights Reserved.
 * 
 * @license The code and other content set out herein is not in the public
 * domain, is considered a trade secret and is confidential to ISARA
 * Corporation. Use, reproduction or distribution, in whole or in part, of such
 * code or other content is strictly prohibited except by express written
 * permission of ISARA Corporation. Please contact ISARA Corporation at
 * info@isara.com for more information.
 */

/**
 * This file manages ignored ports.
 * @module graphql/ignoredPortsQL
 */

const { createUpdateDelete } = require('../isaraql/cud')
const { fetchWanted } = require('../isaraql/fetch')
const { graphQLStateToWanted } = require('../isaraql/wantedUtil')
const { roles, GraphQLEnum, SORT_DIRECTION_ENUM } = require('./commonQL')
const { inRange } = require('lodash')
/**
 * Enum for the fields allowed to be sorted on Ignored Ports.
 */
const SORTABLE_FIELDS_ENUM = new GraphQLEnum('SortableIgnoredPortFields', ['name', 'port'])

/**
 * Query to see ignored ports.
 * @param {Object} fields Fields from the GraphQL query
 * @param {number} [fields.id] An optional ID for retrieving a single ignored port
 * @param {Paging} [fields.paging] Paging information. Defaults to 5 records.
 * @param {IgnoredPortSortingInput} [fields.orderBy] Sort preference for retrieved ignored ports.
 * @param {Object} request GraphQL request
 * @param {Object} graphQLState GraphQL State
 * @param {number[]} [ids] Set of IDs to run query for.
 */
async function ignoredPortsQuery(fields, request, graphQLState, ids) {
    var wanted = graphQLStateToWanted(graphQLState)
    wanted = wanted[Object.keys(wanted)[0]]

    if (!('paging' in fields)) {
        fields.paging = { offset: 0n, limit: 5n }
    }
    var wpcs = { IgnoredPort: { paging: fields.paging } }
    if (wanted.paging && wanted.paging.count) {
        wpcs.IgnoredPort.count = []
    }

    if ('id' in fields) {
        ids = [fields.id]
    }

    let specificIDWanted = ids !== undefined && ids.length !== 0

    if (specificIDWanted) {
        wpcs.IgnoredPort.where = {
            and: [{ in: { column: 'id', value: ids } }],
        }
    }

    if (fields.orderBy) {
        wpcs.IgnoredPort.sort = `"${
            SORTABLE_FIELDS_ENUM.graphQLToInternal[fields.orderBy.field]
        }" ${SORT_DIRECTION_ENUM.graphQLToInternal[fields.orderBy.direction]}`
    }

    var ignoredPorts = await fetchWanted(
        'IgnoredPort',
        wanted.ignoredPorts,
        wpcs
    )
    if (ignoredPorts.length === 0 && specificIDWanted) {
        throw 'Port not found.'
    }
    var toReturn = { ignoredPorts }

    return toReturn
}

const checkExistingTables = {}
const deletableTables = { IgnoredPort: true }
const modifiableTables = deletableTables

/**
 * Create/Update/Delete Ignored Ports.
 * @param {*} fields
 * @param {*} request
 * @param {*} graphQLState
 */
async function ignoredPortsUpdateMutation(fields, request, graphQLState) {
    var ignoredPorts = fields.ignoredPorts
    var config = {
        allowDelete: true,
        allowInsert: true,
        allowUpdate: true,
        checkExistingTables,
        deletableTables,
        modifiableTables,
    }

    for (let ignoredPort of ignoredPorts) {
        const { name, port, DELETE } = ignoredPort
        if (!DELETE) {
            if(!name.trim()) {
                throw new Error('Name field cannot be empty')
            } 
            if(!inRange(port, 1, 65535)) {
                throw new Error('Invalid port')
            }
        }
    }

    var ids = await createUpdateDelete('IgnoredPort', ignoredPorts, config)
    return ignoredPortsQuery(fields, request, graphQLState, ids)
}

exports.graphQL = {
    types: `
        type PagedIgnoredPorts {
            paging: Paging!
            ignoredPorts: [IgnoredPort!]!
        }

        ${SORTABLE_FIELDS_ENUM.toGraphQL()}

        input IgnoredPortSortingInput {
            field: SortableIgnoredPortFields!,
            direction: SortDirection!,
        }
    `,
    queries: `
        """
            Obtain all the ignored ports.
        """
        ignoredPorts(
            """
                Used to control how many ignored ports are returned. The default (without paging) will be 5.
            """
            paging: PagingInput
            """
                When provided, will attempt to find a single ignored port. The port may not exist, or you may not have access.
            """
            id: BigInt
            """
            Used to set the sort order of the Ignored Ports
            """
            orderBy: IgnoredPortSortingInput
        ) : PagedIgnoredPorts!
    `,
    mutations: `
        ignorePortsUpdate(
            ignoredPorts: [IgnoredPortInput!]!
        ) : PagedIgnoredPorts!
    `,
    root: {
        ignoredPorts: ignoredPortsQuery,
        ignorePortsUpdate: ignoredPortsUpdateMutation,
    },
    restrictions: {
        ignoredPorts: [roles.AUTHENTICATED],
        ignorePortsUpdate: [roles.AUTHENTICATED],
    },
}
