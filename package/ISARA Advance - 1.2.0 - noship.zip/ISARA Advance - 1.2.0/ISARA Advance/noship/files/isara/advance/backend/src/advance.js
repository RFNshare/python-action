/**
 * @file advance.js - 1.2.0 - 3826bc12533e078a8e37cfe70ee04d9e85c8530e
 * 
 * @copyright Copyright (C) 2016-2023, ISARA Corporation, All Rights Reserved.
 * 
 * @license The code and other content set out herein is not in the public
 * domain, is considered a trade secret and is confidential to ISARA
 * Corporation. Use, reproduction or distribution, in whole or in part, of such
 * code or other content is strictly prohibited except by express written
 * permission of ISARA Corporation. Please contact ISARA Corporation at
 * info@isara.com for more information.
 */

/**
 * @module advance
 */

const PRODUCTION_LOG_FILE_NAME = '/var/log/isara/advance.backend.log'

let express = require('express')
let expressWS = require('express-ws')

const compression = require('compression')
let {
    graphqlHTTP
} = require('express-graphql')
let {
    buildSchema, GraphQLList, GraphQLNonNull, GraphQLObjectType, GraphQLScalarType, GraphQLInputObjectType
} = require('graphql')
let schemaDiscovery = require('./isaraql/schemaDiscovery')

let {
    roles, userRoleMapping
} = require('./graphql/commonQL')

let {
    tokenParameters
} = require('./graphql/userAuthenticationQL')

let {
    logQuery, addQuery
} = require('./graphql/queryTrackingQL')

let {
    registerKey
} = require('./graphql/userPreferencesQL')

const jwt = require('express-jwt')

const log = require('./util/log')(module)
const { insertResponseHeaders } = require('./util/responseHeaders')
const {
    addRequestStateHandling, addRequestStateHandlingForGraphQL,
    getRequestState
} = require('./util/requestState')
const ingestionJob = require('./ingestion/ingestionJob')
const cleanupTask = require('./util/cleanupTask')

// type resolvers for extended graphql scalar types
const { resolvers } = require('graphql-scalars')

// patch built-in JSON handling to properly handle BigInt objects.
require('json-bigint-patch')

const health = require('./express/health')
const dbUtil = require('./isaraql/dbutil')

const Session = require('./isaraql/session').Session

const systemPreferences = require('./util/systemPreferences')
const { getActiveCPTID } = require('./util/cptHelpers')
const { initializeInstantSearchExports, createCollections } = require('./ingestion/searchIndex')

const axiosFactory = require('./util/axiosFactory')
const { getInstantSearchConfiguration } = require('./isaraql/instantSearchProvider')
const axios = require('axios')

const { prepareHTTPSServer } = require('./util/certificates')
const bodyParser = require('body-parser')
const { initializeReportJobs } = require('../src/graphql/reportsQL')
/**
 * The TCP port the Advance backend services will listen on.
 */
const ADVANCE_SERVICE_PORT = 4000

/**
 * This is the frequency at which the system will perform the health check.
 * It has been chosen as a long time to not flood and idle system with health check logging.
 */
const AUTO_HEALTH_CHECK_DELAY_MS = 15 * 60 * 1000

/**
 * This is the gap between user triggered health checks. This is a shorter time as the system
 * should be responsive to coming back up when a user is attempting to use it.
 */
const USER_TRIGGERED_HEALTH_CHECK_GAP_MS = 30 * 1000

/**
 * This is the delay between a fatal init error and `process.exit` being called.
 */
const ABORT_EXIT_DELAY_MS = 10 * 1000

/**
 * This is the database version that this code expects to find. The number is not meaningful; but database
 * versions above or below do produce a different error.
 */
const EXPECTED_DB_VERSION = 8

/**
 * This delay is to attempt bringing up Advance more rapidly at startup. If Advance and postgres are started
 * at the same time (as an example) it's likely that Advance will be ready before postgres.
 */
const RAPID_INITIAL_HEALTH_CHECK_DELAY_MS = 2 * 1000

/**
 * This indicates the number of times to attempt bring up rapidly, before deferring to the auto or user times.
 */
const RAPID_INITIAL_HEALTH_CHECK_MAX_COUNT = 60

const { validateToken, TOKEN_HEADER_NAME } = require('./ingestion/streaming/streamTokens')

/**
 *
 * @param {function} originalFunction
 */
function addSecurityRestrictionHandling(originalFunction) {
    if (!('roles' in originalFunction)) {
        throw 'Role specification missing.'
    }

    // no need to wrap the function at all if it is wide open.
    let allowedRoles = originalFunction.roles
    if (allowedRoles.includes(roles.UNAUTHENTICATED)) {
        return originalFunction
    }

    return async function () {
        let userRoles = []
        let req = arguments[1]

        if (req.sessionExpired) {
            throw 'Session expired.'
        }
        if (req.user) {
            // JSON deserialization can't necessarily tell that the uid is a bigint,
            // so it may map it as a regular number. This can cause problems later
            // when comparing user.uid to DB rows.
            req.user.uid = BigInt(req.user.uid)
            userRoles = req.user.roles.map(role => userRoleMapping[role])
            let requestState = getRequestState()
            if (requestState) {
                // Copy user object into request state.
                requestState.user = req.user
            }
        }

        // the user must have at least one role with a higher index
        // than the required roles for the function
        if (!userRoles.some(x => allowedRoles.some(y => y <= x))) {
            throw 'Access denied to query.'
        }

        return originalFunction(...arguments)
    }
}

/**
 *
 * @param {string} queryName
 * @param {function} originalFunction
 */
function addFunctionCallLogging(queryName, originalFunction) {
    addQuery(queryName)
    let newFunction = async function () {
        log.d(`Received request for ${queryName}...`)
        let start = new Date().getTime()
        let error = null
        try {
            return await originalFunction(...arguments)
        } catch (e) {
            log.e('Unhandled exception in query', e)
            let request = arguments[1]
            if ('x-isara-ignorestatexception' in request.headers) {
                error = null
            } else {
                error = e
            }
            throw e
        } finally {
            let delta = new Date().getTime() - start
            await logQuery(queryName, delta, error)
        }
    }
    // Original function's attributes are copied - as this is where
    // we store things like roles.
    Object.assign(newFunction, originalFunction)
    return newFunction
}

function registerPreferenceKeys(preferenceKeys) {
    for (let key of Object.keys(preferenceKeys)) {
        let keyInfo = preferenceKeys[key]
        registerKey(key, keyInfo.description, keyInfo.default, keyInfo.validator)
    }
}

const X_ISARA_AUTHORIZATION_HEADER = 'x-isara-authorization'
const AUTHORIZATION_HEADER = 'authorization'

function registerSecurityPolicy(expressApp) {
    expressApp.use(bodyParser.json({ limit: '50mb' }))
    expressApp.use(compression())
    expressApp.use((request, response, next) => {
        if (X_ISARA_AUTHORIZATION_HEADER in request.headers) {
            request.headers[AUTHORIZATION_HEADER] = request.headers[X_ISARA_AUTHORIZATION_HEADER]
        }
        next()
    })
    expressApp.use(jwt(
        {
            secret: tokenParameters.secret,
            algorithms: [tokenParameters.algorithm],
            credentialsRequired: false
        }
    ))

    expressApp.use(function (err, req, res, next) {
        if (err.name === 'UnauthorizedError') {
            req.sessionExpired = true
        }
        next()
    })
}

async function prepareGraphQL(expressApp, route) {
    function insertIntoBlock(schema, header, body) {
        let parts = schema.split(header)
        if (parts.length > 2) {
            throw 'Header in schema too many times'
        } else if (parts.length == 1) {
            // the block doesn't actually exist yet, add it.
            parts.push('\n}\n')
        }
        return parts.join(`${header}\n${body}\n`)
    }

    let graphQLModules = [
        './graphql/commonQL',
        './graphql/connectionsQL',
        './graphql/cryptoPostureTemplatesQL',
        './graphql/cryptoPrimitiveDefaultsQL',
        './graphql/cryptoScoreQL',
        './graphql/dataSourcesQL',
        './graphql/devicesQL',
        './graphql/enumQL',
        './graphql/featureQL',
        './graphql/filterQL',
        './graphql/ignoredPortQL',
        './graphql/instantSearchQL',
        './graphql/loggingQL',
        './graphql/notificationsQL',
        './graphql/pathDiagnosticsQL',
        './graphql/queryTrackingQL',
        './graphql/reportQL',
        './graphql/reportsQL',
        './graphql/softwareQL',
        './graphql/streamTokenQL',
        './graphql/stubsQL',
        './graphql/systemNetmasksQL',
        './graphql/taggingQL',
        './graphql/uiColumnsQL',
        './graphql/userAdministrationQL',
        './graphql/userAuthenticationQL',
        './graphql/userPreferencesQL',
        './graphql/valuesQL',
        './graphql/viewQL',
        './graphql/visualizationsQL',
        './graphql/widgetsQL'
    ]

    // The root provides a resolver function for each API endpoint
    let root = {}

    let textSchema = schemaDiscovery.schema

    // add types from graphql-scalars.
    textSchema += `
        scalar Date
        scalar Time
        scalar DateTime
        scalar Duration
        scalar UtcOffset
        scalar LocalDate
        scalar LocalTime
        scalar LocalEndTime
        scalar EmailAddress
        scalar NegativeFloat
        scalar NegativeInt
        scalar NonEmptyString
        scalar NonNegativeFloat
        scalar NonNegativeInt
        scalar NonPositiveFloat
        scalar NonPositiveInt
        scalar PhoneNumber
        scalar PositiveFloat
        scalar PositiveInt
        scalar PostalCode
        scalar UnsignedFloat
        scalar UnsignedInt
        scalar URL
        scalar ObjectID
        scalar BigInt
        scalar Long
        scalar SafeInt
        scalar UUID
        scalar GUID
        scalar HexColorCode
        scalar HSL
        scalar HSLA
        scalar IPv4
        scalar IPv6
        scalar ISBN
        scalar MAC
        scalar Port
        scalar RGB
        scalar RGBA
        scalar USCurrency
        scalar Currency
        scalar JSON
        scalar JSONObject
        scalar Byte
        scalar Void
    `

    for (let graphQLModule of graphQLModules) {
        log.d(`Processing GraphQL module '${graphQLModule}...`)
        let module = require(graphQLModule)
        if (!module.graphQL) {
            throw `GraphQL module '${graphQLModule}' missing graphQL export`
        }

        if (module.preferenceKeys) {
            registerPreferenceKeys(module.preferenceKeys)
        }

        let config = module.graphQL
        if (!config.restrictions) {
            log.w(`GraphQL module '${graphQLModule}' missing security restriction declarations`)
        }

        for (let key of Object.keys(config.root)) {
            if (config.restrictions && key in config.restrictions) {
                let restrictions = config.restrictions[key]
                if (!Array.isArray(restrictions)) {
                    restrictions = [restrictions]
                }
                config.root[key].roles = restrictions
            } else {
                log.w(`GraphQL query ${key} missing restrictions declaration, marking admin-only.`)
                config.root[key].roles = [roles.ADMIN]
            }
        }

        if (config.initialise) {
            await config.initialise()
        }
        if (config.types) {
            textSchema += config.types
        }
        if (config.queries) {
            textSchema = insertIntoBlock(textSchema, 'type Query {', config.queries)
        }
        if (config.mutations) {
            textSchema = insertIntoBlock(textSchema, 'type Mutation {', config.mutations)
        }
        if (config.root) {
            Object.assign(root, config.root)
        }
    }

    //await flatFacetHelpers.initialise()

    let schema = buildSchema(textSchema)

    // buildSchema() creates a schema tree that is unaware of custom resolvers, and consequently maps all types
    // to its builtins, which mainly rely on string type coercion. This is insufficient in most cases, and consequently
    // we need to remap said resolvers to graphql-scalars appropriate resolver types.
    // Ideally this could eventually be avoided by building up our schemas in object syntax rather than text in the long run.
    cleanupSchema(schema)

    for (let queryName in root) {
        log.d('Preparing query', queryName)
        root[queryName] = addFunctionCallLogging(queryName, root[queryName])
        root[queryName] = addSecurityRestrictionHandling(root[queryName])
        root[queryName] = addRequestStateHandlingForGraphQL(root[queryName])
    }

    const preferences = await systemPreferences()

    expressApp.use(route, graphqlHTTP({
        schema: schema,
        rootValue: root,
        graphiql: preferences?.featureFlags?.GRAPHIQL === true ? { headerEditorEnabled: true } : false
    }))
}

function cleanupSchema(schema) {
    const typeExcludes = ['DateTime']

    // pass 1: rewrite object field types. These are the baseline type definitions for all objects in the schema,
    // so any scalar fields on them must be remapped.
    for (let typeName of Object.keys(schema._typeMap)) {
        if (typeName in resolvers && !typeExcludes.includes(typeName)) {
            schema._typeMap[typeName] = resolvers[typeName]
        } else {
            let type = schema._typeMap[typeName]
            if (type instanceof GraphQLObjectType || type instanceof GraphQLInputObjectType) {
                rewriteFieldResolvers(type, [])
            }
        }
    }

    // pass 2: The same limitation applies to scalar arguments to queries and/or mutations.
    // consequently, we must walk all their arguments to replace them if needed (not applicable to object arguments, since those
    // simply reference the object resolvers from pass 1)
    cleanupArguments(schema._queryType._fields, [])
    cleanupArguments(schema._mutationType._fields, [])
}

function cleanupArgument(arg, resolvedObjectTypes) {
    let typeField = ('type' in arg) ? 'type' : 'ofType'
    if (arg[typeField] instanceof GraphQLNonNull) {
        if (arg[typeField].ofType instanceof GraphQLList) {
            cleanupArgument(arg.type.ofType, resolvedObjectTypes)
        } else if (arg[typeField].ofType instanceof GraphQLInputObjectType) {
            cleanupInputObject(arg[typeField].ofType, resolvedObjectTypes)
        } else {
            rewriteFieldTypeResolver(arg[typeField], 'ofType', resolvers)
        }
    } else {
        if (arg[typeField] instanceof GraphQLList) {
            cleanupArgument(arg[typeField], resolvedObjectTypes)
        } else if (arg[typeField] instanceof GraphQLInputObjectType) {
            cleanupInputObject(arg[typeField], resolvedObjectTypes)
        } else
            rewriteFieldTypeResolver(arg, typeField, resolvers)
    }
}

function cleanupInputObject(input, resolvedObjectTypes) {
    if (resolvedObjectTypes.includes(input.name)) {
        return
    }

    resolvedObjectTypes.push(input.name)
    for (let fieldName of Object.keys(input._fields)) {
        let field = input._fields[fieldName]
        cleanupArgument(field, resolvedObjectTypes)
    }
}

function cleanupArguments(functions, resolvedObjectTypes) {
    for (let name of Object.keys(functions)) {
        let func = functions[name]
        for (let arg of func.args) {
            // required types embed their types within a not-null wrapper.
            // consequently, we need to check for these in order to determine
            // if the wrapped type is one we need to replace.
            cleanupArgument(arg, resolvedObjectTypes)
        }
    }
}

function rewriteFieldTypeResolver(parent, fieldName) {
    const typeExcludes = ['DateTime']
    let typeName = parent[fieldName].name
    if (typeName in resolvers && !typeExcludes.includes(typeName)) {
        parent[fieldName] = resolvers[typeName]
    }
}

function rewriteFieldResolvers(gqlType, resolvedObjectTypes) {
    if (resolvedObjectTypes.includes(gqlType.name)) {
        // already inspected this object type, return.
        // needed to avoid recursion due to GQL's tree structure.
        return
    }
    resolvedObjectTypes.push(gqlType.name)

    for (let fieldName of Object.keys(gqlType._fields)) {
        let field = gqlType._fields[fieldName]
        if (field.type instanceof GraphQLNonNull) {
            if (field.type.ofType instanceof GraphQLScalarType) {
                rewriteFieldTypeResolver(field.type, 'ofType')
            }
        } else if (field.type instanceof GraphQLScalarType) {
            rewriteFieldTypeResolver(field, 'type')
        } else if (field.type instanceof GraphQLList) {
            let ofType = field.type.ofType
            if (ofType instanceof GraphQLNonNull) {
                if (ofType.ofType instanceof GraphQLObjectType) {
                    rewriteFieldResolvers(ofType.ofType,
                        resolvedObjectTypes)
                }
                else if (ofType.ofType instanceof GraphQLScalarType) {
                    rewriteFieldTypeResolver(ofType, 'ofType')
                }
            }
            else if (ofType instanceof GraphQLScalarType) {
                rewriteFieldTypeResolver(field, 'ofType')
            }
            else {
                rewriteFieldResolvers(ofType, resolvedObjectTypes)
            }
        }
    }
}

function addExpressSecurityRestrictionHandling(originalFunction, allowedRoles, notAuthenticated) {
    if (!allowedRoles) {
        throw 'Role specification missing.'
    }

    // no need to wrap the function at all if it is wide open.
    if (allowedRoles.includes(roles.UNAUTHENTICATED)) {
        return originalFunction
    }

    return async function (req, res) {
        try {
            let userRoles = []

            if (allowedRoles.includes(roles.TOKEN) && TOKEN_HEADER_NAME in req.headers) {
                const token = req.headers[TOKEN_HEADER_NAME]
                if (validateToken(token)) {
                    log.d('Request has valid token')
                    return originalFunction(...arguments)
                } else {
                    throw new Error(`Invalid or expired token ${TOKEN_HEADER_NAME} ${token}`)
                }
            }

            if (req.sessionExpired) {
                throw new Error(`Request's session has expired`)
            }
            if (req.user) {
                userRoles = req.user.roles.map(role => userRoleMapping[role])
            }

            // the user must have at least one role with a higher index
            // than the required roles for the function
            if (!userRoles.some(x => allowedRoles.some(y => y <= x))) {
                throw new Error(`Unauthorised request to ${req.path}`)
            }
        } catch (error) {
            if (notAuthenticated) {
                try {
                    await notAuthenticated()
                } catch (notAuthError) {
                    log.e('Error calling not authenticated callback', notAuthError)
                }
            }
            try {
                log.e('Unauthenticated request', error)
                res.status(401).send(error.message)
            } catch (error) {
                log.e('Error reporting authentication error', error)
            }

            return
        }

        return originalFunction(...arguments)
    }
}

function addExpressLogging(originalFunction) {
    return async function () {
        let req = arguments[0]
        let res = arguments[1]
        try {
            return await originalFunction(...arguments)
        } catch (e) {
            log.e(`Unhandled exception in ${req.method} ${req.url}`, e)
        } finally {
            log.d(`${req.method} ${req.url} ${res.statusCode} ${res.statusMessage}`)
        }
    }
}

async function registerUserExpressModules(expressApp) {
    let expressModules = [
        './express/certificate',
        './express/csvIngestion',
        './express/health',
        './express/cns',
        './express/staticData',
        './express/systemStatus',
        './express/version',
    ]

    for (let expressModule of expressModules) {
        log.d(`Processing Express module '${expressModule}'...`)
        let module = require(expressModule)
        if (!module.endpoint) {
            throw `Module '${expressModule}' is missing endpoint configuration`
        }
        if (!module.endpoint.path) {
            throw `Module Endpoint '${expressModule}' is missing path`
        }

        for (let verb of ['get', 'post', 'put', 'update', 'delete', 'use', 'ws']) {
            if (module.endpoint[verb]) {
                let path = module.endpoint[verb].path || module.endpoint.path
                let notAuthenticated = module.endpoint[verb].notAuthenticated || module.endpoint.notAuthenticated
                log.d(`Registering ${verb.toUpperCase()} ${path}`)
                let args = [path]
                if (module.endpoint[verb].middleware) {
                    args.push(module.endpoint[verb].middleware)
                }
                let handler = module.endpoint[verb].handler
                if (!module.bypassWrappers) {
                    let restrictions = module.endpoint[verb].restrictions || module.endpoint.restrictions
                    handler = addExpressSecurityRestrictionHandling(handler, restrictions, notAuthenticated)
                    handler = addRequestStateHandling(handler)
                    handler = addExpressLogging(handler)
                }
                args.push(handler)
                expressApp[verb](...args)
            }
        }
    }
}

class AdvanceBringUp {
    constructor(expressApp) {
        /**
         * Track if the database has ever been available.
         */
        this.databaseEverAvailable = false
        /**
         * Track if the database is available right now.
         */
        this.databaseAvailable = false

        /**
         * Track if GraphQL has ever been available.
         */
        this.graphQLEverAvailable = false

        /**
         * Track if GraphQL is available right now.
         */
        this.graphQLAvailable = false

        /**
         * Track if the cleanup scheduler has been started.
         */
        this.cleanupSchedulerStarted = false

        /**
         * Track if the ingestion scheduler has been started.
         */
        this.ingestionSchedulerStarted = false

        /**
         * Track if the report scheduler has been started.
         */
        this.reportSchedulerStarted = false

        /**
         * Track if the search index scheduler has been started.
         */
        this.searchIndexSchedulerStarted = false

        /**
         * The express app backing Advance.
         */
        this.expressApp = expressApp

        /**
         * Track if this is the first time bring up has been called.
         */
        this.bringUpFirstTime = true

        /**
         * Track if currently checking health. (To prevent long turn around from allowing multi-entrant behaviour)
         */
        this.checkingHealth = false


        /**
         * Track the last time user activity triggered a health check.
         */
        this.lastUserTriggeredCheck = -1

        /**
         * Track if typesense is available right now.
         */
        this.typesenseAvailable = false

        health.addUserHealthCheckListener(async () => {
            await this.userTriggeredHealthCheck()
        })
    }

    /**
     * Set the database health state.
     * @param {string} healthStatus A member from HealthKeys.
     */
    setDatabaseHealth(healthStatus) {
        if (healthStatus === health.healthKeys.HEALTH_OK) {
            this.databaseEverAvailable = true
            this.databaseAvailable = true
        } else {
            health.healthStatus = healthStatus
            this.databaseAvailable = false
        }
    }

    /**
     * Set the GraphQL health state.
     * @param {string} healthStatus A member from HealthKeys.
     */
    setGraphQLHealth(healthStatus) {
        if (healthStatus === health.healthKeys.HEALTH_OK) {
            this.graphQLEverAvailable = true
            this.graphQLAvailable = true
        } else {
            health.healthStatus = healthStatus
            this.graphQLAvailable = false
        }
    }

    /**
     * Set the Typesense health state.
     * @param {string} healthStatus A member from HealthKeys.
     */
    setTypesenseHealth(healthStatus) {
        if (healthStatus === health.healthKeys.HEALTH_OK) {
            this.typesenseAvailable = true
        } else {
            health.healthStatus = healthStatus
            this.typesenseAvailable = false
        }
    }

    /**
     * Called when a user activity has triggered a health check.
     */
    async userTriggeredHealthCheck() {
        const now = Date.now()
        if (now - this.lastUserTriggeredCheck > USER_TRIGGERED_HEALTH_CHECK_GAP_MS) {
            this.lastUserTriggeredCheck = now
            await this.checkHealth()
        }
    }

    /**
     * Called to check Advance's overall health.
     */
    async checkHealth() {
        if (this.checkingHealth) {
            return
        }
        this.checkingHealth = true
        try {
            await this.checkDatabase()
            await this.checkAndBringUpGraphQL()
            await this.checkTypesense()
            await this.startCleanupScheduler()
            await this.startIngestionScheduler()
            await this.startSearchIndexScheduler()
            await this.startReportScheduler()


            if (this.databaseAvailable && this.graphQLAvailable && this.typesenseAvailable &&
                health.healthStatus !== health.healthKeys.HEALTH_OK) {
                health.healthStatus = health.healthKeys.HEALTH_OK
                log.log('Advance backend is up')
            }
        } finally {
            this.checkingHealth = false
        }
    }

    /**
     * Called to start the nightly cleanup scheduler.
     */
    async startCleanupScheduler() {
        if (this.cleanupSchedulerStarted) {
            return
        }

        log.d('Initializing Cleanup Job')

        try {
            await cleanupTask.initializeCleanupJob()
            this.cleanupSchedulerStarted = true
        } catch {
            this.cleanupSchedulerStarted = false
        }
    }

    /**
     * Called to start the ingestion scheduler.
     */
    async startIngestionScheduler() {
        if (this.ingestionSchedulerStarted || !this.databaseAvailable) {
            return
        }

        log.d('Initializing Scan Jobs')

        try {
            await ingestionJob.initializeIngestionJobs()
            this.ingestionSchedulerStarted = true
        } catch {
            this.ingestionSchedulerStarted = false
        }
    }

    /**
     * Called to start the report scheduler.
     */
    async startReportScheduler() {
        if (this.reportSchedulerStarted || !this.databaseAvailable) {
            return
        }

        log.d('Initializing report Jobs')

        try {
            await initializeReportJobs()
            this.reportSchedulerStarted = true
        } catch {
            this.reportSchedulerStarted = false
        }
    }

    /**
     * Called to start the search index scheduler.
     */
    async startSearchIndexScheduler() {
        if (this.searchIndexSchedulerStarted || !this.databaseAvailable) {
            return
        }

        log.d('Initializing Search Indexer')

        try {
            await initializeInstantSearchExports()
            this.searchIndexSchedulerStarted = true
        } catch {
            this.searchIndexSchedulerStarted = false
        }
    }

    /**
     * Checks if the database is connectable, has the right version and enough users for Advance to run.
     */
    async checkDatabase() {
        if (await dbUtil.canDBConnect() === false) {
            log.e('Advance cannot connect to the database')
            this.setDatabaseHealth(health.healthKeys.HEALTH_DATABASE_FAILURE)
            return
        }

        const dbVersion = await dbUtil.getDBVersion()
        if (!dbVersion) {
            log.e(`Advance version number missing from database.`)
            this.setDatabaseHealth(health.healthKeys.HEALTH_DATABASE_VERSION_MISSING)
            return
        }

        let dbVersionNumber = -1
        try {
            dbVersionNumber = parseFloat(dbVersion)
        } catch (e) {
            log.e(`Advance treating version number as -1. In DB as ${dbVersion}`)
        }

        if (dbVersionNumber === EXPECTED_DB_VERSION) {
            // good
        } else if (dbVersion > EXPECTED_DB_VERSION) {
            this.setDatabaseHealth(health.healthKeys.HEALTH_DATABASE_VERSION_TOO_HIGH)
            log.e(`Advance DB version number too high - need to upgrade Advance ${dbVersionNumber}`)
            return
        } else {
            this.setDatabaseHealth(health.healthKeys.HEALTH_DATABASE_VERSION_TOO_LOW)
            log.e(`Advance DB version number invalid or too low - need to upgrade database ${dbVersion}`)
            return
        }

        try {
            const session = new Session()
            const userCount = await session.query('select count(id) as c from "User" where "lockedOut" <> true and "hidden" <> true')
            if (userCount.rows[0].c > 0) {
                // Good. there's at least one user.
            } else {
                this.setDatabaseHealth(health.healthKeys.HEALTH_DATABASE_NO_USERS)
                log.e(`Advance detected no existing users`)
                return
            }

            this.setDatabaseHealth(health.healthKeys.HEALTH_OK)
        } catch (e) {
            log.e(`Advance could not CHECK for existing users`, e)
            this.setDatabaseHealth(health.healthKeys.HEALTH_DATABASE_FAILURE)
            return
        }

        return true
    }

    /**
     * Checks if GraphQL can be brought, and attempts to bring up GraphQL.
     */
    async checkAndBringUpGraphQL() {
        if (!this.databaseAvailable) {
            return
        }
        try {
            if (!this.graphQLEverAvailable) {
                await schemaDiscovery.discoverSchema()
                //await facets.discoverPaths()
                await getActiveCPTID()
                await prepareGraphQL(this.expressApp, '/service/graphql')
                //await flatFacetHelpers.rebuildAllFlatFacetTables(false)
            }

            this.setGraphQLHealth(health.healthKeys.HEALTH_OK)
        } catch (e) {
            log.e('Could not bring up schema / graphql', e)
            this.setGraphQLHealth(health.healthKeys.HEALTH_GRAPHQL_FAILURE)
        }
    }

    /**
     * Checks if typesense server is running or not.
     */
    async checkTypesense() {
        try {
            const config = await getInstantSearchConfiguration()
            const { nodes: [typesenseNode] } = config
            const typesenseUrl = `${typesenseNode.protocol}://${typesenseNode.host}:${typesenseNode.port}`
            const { data } = await axios.get(`${typesenseUrl}/health`)
            if (data?.ok === true) {
                await createCollections()
                this.setTypesenseHealth(health.healthKeys.HEALTH_OK)
            } else {
                throw new Error(`Status from server is not ok ${JSON.stringify(data)}`)
            }
        } catch (e) {
            log.e(`Typesense server is not running`, e)
            this.setTypesenseHealth(health.healthKeys.HEALTH_TYPESENSE_FAILURE)
        }
    }

    /**
     * Attempts to bring up Advance's connection to the database and its GraphQL services.
     *
     * Also starts an interval timer which continually checks Advance's health.
     */
    async bringUpAdvance() {
        if (!this.bringUpFirstTime) {
            log.e('bringUpAdvance already called')
            return
        }
        this.bringUpFirstTime = false

        health.healthStatus = health.healthKeys.HEALTH_STARTING_CHECKS
        this.expressApp.use(insertResponseHeaders)

        registerSecurityPolicy(this.expressApp)
        await registerUserExpressModules(this.expressApp)
        await axiosFactory.init()

        await this.checkHealth()

        let rapidInitialCheckCount = 0
        const rapidInitialCheckInterval = setInterval(async () => {
            let clear = false
            if (this.databaseAvailable && this.graphQLAvailable) {
                clear = true
            } else {

                await this.checkHealth()

                ++rapidInitialCheckCount
                if (rapidInitialCheckCount > RAPID_INITIAL_HEALTH_CHECK_MAX_COUNT) {
                    clear = true

                }
            }

            if (clear) {
                clearInterval(rapidInitialCheckInterval)
            }
        }, RAPID_INITIAL_HEALTH_CHECK_DELAY_MS)

        setInterval(() => {
            this.checkHealth().catch((e) => {
                log.e('Problem checking system health', e)
            })
        }, AUTO_HEALTH_CHECK_DELAY_MS)
    }
}

/**
 * Main entry point for the Advance back end.
 *
 * This will create the express app, and attempt to start GraphQL.
 */
async function main() {
    log.logFile = PRODUCTION_LOG_FILE_NAME

    try {
        let expressApp = express()

        const server = await prepareHTTPSServer(ADVANCE_SERVICE_PORT, expressApp, 'backend')
        expressWS(expressApp, server)

        log.log('Listening on', ADVANCE_SERVICE_PORT)

        const advanceBringUp = new AdvanceBringUp(expressApp)
        await advanceBringUp.bringUpAdvance()
    } catch (e) {
        log.e('Exception in main', e)
        setTimeout(() => {
            process.exit(1)
        }, ABORT_EXIT_DELAY_MS)
    }
}

main()
