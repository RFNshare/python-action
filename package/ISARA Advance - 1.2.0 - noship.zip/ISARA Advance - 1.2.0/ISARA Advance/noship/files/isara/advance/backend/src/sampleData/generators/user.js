/**
 * @file user.js - 1.2.0 - 3826bc12533e078a8e37cfe70ee04d9e85c8530e
 * 
 * @copyright Copyright (C) 2016-2023, ISARA Corporation, All Rights Reserved.
 * 
 * @license The code and other content set out herein is not in the public
 * domain, is considered a trade secret and is confidential to ISARA
 * Corporation. Use, reproduction or distribution, in whole or in part, of such
 * code or other content is strictly prohibited except by express written
 * permission of ISARA Corporation. Please contact ISARA Corporation at
 * info@isara.com for more information.
 */



var log = require('../../util/log')(module)

exports.insertUsers = async function (password) {
    var names = [
        { name: 'callum', fullName: 'Callum Craig' },
        { name: 'fred', fullName: 'Fred Ferguson' },
        { name: 'sara', fullName: 'Sara Smith' }
    ]

    let usersArray = []
    for (var name of names) {
        var user = new User(name.name, name.fullName, await hashPassword(password))
        usersArray.push(user.nameValues)
    }

    let results
    try{
        results = await bulkInsertRecords('User', usersArray, session)
    }catch(e){console.log(e)}
    users.push(...results.rows)
    usersArray = []
}

exports.insertUserRoles = async function () {
    var roleIndex = 0
    let userRoleArray = []
    for (var user of users) {
        var roleNames = Object.keys(roles)
        var roleName = roleNames[roleIndex++]
        if (roleIndex == roleNames.length) {
            roleIndex = 0
        }
        var role = roles[roleName]
        var userRole = new UserRole(user.id, role.id)
        userRoleArray.push(userRole.nameValues)
    }
    try{
        await bulkInsertRecords('UserRole', userRoleArray, session)
    }catch(e){console.log(e)}
    userRoleArray = []
}

