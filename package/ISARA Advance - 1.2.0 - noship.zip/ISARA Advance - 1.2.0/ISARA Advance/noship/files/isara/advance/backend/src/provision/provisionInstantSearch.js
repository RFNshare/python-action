/**
 * @file provisionInstantSearch.js - 1.2.0 - 3826bc12533e078a8e37cfe70ee04d9e85c8530e
 * 
 * @copyright Copyright (C) 2016-2023, ISARA Corporation, All Rights Reserved.
 * 
 * @license The code and other content set out herein is not in the public
 * domain, is considered a trade secret and is confidential to ISARA
 * Corporation. Use, reproduction or distribution, in whole or in part, of such
 * code or other content is strictly prohibited except by express written
 * permission of ISARA Corporation. Please contact ISARA Corporation at
 * info@isara.com for more information.
 */

const { getInstantClient } = require('../isaraql/instantSearchProvider')
const { instantSearchSchemas } = require('./instantSchema')

const log = require('../util/log')(module)

const PRODUCTION_LOG_FILE_NAME = '/var/log/isara/advance.provision.log'

async function main() {
    log.logFile = PRODUCTION_LOG_FILE_NAME
    const argv = require('minimist')(process.argv.slice(2))

    const forceDestruction = argv.force ?? false
    const client = await getInstantClient()

    for(let schema of instantSearchSchemas) {
        const exists = await client.collections(schema.name).exists()

        // Delete existing
        if (exists && forceDestruction) {
            log.log(`Deleting instant search schema: ${schema.name}`)
            await client.collections(schema.name).delete()
        }

        // Create new if it didn't exist, or we just destroyed it
        if (!exists || forceDestruction) {
            log.log(`Creating instant search schema: ${schema.name}`)
            await client.collections().create(schema)
        }
    }
}

main().then(() => {
    log.log('Success')
}).catch(e => {
    log.e('Fatal exception:', e)
    process.exit(1)
})