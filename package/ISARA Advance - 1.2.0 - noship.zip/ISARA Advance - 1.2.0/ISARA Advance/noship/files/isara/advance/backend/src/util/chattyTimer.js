/**
 * @file chattyTimer.js - 1.2.0 - 3826bc12533e078a8e37cfe70ee04d9e85c8530e
 * 
 * @copyright Copyright (C) 2016-2023, ISARA Corporation, All Rights Reserved.
 * 
 * @license The code and other content set out herein is not in the public
 * domain, is considered a trade secret and is confidential to ISARA
 * Corporation. Use, reproduction or distribution, in whole or in part, of such
 * code or other content is strictly prohibited except by express written
 * permission of ISARA Corporation. Please contact ISARA Corporation at
 * info@isara.com for more information.
 */

const log = require('./log')(module)

/**
 * Timer that logs a chatty message when `stop` or `summary` called.
 */
class ChattyTimer {
    #started = -1n
    #total = 0n
    #count = 0
    #things = undefined
    #thingName = undefined
    #name = 'Empty Timer'

    /**
     *
     * @param {String} name Name of the timer
     * @param {[String]} thingName Name of things that are counted inside the timer's intervals
     */
    constructor(name, thingName) {
        this.#name = name
        this.#thingName = thingName
    }

    /**
     * Start the timer. Not an error to start it when it's already started.
     */
    start() {
        log.log(`TIMER: Started ${this.#name}`)
        this.#started = process.hrtime.bigint()
    }

    /**
     * Stop the timer. Report how long the current run took.
     * @param {[Number]} things The optional number of things that happened in this interval.
     */
    stop(things) {
        if (this.#started === -1n) {
            log.log(`TIMER: Stopped ${this.#name} when it wasn't started`)
            return
        }
        let delta = process.hrtime.bigint() - this.#started
        this.#started = -1n
        this.#total += delta
        this.#count += 1
        if (things !== undefined) {
            this.#things = (this.#things ?? 0) + things
        }
        log.log(`TIMER: ${this.#name} took ${Number(delta) / 1000000000}s${things !== undefined ? ` for ${things} ${this.#thingName ?? 'things'}` : ''}`)
        this.summary()
    }
    summary() {
        log.log(`TIMER: ${this.#name} ran ${this.#count} times for a total of ${Number(this.#total) / 1000000000}s${this.#things !== undefined ? ` for ${this.#things} ${this.#thingName ?? 'things'}` : ''}`)
    }
}

exports.ChattyTimer = ChattyTimer
