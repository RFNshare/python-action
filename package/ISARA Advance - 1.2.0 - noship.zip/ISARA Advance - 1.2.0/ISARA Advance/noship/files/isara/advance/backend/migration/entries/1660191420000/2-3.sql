--
-- @file 2-3.sql - 1.2.0 - 3826bc12533e078a8e37cfe70ee04d9e85c8530e
-- 
-- @copyright Copyright (C) 2016-2023, ISARA Corporation, All Rights Reserved.
-- 
-- @license The code and other content set out herein is not in the public
-- domain, is considered a trade secret and is confidential to ISARA
-- Corporation. Use, reproduction or distribution, in whole or in part, of such
-- code or other content is strictly prohibited except by express written
-- permission of ISARA Corporation. Please contact ISARA Corporation at
-- info@isara.com for more information.
--

    /* 
    * 
    *    SCHEMA - FORWARDS 
    *    MIGRATION 2 to 3
    *    >FOR RELEASE 0.83.1
    *    ORIGIN GIT HASH:38757389a016075ac449e8b7ee29cdf06878b7b6
    * 
    *    CREATED ON 2022-08-11T04:17:00.000Z
    *
    */


ALTER TABLE "advance"."Netmask" DROP CONSTRAINT IF EXISTS "uniqueSortOrder";

CREATE TABLE "advance"."CryptoPostureReport" (
    "id" bigserial PRIMARY KEY,
    "name" varchar(1024) NOT NULL,
    "addedAt" timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "lastModified" timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "metadata" text NULL,
    "owner" bigint NOT NULL REFERENCES "advance"."User",
    "cryptoPostureTemplate" BIGINT NULL REFERENCES "advance"."CryptoPostureTemplate",
    CONSTRAINT "reportsUniqueNamePerOwner" UNIQUE ("name", "owner")
);
ALTER TABLE "advance"."CryptoPostureReport" OWNER TO "postgres";
COMMENT ON TABLE "advance"."CryptoPostureReport" IS 'Stores Reports which a user has created. ';
COMMENT ON COLUMN "advance"."CryptoPostureReport"."id" IS 'The primary key.';
COMMENT ON COLUMN "advance"."CryptoPostureReport"."name" IS 'The name of the report - may be used in a list or possibly on the report. ';
COMMENT ON COLUMN "advance"."CryptoPostureReport"."addedAt" IS 'Records the date this Report was initially added.
@graphQL.readOnly';
COMMENT ON COLUMN "advance"."CryptoPostureReport"."lastModified" IS 'The time the Report was last modified.
@graphQL.readOnly';
COMMENT ON COLUMN "advance"."CryptoPostureReport"."metadata" IS 'The data related to panels, applied filters for this Report.';
COMMENT ON COLUMN "advance"."CryptoPostureReport"."owner" IS 'The User who owns this Report.
@graphQL.readOnly';
COMMENT ON CONSTRAINT "reportsUniqueNamePerOwner" ON "advance"."CryptoPostureReport" IS 'This constraint prevents a user from having reports with the same name.';
CREATE TABLE "advance"."ReportSnapshot" (
    "id" bigserial PRIMARY KEY,
    "snapshot" varchar NULL,
    "addedAt" timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "lastModified" timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "cryptoPostureReport" BIGINT NULL REFERENCES "advance"."CryptoPostureReport"
);
ALTER TABLE "advance"."ReportSnapshot" OWNER TO "postgres";
COMMENT ON TABLE "advance"."ReportSnapshot" IS 'Stores report snapshots. ';
COMMENT ON COLUMN "advance"."ReportSnapshot"."id" IS 'The primary key.';
COMMENT ON COLUMN "advance"."CryptoPostureReport"."name" IS 'Stores the snapshot in base64 format';
COMMENT ON COLUMN "advance"."CryptoPostureReport"."addedAt" IS 'Records the date this Report was initially added.
@graphQL.readOnly';
COMMENT ON COLUMN "advance"."CryptoPostureReport"."lastModified" IS 'The time the Report was last modified.
@graphQL.readOnly';


