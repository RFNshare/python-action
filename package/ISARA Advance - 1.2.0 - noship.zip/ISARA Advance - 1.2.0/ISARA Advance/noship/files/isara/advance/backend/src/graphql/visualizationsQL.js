/**
 * @file visualizationsQL.js - 1.2.0 - 3826bc12533e078a8e37cfe70ee04d9e85c8530e
 * 
 * @copyright Copyright (C) 2016-2023, ISARA Corporation, All Rights Reserved.
 * 
 * @license The code and other content set out herein is not in the public
 * domain, is considered a trade secret and is confidential to ISARA
 * Corporation. Use, reproduction or distribution, in whole or in part, of such
 * code or other content is strictly prohibited except by express written
 * permission of ISARA Corporation. Please contact ISARA Corporation at
 * info@isara.com for more information.
 */

const log = require('../util/log')(module)
const {
    Session
} = require('../isaraql/session')

const {
    generatePlaceholders
} = require('../isaraql/fetch')

const {
    roles
} = require('./commonQL')

const { expressionToQueryAndParams } = require('../filterql/filterSQL')

const schemaDiscovery = require('../isaraql/schemaDiscovery')
// const { getRequestState } = require('../util/requestState')
const { getCptForRequest } = require('../util/cptHelpers')

let supportedConnectionGroups = [
    {
        groupName: 'clientos',
        name: 'Client Operating System'
    },
    {
        groupName: 'serveros',
        name: 'Server Operating System'
    },
    {
        groupName: 'application',
        name: 'Application'
    },
    {
        groupName: 'crypto',
        name: 'Crypto Score'
    },
    {
        groupName: 'cryptocoarse',
        name: 'Crypto Category'
    },
    // {
    //     groupName: 'zoneIn',
    //     name: 'Zone In'
    // },
    // {
    //     groupName: 'zoneOut',
    //     name: 'Zone Out'
    // }
]

let supportedDeviceGroups = [
    {
        groupName: 'os',
        name: 'Operating System'
    },
    {
        groupName: 'application',
        name: 'Application'
    },
    {
        groupName: 'crypto',
        name: 'Crypto Score'
    },
    {
        groupName: 'cryptocoarse',
        name: 'Crypto Category'
    },
    {
        groupName: 'devicetype',
        name: 'Device Type'
    }
]

let supportedSoftwareGroups = [
    {
        groupName: 'cryptocoarse',
        name: 'Crypto Category'
    }
]

function cryptoScoreMapFunction(_, value) {
    return value
}

function cryptoScoreCoarseMapFunction(_, value) {
    return schemaDiscovery.allTypes['CryptoScoreCoarse']._enum.detailsByID[value].friendlyName
}

async function softwareNameMapper(softwareNames, _, id) {
    let softwareName = softwareNames[id]
    if (softwareName !== undefined) {
        return softwareName
    }

    return 'Unknown'
}

async function deviceVisualizationsCommon(fields, period) {
    validatePeriod(period)
    validateGroups(fields.groupNames, supportedDeviceGroups)
    let session = new Session()
    const epoch = fields.asOf ? new Date(fields.asOf) : undefined
    try {
        let results
        await session.reuseConnection(async () => {

            let wheres = []
            let joinParams = []
            let whereParams = []

            if (period !== undefined || epoch !== undefined) {
                await session.configureHistory(period, epoch)
            }

            if (fields.filter && fields.filter.length > 0) {
                let deviceIDQuery = await expressionToQueryAndParams('Device', fields.filter)
                whereParams.push(...deviceIDQuery.params)
                wheres.push(`"Device".id IN (${deviceIDQuery.query})`)
            }

            let joins = []
            let groupByClause = ' GROUP BY 1'

            let groupNames = fields.groupNames
            if (groupNames.length > 1) {
                groupByClause += ',2'
            }
            let identityMapFunction = function (_, value) {
                return value
            }

            let softwareTypes = schemaDiscovery.allTypes['SoftwareType']._enum

            let softwareNames = {}

            let columns = []
            let mapFunctions = []

            let nameMapper = softwareNameMapper.bind(null, softwareNames)
            let getSoftwareMap = false
            let softwareMapTypes = []

            let activeCpt =  await getCptForRequest(fields.cryptoPostureTemplate)
            let scoresJoined = false
            let scoreClause = `"DeviceScore" ds on ds."device" = "Device".id
                JOIN "CryptoScore" score ON score.id = ds."cryptoScore"
                JOIN "CryptoScoreCoarse" csc ON score."cryptoScoreCoarse" = csc.id`

            for (var name of groupNames) {
                name = name.toLowerCase()
                switch (name) {
                    case 'crypto':
                    {
                        mapFunctions.push(cryptoScoreMapFunction)
                        columns.push('score."friendlyName"')
                        if (!scoresJoined) {
                            joins.push(scoreClause)
                            wheres.push(`ds."cryptoPostureTemplate" = ${activeCpt}`)
                            scoresJoined = true
                        }
                        break
                    }
                    case 'cryptocoarse':
                    {
                        mapFunctions.push(cryptoScoreCoarseMapFunction)
                        columns.push('csc.id')
                        if (!scoresJoined) {
                            joins.push(scoreClause)
                            wheres.push(`ds."cryptoPostureTemplate" = ${activeCpt}`)
                            scoresJoined = true
                        }
                        break
                    }
                    case 'os':
                    {
                        mapFunctions.push(nameMapper)
                        getSoftwareMap = true
                        columns.push('os')
                        joins.push(`(select ds.device as "deviceSoftwareDevice", s.id as os from "DeviceSoftware" ds
                        , "SoftwareVersion" sv, "Software" s
                            where ds."softwareVersion" = sv.id and sv.software = s.id and s."softwareType" = ?) as oses on
                            "Device".id = oses."deviceSoftwareDevice"`
                        )
                        joinParams.push(softwareTypes.idByName['OS'])
                        softwareMapTypes.push(joinParams[joinParams.length - 1])
                        break
                    }
                    case 'application':
                    {
                        mapFunctions.push(nameMapper)
                        getSoftwareMap = true
                        columns.push('app')
                        joins.push(`(select ds.device as "deviceSoftwareDevice", s.id as app from
                            "DeviceSoftware" ds, "SoftwareVersion" sv, "Software" s
                            where  ds."softwareVersion" = sv.id and sv.software = s.id and s."softwareType" NOT IN (?,?)) as apps on
                            "Device".id = apps."deviceSoftwareDevice"`
                        )

                        let appTypes = [softwareTypes.idByName['OS'], softwareTypes.idByName['DATA']]
                        joinParams.push(...appTypes)
                        softwareMapTypes.push(...Object.values(softwareTypes.idByName).filter(x => !appTypes.includes(x)))
                        break
                    }
                    case 'devicetype':
                    {
                        mapFunctions.push(identityMapFunction)
                        columns.push('"DeviceType"."name"')
                        joins.push(`"DeviceType" ON "Device"."deviceType" = "DeviceType".id`)
                        break
                    }
                    default:
                        throw `Unknown/unsupported category "${name}".`
                }
            }

            let query = `SELECT ${columns[0]} as col1`
            if (columns.length > 1) {
                query += `, ${columns[1]} as col2`
            }
            query += `, COUNT(*) AS count FROM "Device"`
            if (joins.length > 0) {
                query += ` LEFT JOIN ${joins.join(' LEFT JOIN ')} `
            }
            if (wheres.length > 0) {
                query += ` WHERE ${wheres.join(' AND ')} `
            }
            query += groupByClause

            let result = await session.query(query, joinParams.concat(whereParams))
            if (getSoftwareMap) {
                let mappedValues = await session.query(`SELECT id,name FROM "Software" WHERE "softwareType" IN (${generatePlaceholders(softwareMapTypes)})`, softwareMapTypes)
                mappedValues.rows.map(x => softwareNames[x.id] = x.name)
            }

            results = buildDataFromRows(result.rows, groupNames, mapFunctions)
        })

        return results
    }
    catch (e) {
        log.e(e)
        throw e
    }
}

async function deviceVisualizations(fields /*, request, graphqlState*/) {
    return deviceVisualizationsCommon(fields, fields.period)
}

async function deviceVisualizationsHistory(fields /*, request, graphqlState*/) {
    return [await deviceVisualizationsCommon(fields),
        await deviceVisualizationsCommon(fields, { period: fields.period, offset: -1 }),
        await deviceVisualizationsCommon(fields, { period: fields.period, offset: -2 })]

}

function buildDataFromRows(rows, groupNames, mapFunctions) {
    let groupedData = {}
    for (var row of rows) {
        let currentLevel = addEntryToData(groupedData, groupNames[0], row.col1, mapFunctions[0])
        currentLevel.value += row.count

        if ('col2' in row) {
            currentLevel = addEntryToData(currentLevel.levels, groupNames[1], row.col2, mapFunctions[1])
            currentLevel.value += row.count
        }
    }

    // deconstruct the dictionaries for the final output.
    let finalData = Object.values(groupedData)
    for (var value of finalData) {
        value.levels = Object.values(value.levels)
    }

    return finalData
}

function addEntryToData(groupedData, group, name, mapFunction) {
    if (!(name in groupedData)) {
        groupedData[name] = {
            groupName: group,
            name: mapFunction(group, name),
            value: 0n,
            levels: {}
        }
    }

    return groupedData[name]
}

function validateGroups(groupNames, supportedGroups) {
    if (groupNames.length > 2) {
        throw 'Only one level of nested grouping is supported.'
    }

    if (groupNames.length > 1) {
        if (groupNames[0] === groupNames[1]) {
            throw 'Nested groupings must differ.'
        }
    }

    for (var group of groupNames) {
        if (supportedGroups.find(x => x.groupName === group) === undefined) {
            throw `Unsupported group '${group}'`
        }
    }
}

function validatePeriod(period) {
    if (period !== undefined) {
        let allowedPeriods = ['HOUR', 'DAY', 'WEEK', 'MONTH', 'YEAR']
        if (!allowedPeriods.includes(period.period)) {
            throw (`Unrecognized period '${period.period}`)
        }
    }
}


async function softwareVisualizationsCommon(fields, period) {
    validatePeriod(period)
    validateGroups(fields.groupNames, supportedSoftwareGroups)
    let session = new Session()
    const epoch = fields.asOf ? new Date(fields.asOf) : undefined
    try {
        let results
        await session.reuseConnection(async () => {

            let wheres = []
            let joinParams = []
            let whereParams = []

            if (period !== undefined || epoch !== undefined) {
                await session.configureHistory(period, epoch)
            }

            if (fields.filter && fields.filter.length > 0) {
                let connectionIDQuery = await expressionToQueryAndParams('Connection', fields.filter)
                whereParams.push(...connectionIDQuery.params)
                wheres.push(`"Connection".id IN (${connectionIDQuery.query})`)
            }

            let joins = []
            let groupByClause = ' GROUP BY 1'

            let groupNames = fields.groupNames
            if (groupNames.length > 1) {
                groupByClause += ',2'
            }

            let softwareNames = {}

            let columns = []
            let mapFunctions = []

            let getSoftwareMap = false
            let softwareMapTypes = []

            for (var name of groupNames) {
                name = name.toLowerCase()
                switch (name) {
                    case 'cryptocoarse':
                    {
                        mapFunctions.push(cryptoScoreCoarseMapFunction)
                        columns.push('csc.id')
                        joins.push(`"DeviceSoftware" ON "SoftwareVersion"."id"  = "DeviceSoftware"."softwareVersion"
                                Join "DeviceSoftwareConnection" on "DeviceSoftware"."id" = "DeviceSoftwareConnection"."deviceSoftware"
                                LEFT JOIN "Connection" on  "DeviceSoftwareConnection"."connection" = "Connection"."id"
                                Join "CryptoScore" ON "Connection"."cryptoScore" = "CryptoScore"."id"
                                JOIN "CryptoScoreCoarse" csc ON "CryptoScore"."cryptoScoreCoarse" = csc."id"`)
                        break
                    }
                    default:
                        throw `Unknown/unsupported category "${name}".`
                }
            }

            let query = `SELECT ${columns[0]} as col1`
            if (columns.length > 1) {
                query += `, ${columns[1]} as col2`
            }
            query += `, COUNT(*) AS count FROM "SoftwareVersion"`
            if (joins.length > 0) {
                query += ` LEFT JOIN ${joins.join(' LEFT JOIN ')} `
            }
            if (wheres.length > 0) {
                query += ` WHERE ${wheres.join(' AND ')} `
            }
            query += groupByClause

            let result = await session.query(query, joinParams.concat(whereParams))
            if (getSoftwareMap) {
                let mappedValues = await session.query(`SELECT id,name FROM "Software" WHERE "softwareType" IN (${generatePlaceholders(softwareMapTypes)})`, softwareMapTypes)
                mappedValues.rows.map(x => softwareNames[x.id] = x.name)
            }

            results = buildDataFromRows(result.rows, groupNames, mapFunctions)
        })

        return results
    }
    catch (e) {
        log.e(e)
        throw e
    }
}

async function connectionVisualizationsCommon(fields, period) {
    validatePeriod(period)
    validateGroups(fields.groupNames, supportedConnectionGroups)
    let session = new Session()
    const epoch = fields.asOf ? new Date(fields.asOf) : undefined
    try {
        let results
        await session.reuseConnection(async () => {

            let wheres = []
            let joinParams = []
            let whereParams = []

            if (period !== undefined || epoch !== undefined) {
                await session.configureHistory(period, epoch)
            }

            if (fields.filter && fields.filter.length > 0) {
                let connectionIDQuery = await expressionToQueryAndParams('Connection', fields.filter)
                whereParams.push(...connectionIDQuery.params)
                wheres.push(`"Connection".id IN (${connectionIDQuery.query})`)
            }

            let groupNames = fields.groupNames

            let joins = []
            let groupByClause = ' GROUP BY 1'
            if (groupNames.length > 1) {
                groupByClause += ',2'
            }

            let columns = []
            let mapFunctions = []

            let softwareNames = {}

            let nameMapper = softwareNameMapper.bind(null, softwareNames)
            let getSoftwareMap = false
            let softwareMapTypes = []

            let softwareTypes = schemaDiscovery.allTypes['SoftwareType']._enum


            let activeCpt = await getCptForRequest(fields.cryptoPostureTemplate)
            let scoresJoined = false
            let scoreClause = `"ConnectionScore" cs on cs."connection" = "Connection".id
                JOIN "CryptoScore" score ON score.id = cs."cryptoScore"
                JOIN "CryptoScoreCoarse" csc ON score."cryptoScoreCoarse" = csc.id`

            for (var name of groupNames) {
                name = name.toLowerCase()
                switch (name) {
                    case 'crypto':
                    {
                        mapFunctions.push(cryptoScoreMapFunction)
                        columns.push('score."friendlyName"')
                        if (!scoresJoined) {
                            joins.push(scoreClause)
                            wheres.push(`cs."cryptoPostureTemplate" = ${activeCpt}`)
                            scoresJoined = true
                        }
                        break
                    }
                    case 'cryptocoarse':
                    {
                        mapFunctions.push(cryptoScoreCoarseMapFunction)
                        columns.push('csc.id')
                        if (!scoresJoined) {
                            joins.push(scoreClause)
                            wheres.push(`cs."cryptoPostureTemplate" = ${activeCpt}`)
                            scoresJoined = true
                        }
                        break
                    }
                    case 'clientos':
                    case 'serveros':
                    {
                        let connectionPath = name === 'clientos' ? 'clientDeviceAddressPort' : 'serverDeviceAddressPort'
                        mapFunctions.push(nameMapper)
                        getSoftwareMap = true
                        columns.push('os')
                        joins.push(`
                                (
                                    select
                                        dap.id as "deviceAddressPort",
                                        soft.os as os
                                    from
                                        "DeviceAddressPort" dap
                                        join "DeviceAddress" da on dap."deviceAddress" = da.id
                                        join "Device" d on da.device = d.id
                                        left join (
                                            select
                                                s.id as os,
                                                ds.device as device
                                            from
                                                "Software" s
                                                join "SoftwareVersion" sv on s.id = sv.software
                                                join "DeviceSoftware" ds on sv.id = ds."softwareVersion"
                                            where
                                                s."softwareType" = ?
                                        ) soft on d.id = soft.device
                                ) as oses on "Connection"."${connectionPath}" = oses."deviceAddressPort"
                                `)

                        joinParams.push(softwareTypes.idByName['OS'])
                        softwareMapTypes.push(joinParams[joinParams.length - 1])
                        break
                    }
                    case 'application':
                    {
                        mapFunctions.push(nameMapper)
                        getSoftwareMap = true
                        columns.push('app')
                        joins.push(`(select dsc.connection as "deviceSoftwareConnection", ds.device as "deviceSoftwareDevice",
                            s.id as app from "DeviceSoftwareConnection" dsc, "DeviceSoftware" ds,
                            "SoftwareVersion" sv, "Software" s where dsc."deviceSoftware" = ds.id and
                            ds."softwareVersion" = sv.id and sv.software = s.id and s."softwareType" NOT IN (?,?)) as apps on
                            "Connection".id = apps."deviceSoftwareConnection"`
                        )

                        let appTypes = [softwareTypes.idByName['OS'], softwareTypes.idByName['DATA']]
                        joinParams.push(...appTypes)
                        softwareMapTypes.push(...Object.values(softwareTypes.idByName).filter(x => !appTypes.includes(x)))
                        break
                    }
                    default:
                        throw `Unknown/unsupported category '${name}'.`
                }
            }

            let query = `SELECT ${columns[0]} as col1`
            if (columns.length > 1) {
                query += `, ${columns[1]} as col2`
            }
            query += `, COUNT(*) AS count FROM "Connection"`
            if (joins.length > 0) {
                query += ` LEFT JOIN ${joins.join(' LEFT JOIN ')} `
            }
            if (wheres.length > 0) {
                query += ` WHERE ${wheres.join(' AND ')} `
            }
            query += groupByClause

            let result = await session.query(query, joinParams.concat(whereParams))
            if (getSoftwareMap) {
                let mappedValues = await session.query(`SELECT id,name FROM "Software" WHERE "softwareType" IN (${generatePlaceholders(softwareMapTypes)})`, softwareMapTypes)
                mappedValues.rows.map(x => softwareNames[x.id] = x.name)
            }

            results = buildDataFromRows(result.rows, groupNames, mapFunctions)
        })
        return results
    } catch (e) {
        log.e(e)
        throw e
    }
}

async function softwareVisualizations(fields /*, request, graphqlState*/) {
    return softwareVisualizationsCommon(fields, fields.period)
}

async function connectionVisualizations(fields /*, request, graphqlState*/) {
    return connectionVisualizationsCommon(fields, fields.period)
}

async function connectionVisualizationsHistory(fields /*, request, graphqlState*/) {
    return [await connectionVisualizationsCommon(fields),
        await connectionVisualizationsCommon(fields, { period: fields.period, offset: -1 }),
        await connectionVisualizationsCommon(fields, { period: fields.period, offset: -2 })]
}

async function getSupportedVisualizationGroups(fields /*, request, graphqlState*/) {
    switch (fields.type) {
        case 'CONNECTION':
        {
            return supportedConnectionGroups
        }
        case 'DEVICE':
        {
            return supportedDeviceGroups
        }
        default:
        {
            throw `Unsupported group type '${fields.type}'.`
        }
    }
}

/**
 * Dictionary for enum name to table name.
 */
const countVisualizationNameMapping = {
    'DEVICE': 'Device',
    'CONNECTION': 'Connection',
    'SOFTWARE': 'Software'
}

/**
 * This visualisation query is a filtered count of things.
 * @param {Object} fields GraphQL parameters.
 * @param {string} [fields.filter] Optional filter to apply.
 * @param {string[]} fields.types Types of counts to return. (eg: [DEVICE, CONNECTION])
 * @param {string} [fields.period] The period of samples to return. (eg: MONTH). No period will report on now or `asOf` only.
 * @param {string} [fields.asOf] When the data should be reported on. If not provided the counts will be as of now.
 * @param {object} request The GraphQL request
 * @param {object} graphQLState GraphQL state
 */
async function countVisualization(fields /*, request, graphQLState */) {
    const filter = fields.filter
    const types = new Set(fields.types)
    const periodGiven = fields.period
    const periodToUse = periodGiven ? periodGiven : 'DAY'

    const asOf = fields.asOf

    const result = []

    if (types.size === 0) {
        return []
    }

    const session = new Session()

    const epoch = asOf ? new Date(asOf) : new Date()

    await session.reuseConnection(async () => {
        const typeArrays = {}

        for (let offset = 0; (periodGiven && offset < 3) || offset < 1; ++offset) {
            const dateUsed = await session.configureHistory({ period: periodToUse, offset: -offset }, epoch)

            for (const type of types) {
                if (!(type in typeArrays)) {
                    typeArrays[type] = { type, value: [] }
                    result.push(typeArrays[type])
                }
                const typeTable = countVisualizationNameMapping[type]
                let query = `select count(id) from "${typeTable}" `
                let params = []
                if (filter && filter.length != 0) {
                    var whereAndParams = await expressionToQueryAndParams(typeTable, filter)
                    query += ` where "${typeTable}".id in ${whereAndParams.query} `
                    params = whereAndParams.params
                }
                const queryResult = await session.query(query, params)
                const count = queryResult.rows[0].count
                typeArrays[type].value.push({ when: dateUsed, count })
            }
        }

    })

    return result
}

/* This visualisation query is a filtered count of things, with grouping.
 * @param {Object} fields GraphQL parameters.
 * @param {string} [fields.filter] Optional filter to apply.
 * @param {string} fields.group Type of group counts to return. (eg: CRYPTO_PRIMITIVE_FAMILY)
 * @param {string} fields.subgroup The secondary grouping (eg: AES, ECDH)
 * @param {string} [fields.period] The period of samples to return. (eg: MONTH). No period will report on now or `asOf` only.
 * @param {string} [fields.asOf] When the data should be reported on. If not provided the counts will be as of now.
 * @param {object} request The GraphQL request
 * @param {object} graphQLState GraphQL state
 */
async function groupedCountVisualization(fields /*, request, graphQLState*/) {
    const filter = fields.filter
    const periodGiven = fields.period
    const periodToUse = periodGiven ? periodGiven : 'DAY'
    // const group = 'CryptoFamily'
    const subgroup = fields.subgroup

    const asOf = fields.asOf

    const result = []

    const session = new Session()

    const epoch = asOf ? new Date(asOf) : new Date()

    const mappedSubgroup = schemaDiscovery.allTypes['CryptoAlgorithm']._enum.idByName[subgroup]

    await session.reuseConnection(async () => {
        for (let offset = 0; (periodGiven && offset < 3) || offset < 1; ++offset) {
            let dateUsed = epoch

            if (asOf || offset != 0) {
                dateUsed = await session.configureHistory({ period: periodToUse, offset: -offset }, epoch)
            }

            let query = `
                select
                    primitive,
                    name,
                    count(connection) as count
                from (
                    select
                        c.id as connection,
                        cp.id as primitive,
                        cp."friendlyName" as name
                    from "Connection" c
                        inner join "ConnectionCertificate" cc on cc."connection" = c.id
                        inner join "Certificate" cert on cert.id = cc.certificate
                        inner join "CertificateCryptoPrimitive" ccp on ccp.certificate = cert.id
                        inner join "CryptoPrimitive" cp on cp.id = ccp."cryptoPrimitive"
                    where cp."cryptoAlgorithm" = ?

                    union

                    select
                        c.id as connection,
                        cp.id as primitive,
                        cp."friendlyName" as name
                    from "Connection" c
                        inner join "ConnectionCipherSuite" ccs on ccs."connection" = c.id
                        inner join "CipherSuiteCryptoPrimitive" csp on csp."cipherSuite" = ccs."cipherSuite"
                        inner join "CryptoPrimitive" cp on cp.id = csp."cryptoPrimitive"
                    where cp."cryptoAlgorithm" = ?

                    union

                    select
                        c.id as connection,
                        cp.id as primitive,
                        cp."friendlyName" as name
                    from "Connection" c
                        inner join "ConnectionCryptoPrimitive" ccp on ccp."connection" = c.id
                        inner join "CryptoPrimitive" cp on cp.id = ccp."cryptoPrimitive"
                    where cp."cryptoAlgorithm" = ?
                ) as allConnections`

            let params = [mappedSubgroup, mappedSubgroup, mappedSubgroup]
            if (filter && filter.length != 0) {
                var whereAndParams = await expressionToQueryAndParams('Connection', filter)
                query += ` where connection in ${whereAndParams.query} `
                params.push(...whereAndParams.params)
            }
            query += ` group by allConnections."primitive", allConnections."name"`

            const queryResult = await session.query(query, params)

            if (!result.length) {
                result.push({ when: dateUsed, groups: queryResult.rows })
            } else {
                const orderedGroups = result[0].groups
                const resultGroup = queryResult.rows

                const resultToPush = []
                if (resultGroup.length) {
                    for (let group of orderedGroups) {
                        const groupIndex = resultGroup.findIndex(val => val.name === group.name)

                        if (groupIndex > -1) {
                            const slicedGroup = resultGroup.splice(groupIndex, 1)
                            resultToPush.push(...slicedGroup)
                        } else {
                            resultToPush.push({
                                ...group,
                                count: 0
                            })
                        }

                    }
                }

                result.push({ when: dateUsed, groups: [...resultToPush, ...resultGroup] })

            }
        }
    })

    return result
}


/**
 * Visualisation query for cryptoscores.
 * @param {Object} fields GraphQL parameters.
 * @param {string} [fields.filter] Optional filter to apply.
 * @param {string} fields.type Type of count to return (eg: DEVICE).
 * @param {string} [fields.period] The period of samples to return. (eg: MONTH). No period will report on now or `asOf` only.
 * @param {string} [fields.asOf] When the data should be reported on. If not provided the counts will be as of now.
 * @param {object} request The GraphQL request.
 * @param {object} graphQLState GraphQL state.
 */
async function cryptoScoreVisualization(fields /*, request, graphQLState */) {
    const filter = fields.filter
    const type = fields.type

    const periodGiven = fields.period

    const results = []

    if (!type.length) {
        return []
    }

    const session = new Session()

    let cpt = await getCptForRequest(fields.cryptoPostureTemplate)

    await session.reuseConnection(async () => {
        for (let offset = 0; (periodGiven && offset < 3) || offset < 1; ++offset) {
            const typeTable = countVisualizationNameMapping[type]
            let query = `SELECT "${typeTable}Score"."cryptoScore", "CryptoScore"."score", count(*) FROM "${typeTable}"
            JOIN "${typeTable}Score" on "${typeTable}Score"."${typeTable.toLowerCase()}" = "${typeTable}".id
            JOIN "CryptoScore" on "CryptoScore".id = "${typeTable}Score"."cryptoScore"`
            let params = []
            if (filter && filter.length != 0) {
                var whereAndParams = await expressionToQueryAndParams(typeTable, filter)
                query += ` where "${typeTable}".id in ${whereAndParams.query} `
                params = whereAndParams.params
            }

            query += ` ${filter && filter.length != 0 ? 'and' : 'where'} "${typeTable}Score"."cryptoPostureTemplate" = ${cpt}`

            query += ` group by 1, 2`
            const queryResult = await session.query(query, params)

            if (queryResult.rows.length) {
                for (const result of queryResult.rows) {
                    const { count, cryptoScore, score } = result
                    results.push({ cryptoScore, count, score })
                }
            }
        }

    })

    return results
}

exports.graphQL = {
    types: `
        enum VisualizationPeriod {
            HOUR
            DAY
            WEEK
            MONTH
            YEAR
        }

        enum VisualizationType {
            CONNECTION
            DEVICE
            SOFTWARE
        }

        enum VisualizationCountGroup {
            PROTOCOL_TYPE
            PROTOCOL_VARIANT
            CRYPTO_PRIMITIVE_FAMILY
            OPERATING_SYSTEM
        }

        input VisualizationPeriodOffset {
            period: VisualizationPeriod!
            offset: Int!
        }

        type VisualizationCountDetail {
            when: DateTime!
            count: BigInt!
        }


        type VisualizationGroupCountDetail {
            name: String!
            count: BigInt!
        }

        type VisualizationCount {
            type: VisualizationType!
            value: [VisualizationCountDetail!]!
        }

        type VisualizationGroupCount {
            when: DateTime!
            groups: [VisualizationGroupCountDetail!]!
        }

        type VisualizationGroup {
            groupName: String! # short name to use for input to the queries
            name: String! # User-friendly name of the group for e.g. populating a drop-down.
        }

        type VisualizationLevel {
            groupName: String!
            name: String! # To show in the UI, for example 'Acceptable' or 'Broken'
            value: BigInt! # The number of devices / connections for a given 'name'
            levels: [VisualizationLevel] # Recursive visualizations that would appear as a subgroup
        }

        type CryptoScoreVisualizationCount {
            cryptoScore: BigInt!
            score: BigInt!
            count: BigInt!
        }`,
    queries: `
        connectionVisualizations(filter: String, groupNames: [String!]!, period: VisualizationPeriodOffset, asOf: DateTime, cryptoPostureTemplate: BigInt): [VisualizationLevel!]!
        connectionVisualizationsHistory(filter: String, groupNames: [String!]!, period: VisualizationPeriod!, asOf: DateTime, cryptoPostureTemplate: BigInt): [[VisualizationLevel!]!]!
        deviceVisualizations(filter: String, groupNames: [String!]!, period: VisualizationPeriodOffset, asOf: DateTime, cryptoPostureTemplate: BigInt): [VisualizationLevel!]!
        deviceVisualizationsHistory(filter: String, groupNames: [String!]!, period: VisualizationPeriod!, asOf: DateTime, cryptoPostureTemplate: BigInt): [[VisualizationLevel!]!]!
        softwareVisualizations(filter: String, groupNames: [String!]!, period: VisualizationPeriodOffset, asOf: DateTime, cryptoPostureTemplate: BigInt): [VisualizationLevel!]!
        getSupportedVisualizationGroups(type: VisualizationType!) : [VisualizationGroup!]!

        # Gives data for the count style static and temporal widgets.
        countVisualization(filter: String, types: [VisualizationType!], period: VisualizationPeriod, asOf: DateTime, cryptoPostureTemplate: BigInt) : [VisualizationCount!]!
        groupedCountVisualization(filter: String, group: VisualizationCountGroup!, subgroup: CryptoAlgorithm!, period: VisualizationPeriod, asOf: DateTime, cryptoPostureTemplate: BigInt) : [VisualizationGroupCount!]!

        # Gives data for the connection and device rating widget.
        cryptoScoreVisualization(filter: String, type: VisualizationType!, period: VisualizationPeriod, asOf: DateTime, cryptoPostureTemplate: BigInt): [CryptoScoreVisualizationCount!]!
    `,
    mutations: `
            `,
    root: {
        connectionVisualizations,
        connectionVisualizationsHistory,
        deviceVisualizations,
        deviceVisualizationsHistory,
        softwareVisualizations,
        getSupportedVisualizationGroups,
        countVisualization,
        groupedCountVisualization,
        cryptoScoreVisualization
    },
    restrictions: {
        connectionVisualizations: roles.AUTHENTICATED,
        connectionVisualizationsHistory: roles.AUTHENTICATED,
        deviceVisualizations: roles.AUTHENTICATED,
        deviceVisualizationsHistory: roles.AUTHENTICATED,
        softwareVisualizations: roles.AUTHENTICATED,
        getSupportedVisualizationGroups: roles.AUTHENTICATED,
        countVisualization: roles.AUTHENTICATED,
        cryptoScoreVisualization: roles.AUTHENTICATED,
        groupedCountVisualization: roles.AUTHENTICATED
    }
}
