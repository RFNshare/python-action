/**
 * @file systemStatus.js - 1.2.0 - 3826bc12533e078a8e37cfe70ee04d9e85c8530e
 * 
 * @copyright Copyright (C) 2016-2023, ISARA Corporation, All Rights Reserved.
 * 
 * @license The code and other content set out herein is not in the public
 * domain, is considered a trade secret and is confidential to ISARA
 * Corporation. Use, reproduction or distribution, in whole or in part, of such
 * code or other content is strictly prohibited except by express written
 * permission of ISARA Corporation. Please contact ISARA Corporation at
 * info@isara.com for more information.
 */

/**
 * This module defines the Certificate Management Endpoint.
 * @module express/systemStatus
 */

const { roles } = require('../graphql/commonQL')
const log = require('../util/log')(module)

const webSocketClients = {}
let index = 0

async function addWebSocket(ws) {
    const myIndex = ++index
    log.log('New systemStatus web socket client', myIndex)
    webSocketClients[myIndex] = ws

    ws.on('message', message => {
        // incoming messages are currently ignored
        log.d('Ignoring incoming message', myIndex, message)
    })

    ws.on('close', () => {
        log.d('Web socket client closed', myIndex)
        delete webSocketClients[myIndex]
    })

    ws.on('error', error => {
        log.e('Web socket client error', myIndex, error)
        delete webSocketClients[myIndex]
    })
}

exports.endpoint = {
    path: '/service/systemStatus',
    ws: {
        handler: async function (ws) {
            try {
                await addWebSocket(ws)
            } catch (e) {
                log.e(e)
            }
        },
        restrictions: [roles.NONE]
    },
}

exports.bypassWrappers = true

exports.broadcastStatus = function (name, params) {
    if (typeof name !== 'string') {
        throw new Error('Type of name must be string')
    }
    let toSend = { name }
    if (params) {
        toSend.params = params
    }
    toSend.timestamp = Date.now()
    const toSendJSON = JSON.stringify(toSend)

    const toSendTo = Object.entries(webSocketClients)

    let count = 0

    for (let keyAndValue of toSendTo) {
        const ws = keyAndValue[1]
        if (ws && ws.send) {
            try {
                ws.send(toSendJSON)
                count++
            } catch (e) {
                log.e('Error attempting to send to web socket client', keyAndValue[0], e)
            }
        }
    }

    log.d('Broadcast status message to', count, 'clients')
}

/**
 * Broadcast a server alive message every few minutes.
 */
setInterval(() => {
    exports.broadcastStatus('com.isara.advance.backend.ws.alive')
}, 1.5 * 60 * 1000)
