/**
 * @file userAuthenticationQL.js - 1.2.0 - 3826bc12533e078a8e37cfe70ee04d9e85c8530e
 * 
 * @copyright Copyright (C) 2016-2023, ISARA Corporation, All Rights Reserved.
 * 
 * @license The code and other content set out herein is not in the public
 * domain, is considered a trade secret and is confidential to ISARA
 * Corporation. Use, reproduction or distribution, in whole or in part, of such
 * code or other content is strictly prohibited except by express written
 * permission of ISARA Corporation. Please contact ISARA Corporation at
 * info@isara.com for more information.
 */

/**
 * This module contains queries to implement user authentication.
 * @module graphql/userAuthenticationQL
 */

var {
    buildWanted, fetchWanted
} = require('../isaraql/fetch')

const {
    hashPassword, randomSleep, verifyPassword
} = require('../util/passwordUtils')


var {
    userPreference, setUserPreference
} = require('./userPreferencesQL').graphQL.root

var {
    roles
} = require('./commonQL')

var {
    parseIntStrict
} = require('../util/conversion')

const systemPreferences = require('../util/systemPreferences')
const crypto = require('crypto')
const LazySingleton = require('../util/lazySingleton')

var log = require('../util/log')(module)

const jwt = require('jsonwebtoken')

var { graphQLStateToWanted } = require('../isaraql/wantedUtil')

const TOKEN_SECRET = crypto.randomBytes(512)
const TOKEN_SIGNATURE_ALGORITHM = 'HS384'
const DEFAULT_TOKEN_EXPIRATION_TIME = 300

async function getDefaultTokenExpirationTime() {
    let expirationTime = DEFAULT_TOKEN_EXPIRATION_TIME

    const preferences = await systemPreferences()
    if ('tokenExpirationTime' in preferences) {
        expirationTime = preferences.tokenExpirationTime
    }

    return expirationTime
}

const defaultHash = new LazySingleton(async () => {
    // generate a random busy hash for the case where no record exists
    // in the DB. This ensures that the password hash check will fail
    // if no user is found, since the chances of a random input password
    // matching this are statistically close enough to 0.
    let pwHash = crypto.randomBytes(64).toString('hex')
    return hashPassword(pwHash)
})

async function getTokenExpirationTime(uid) {
    let request = {
        user: {
            uid: uid
        }
    }

    let fields = {
        keyName: Object.keys(exports.preferenceKeys)[0]
    }

    let response = await userPreference(fields, request)
    if (!response) {
        throw 'Failed to get session expiration time.'
    }

    return response
}

/**
 * Generates a signed JWT authorization token for a given payload.
 * @param {object} payLoad An object containing the set of fields that should be included in the resulting JWT. Note that this will
 * be augmented with several reserved fields by the signing and creation process, most notably "nbf" and "exp"
 * [(RFC7519, Section 4.1)](https://tools.ietf.org/html/rfc7519#section-4.1). Tokens are generated with a config-defined expiration
 * time, defaulting to 5 minutes if not overridden.
 * @param {bool} useDefaultTime If specified, indicates that the default session timeout should be used rather than attempting
 * to look up the user preference.
 *
 * @returns {string} A base64-encoded JWT string that comprises the JSON content and appended hash signature of the token.
 */
async function getTokenForPayload(payLoad, useDefaultTime) {
    let tokenExpirationTime = await getDefaultTokenExpirationTime()
    if (!useDefaultTime) {
        tokenExpirationTime = await getTokenExpirationTime(payLoad.uid)
    }

    return jwt.sign(payLoad, TOKEN_SECRET, {
        algorithm: TOKEN_SIGNATURE_ALGORITHM,
        expiresIn: tokenExpirationTime
    })
}

/**
 * Generates a signed JWT authorization token for the specified user.
 * @param {object} userInfo The target user object for whom a token is required. The associated user's roles are retrieved from the
 * database for use in the finalized token.
 *
 * @returns {string} A base64-encoded JWT string representing a session token. This will contain several user-related fields (ID,
 * username, full name, roles list), as well as JWT reserved fields needed for correct token functionality.
 */
async function generateToken(userInfo) {

    var wpcs = [
        {
            UserRole: {
                where: {
                    and: [
                        {
                            equals:
                            {
                                column: 'user', value: userInfo.id
                            }
                        }]
                }
            },
        }
    ]

    var tableName = 'UserRole'
    var wanted = await buildWanted(tableName, {
        role: {
            name: true
        }
    })

    var roles = await fetchWanted(tableName, wanted, wpcs)
    roles = roles.map(function getName(role) { return role.role.name })

    var payLoad = {
        uid: userInfo.id,
        userName: userInfo.userName,
        fullName: userInfo.humanName,
        cryptoPostureTemplate: userInfo.cryptoPostureTemplate,
        roles: roles
    }

    return getTokenForPayload(payLoad)
}

/**
 * Request handler for the refreshToken mutation. Given a (valid) input token, generate an identical token with an updated
 * expiration time.
 *
 * @param {object} fields The GraphQL fields structure containing the token needing to be refreshed. This is expected in the same
 * raw format in which it was originally returned to the user.
 * @param {object} request Unused.
 * @param {object} response Unused.
 *
 * @returns {object} An updated token with new not-before and expiration claims.
 *
 * @throws {string} An exception is thrown if the passed-in token is invalid (signature mismatch, expired, or otherwise
 * non-compliant).
 */
async function refreshTokenMutation(fields, request, response) {
    if (!('token' in fields)) {
        throw 'Missing required parameter.'
    }

    var verified = jwt.verify(fields.token, TOKEN_SECRET)

    // removed the issued at/expired claims since these need to be rewritten.
    delete verified.exp
    delete verified.iat

    let wpcs = {
        User: { where: { equals: { column: 'id', value: request.user.uid } } }
    }
    let wanted = graphQLStateToWanted(response)

    if (!wanted.refreshToken.user) {
        wanted.refreshToken.user = {}
    }
    Object.assign(wanted.refreshToken.user, { passwordHash: false, hidden: true, lockedOut: true })


    let user = (await fetchWanted('User', wanted.refreshToken.user, wpcs))[0]

    if (user.lockedOut || user.hidden) {
        throw 'User account locked'
    }

    // ensure that there is no way the passwordHash can accidentally be
    // leaked back to the caller
    delete user.passwordHash

    // Update user info
    const updated = {
        ...verified,
        userName: user.userName,
        fullName: user.humanName,
        roles: user.userRoles.map(function getName({ role }) { return role }),
        cryptoPostureTemplate: user.cryptoPostureTemplate
    }

    return { token: getTokenForPayload(updated), user }
}

/**
 * Request handler for the login mutation. Validates that the user and password are correct, and that the account in question is
 * not deleted or locked out if so. Assuming all checks pass, a session token is issued.
 *
 * @param {object} fields The GraphQL fields structure containing the username and password to validate.
 * @param {object} request Unused.
 * @param {object} graphQLState The GraphQL graphQLState structure dictating the desired field selections for the resulting Authentication.
 *
 * @returns {object} An Authentication structure containing the token, as well as any requested user fields.
 *
 * @throws {string} An exception is thrown if an error occurs while querying the database, or if the user fails to validate in some
 * way (invalid user/pass combination, deleted or locked out user).
 */
async function loginMutation(fields, request, graphQLState) {
    var and = []

    if ('userName' in fields) {
        and.push({ equals: { column: 'userName', value: fields.userName } })
    }

    var tableName = 'User'

    var wpcs = {
        User: { where: { and } }
    }

    try {
        let pwHash = await defaultHash.get()

        var wanted = graphQLStateToWanted(graphQLState)

        if (!wanted.login.user) {
            wanted.login.user = {}
        }

        // In order to avoid having to query for the user twice,
        // we hijack the passed in selection set to inject the fields
        // we need to verify authenticity (hidden, locked out, password).
        // if these weren't part of the input selection set, we erase them
        // before returning the requested data.
        Object.assign(wanted.login.user, {
            userName: true, humanName: true, hidden: true, lockedOut: true, passwordHash: true,
            cryptoPostureTemplate: {
                id: true
            }
        })

        let records = await fetchWanted(tableName, wanted.login.user, wpcs)

        if (records.length > 0) {
            pwHash = records[0].passwordHash
        }

        // NB: we always attempt to verify a password hash in order to stay approximately constant time.
        let passVerified = await verifyPassword(fields.password, pwHash)
        if (!passVerified) {
            throw 'Bad username or password'
        }

        var user = records[0]
        if (user.hidden) {
            throw 'Bad username or password'
        }
        if (user.lockedOut) {
            throw 'User suspended'
        }

        // ensure that there is no way the passwordHash can accidentally be
        // leaked back to the caller
        delete user.passwordHash
        return {
            user,
            token: generateToken(user)
        }
    } catch (e) {
        await randomSleep()
        log.d('Error in login', e)
        throw e
    }
}

/**
 * Resolver function to query for user session timeout. Implicitly queries the currently signed in user.
 *
 * @param {object} fields Unused.
 * @param {object} request HTTP request headers object.
 * @param {int} request.user.uid The unique ID of the user of interest. Populated implicitly by token.
 * @param {object} response unused.
 *
 * @returns {int} The appropriate user session timeout. This will be the system default if no explicit user preference has been
 * set yet.
 * @throws An exception is thrown if an error occurs while querying.
 */
async function userSessionTimeoutQuery(fields, request) {
    return getTokenExpirationTime(request.user.uid)
}

/**
 * Resolver function to handle modifying a user's session timeout.
 *
 * @param {*} fields The GraphQL fields structure specifying the new session timeout.
 * @param {*} request HTTP request headers object.
 * @param {*} response The GraphQL response structure. Unused.
 * @returns {int} The updated user session timeout.
 * @throws An exception is thrown if an error occurs while updating.
 */
async function setUserSessionTimeoutMutation(fields, request) {
    if (!('timeout' in fields)) {
        throw 'Timeout required.'
    }

    return await setUserPreference(
        {
            keyName: Object.keys(exports.preferenceKeys)[0],
            value: fields.timeout
        },
        request
    )
}


exports.tokenParameters = {
    secret: TOKEN_SECRET,
    algorithm: TOKEN_SIGNATURE_ALGORITHM
}

exports.preferenceKeys = {
    _UserSessionTimeout: {
        description: "The user's session token timeout. If not explicitly set, the default is taken from the config file.",
        default: async function () {
            return getDefaultTokenExpirationTime()
        },
        validator: function (value) {
            let tempValue = value
            if (!Number.isInteger(tempValue)) {
                tempValue = parseIntStrict(tempValue, 0)
            }

            return {
                value: tempValue,
                valid: tempValue > 0
            }
        }
    }
}

// for internal use only
exports.getTokenForPayload = getTokenForPayload

exports.graphQL = {
    types: `
        type Authentication {
            "JWT token generated by successful authentication."
            token: String!
            "Any additional requested user metadata."
            user: User!
        }
    `,
    queries: `
        "Returns the logged in user's current session timeout in seconds."
        userSessionTimeout : Int!
    `,
    mutations: `
        "Attempts to authenticate with the given username and password."
        login(userName: String!, password: String!) : Authentication!

        "Requests a new token with an updated expiration time, based on an existing (non-expired) token."
        refreshToken(token: String!) : Authentication!

        "Updates the logged in user's session timeout. Input is given in seconds. This does not retroactively update the timeout on the user's current token."
        setUserSessionTimeout(timeout: Int!) : Int!
    `,
    root: {
        userSessionTimeout: userSessionTimeoutQuery,
        login: loginMutation,
        refreshToken: refreshTokenMutation,
        setUserSessionTimeout: setUserSessionTimeoutMutation
    },
    restrictions: {
        userSessionTimeout: [roles.AUTHENTICATED],
        login: [roles.UNAUTHENTICATED],
        refreshToken: [roles.AUTHENTICATED],
        setUserSessionTimeout: [roles.AUTHENTICATED]
    }
}
