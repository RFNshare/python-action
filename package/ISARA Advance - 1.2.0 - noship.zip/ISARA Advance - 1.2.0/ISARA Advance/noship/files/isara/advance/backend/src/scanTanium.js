/**
 * @file scanTanium.js - 1.2.0 - 3826bc12533e078a8e37cfe70ee04d9e85c8530e
 * 
 * @copyright Copyright (C) 2016-2023, ISARA Corporation, All Rights Reserved.
 * 
 * @license The code and other content set out herein is not in the public
 * domain, is considered a trade secret and is confidential to ISARA
 * Corporation. Use, reproduction or distribution, in whole or in part, of such
 * code or other content is strictly prohibited except by express written
 * permission of ISARA Corporation. Please contact ISARA Corporation at
 * info@isara.com for more information.
 */

/**
 * @module advance
 */

const { scan } = require('./ingestion/tanium/scanner')

async function main() {

    const dataSourceScan = {
        configuration: '{ "computer_group": "All Computers" }',
        dataSource: {
            softwareVersion: {
                name: 'Tanium'
            },
            configuration: '{ "url": "https://isara-api.cloud.tanium.com", "token": "token-0bc8513a4946e32e20c5754c493509b4e8e747870604a13f3d02d6d22e" }'
        }
    }
    
    scan(
        dataSourceScan,
        null, // scanResults
        async (status) => {
            console.log(`onFulfilled ${status}`)
        },
        async (e) => {
            console.log(`onRejected ${e.message}`)
        },
        async () => {
            console.log('onFinally')
        }
    )
}

main()
