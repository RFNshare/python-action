/**
 * @file filterCategoryHelpers.js - 1.2.0 - 3826bc12533e078a8e37cfe70ee04d9e85c8530e
 * 
 * @copyright Copyright (C) 2016-2023, ISARA Corporation, All Rights Reserved.
 * 
 * @license The code and other content set out herein is not in the public
 * domain, is considered a trade secret and is confidential to ISARA
 * Corporation. Use, reproduction or distribution, in whole or in part, of such
 * code or other content is strictly prohibited except by express written
 * permission of ISARA Corporation. Please contact ISARA Corporation at
 * info@isara.com for more information.
 */


const {
    filterCategoryTypes,
    filterCategoryNames,
    postureCategories
} = require('../graphql/categoryConstants')


const { cloneDeep } = require('lodash')

const {
    facets
} = require('../filterql/facets')

const filterCache = {}

const { allTypes } = require('../isaraql/schemaDiscovery')
const { generatePlaceholders } = require('../isaraql/fetch')
const { flatFacetIDMap, cacheTablespace, getSourceTableForPostureCategory } = require('./flatFacetHelpers')
const { getRequestState, suspendRequestState, resumeRequestState } = require('./requestState')

const log = require('../util/log')(module)

/**
 * This set of groups will follow their initial sort order, and not become sorted by number.
 */
const GROUPS_THAT_STAY_SORTED = new Set(['1-CONNECTIONCRYPTO-Strength-panel', '0-CONNECTIONCRYPTO-Strength-panel', '2-CONNECTIONCRYPTO-Strength-panel', '1-DEVICECRYPTO-Strength-panel', '0-DEVICECRYPTO-Strength-panel', '2-DEVICECRYPTO-Strength-panel'])

function getFilterGroupId(postureCategory, categoryName, filterGroup) {
    return `${postureCategory}-${categoryName}-${filterGroup}-panel`
}

function getFilterId(postureCategory, filter, id) {
    return `${postureCategory}-panel-${filter}-${id}`
}

function makeOrFindFilterGroup(postureCategory, name, filterCategory) {
    let group = filterCategory.filterGroups.find(x => x.groupName === name)
    if (group === undefined) {
        group = {
            id: getFilterGroupId(postureCategory, filterCategory.id, name),
            groupName: name,
            filters: []
        }
        filterCategory.filterGroups.push(group)
    }
    return group
}

function makeFilterCategory(name) {
    if (!Object.keys(filterCategoryTypes).includes(name)) {
        throw `Unsupported top-level filter category ${name}`
    }

    // c.f. FilterCategory definition in commonQL
    return {
        id: name,
        categoryName: filterCategoryNames[name],
        filterGroups: []
    }
}

function refreshFilterCache(postureCategory, categories, cryptoScores) {
    let filterCategories = {}
    for (const filterCategory of categories) {
        let category = filterCategories[filterCategory.id] = Object.assign({}, filterCategory)
        category.filterGroups = {}
        for (const filterGroup of filterCategory.filterGroups) {
            let group = Object.assign({}, filterGroup)
            group.filters = {}
            category.filterGroups[group.id] = group
            filterGroup.filters.forEach((filter, index) => {
                filter.sortOrder = index
                filter.value = 0n
                group.filters[filter.id] = filter
            })
        }
    }

    let cryptoSection = ''
    let facetName = ''

    let facets = ['devicecryptoscore', 'concryptoscore']
    facets.forEach(facetValue => {
        facetName = facetValue
        if (facetName === 'devicecryptoscore') {
            cryptoSection = filterCategories['DEVICECRYPTO'].filterGroups[getFilterGroupId(postureCategory, 'DEVICECRYPTO', 'Strength')]
        } else {
            cryptoSection = filterCategories['CONNECTIONCRYPTO'].filterGroups[getFilterGroupId(postureCategory, 'CONNECTIONCRYPTO', 'Strength')]
        }

        let strengths = cryptoScores.map(score => ({ [score.id]: score.name }))
        let existingFilters = Object.keys(cryptoSection.filters)
        for (let strength of (Object.keys(strengths))) {
            let filterId = getFilterId(postureCategory, facetName, strength)
            if (filterId in existingFilters) {
                continue
            }

            cryptoSection.filters[filterId] = {
                id: filterId,
                name: strength,
                facet: facetName,
                sortOrder: strengths[strength],
                value: 0n
            }
        }

    })

    filterCache[postureCategory] = filterCategories
}

function addFacetResults(postureCategory, categoriesByType, facet, results) {
    let category = categoriesByType[facet.filterCategory.category]
    let group = makeOrFindFilterGroup(postureCategory, facet.filterCategory.group, category)

    let enumTable = {}
    if (facet.type === 'enum') {
        enumTable = allTypes[facet.converter.enumType]._enum.nameByID
    }

    for (let result of Object.keys(results)) {
        let name = result
        if (facet.type === 'enum') {
            name = enumTable[name]
        }

        if (name === undefined) {
            name = 'N/A'
        }

        let filter = {
            id: getFilterId(postureCategory, facet.name, name),
            facet: facet.name,
            name: name
        }

        group.filters.push(filter)
        filter.value = results[result]
    }
}

async function makeFilterCategoriesFromFlat(categoriesByType, postureCategory, applicableFacets, session, filterTable) {
    let posturePanelTable = `"${cacheTablespace}"."${getSourceTableForPostureCategory(postureCategory)}Flat"`

    let facetQuery = `SELECT facet, value AS "filterValue", count(*) FROM ${posturePanelTable} `
    if (filterTable !== undefined) {
        facetQuery += `WHERE object_id IN (SELECT id FROM "${filterTable}") `
    }

    facetQuery += ' GROUP BY 1,2'

    let start = Date.now()
    let result = await session.query(facetQuery)
    if (log.debug) {
        let total = Date.now() - start
        log.d(`Executed flat facet query in ${total} msec`)
    }

    for (let facet of applicableFacets) {
        log.d('Parsing facet ', facet.name)
        let flatID = flatFacetIDMap[facet.name]

        let remapColumn = false
        let currentFacet = allTypes[facet.table][facet.column]
        if (currentFacet.startsWith('String')) {
            remapColumn = true
        }

        let column = ''
        if (facet.isTag) {
            column = `"Tag".value`
        } else if (facet.column) {
            column = `"${facet.table}"."${facet.column}"`
        } else {
            throw `Don't know how to handle facet ${facet.name}`
        }

        let results = {}
        let remap = {}
        if (remapColumn && result.rows.length > 0) {
            let ids = []
            for (let row of result.rows) {
                if (row.facet === flatID) {
                    ids.push(row.filterValue)
                }
            }

            if (ids.length > 0) {
                let tempResult = await session.query(`SELECT id,${column} as value FROM "${facet.table}" WHERE id IN (${generatePlaceholders(ids)})`, ids)
                for (let row of tempResult.rows) {
                    remap[row.id] = row.value
                }
            }
        }

        for (var row of result.rows) {
            if (row.facet !== flatID) {
                continue
            }

            let filterValue = row.filterValue
            if (remapColumn) {
                filterValue = remap[filterValue]
            }

            if (!(filterValue in results)) {
                results[filterValue] = 0n
            }

            results[filterValue] += row.count
        }

        addFacetResults(postureCategory, categoriesByType, facet, results)
    }
}

async function makeMappedFilterCategoriesFromFlat(categoriesByType, postureCategory, applicableFacets, session, filterTable, activeCpt) {
    for (let facet of applicableFacets) {

        let posturePanelTable = `"${cacheTablespace}"."${getSourceTableForPostureCategory(postureCategory)}${facet.table}Flat"`
        let linkedValue = await facet.filterCategory?.additionalFlatCacheMapping?.linkedValue(activeCpt)

        log.d('Parsing facet ', facet.name)
        let flatID = flatFacetIDMap[facet.name]

        let facetQuery= `select "${facet.table}"."${facet.column}" as "filterValue", ${posturePanelTable}.facet, count(${posturePanelTable}.facet)
            from "${facet.table}"
            left join ${posturePanelTable} on ${posturePanelTable}.value = "${facet.table}"."${facet.column}" and ${posturePanelTable}.link = ${linkedValue}
            where "${facet.table}"."${facet.filterCategory?.additionalFlatCacheMapping.column}" = ${linkedValue} `

        if (filterTable !== undefined) {
            facetQuery += `AND object_id IN (SELECT id FROM "${filterTable}") `
        }

        facetQuery += `group by 1,2`

        let start = Date.now()
        let result = await session.query(facetQuery)
        if (log.debug) {
            let total = Date.now() - start
            log.d(`Executed flat facet query in ${total} msec`)
        }

        let remapColumn = false
        let currentFacet = allTypes[facet.table][facet.column]
        if (currentFacet.startsWith('String')) {
            remapColumn = true
        }

        let column = ''
        if (facet.isTag) {
            column = `"Tag".value`
        } else if (facet.column) {
            column = `"${facet.table}"."${facet.column}"`
        } else {
            throw `Don't know how to handle facet ${facet.name}`
        }

        let results = {}
        let remap = {}
        if (remapColumn && result.rows.length > 0) {
            let ids = []
            for (let row of result.rows) {
                if (row.facet === flatID) {
                    ids.push(row.filterValue)
                }
            }

            if (ids.length > 0) {
                let tempResult = await session.query(`SELECT id,${column} as value FROM "${facet.table}" WHERE id IN (${generatePlaceholders(ids)})`, ids)
                for (let row of tempResult.rows) {
                    remap[row.id] = row.value
                }
            }
        }

        for (var row of result.rows) {
            if (row.facet !== null && row.facet !== flatID) {
                continue
            }

            let filterValue = row.filterValue
            if (remapColumn) {
                filterValue = remap[filterValue]
            }

            if (!(filterValue in results)) {
                results[filterValue] = 0n
            }

            results[filterValue] += row.count
        }

        addFacetResults(postureCategory, categoriesByType, facet, results)
    }
}

async function makeFilterCategoriesFromQueries(categoriesByType, postureCategory, applicableFacets, session, filterTable) {
    let posturePanelTable
    switch (postureCategory) {
        case postureCategories.DEVICE:
            posturePanelTable = 'Device'
            break
        case postureCategories.CONNECTION:
            posturePanelTable = 'Connection'
            break
        case postureCategories.SOFTWARE:
            posturePanelTable = 'Software'
            break
    }

    for (let facet of applicableFacets) {
        log.d('Parsing facet ', facet.name)

        let remapColumn = false
        let countingPaths = []
        let currentFacet = allTypes[facet.table][facet.column]
        if (currentFacet.startsWith('String')) {
            remapColumn = true
        }

        if (facet.table !== posturePanelTable) {
            countingPaths = facet.paths[posturePanelTable]
        } else {
            countingPaths.push(` FROM "${posturePanelTable}" `)
        }

        if (!countingPaths || countingPaths.length === 0) {
            log.w(`No path found from ${posturePanelTable} to ${facet.table} for facet ${facet.name}`)
            continue
        }

        let column = ''
        if (facet.isTag) {
            column = `"Tag".value`
        } else if (facet.column) {
            column = `"${facet.table}"."${facet.column}"`
        } else {
            throw `Don't know how to handle facet ${facet.name}`
        }

        countingPaths = countingPaths.map(p => `SELECT "${posturePanelTable}".id,${remapColumn ? '"' + facet.table + '".id' : column} AS "filterValue" ${p}`)
        let wheres = []
        if (filterTable !== undefined) {
            wheres.push(`"${posturePanelTable}".id IN (SELECT id FROM "${filterTable}")`)
        }

        if (facet.isTag) {
            let tagType = allTypes['TagType']._enum.idByName[facet.tagType]
            wheres.push(`"Tag"."tagType" = ${tagType}`)
        }

        if (wheres.length > 0) {
            countingPaths = countingPaths.map(p => `${p} WHERE ${wheres.join(' AND ')}`)
        }

        let path = `SELECT t1."filterValue", count(*) AS count FROM (${countingPaths.join(' UNION ')}) t1 GROUP BY 1`

        if (log.debug) {
            log.d(`Facet ${facet.name}, generated query "${path}"`)
        }

        let results = {}
        let result = await session.query(path)

        let remap = {}
        if (remapColumn && result.rows.length > 0) {
            let ids = []
            result.rows.map(row => ids.push(row.filterValue))

            let tempResult = await session.query(`SELECT id,${column} as value FROM "${facet.table}" WHERE id IN (${generatePlaceholders(ids)})`, ids)
            for (let row of tempResult.rows) {
                remap[row.id] = row.value
            }
        }

        for (var row of result.rows) {
            let filterValue = row.filterValue
            if (remapColumn) {
                filterValue = remap[filterValue]
            }

            if (!(filterValue in results)) {
                results[filterValue] = 0n
            }

            results[filterValue] += row.count
        }

        addFacetResults(postureCategory, categoriesByType, facet, results)
    }
}

async function makeFilterCategories(graphQLResult, postureCategory, wanted, session, activeCpt) {
    log.d(`Making filters for posture: ${postureCategory}`)
    let categoriesByType = {}

    let state = getRequestState()

    let filterTable
    if (state !== undefined) {
        filterTable = state.filterTable
        if (filterTable !== undefined) {
            filterTable = filterTable.table
        }
    }

    // generate placeholders
    graphQLResult.filterCategories = []
    for (let categoryType of Object.keys(filterCategoryTypes)) {
        let category = makeFilterCategory(categoryType)
        graphQLResult.filterCategories.push(category)
        categoriesByType[categoryType] = category
    }

    // fetch scores
    let cryptoScores = (await session.query('SELECT name, id FROM "CryptoScore" cs WHERE cs."cryptoPostureTemplate" = ?', [activeCpt])).rows

    try {
        let applicableFacets = []
        let additionalMappingFacets = []
        for (let facet of facets.attributes) {
            if ('filterCategory' in facet) {
                let categoryMeta = facet.filterCategory
                // exclude any facets that aren't applicable to the current posture view
                if ('appliesTo' in categoryMeta && !categoryMeta.appliesTo.includes(postureCategory)) {
                    continue
                }

                if (facet.filterCategory.additionalFlatCacheMapping) {
                    additionalMappingFacets.push(facet)
                } else {
                    applicableFacets.push(facet)
                }
            }
        }

        if (session.historyEnabled === undefined) {
            await makeFilterCategoriesFromFlat(categoriesByType, postureCategory, applicableFacets, session,
                filterTable)
            await makeMappedFilterCategoriesFromFlat(categoriesByType, postureCategory, additionalMappingFacets, session,
                filterTable, activeCpt)
            if (filterTable === undefined) {
                // TODO: GAP1603 - make this smarter so it's only re-cloned on changes, possibly by hooking the same way the flat facet
                // rebuilder does.
                refreshFilterCache(postureCategory, cloneDeep(graphQLResult.filterCategories), cryptoScores)
            }
        } else {
            await makeFilterCategoriesFromQueries(categoriesByType, postureCategory, applicableFacets, session,
                filterTable)
        }

    } catch (e) {
        log.w('Exception while building filter categories: ', e)
        throw e
    }

    // the cache is only for live numbers, we can't merge placeholders for history.
    if (session.historyEnabled) {
        return
    }

    if (graphQLResult.filterCategories && Object.keys(graphQLResult.filterCategories).length > 0) {
        // we have category results, but the filter cache has not been lazily populated yet, force it to be.
        if (filterCache[postureCategory] === undefined) {
            if (state !== undefined) {
                try {
                    suspendRequestState()
                    await makeFilterCategories({}, postureCategory, {}, session, activeCpt)
                } finally {
                    resumeRequestState()
                }
            }
        }

        let valCopy = cloneDeep(filterCache[postureCategory])

        for (let category of graphQLResult.filterCategories) {
            let catId = category.id
            let catCopy = cloneDeep(valCopy[catId])

            for (let group of category.filterGroups) {
                let groupId = group.id
                let groupCopy = cloneDeep(catCopy.filterGroups[groupId])

                if (GROUPS_THAT_STAY_SORTED.has(group.id)) {
                    for (let filter of group.filters) {
                        const filterId = filter.id
                        if (groupCopy.filters[filterId]) {
                            groupCopy.filters[filterId].value = filter.value
                        } else {
                            groupCopy.filters[filterId] = cloneDeep(filter)
                        }
                    }
                    group.filters = Object.values(groupCopy.filters).sort((a, b) => a.sortOrder - b.sortOrder)
                } else {
                    for (let filter of group.filters) {
                        let filterId = filter.id

                        delete groupCopy.filters[filterId]
                    }

                    for (let filterKey of Object.keys(groupCopy.filters)) {
                        group.filters.push(groupCopy.filters[filterKey])
                    }
                }

                delete catCopy.filterGroups[groupId]
            }


            delete valCopy[catId]
        }

        // This means that any top level values left in val copy weren't generated.
    }
}

exports.makeFilterCategories = makeFilterCategories
