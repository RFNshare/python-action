/**
 * @file queryTrackingQL.js - 1.2.0 - 3826bc12533e078a8e37cfe70ee04d9e85c8530e
 * 
 * @copyright Copyright (C) 2016-2023, ISARA Corporation, All Rights Reserved.
 * 
 * @license The code and other content set out herein is not in the public
 * domain, is considered a trade secret and is confidential to ISARA
 * Corporation. Use, reproduction or distribution, in whole or in part, of such
 * code or other content is strictly prohibited except by express written
 * permission of ISARA Corporation. Please contact ISARA Corporation at
 * info@isara.com for more information.
 */

/**
 * This module contains queries to track the other queries.
 * @module graphql/queryTrackingQL
 */

var log = require('../util/log.js')(module)

var {
    UNAUTHENTICATED
} = require('./commonQL').roles

class QueryStatistics {
    constructor() {
        this.durationTotal = 0
        this.count = 0
        this.errorCount = 0
        this.lastError = null
    }

    logQuery(duration, error) {
        this.durationTotal += duration
        this.count++
        if (error) {
            this.errorCount++
            this.lastError = error
        }
    }

    /**
     * Clear totals, counts and errors.
     * @returns undefined
     */
    clear() {
        this.count = 0
        this.errorCount = 0
        this.lastError = null
        this.durationTotal = 0
    }
}

var queryStatistics = {}

async function queryStatisticsQuery() {
    return JSON.stringify(queryStatistics)
}

/**
 * Clear the counts on all query tracking. Does not remove
 * any entries.
 * @return `true`
 */
async function clearStatisticsMutation() {
    for (var key in queryStatistics) {
        queryStatistics[key].clear()
    }
    return true
}

exports.addQuery = async function(name) {
    if (!(name in queryStatistics)) {
        queryStatistics[name] = new QueryStatistics()
    }
}

exports.logQuery = async function(name, duration, error) {
    log.d('Query Performed', name, duration, error)
    if (!(name in queryStatistics)) {
        queryStatistics[name] = new QueryStatistics()
    }
    queryStatistics[name].logQuery(duration, error)
}

exports.graphQL = {
    queries: `
        queryStatistics: String!
    `,
    mutations: `
        clearStatistics: Boolean!
    `,
    root: {
        queryStatistics: queryStatisticsQuery,
        clearStatistics: clearStatisticsMutation
    },
    restrictions: {
        queryStatistics: [UNAUTHENTICATED],
        clearStatistics: [UNAUTHENTICATED],
    }
}
