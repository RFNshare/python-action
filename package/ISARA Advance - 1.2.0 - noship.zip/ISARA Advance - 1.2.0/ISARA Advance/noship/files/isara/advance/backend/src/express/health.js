/**
 * @file health.js - 1.2.0 - 3826bc12533e078a8e37cfe70ee04d9e85c8530e
 * 
 * @copyright Copyright (C) 2016-2023, ISARA Corporation, All Rights Reserved.
 * 
 * @license The code and other content set out herein is not in the public
 * domain, is considered a trade secret and is confidential to ISARA
 * Corporation. Use, reproduction or distribution, in whole or in part, of such
 * code or other content is strictly prohibited except by express written
 * permission of ISARA Corporation. Please contact ISARA Corporation at
 * info@isara.com for more information.
 */

/**
 * This module defines a simple health check API.
 */

const log = require('../util/log')(module)

const userHealthCheckListeners = []

exports.endpoint = {
    path: '/service/health',
    get: {
        handler: async function (request, response) {
            for (const listener of userHealthCheckListeners) {
                try {
                    listener()
                } catch (e) {
                    log.e(e)
                }
            }
            response.setHeader('Content-type', 'application/json')
            response.send(JSON.stringify({ status: healthStatus, description: healthComments[healthStatus] }))
            response.status(200).end()
        }
    }
}

const healthKeysArray = [
    'HEALTH_UNKNOWN',
    'HEALTH_STARTING_CHECKS',
    'HEALTH_DATABASE_FAILURE',
    'HEALTH_DATABASE_TABLES',
    'HEALTH_DATABASE_VERSION_MISSING',
    'HEALTH_DATABASE_VERSION_TOO_LOW',
    'HEALTH_DATABASE_VERSION_TOO_HIGH',
    'HEALTH_DATABASE_NO_USERS',
    'HEALTH_GRAPHQL_FAILURE',
    'HEALTH_OK',
    'HEALTH_TYPESENSE_FAILURE'
]

const healthKeys = (() => {
    const toReturn = {}
    for (const key of healthKeysArray) {
        toReturn[key] = key
        exports[key] = key
    }
    return toReturn
})()


let healthStatus = healthKeys.HEALTH_UNKNOWN

const healthComments = {
    HEALTH_UNKNOWN: 'Nothing indicated if the system is up or down. How could they be jamming us...',
    HEALTH_STARTING_CHECKS: 'Health checks have been started, but are not completed yet',
    HEALTH_DATABASE_FAILURE: 'The database connection may be misconfigured or the database is currently unavailable.',
    HEALTH_DATABASE_TABLES: 'The database connection works, but expected tables are missing.',
    HEALTH_DATABASE_VERSION_MISSING: 'The database connection works, but the version number is missing, database maintenance/repair may be needed.',
    HEALTH_DATABASE_VERSION_TOO_LOW: 'The database connection works, but the version number is lower than expected. Please run the upgrade script.',
    HEALTH_DATABASE_VERSION_TOO_HIGH: ' The database connection works, but the version number is higher than expected. Please ensure you are running the correct version of Advance.',
    HEALTH_DATABASE_NO_USERS: 'There are no users in the currently selected database',
    HEALTH_GRAPHQL_FAILURE: 'GraphQL failed to initialise',
    HEALTH_OK: 'OK',
    HEALTH_TYPESENSE_FAILURE: 'Typesense server is not running'
}

function checkKeysHaveComments() {
    const commentCopy = Object.assign({}, healthComments)
    for (const key of healthKeysArray) {
        if (!(key in commentCopy)) {
            throw new Error(`Missing comment for health key ${key}`)
        }
        delete commentCopy[key]
    }
    if (Object.keys(commentCopy).length > 0) {
        throw new Error(`Mismatched comments, extra keys: ${JSON.stringify(Object.keys(commentCopy))}`)
    }
}
checkKeysHaveComments()

/**
 * @typedef HealthKeys
 * @property {string} HEALTH_UNKNOWN
 * @property {string} HEALTH_STARTING_CHECKS
 * @property {string} HEALTH_DATABASE_FAILURE
 * @property {string} HEALTH_DATABASE_TABLES
 * @property {string} HEALTH_DATABASE_VERSION_MISSING
 * @property {string} HEALTH_DATABASE_VERSION_TOO_LOW
 * @property {string} HEALTH_DATABASE_VERSION_TOO_HIGH
 * @property {string} HEALTH_DATABASE_NO_USERS
 * @property {string} HEALTH_GRAPHQL_FAILURE
 * @property {string} HEALTH_OK
 * @property {string} HEALTH_TYPESENSE_FAILURE
 */

Object.defineProperty(exports, 'healthStatus', {
    get() {
        return healthStatus
    },
    set(healthKey) {
        if (healthKey in exports.healthKeys) {
            healthStatus = healthKey
        } else {
            const message = `Invalid attempt to set health status to ${healthKey}`
            log.e(message)
            throw new Error(message)
        }
    }
})

/**
 * The available health keys.
 * @type HealthKeys
 */
exports.healthKeys = Object.freeze(healthKeys)

/**
 * The health check is bypassing security and logging wrappers.
 */
exports.bypassWrappers = true

exports.addUserHealthCheckListener = (listener) => {
    if (!listener) {
        return
    }
    if (userHealthCheckListeners.includes(listener)) {
        return
    }
    userHealthCheckListeners.push(listener)
}