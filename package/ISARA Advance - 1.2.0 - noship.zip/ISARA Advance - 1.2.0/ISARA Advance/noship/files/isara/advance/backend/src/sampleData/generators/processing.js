/**
 * @file processing.js - 1.2.0 - 3826bc12533e078a8e37cfe70ee04d9e85c8530e
 * 
 * @copyright Copyright (C) 2016-2023, ISARA Corporation, All Rights Reserved.
 * 
 * @license The code and other content set out herein is not in the public
 * domain, is considered a trade secret and is confidential to ISARA
 * Corporation. Use, reproduction or distribution, in whole or in part, of such
 * code or other content is strictly prohibited except by express written
 * permission of ISARA Corporation. Please contact ISARA Corporation at
 * info@isara.com for more information.
 */


const {
    dumpObjectTimingStats,
    initDbConnection,
    insertObject,
    resetObjectTimingStats,
    bulkInsertRecords,
} = require('../dbHelpers')
var log = require('../../util/log')(module)
const { tidyOldRecords } = require('../utils')
const {
    Session
} = require('../../isaraql/session')

const {
    pickOne,
    randomBelow,
    randomCompany,
    randomName,
} = require('../sampleHelpers')

const {
    loadDatabaseTypes,
} = require('../dbTypeHelpers')

const {
    allStrongCryptoPrimitives,
    allWeakCryptoPrimitives,
    strongProtocolVariants,
    weakProtocolVariants,
    roles,
    softwareTypes,
    tagTypes,
    users
} = require('../dbTypes')

var {
    hashPassword
} = require('../../util/passwordUtils')

const { updateCryptoScoresForDevice, updateCryptoScoresForConnection } = require('../../util/scoreHelpers')

const { rebuildAllFlatFacetTables } = require('../../util/flatFacetHelpers')

const facets = require('../../filterql/facets')

const { Mutex } = require('async-mutex')


const {
    allTypes,
    discoverSchema
} = require('../../isaraql/schemaDiscovery')

const {
    Agent,
    AgentCertificate,
    CAIssuedCertificate,
    Certificate,
    CertificateCryptoPrimitive,
    CertificationAuthority,
    Connection,
    ConnectionCertificate,
    ConnectionCipherSuite,
    ConnectionCryptoPrimitive,
    ConnectionProtocolVariant,
    ConnectionProtocolVariantCertificate,
    ConnectionTag,
    Device,
    DeviceAddress,
    DeviceAddressMACAddress,
    DeviceAddressPort,
    DeviceCertificate,
    DeviceMACAddress,
    DeviceSoftware,
    DeviceSoftwareConnection,
    DeviceTag,
    KeyStore,
    KeyStoreKey,
    OneTimeKey,
    Netmask,
    Notification,
    NotificationAction,
    Software,
    SoftwareVersion,
    SoftwareVersionTag,
    Tag,
    User,
    UserRole,
} = require('../dbObjects')


exports.initGenerator = async (session, data) => {
    data.startTime = new Date()
    //log.log('Purging database...')
    // await tidyOldRecords(session)

    //log.log('Discovering schema...')
    //await discoverSchema()
    //await facets.discoverPaths()

    log.log('Loading database types...')
    await loadDatabaseTypes(session, data)

}

exports.oldProcess = async () => {
    connection = await initDbConnection()
    await discoverSchema()
    const myArgs = minimist(process.argv.slice(2))
    for (let arg of Object.keys(myArgs)) {
        // The first argument is always _ which returns an array of arguments without dashes
        if (arg !== '_' && !Object.keys(optionalArguments).includes(arg)) {
            console.log(`Unsupported argument: ${arg}`)
            usage()
        }
    }

    if (myArgs.help) {
        usage()
    }

    let bulkSize = 100
    let createBaselineOnly = myArgs?.baselineOnly || false

    let numGoodServerCount = Number(myArgs?.numGoodServers) || 20
    let numBadServerCount = Number(myArgs?.numBadServers) || 25
    let numClients = Number(myArgs?.numClients) || 200

    let pocGoodServers = Number(myArgs?.pocGoodServers) || 0.9
    let minGoodConnections = Number(myArgs?.minGoodConnections) || 500

    let pocBadServers = Number(myArgs?.pocBadServers) || .01
    let minBadConnections = Number(myArgs?.minBadConnections) || 100

    let maxCertificateCount = Number(myArgs?.maxCertificates) || 5

    let userPassword = myArgs?.userPassword || 'password'

    let goodServerPorts = [
        { port: 443, count: 3000 },
        { port: 8080, count: 4000 },
        { port: 80, count: 500 },
        { port: 22, count: 300 },
        { port: 23, count: 400 }
    ]

    let badServerPorts = [
        { port: 443, count: 2000 },
        { port: 8080, count: 1000 },
        { port: 80, count: 3000 },
        { port: 22, count: 4000 },
        { port: 23, count: 600 }
    ]

    try {
        goodServerPorts = JSON.parse(myArgs?.goodServerPorts)
        badServerPorts = JSON.parse(myArgs?.badServerPorts)
    } catch {
        goodServerPorts = goodServerPorts
        badServerPorts = badServerPorts
    }

    let listeningGoodServerAddressPorts = []
    let listeningBadServerAddressPorts = []
    let listeningClientAddressPorts = []
    let existingCertificates = []
    let CertsWithPrimitives = []

    log.log('Purging database...')
    await tidyOldRecords()

    log.log('Discovering schema...')
    await discoverSchema()
    await facets.discoverPaths()

    log.log('Loading database types...')
    await loadDatabaseTypes()

    log.log('Adding users...')
    await insertUsers(userPassword)
    await insertUserRoles()

    if (createBaselineOnly) {
        await connection.end()
        return
    }

    let startTime = new Date()

    log.log('Adding software version tags...')
    await generateAndInsertSoftwareVersionTags()

    log.log('Adding connection tags...')
    await generateAndInsertConnectionTags()

    log.log('Adding notifications...')
    await insertNotifications()
    await insertNotificationActions()

    log.log('Adding network masks...')
    await insertNetmasks()

    log.log('Adding software...')
    await populateSoftware()

    dumpObjectTimingStats()
    resetObjectTimingStats()

    let bulkDeviceAddressPort = []
    let bulkDeviceAddressPortType = []
    let deviceAgents = {}
    const mutex = new Mutex()
    let bulkUpdateDevice = []
    let deviceTypeArray = []
    let certAuthorities = []
    await addKeyStore(certAuthorities)

    resetObjectTimingStats()
    let allCipherSuites = (await connection.query(`select * from "CipherSuite"`)).rows
    let strongCipherSuites = popularStrongCipherSuite.map(name => allCipherSuites.find(ciphersuite => ciphersuite.name === name))
    let badCipherSuites = popularBadCipherSuite.map(name => allCipherSuites.find(ciphersuite => ciphersuite.name === name))

    let bulkAddConnectionsArray = []
    let connectionsItems = []

    await callAddDevice(deviceTypes.GOOD_SERVER, numGoodServerCount, 'Good Server')
    await callAddDevice(deviceTypes.CLIENT, numClients, 'Clients')

    let goodServerClients = lodash.shuffle(listeningClientAddressPorts)
    let currentGoodServerClientPorts = []
    for (let s = 0; s < (goodServerClients.length + minGoodConnections); ++s) {
        const connectionsForThisClient = Math.floor(Math.random() * 20) + 1
        for (let tt = 0; tt < connectionsForThisClient; ++tt) {
            if ((minGoodConnections > 0) || (Math.random() < pocGoodServers)) {
                let portForServer = pickOne(lodash.shuffle(listeningGoodServerAddressPorts))
                minGoodConnections--
                let client = goodServerClients[Math.floor(Math.random() * goodServerClients.length)]
                let portPair = { clientPort: client.port.id, serverPort: portForServer.port.id }
                let itemNotFound = currentGoodServerClientPorts.find(item => item.clientPort === client.port.id && item.serverPort === portForServer.port.id) ? false : true
                while (!itemNotFound) {
                    client = goodServerClients[Math.floor(Math.random() * goodServerClients.length)]
                    itemNotFound = currentGoodServerClientPorts.find(item => item.clientPort === client.port.id && item.serverPort === portForServer.port.id) ? false : true
                }
                if (itemNotFound) {
                    log.log('Adding a Good Connection ...')
                    await callAddConnection(deviceTypes.GOOD_SERVER, portForServer, client)
                    currentGoodServerClientPorts.push(portPair)
                }
            }
        }
    }
    await bulkAddConnections()
    currentGoodServerClientPorts = []
    listeningGoodServerAddressPorts = []

    await callAddDevice(deviceTypes.BAD_SERVER, numBadServerCount, 'Bad Server')

    let badServerClients = lodash.shuffle(listeningClientAddressPorts)
    let currentBadServerClientPorts = []
    for (let s = 0; s < (badServerClients.length + minBadConnections); ++s) {
        const connectionsForThisClient = Math.floor(Math.random() * 20) + 1
        for (let tt = 0; tt < connectionsForThisClient; ++tt) {
            if ((minBadConnections > 0) || (Math.random() < pocBadServers)) {
                let portForServer = pickOne(lodash.shuffle(listeningBadServerAddressPorts))
                let client = badServerClients[Math.floor(Math.random() * badServerClients.length)]
                let badReason = pickOne(lodash.shuffle(badServerReasonsArray))
                let portPair = { clientPort: client.port.id, serverPort: portForServer.port.id }
                let itemNotFound = currentBadServerClientPorts.find(item => item.clientPort === client.port.id && item.serverPort === portForServer.port.id) ? false : true
                while (!itemNotFound) {
                    client = badServerClients[Math.floor(Math.random() * badServerClients.length)]
                    itemNotFound = currentBadServerClientPorts.find(item => item.clientPort === client.port.id && item.serverPort === portForServer.port.id) ? false : true
                }
                minBadConnections--
                if (itemNotFound) {
                    log.log('Adding a Bad Connection ...')
                    await callAddConnection(deviceTypes.BAD_SERVER, portForServer, client, badReason)
                    currentBadServerClientPorts.push(portPair)
                }
            }
        }
    }
    await bulkAddConnections()

    const clientCount = (await connection.query(`select count("id") from (select d.id,count(*) FROM "Device" d JOIN "DeviceAddress" da ON da.device = d.id JOIN "DeviceAddressPort" dap ON dap."deviceAddress" = da.id JOIN "Connection" c on c."clientDeviceAddressPort" = dap.id GROUP BY 1 ORDER BY  1 ASC) AS derived`)).rows[0].count
    let offsetClient = 0
    while (offsetClient <= clientCount) {
        const clients = (await connection.query(
            `select d.id,count(*) FROM "Device" d JOIN "DeviceAddress" da ON da.device = d.id JOIN "DeviceAddressPort" dap ON dap."deviceAddress" = da.id JOIN "Connection" c on c."clientDeviceAddressPort" = dap.id GROUP BY 1 ORDER BY  1 ASC LIMIT ${bulkSize} offset ${offsetClient}`,
        )).rows
        let outgoingConnectionCounts = []
        if (clients.length > 0) {
            let i = 0
            for (let client of clients) {
                outgoingConnectionCounts.push(`(${client.count},${client.id})`)
                showCount('Update Client Connection Counts', i, clients.length)
                i++
            }
            showCount('Update Client Connection Counts', i, clients.length)
            await connection.query(`UPDATE "Device" as t SET "outgoingConnectionCount"=c.outgoingConnectionCount from (values ${outgoingConnectionCounts.join(',')} ) as c(outgoingConnectionCount, id) WHERE c.id=t.id`)
        }
        offsetClient = offsetClient + bulkSize
    }

    const serverCount = (await connection.query(`select count("id") from (select d.id,count(*) FROM "Device" d JOIN "DeviceAddress" da ON da.device = d.id JOIN "DeviceAddressPort" dap ON dap."deviceAddress" = da.id JOIN "Connection" c on c."serverDeviceAddressPort" = dap.id GROUP BY 1 ORDER BY  1 ASC) AS derived`)).rows[0].count
    let offsetServer = 0
    while (offsetServer <= serverCount) {
        const servers = (await connection.query(
            `select d.id,count(*) FROM "Device" d JOIN "DeviceAddress" da ON da.device = d.id JOIN "DeviceAddressPort" dap ON dap."deviceAddress" = da.id JOIN "Connection" c on c."serverDeviceAddressPort" = dap.id GROUP BY 1 ORDER BY  1 ASC LIMIT ${bulkSize} offset ${offsetServer}`,
        )).rows
        let incomingConnectionCount = []
        if (servers.length > 0) {
            let i = 0
            for (let server of servers) {
                incomingConnectionCount.push(`(${server.count},${server.id})`)
                showCount('Update Server Connection Counts', i, servers.length)
                i++
            }
            showCount('Update Server Connection Counts', i, servers.length)
            await connection.query(`UPDATE "Device" as t SET "incomingConnectionCount"=c.incomingConnectionCount from (values ${incomingConnectionCount.join(',')} ) as c(incomingConnectionCount, id) WHERE c.id=t.id`)
        }
        offsetServer = offsetServer + bulkSize
    }

    console.log('Adding software version tags...')
    let versionCount = Math.floor(Math.random() * 100)
    for (let j = 0; j < versionCount; ++j) {
        // Add random version tags
        var randomVersion = pickOne(pickOne(allSoftwareVersions))
        insertSoftwareVersionTag(randomVersion)
        showCount('SoftwareVersionTag', j + 1, versionCount)
    }

    await bulkInsertRecords('SoftwareVersionTag', softwareVersionTagArray, session)
    softwareVersionTagArray = []

    console.log('Adding connection tags...')
    let connectionCount = Math.floor(Math.random() * 100)
    for (let j = 0; j < connectionCount; ++j) {
        // Add random version tags
        let randomConnection = pickOne(allConnections)
        insertConnectionTag(randomConnection)
        showCount('ConnectionTag', j + 1, connectionCount)
    }

    await bulkInsertRecords('ConnectionTag', connectionsTags, session)
    connectionsTags = []

    console.log('Calculating crypto scores...')
    let j = 0
    let promises = []
    for (let connection of allConnections) {
        promises.push(updateCryptoScoresForConnection(connection.id))
        if (promises.length >= 10) {
            await Promise.allSettled(promises)
            promises = []
        }

        showCount('Connection Score', ++j, allConnections.length)
    }

    await Promise.allSettled(promises)
    promises = []

    j = 0
    for (let device of allDevices) {
        promises.push(updateCryptoScoresForDevice(device.id))
        if (promises.length >= 10) {
            await Promise.allSettled(promises)
            promises = []
        }

        showCount('Device Score', ++j, allDevices.length)
    }

    await Promise.allSettled(promises)

    await rebuildAllFlatFacetTables(true)
    dumpObjectTimingStats(true)
    await connection.end()
    let endTime = new Date()
    log.log(`Run Time in milliseconds ${endTime.getTime() - startTime.getTime()}`)
}