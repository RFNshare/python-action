/**
 * @file filterSQL.js - 1.2.0 - 3826bc12533e078a8e37cfe70ee04d9e85c8530e
 * 
 * @copyright Copyright (C) 2016-2023, ISARA Corporation, All Rights Reserved.
 * 
 * @license The code and other content set out herein is not in the public
 * domain, is considered a trade secret and is confidential to ISARA
 * Corporation. Use, reproduction or distribution, in whole or in part, of such
 * code or other content is strictly prohibited except by express written
 * permission of ISARA Corporation. Please contact ISARA Corporation at
 * info@isara.com for more information.
 */

const { facets } = require('./facets')
const { generateNode } = require('./generateNode')
const { parse } = require('./filterql')
const { walk } = require('./walk')
const log = require('../util/log')(module)
const { QueryAndParams, TempTable } = require('../isaraql/fetch')

/**
* SQL expression bound to the facet's network model attributes.
*
* @param {string} expression The expression to be parsed and bound
* @param {object[]} attributes The list of facet attributes.
*
* @return {object[]} of term objects for the wpcs where clause
*/
exports.expression = function (expression, attributes) {
    return expression.trim().length
        ? walk(parse(expression), generateNode)
            .generateQueryStruct({ attributes: attributes })
        : undefined
}

/**
 * Convert an expression to a `QueryAndParams`.
 * @param {string} table Root table for the expression.
 * @param {string} expression Filter/search expression.
 *
 * @return {QueryAndParams} The query and params needed to find the desired records.
 */
exports.expressionToQueryAndParams = async function (table, expression) {
    if (typeof (expression) !== 'string' || expression.trim() === '') {
        return null
    }

    var astTree = walk(parse(expression), generateNode)
    var asStruct = astTree.generateQueryStruct({ attributes: facets.attributes })

    var params = []
    var query = await structToQuery(table, asStruct, params)

    log.d('Generated query for expression', expression, query, params)

    return new QueryAndParams(query, params)
}

/**
 * Convert an expression to a temporary table.
 * @param {string} table Root table for the expression.
 * @param {string} expression Filter/search expression.
 *
 * @return {TempTable} The name of the temporary table containing the results of the query expression.
 */
exports.expressionToTempTable = async function (table, expression, session) {
    if (!session) {
        throw 'A session is required to generate a temp table.'
    }

    if (typeof (expression) !== 'string' || expression.trim() === '') {
        return null
    }

    let astTree = walk(parse(expression), generateNode)
    let asStruct = astTree.generateQueryStruct({ attributes: facets.attributes })

    let params = []
    let query = await structToQuery(table, asStruct, params)

    let tempTableName = await session.generateTempTable(`Filter_${table}`, query, params)

    return new TempTable(tempTableName, 'id')
}

const operators = {
    equals: ' = ',
    ne: ' != ',
    lte: ' <= ',
    gte: ' >= ',
    lt: ' < ',
    gt: ' > ',
    like: ' ilike ',
    isnull: ' IS NULL ',
    isnotnull: ' IS NOT NULL ',
    rangelte: ' <@ '
}

function pushSingleOrArray(destination, value) {
    if (Array.isArray(value)) {
        destination.push(...value)
    } else if (value != null) {
        destination.push(value)
    }
}

async function structToQuery(table, where, params) {
    if ('and' in where || 'or' in where) {
        if ('or' in where && 'and' in where) {
            throw 'where has or and and'
        }
        var logicOp
        var sqlOp
        if ('or' in where) {
            logicOp = 'or'
            sqlOp = 'union'
        } else {
            logicOp = 'and'
            sqlOp = 'intersect'
        }

        let clauseArray = []
        for (let i = 0; i < where[logicOp].length; i++) {
            clauseArray.push(await structToQuery(table, where[logicOp][i], params))
        }
        let clause = clauseArray.filter(exists => exists).join(` ${sqlOp} `)

        return ` ( ${clause} ) `
    } else if ('not' in where) {
        let clause = await structToQuery(table, where['not'], params)
        return ` select "${table}".id from "${table}" where "${table}".id not in ( ${clause} ) `
    }
    for (var operator in operators) {
        if (operator in where) {
            var part = where[operator]
            var value = part.value
            var column = part.column

            var attribute = facets.attributesByName[column]
            if (!attribute) {
                throw `Could not find attribute named ${column} in attributes for ${table}`
            }

            if (attribute.converter) {
                value = attribute.converter(value, operator)
            }

            if (attribute.operatorConverter) {
                operator = attribute.operatorConverter(part.value, operator, value)
            }

            var paths = attribute.paths[table]

            var queryParts = []

            let clause = `"${attribute.table}"."${attribute.column}"`

            if (attribute.customClause) {
                clause = attribute.customClause()
            }
            if (operator === 'isnull' || operator === 'isnotnull') {
                clause +=  `${operators[operator]}`
            } else if (operator === 'rangelte') {
                clause +=  `${operators[operator]} tstzrange(?, ?)`
            } else {
                clause += `${operators[operator]} ? `
            }
            let prependQuery = ''

            if (attribute.extraMatching) {
                clause = await attribute.extraMatching(part.value, clause)
            } else if (Array.isArray(value) && operator != 'rangelte') {
                clause = ` "${attribute.table}"."${attribute.column}" in (${value.map(() => '?').join(',')}) `
            }

            if (attribute.prependQuery) {
                prependQuery = await attribute.prependQuery(part.value, prependQuery, table)
            }

            if (paths === null) {
                // This is normal if the facet is on 'this' table.
                pushSingleOrArray(params, value)
                queryParts.push(` ( select distinct "${table}".id from "${table}" where ${clause} )`)
            } else {
                // The value is on a different table - need to follow paths.
                if (paths.length === 0) {
                    throw new Error('Paths are expected but none exist.')
                }

                if (clause) {
                    clause = `AND (${clause})`
                } else {
                    params = []
                }
                for (var path of paths) {
                    pushSingleOrArray(params, value)
                    queryParts.push(` ${prependQuery} ( select distinct "${table}".id ${path}  ${clause} ) `)

                }
            }
            const toReturn = '(' + queryParts.join(' UNION ') + ')'

            return toReturn
        }
    }
    throw 'Unhandled where type'
}
