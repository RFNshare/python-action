/**
 * @file csvIngestion.js - 1.2.0 - 3826bc12533e078a8e37cfe70ee04d9e85c8530e
 * 
 * @copyright Copyright (C) 2016-2023, ISARA Corporation, All Rights Reserved.
 * 
 * @license The code and other content set out herein is not in the public
 * domain, is considered a trade secret and is confidential to ISARA
 * Corporation. Use, reproduction or distribution, in whole or in part, of such
 * code or other content is strictly prohibited except by express written
 * permission of ISARA Corporation. Please contact ISARA Corporation at
 * info@isara.com for more information.
 */

/**
 * This module defines the CSV Ingestion Endpoint.
 * @module express/csvIngestion
 */

const multer = require('multer')
const os = require('os')

const { roles } = require('../graphql/commonQL')
const { getRequestState } = require('../util/requestState')
const { insertRecord } = require('../isaraql/fetch')
const { Session } = require('../isaraql/session')
const { selectByLooks } = require('../ingestion/commonIngestion')
const { allTypes } = require('../isaraql/schemaDiscovery')
const ingestionJob = require('../ingestion/ingestionJob')
const { createUpdateDelete } = require('../isaraql/cud')
const {
    CSV_SOFTWARE_NAME,
    CSV_SOFTWARE_VERSION_NAME,
    CSV_SOFTWARE_VENDOR
} = require('../graphql/dataSourcesQL')

const supportedFormats = {
    devices: 'Device Inventory',
    connections: 'Network Connections',
    netscout_tls: 'NetScout TLS Connections'
}

const supportedFileExtensions = ['.csv', '.zip']

async function findOrCreateDataSource(session) {
    let software = (await selectByLooks('Software', { name: CSV_SOFTWARE_NAME, softwareVendor: CSV_SOFTWARE_VENDOR }, session))[0]
    let softwareVersion = (await selectByLooks('SoftwareVersion', { name: CSV_SOFTWARE_VERSION_NAME, software: software.id }, session))[0]
    let dataSource = (await selectByLooks('DataSource', { softwareVersion: softwareVersion.id }, session))[0]

    if (!dataSource) {
        let now = new Date()
        let entryToInsert = {
            friendlyName: CSV_SOFTWARE_VERSION_NAME,
            configuration: '{}',
            softwareVersion: softwareVersion.id,
            addedBy: getRequestState().user.uid,
            addedAt: now,
            status: allTypes['DataSourceStatus']._enum.idByName['ENABLED'],
            lastModified: now,
        }
        dataSource = await insertRecord('DataSource', entryToInsert, session)
    }

    return dataSource
}

async function createDataSourceScan(session, file, tmpFile, mimeType, type, tagText, dataSource) {
    let now = new Date()
    let entryToInsert = {
        friendlyName: `${supportedFormats[type]} ${CSV_SOFTWARE_VERSION_NAME} '${file}'`,
        dataSource: { id: dataSource.id },
        metadata: JSON.stringify({ tmpFile, mimeType }),
        configuration: JSON.stringify({ file, type }),
        lastModified: now,
        scanCount: 0,
    }

    if (tagText) {
        entryToInsert.dataSourceScanTags = [{ tag: { value: tagText, tagType: allTypes['TagType']._enum.idByName['CUSTOM'] } }]
    }

    let config = {
        allowInsert: true,
        populateIDs: true,
        modifiableTables: {
            DataSourceScan: true,
            DataSourceScanTag: true,
            Tag: true,
        },
        checkExistingTables: {
            DataSource: true,
            Tag: true,
            User: true,
        },
        session,
    }
    const result = await createUpdateDelete('DataSourceScan', [entryToInsert], config)
    if (result.length > 0) {
        return {id: result[0], ...entryToInsert}
    }
    throw 'Unable to ingest CSV'
}

/**
 * Use disk storage engine to define upload destination and file name.
 */
let storage = multer.diskStorage({
    /*
     * Upload the CSV file into the OS tmp dir.
     */
    destination: function (request, file, cb) {
        cb(null, os.tmpdir())
    },

    /*
     * Append timestamp to the uploaded CSV filename.
     */
    filename: function (request, file, cb) {
        cb(null, `${file.originalname}.${Date.now()}`)
    }
})

/**
 * Do not upload file if the file does not have .csv/.zip extension, or if the query
 * type is incorrect.
 */
function fileFilter(request, file, cb) {
    if (!request.query.type || !supportedFormats[request.query.type]) {
        cb(null, false)
        return
    }

    if (supportedFileExtensions.some(type => file.originalname.toLowerCase().endsWith(type))) {
        cb(null, true)
    } else {
        cb(null, false)
    }
}

let upload = multer({ storage: storage, fileFilter: fileFilter })

/**
 * Exposes the CSV Ingestion POST Endpoint.
 *
 * Example usage:
 *  curl -H "authorization:Bearer [TOKEN]" -F 'csv=@/path/to/devices.csv' http://localhost:4000/service/ingestion/csv?type=devices
 *  (On Windows, use curl.exe from PowerShell, not curl)
 */
exports.endpoint = {
    path: '/service/ingestion/csv',
    post: {
        middleware: upload.single('csv'),
        handler: async (request, response) => {
            /*
             * This error condition should have been caught by the filter, and
             * here we send the error msg.
             */
            if (!request.query.type || !supportedFormats[request.query.type]) {
                response.status(400).send(`Unsupported CSV Type '${request.query.type}'`)
                return
            }

            /*
             * For any non-CSV/ZIP file removed by the filter, request.file should
             * be undefined.
             */
            if (request.file == undefined) {
                response.status(400).send('Invalid file input.')
                return
            }

            /*
             * At this point, the file should have been uploaded. Kick off
             * ingestion.
             */
            let session = new Session()
            let dataSource = await findOrCreateDataSource(session)
            let dataSourceScan = await createDataSourceScan(session, request.file.filename, request.file.path, request.file.mimetype, request.query.type, request.query.tag, dataSource)
            await ingestionJob.runDataSourceScan(dataSourceScan.id)

            response.sendStatus(202)
        },
        restrictions: [roles.AUTHENTICATED]
    },
}
