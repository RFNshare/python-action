/**
 * @file enumQL.js - 1.2.0 - 3826bc12533e078a8e37cfe70ee04d9e85c8530e
 * 
 * @copyright Copyright (C) 2016-2023, ISARA Corporation, All Rights Reserved.
 * 
 * @license The code and other content set out herein is not in the public
 * domain, is considered a trade secret and is confidential to ISARA
 * Corporation. Use, reproduction or distribution, in whole or in part, of such
 * code or other content is strictly prohibited except by express written
 * permission of ISARA Corporation. Please contact ISARA Corporation at
 * info@isara.com for more information.
 */

/**
 * This module contains queries to expose the extra attributes (if there are any) of all enums.
 * @module graphql/devicesQL
 */

const { allTypes } = require('../isaraql/schemaDiscovery')
const { roles } = require('./commonQL')

/**
 * Build the full detail of the values for the given enum type. 
 * @param {Object} type A type from schemaDiscovery.allTypes
 * @returns {Function} A function that will return an array of the correct enum's details.
 */
function createEnumQueryFunction(type) {
    if (!type._meta._isEnum) {
        throw new Error('Cannot build enum detail for non enum')
    }
    const allDetails = []
    for (const id of type._enum.ids) {
        // Create a copy of the enum object.
        const value = { ...type._enum.detailsByID[id] }
        for (const property in type._meta) {
            if (property.startsWith('_') || !(property in value)) {
                continue
            }
            // Lookup the enum name for graphQL. GraphQL will not handle the internal bigint id.
            const referencedTable = type._meta[property].table
            value[property] = allTypes[referencedTable]._enum.detailsByID[value[property]].name
        }
        allDetails.push(value)
    }

    return () => {
        return allDetails
    }
}

/**
 * Exported graphql queries, types and restrictions.
 */
exports.graphQL = (() => {
    const toReturn = {}
    toReturn.types = ''
    toReturn.queries = ''
    const root = toReturn.root = {}
    const restrictions = toReturn.restrictions = {}

    for (const typeName in allTypes) {
        const type = allTypes[typeName]
        if (type._meta._isEnum) {
            const queryName = `${typeName}EnumDetail`
            const enumName = `${typeName}Enum`

            toReturn.queries += `${queryName}:[${enumName}!]!\n`
            root[queryName] = createEnumQueryFunction(type)
            restrictions[queryName] = [roles.UNAUTHENTICATED]
        }
    }

    return toReturn
})()

