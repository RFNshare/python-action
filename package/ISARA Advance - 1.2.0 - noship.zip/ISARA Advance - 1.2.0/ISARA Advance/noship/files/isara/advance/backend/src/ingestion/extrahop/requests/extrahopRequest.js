/**
 * @file extrahopRequest.js - 1.2.0 - 3826bc12533e078a8e37cfe70ee04d9e85c8530e
 * 
 * @copyright Copyright (C) 2016-2023, ISARA Corporation, All Rights Reserved.
 * 
 * @license The code and other content set out herein is not in the public
 * domain, is considered a trade secret and is confidential to ISARA
 * Corporation. Use, reproduction or distribution, in whole or in part, of such
 * code or other content is strictly prohibited except by express written
 * permission of ISARA Corporation. Please contact ISARA Corporation at
 * info@isara.com for more information.
 */

/**
 * Abstract base class for all extrahop requests.
 * @module extrahop/requests/extrahopRequest
 */

const axios = require('../../../util/axiosFactory').createFactory('ExtraHop')
const https = require('https')
const { IngestionAuthError, IngestionCommError } = require('../../commonIngestion')
const log = require('../../../util/log')(module)

class ExtrahopRequest {
    constructor(baseURL, apiPath, token, method, body, parameters) {
        this.baseURL = baseURL
        this.apiPath = apiPath
        this.method = method
        this.token = token
        this.requestType = method
        this.body = body
        this.complete = false
        this.parameters = parameters || {}
        this.timeout = 300000
        this.axios = axios.create({
            baseURL: this.baseURL,
            timeout: this.timeout,
            httpsAgent: new https.Agent({
                rejectUnauthorized: false
            }),
            headers: {
                'Accept': 'application/json',
                'Accept-Encoding': 'gzip, br',
                'Authorization': `ExtraHop apikey=${token}`
            }
        })
    }

    async execute() {
        let config = {
            method: this.method,
            url: this.apiPath
        }

        if (this.method === 'GET') {
            config.params = this.parameters
        }
        if (this.method === 'POST') {
            config.data = this.body
        }

        try {
            const response = await this.axios.request(config)
            log.d('ExtraHop HTTP', this.baseURL, config, response.status)
            if (response.status !== 200) {
                log.e('ExtraHop HTTP', this.baseURL, config, response.status, response.data)
            }
            this.checkComplete(response.data)
            return response.data
        } catch (e) {
            log.e('ExtraHop HTTP', this.baseURL, config, e)
            if (e.response) {
                if (e.response.status === 401) {
                    throw new IngestionAuthError(e.response.data.error_message)
                }

                throw { code: e.response.status, message: e.response.data.error_message }
            } else {
                throw new IngestionCommError(e.message)
            }
        }
    }

    async checkComplete() {
        this.complete = true
    }
}

exports.ExtrahopRequest = ExtrahopRequest
