/**
 * @file viewQL.js - 1.2.0 - 3826bc12533e078a8e37cfe70ee04d9e85c8530e
 * 
 * @copyright Copyright (C) 2016-2023, ISARA Corporation, All Rights Reserved.
 * 
 * @license The code and other content set out herein is not in the public
 * domain, is considered a trade secret and is confidential to ISARA
 * Corporation. Use, reproduction or distribution, in whole or in part, of such
 * code or other content is strictly prohibited except by express written
 * permission of ISARA Corporation. Please contact ISARA Corporation at
 * info@isara.com for more information.
 */

/**
 * This file manages user Views. Note that the backend isn't aware of the meaning of a view.
 * @module graphql/viewQL
 */

const { createUpdateDelete, registerHook, CUD_OP_INSERT, CUD_OP_UPDATE, CUD_OP_DELETE, CUD_OP_PRE } = require('../isaraql/cud')
const { fetchWanted } = require('../isaraql/fetch')
const { graphQLStateToWanted } = require('../isaraql/wantedUtil')
const { getRequestState } = require('../util/requestState')
const { roles, GraphQLEnum, SORT_DIRECTION_ENUM } = require('./commonQL')
const { isValidJSON } = require('./userPreferencesQL')
const { Session } = require('../isaraql/session')
/**
 * Enum for the fields allowed to be sorted on Views.
 */
const SORTABLE_FIELDS_ENUM = new GraphQLEnum('SortableViewFields', ['name', 'addedAt', 'lastModified'])

/**
 * @typedef ViewSortingInput Structure to indicate how to sort views.
 * @property {string} field which field to sort
 * @property {string} direction which direction to sort
 */


/**
 * Query to see views.
 * @param {Object} fields Fields from the GraphQL query
 * @param {number} [fields.id] An optional ID for retrieving a single (probably shared?) View
 * @param {Paging} [fields.paging] Paging information. Defaults to 5 records.
 * @param {ViewSortingInput} [fields.orderBy] Sort preference for retrieved views.
 * @param {Object} request GraphQL request
 * @param {Object} graphQLState GraphQL State
 * @param {number[]} [ids] Set of IDs to run query for.
 */
async function viewQuery(fields, request, graphQLState, ids) {
    var wanted = graphQLStateToWanted(graphQLState)
    wanted = wanted[Object.keys(wanted)[0]]

    if (!('paging' in fields)) {
        fields.paging = { offset: 0n, limit: 5n }
    }
    var wpcs = { View: { paging: fields.paging } }
    if (wanted.paging && wanted.paging.count) {
        wpcs.View.count = []
    }

    if ('id' in fields) {
        ids = [fields.id]
    }

    var userClause = { equals: { column: 'owner', value: getRequestState().user.uid } }

    let specificIDWanted = ids !== undefined && ids.length !== 0
    if (specificIDWanted) {
        // Specific views requested; send them back if they're shared or owned by this user.
        wpcs.View.where = {
            and: [{ in: { column: 'id', value: ids } }, {
                or: [
                    userClause,
                    { equals: { column: 'shared', value: true } }
                ]
            }]
        }
    } else {
        // Limit views to views owned by this user.
        wpcs.View.where = userClause
    }

    if (fields.orderBy) {
        wpcs.View.sort = `"${SORTABLE_FIELDS_ENUM.graphQLToInternal[fields.orderBy.field]}" ${SORT_DIRECTION_ENUM.graphQLToInternal[fields.orderBy.direction]}`
    }

    var views = await fetchWanted('View', wanted.views, wpcs)
    if (views.length === 0 && specificIDWanted) {
        // a specific view was requested, but no result was found. Consequently, the view either is not shared, or no longer exists.
        throw 'View not found.'
    }
    var toReturn = { views }
    if (wpcs.View.count) {
        toReturn.paging = { count: wpcs.View.count[0] }
    }

    return toReturn
}

const checkExistingTables = {}
const deletableTables = { 'View': true }
const modifiableTables = deletableTables

/**
 * Create/Update/Delete views.
 * @param {*} fields
 * @param {*} request
 * @param {*} graphQLState
 */
async function viewUpdateMutation(fields, request, graphQLState) {
    var views = fields.views
    var config = {
        allowDelete: true,
        allowInsert: true,
        allowUpdate: true,
        checkExistingTables,
        deletableTables,
        modifiableTables
    }
    if (fields.views[0].DELETE) {
        const session = new Session()
        const viewJSON = (await session.query('select "value" from "UserPreference" where "keyName"=\'widgets\'')).rows
        if(viewJSON.length) {
            const parsedJSON = isValidJSON(viewJSON[0]?.value)
            if(parsedJSON.valid) {
                const viewRecords = parsedJSON.parsedValue
                if (viewRecords.length) {
                    if (viewRecords.some(widget => widget?.filterByView?.id === Number(fields.views[0].id))) {
                        throw new Error('View is being used by a Widget')
                    }
                }
            }
        }
    }
    var ids = await createUpdateDelete('View', views, config)
    return viewQuery(fields, request, graphQLState, ids)
}

async function viewHook(params) {
    var user = getRequestState().user
    if (!user) {
        throw new Error('User not set when trying to modify View')
    }
    if (params.operation === CUD_OP_UPDATE || params.operation === CUD_OP_DELETE) {
        // Need to enforce that some user isn't changing other users' views.
        var existingRecords = (await params.session.query('select owner from "View" where id = ?', [params.record.id])).rows
        if (existingRecords.length === 0) {
            throw new Error('Existing record expected for user permission check')
        }
        if (existingRecords[0].owner !== user.uid) {
            throw new Error(`Permission denied - cannot update other user's Views`)
        }
    }

    if (params.operation !== CUD_OP_DELETE) {
        params.record.owner = user.uid
        const now = new Date()
        params.record.lastModified = now
        if (params.operation === CUD_OP_INSERT) {
            params.record.addedAt = now
        }
    }
}

async function initialise() {
    registerHook('View', CUD_OP_INSERT, CUD_OP_PRE, viewHook)
    registerHook('View', CUD_OP_UPDATE, CUD_OP_PRE, viewHook)
    registerHook('View', CUD_OP_DELETE, CUD_OP_PRE, viewHook)
}

exports.graphQL = {
    types: `
        type PagedViews {
            paging: Paging!
            views: [View!]!
        }

        ${SORTABLE_FIELDS_ENUM.toGraphQL()}

        input ViewSortingInput {
            field: SortableViewFields!,
            direction: SortDirection!,
        }
    `,
    queries: `
        """
            Obtain all of the current User's Views, or see a specific shared View.
        """
        views(
            """
                Used to control how many views are returned. The default (without paging) will be 5.
            """
            paging: PagingInput
            """
                When provided, will attempt to find a single view. The view may not exist, or you may not have access.
            """
            id: BigInt
            """
               Used to set the sort order of the Views
            """
            orderBy: ViewSortingInput
        ) : PagedViews!
    `,
    mutations: `
        viewUpdate(
            views: [ViewInput!]!
        ) : PagedViews!
    `,
    root: {
        views: viewQuery,
        viewUpdate: viewUpdateMutation,
    },
    restrictions: {
        views: [roles.AUTHENTICATED],
        viewUpdate: [roles.AUTHENTICATED],
    },
    initialise
}
