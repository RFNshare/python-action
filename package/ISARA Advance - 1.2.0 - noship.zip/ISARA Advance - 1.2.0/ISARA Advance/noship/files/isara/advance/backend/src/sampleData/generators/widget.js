/**
 * @file widget.js - 1.2.0 - 3826bc12533e078a8e37cfe70ee04d9e85c8530e
 * 
 * @copyright Copyright (C) 2016-2023, ISARA Corporation, All Rights Reserved.
 * 
 * @license The code and other content set out herein is not in the public
 * domain, is considered a trade secret and is confidential to ISARA
 * Corporation. Use, reproduction or distribution, in whole or in part, of such
 * code or other content is strictly prohibited except by express written
 * permission of ISARA Corporation. Please contact ISARA Corporation at
 * info@isara.com for more information.
 */



var log = require('../../util/log')(module)
const { getSampleUser } = require('../utils')
const { sampleReportDataConnection } = require("../constants")
const clearWidgetsViews = async (session, curUser) => {
    //delete the old views
    let text = 'DELETE FROM advance."View" where "View"."name"=\'test-view\'';
    let values = [];
    try {
        res = await session.query(text, values);
    } catch (e) {
        console.log("Failed to delete view ", e);
        return;
    }

    //delete old widgets
    text = `DELETE FROM advance."UserPreference" WHERE "UserPreference"."keyName" ='widgets' and "UserPreference"."user"=${curUser.id}`;
    try {
        res = await session.query(text, values);
    } catch (e) {
        console.log("Failed to delete widgets ", e);
        return;
    }
}
const createView = async function (session, curUser, config, view) {
    let res = null;
    let text = 'INSERT INTO  advance."View"("addedAt","lastModified","meta","name","owner","shared") VALUES($1,$2,$3,$4,$5,$6) RETURNING *'

    let values = [new Date(), new Date(), `{"instantSearch":{"searchState":{"refinementList":{"cryptoStrength":${JSON.stringify(view.cryptoStrength)}},"page":1,"configure":{"hitsPerPage":100,"maxValuesPerFacet":150}},"index":"${view.index}"},"showFilters":true,"showAdvancedSearch":false,"searchTerm":"","columns":[{"id":"clientAddress","name":"Client IP","width":260},{"id":"serverAddress","name":"Server IP","width":260},{"id":"port","name":"Port","width":80,"isRightAligned":true},{"id":"protocol","name":"Protocol Variants","width":100,"isRightAligned":false},{"id":"cryptoScore","name":"Crypto Level","width":100},{"id":"cryptoScoreCoarse","name":"Crypto Strength","width":200,"isRightAligned":false}],"filterPairs":[],"columnGroups":[{"id":"connection","name":"Connection","columns":[{"id":"clientAddress","name":"Client IP","width":260},{"id":"serverAddress","name":"Server IP","width":260},{"id":"port","name":"Port","width":80,"isRightAligned":true},{"id":"protocol","name":"Protocol Variants","width":100,"isRightAligned":false},{"id":"cryptoScore","name":"Crypto Level","width":100},{"id":"cryptoScoreCoarse","name":"Crypto Strength","width":200,"isRightAligned":false}]}],"tab":"${view.index.toUpperCase()}","type":"CLUSTER"}`, view.name, curUser.id, false];
    let curView = null;
    try {
        res = await session.query(text, values);
        curView = res.rows[0]
        console.log("view created ")
    } catch (e) {
        console.log("Failed to create view ", e);
        return;
    }
    await createWidgetsInView(session, curUser, config, {...view, ...curView})
}
const createWidgetsInView = async function (session, curUser, config, view) {
    if (view.Widgets) {
        //start of widget creation
        let user = curUser.id;
        let keyName = 'widgets';
        let value = view.Widgets.map((widget) => {
            let visType = view.index.toUpperCase()
            if (visType.substr(-1, 1) === "S") {
                visType = visType.substr(0, visType.length - 1)
            }
            return {
                "visualizationType": visType,
                "filterByView": { "id": view.id, "name": view.name, "__typename": "View" },
                "ratingType": "GOOD"
                , ...widget
            }
        })

        text = 'INSERT INTO  advance."UserPreference"("user","keyName","value") VALUES($1,$2,$3) RETURNING *'
        values = [user, keyName, JSON.stringify(value)];

        let curWidget = null;
        try {
            res = await session.query(text, values);
            curWidget = res.rows[0]
            console.log("widget created ")
        } catch (e) {
            console.log("Failed to create widget ", e);
            return;
        }
    }



}
exports.createWidgetsInView = createWidgetsInView;
const createReportsFromConfig = async function (session, curUser, config) {
    if (config.Reports) {
    //connection report
    text = 'INSERT INTO  advance."CryptoPostureReport"("name", "addedAt", "lastModified","metadata","owner") VALUES($1,$2,$3,$4,$5) RETURNING *'
    values = ["test-report-connection", new Date(), new Date(), JSON.stringify(sampleReportDataConnection), curUser.id];
    try {
        await session.query(text, values);
        console.log("connection report created")
    } catch (e) {
        console.log("Failed to create connection report ", e);
        return;
    }

    //devices report
    text = 'INSERT INTO  advance."CryptoPostureReport"("name", "addedAt", "lastModified","metadata","owner") VALUES($1,$2,$3,$4,$5) RETURNING *'
    values = ["test-report-devices", new Date(), new Date(), JSON.stringify(sampleReportDataDevice), curUser.id];
    try {
        await session.query(text, values);
        console.log("devices report created")
    } catch (e) {
        console.log("Failed to create devices report ", e);
        return;
    }
    }
}
exports.createReportsFromConfig = createReportsFromConfig;
exports.createWidgetFromConfig = async function (session, curUser, config) {
    if (config.Views) {
        await clearWidgetsViews(session, curUser)
        config.Views.map(async (view) => {
            await createView(session, curUser, config, view)
        })
    }
}

const createWidget = async function (session, config) {
    let curUser = await getSampleUser(session);
    let res = null;
    let commonName = 'test-view';
    await clearWidgetsViews(session, curUser)


    text = 'INSERT INTO  advance."View"("addedAt","lastModified","meta","name","owner","shared") VALUES($1,$2,$3,$4,$5,$6) RETURNING *'
    values = [new Date(), new Date(), `{"instantSearch":{"searchState":{"refinementList":{"cryptoStrength":["Strong","Quantum Safe"]},"page":1,"configure":{"hitsPerPage":100,"maxValuesPerFacet":150}},"index":"connections"},"showFilters":true,"showAdvancedSearch":false,"searchTerm":"","columns":[{"id":"clientAddress","name":"Client IP","width":260},{"id":"serverAddress","name":"Server IP","width":260},{"id":"port","name":"Port","width":80,"isRightAligned":true},{"id":"protocol","name":"Protocol Variants","width":100,"isRightAligned":false},{"id":"cryptoScore","name":"Crypto Level","width":100},{"id":"cryptoScoreCoarse","name":"Crypto Strength","width":200,"isRightAligned":false}],"filterPairs":[],"columnGroups":[{"id":"connection","name":"Connection","columns":[{"id":"clientAddress","name":"Client IP","width":260},{"id":"serverAddress","name":"Server IP","width":260},{"id":"port","name":"Port","width":80,"isRightAligned":true},{"id":"protocol","name":"Protocol Variants","width":100,"isRightAligned":false},{"id":"cryptoScore","name":"Crypto Level","width":100},{"id":"cryptoScoreCoarse","name":"Crypto Strength","width":200,"isRightAligned":false}]}],"tab":"CONNECTIONS","type":"CLUSTER"}`, commonName, curUser.id, false];
    let curView = null;
    try {
        res = await session.query(text, values);
        curView = res.rows[0]
        console.log("view created ")
    } catch (e) {
        console.log("Failed to create view ", e);
        return;
    }
    //start of widget creation
    let user = curUser.id;
    let keyName = 'widgets';
    let value = [
        {
            "widgetName": "test-overall",
            "widgetType": "OVERALL", "deltaPeriod": "DAY",
            "visualizationType": "CONNECTION",
            "filterByView": { "id": curView.id, "name": "test-view", "__typename": "View" },
            "group": "CRYPTO_PRIMITIVE_FAMILY", "subgroup": "AES",
            "ratingType": "GOOD"
        },
        {
            "widgetName": "test-rating",
            "widgetType": "RATING", "deltaPeriod": "DAY",
            "visualizationType": "CONNECTION", "filterByView": { "id": curView.id, "name": "test-view", "__typename": "View" },
            "group": "CRYPTO_PRIMITIVE_FAMILY",
            "subgroup": "AES", "ratingType": "GOOD"
        },
        {
            "widgetName": "test-ratio",
            "widgetType": "RATIO",
            "deltaPeriod": "DAY",
            "visualizationType": "CONNECTION",
            "filterByView": { "id": curView.id, "name": "test-view", "__typename": "View" },
            "group": "CRYPTO_PRIMITIVE_FAMILY", "subgroup": "AES", "ratingType": "GOOD"
        }]



    text = 'INSERT INTO  advance."UserPreference"("user","keyName","value") VALUES($1,$2,$3) RETURNING *'
    values = [user, keyName, JSON.stringify(value)];

    let curWidget = null;
    try {
        res = await session.query(text, values);
        curWidget = res.rows[0]
        console.log("widget created ")
    } catch (e) {
        console.log("Failed to create widget ", e);
        return;
    }

    //connection report
    text = 'INSERT INTO  advance."CryptoPostureReport"("name", "addedAt", "lastModified","metadata","owner") VALUES($1,$2,$3,$4,$5) RETURNING *'
    values = ["test-report-connection", new Date(), new Date(), JSON.stringify(sampleReportDataConnection), curUser.id];
    try {
        await session.query(text, values);
        console.log("connection report created")
    } catch (e) {
        console.log("Failed to create connection report ", e);
        return;
    }

    //devices report
    text = 'INSERT INTO  advance."CryptoPostureReport"("name", "addedAt", "lastModified","metadata","owner") VALUES($1,$2,$3,$4,$5) RETURNING *'
    values = ["test-report-devices", new Date(), new Date(), JSON.stringify(sampleReportDataDevice), curUser.id];
    try {
        await session.query(text, values);
        console.log("devices report created")
    } catch (e) {
        console.log("Failed to create devices report ", e);
        return;
    }
}
exports.createWidget=createWidget;