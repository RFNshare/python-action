/**
 * @file connectionsQL.js - 1.2.0 - 3826bc12533e078a8e37cfe70ee04d9e85c8530e
 * 
 * @copyright Copyright (C) 2016-2023, ISARA Corporation, All Rights Reserved.
 * 
 * @license The code and other content set out herein is not in the public
 * domain, is considered a trade secret and is confidential to ISARA
 * Corporation. Use, reproduction or distribution, in whole or in part, of such
 * code or other content is strictly prohibited except by express written
 * permission of ISARA Corporation. Please contact ISARA Corporation at
 * info@isara.com for more information.
 */

/**
 * This module contains Connection focused queries.
 * @module graphql/connectionsQL
 */

var {
    getSort, roles, collectAggregateResults, collectAggregateResultsLikeFacet,postureModifiableTables, postureCheckExistingTables, populateAddedBy,
    updateTagUsedDate, updateDeviceConnectionCounts
} = require('./commonQL')

var {
    postureCategories
} = require('../graphql/categoryConstants')

var {
    makeFilterCategories
} = require('../util/filterCategoryHelpers')

var {
    filterQuery
} = require('./filterQL')

const { allTypes } = require('../isaraql/schemaDiscovery')

const { AdvancedSort } = require('../isaraql/fetch')
const { createUpdateDelete, registerHook, registerTreeHook, CUD_OP_INSERT, CUD_OP_PRE, CUD_OP_POST, CUD_OP_UPDATE,
    CUD_OP_DELETE, CUD_OP_POST_CHILDREN } = require('../isaraql/cud')
const { updateCryptoScoresForConnection, updateCryptoScoresForDevice } = require('../util/scoreHelpers')
const { getCptForRequest } = require('../util/cptHelpers')

async function updateFriendlyName(params, connectionId) {
    let devicePortQuery = (column) => {
        return (
            `SELECT dap.port
            FROM "Connection" c
            JOIN "DeviceAddressPort" dap on dap.id = c."${column}"
            WHERE c.id = ?;`
        )
    }
    let deviceAddressQuery = (column) => {
        return (
            `SELECT da.address
            FROM "Connection" c
            JOIN "DeviceAddressPort" dap on dap.id = c."${column}"
            JOIN "DeviceAddress" da on da.id = dap."deviceAddress"
            WHERE c.id = ?;`
        )
    }

    let updateConnectionQuery = (value) => {
        return (
            `UPDATE "Connection" c
            SET "friendlyName" = '${value}'
            WHERE c.id = ?;`
        )
    }

    if (connectionId) {
        let clientAddressRows = (await params.session.query(
            deviceAddressQuery`clientDeviceAddressPort`,
            [connectionId])
        ).rows
        let clientAddress = (clientAddressRows.length > 0) ? (clientAddressRows[0].address) : '\u2015'
        let serverPortRows = (await params.session.query(
            devicePortQuery`serverDeviceAddressPort`,
            [connectionId])
        ).rows
        let serverPort = (serverPortRows.length > 0) ? (serverPortRows[0].port) : '\u2015'
        let serverAddressRows = (await params.session.query(
            deviceAddressQuery`serverDeviceAddressPort`,
            [connectionId])
        ).rows
        let serverAddress = (serverAddressRows.length > 0) ? (serverAddressRows[0].address) : '\u2015'
        let friendlyName = clientAddress +' \u2192 ' + serverAddress + ' : ' + serverPort
        await params.session.query(
            updateConnectionQuery(`${friendlyName}`),
            [connectionId])
    }
}

async function connectionQuery(fields, request, graphQLState) {
    return connectionFilterQuery(fields, request, graphQLState, [fields.id])
}

/**
 * Main query to see connections.
 * @param {Object} fields fields from GraphQL Query
 * @param {Object} request GrapQL request
 * @param {Object} graphQLState GraphQL State
 * @param {number[]} [ids] Array of IDs to run query for (instead of using a filter)
 */
async function connectionFilterQuery(fields, request, graphQLState, ids) {
    if (!('paging' in fields)) {
        fields.paging = { offset: 0n, limit: 5n }
    }

    var wpcs = { Connection: { paging: fields.paging } }
    if (ids && ids.length !== 0) {
        wpcs.Connection.where = { in: { column: 'id', value: ids } }
    }
    if ('sorting' in fields) {
        wpcs.Connection.sort = await getSort(sortDictionary, fields.sorting)
    }

    return filterQuery('Connection', 'connections', fields.filter, graphQLState, wpcs, fields.asOf, fields.cryptoPostureTemplate, makeMetaAndConnectionSummaries)
}

async function makeMetaAndConnectionSummaries(graphQLResult, wanted, session) {

    let activeCpt = await getCptForRequest()

    if (wanted.meta) {
        await makeConnectionMeta(graphQLResult, wanted, session)
    }

    if (wanted.connectionSummaries) {
        await makeConnectionSummaries(graphQLResult, wanted, session)
    }

    if (wanted.filterCategories) {
        await makeFilterCategories(graphQLResult, postureCategories.CONNECTION, wanted, session, activeCpt)
    }
}

async function makeConnectionMeta(graphQLResult/*, wanted, session*/) {
    graphQLResult.meta = []
}

async function collectConnectionAggregateResults(destinationTable, excludes, includes, connectionIDs, resultsByConnectionID, connectionAttributeName, session) {
    await collectAggregateResults('Connection', destinationTable, excludes, includes, connectionIDs, resultsByConnectionID, connectionAttributeName, session)
}

function filterCiphersuitePrimitives(resultsByConnectionID) {
    for (let [/*_, */value] of Object.entries(resultsByConnectionID)) {
        value.cryptoPrimitives.sort((first, second) => first.name < second.name ? -1 : 1)
        let newPrimitives = []
        for (let i = 0; i < value.cryptoPrimitives.length; i++) {
            if (i === value.cryptoPrimitives.length - 1
                || value.cryptoPrimitives[i + 1].name.indexOf(value.cryptoPrimitives[i].name) !== 0 ) {
                newPrimitives.push(value.cryptoPrimitives[i])
            }
        }
        value.cryptoPrimitives = newPrimitives
    }
}

async function makeConnectionSummaries(graphQLResult, wanted, session) {
    graphQLResult.connectionSummaries = []

    if (graphQLResult.connections.length === 0) {
        return
    }

    var connectionIDs = []
    var resultsByConnectionID = {}
    var connectionSummary = graphQLResult.connectionSummaries
    graphQLResult.connections.forEach(connection => {
        connectionIDs.push(connection.id)
        var resultForSoftwareID = {
            id: connection.id,
            cipherSuites: [], cryptoPrimitives: [], protocols: [], certificateAlgorithms: []
        }
        resultsByConnectionID[connection.id] = resultForSoftwareID
        connectionSummary.push(resultForSoftwareID)
    })

    if (wanted.connectionSummaries.cipherSuites) {
        await collectConnectionAggregateResults('CipherSuite',
            { 'CryptoPrimitive': true, 'Protocol': true }, null,
            connectionIDs, resultsByConnectionID, 'cipherSuites', session)
    }
    if (wanted.connectionSummaries.cryptoPrimitives) {
        await collectConnectionAggregateResults('CryptoPrimitive', null, null,
            connectionIDs, resultsByConnectionID, 'cryptoPrimitives', session)
        // Filter out duplicate ciphersuites
        filterCiphersuitePrimitives(resultsByConnectionID)
    }
    if (wanted.connectionSummaries.protocols) {
        await collectAggregateResultsLikeFacet('Connection', 'Protocol', 'protocol', connectionIDs, resultsByConnectionID, 'protocols', session)
    }
    if (wanted.connectionSummaries.certificateAlgorithms) {
        await collectConnectionAggregateResults('CryptoAlgorithm',
            { 'ConnectionCryptoPrimitive': true, 'ConnectionCipherSuite': true }, { 'CryptoPrimitive': true },
            connectionIDs, resultsByConnectionID, 'certificateAlgorithms', session)
    }
}

const deletableTables = (() => {
    var result = Object.assign({}, postureModifiableTables)
    // Preventing Software deletion as many connections may use this Software - deletion through here is probably unintended.
    delete result.Software
    delete result.SoftwareVersion

    // Preventing Tag deletion as the Tag records are shared.
    delete result.Tag

    result.Agent = true
    result.AgentCertificate = true

    return result
})()

const checkExistingTables = (() => {
    var result = Object.assign({}, postureCheckExistingTables)
    result.Software = true
    result.SoftwareVersion = true
    result.DeviceAddressPort = true
    return result
})()

/**
 * Mutation for creating/updating/deleting Connections and their attributes.
 * @param {Object} fields
 * @param {Object} request
 * @param {Object} graphQLState
 */
async function connectionUpdateMutation(fields, request, graphQLState) {
    var connections = fields.connections
    var config = {
        allowDelete: true,
        allowInsert: true,
        allowUpdate: true,
        checkExistingTables,
        deletableTables,
        modifiableTables: postureModifiableTables
    }
    var ids = await createUpdateDelete('Connection', connections, config)
    return connectionFilterQuery(fields, request, graphQLState, ids)
}

/**
 * This dictionary will hold the SQL fragments needed by `fetch.js` to build a table spanning sort query.
 */
const sortDictionary = {}

/**
 * Builds the sorting dictionary showing `fetch` how to sort for named parameters.
 */
function buildSortDictionary() {
    var commonTagSortJoins = `
    left join
        "ConnectionTag" on "ConnectionTag".connection = "Connection".id
    left join
        "Tag" on "Tag".id = "ConnectionTag".tag and "Tag"."tagType" = ?`

    var commonTagSortOrderBys = `min("Tag".value) %DIR%`

    var tagTypes = allTypes.TagType._enum

    /* Connections have no enums that map to tags, but we put this here in case some are added. */
    for (var name in tagTypes.names) {
        sortDictionary[name] = new AdvancedSort(commonTagSortJoins,
            `"Connection".id`,
            commonTagSortOrderBys,
            tagTypes.idByName[name]
        )
    }

    // All the simple sorts that use a field which exists ON the `Connection` table.
    sortDictionary['ADDED_DATE'] = `"addedAt" %DIR%`
    sortDictionary['NICKNAME'] = `friendlyName %DIR%`
    sortDictionary['SENSITIVITY_OF_DATA'] = 'sensitivity %DIR%'
    sortDictionary['BYTES_TRANSFERRED'] = 'bytesTransferred %DIR%'
    sortDictionary['IMPORTANCE'] = 'importance %DIR%'

    // All the special sorts that have joins.
    var fromSortJoins = `
        LEFT JOIN "DeviceAddressPort" ON "Connection"."clientDeviceAddressPort" = "DeviceAddressPort".id
        LEFT JOIN "DeviceAddress" ON "DeviceAddressPort"."deviceAddress" = "DeviceAddress".id`
    var toSortJoins = `
        LEFT JOIN "DeviceAddressPort" ON "Connection"."serverDeviceAddressPort" = "DeviceAddressPort".id
        LEFT JOIN "DeviceAddress" ON "DeviceAddressPort"."deviceAddress" = "DeviceAddress".id`

    sortDictionary['FROM'] = new AdvancedSort(fromSortJoins,
        [`"Connection".id`, `"DeviceAddress"."friendlyName"`],
        `"DeviceAddress"."friendlyName" %DIR%`,
        null
    )

    sortDictionary['FROM_IP_ADDRESS'] = new AdvancedSort(fromSortJoins,
        [`"Connection".id`, `"DeviceAddress"."addressHex"`, `"DeviceAddressPort".port`],
        `"DeviceAddress"."addressHex" %DIR%`,
        null
    )

    sortDictionary['TO'] = new AdvancedSort(toSortJoins,
        [`"Connection".id`, `"DeviceAddress"."friendlyName"`],
        `"DeviceAddress"."friendlyName" %DIR%`,
        null
    )

    sortDictionary['TO_IP_ADDRESS_AND_PORT'] = new AdvancedSort(toSortJoins,
        [`"Connection".id`, `"DeviceAddress"."addressHex"`, `"DeviceAddressPort".port`],
        [`"DeviceAddress"."addressHex" %DIR%`, `"DeviceAddressPort".port %DIR%`],
        null
    )

    sortDictionary['TO_IP_ADDRESS'] = new AdvancedSort(toSortJoins,
        [`"Connection".id`, `"DeviceAddress"."addressHex"`, `"DeviceAddressPort".port`],
        `"DeviceAddress"."addressHex" %DIR%`,
        null
    )

    sortDictionary['TO_PORT'] = new AdvancedSort(toSortJoins,
        [`"Connection".id`, `"DeviceAddress"."addressHex"`, `"DeviceAddressPort".port`],
        `"DeviceAddressPort".port %DIR%`,
        null
    )
}

function initialise() {
    registerHook('Connection', CUD_OP_INSERT, CUD_OP_PRE, preInsertConnection)
    registerHook('Connection', CUD_OP_INSERT, CUD_OP_POST, postInsertConnection)
    registerHook('Connection', CUD_OP_UPDATE, CUD_OP_PRE, preUpdateConnection)
    registerTreeHook('Connection', CUD_OP_POST_CHILDREN, postWriteConnection)
    registerHook('Connection', CUD_OP_DELETE, CUD_OP_PRE, preDeleteConnection)
    registerHook('Connection', CUD_OP_DELETE, CUD_OP_POST, postDeleteConnection)
    registerHook('Connection', CUD_OP_INSERT, CUD_OP_POST, postUpdateConnection)
    registerHook('Connection', CUD_OP_UPDATE, CUD_OP_POST, postUpdateConnection)
    registerHook('ConnectionTag', CUD_OP_INSERT, CUD_OP_PRE, preWriteConnectionTag)
    registerHook('ConnectionTag', CUD_OP_UPDATE, CUD_OP_PRE, preWriteConnectionTag)
    registerHook('DeviceAddressPort', CUD_OP_INSERT, CUD_OP_PRE, preInsertDeviceAddressPort)
    buildSortDictionary()
}

/**
 * This function will be called before a new Connection is inserted.
 * @param {CUDHook} params
 */
async function preInsertConnection(params) {
    populateAddedBy(params)
}

/**
 * This function will be called after a new Connection is inserted.
 * @param {CUDHook} params
 */
async function postInsertConnection(params) {
    // insert pending score records for all CPTs.
    await params.session.query('WITH cpts AS (SELECT id as score, "cryptoPostureTemplate" as cpt FROM "CryptoScore" WHERE score=?) INSERT INTO "ConnectionScore" (connection, "cryptoScore", "cryptoPostureTemplate") SELECT ?, cpts.score, cpts.cpt FROM cpts',
        [-1, params.record.id])
}

/**
 * This function will be called before a new Connection is updated.
 * @param {CUDHook} params
 */
async function preUpdateConnection(params) {
    populateAddedBy(params)
}




/**
 * This function will be called before a new Connection is updated.
 * @param {CUDHook} params
 */
async function postUpdateConnection(params) {

    let deviceQuery = (column) =>
        (`SELECT device
        FROM "DeviceAddress" where device in (
            SELECT da."device"
            FROM (
                SELECT  dap."deviceAddress" as deviceAddress
                FROM "Connection" c
                JOIN "DeviceAddressPort" dap on c."${column}" = dap.id
                WHERE c.id = ?
        ) as dAddr
        JOIN "DeviceAddress" da ON dAddr.deviceAddress = da."id"
      )`
        )

    if (params.record.id) {
        // Trace back the device id
        let clientDevice = (
            await params.session.query(deviceQuery`clientDeviceAddressPort`,
                [params.record.id]
            )
        ).rows

        let serverDevice = (
            await params.session.query(deviceQuery`serverDeviceAddressPort`,
                [params.record.id]
            )
        ).rows

        if (clientDevice.length > 0) {
            await updateDeviceConnectionCounts(params, clientDevice[0].device, true)
        }

        if (serverDevice.length > 0) {
            await updateDeviceConnectionCounts(params, serverDevice[0].device, false)
        }
    }
}

/**
 * This function will be called after a Connection is inserted or updated.
 * @param {CUDHook} params
 */
async function postWriteConnection(params) {
    // Only initiate a score recalculation if one isn't supplied ; as this field
    // is not exposed for write to graphQL, this will only be the case when the backend is supplying a new score, and we need
    // to avoid calling again in that case, as we will otherwise wind up infinitely recursing to recalculate a new score.
    if (params.record.id) {
        await updateCryptoScoresForConnection(params.record.id, params.session)
    }
    if (params.record.id) {
        await updateFriendlyName(params, params.record.id)
    }
}

/**
 * This function will be called before a Connection is deleted.
 * @param {CUDHook} params
 */
async function preDeleteConnection(params) {
    // Get DeviceAddressPort values
    if (params.record.id) {
        let results = (await params.session.query(`SELECT "clientDeviceAddressPort", "serverDeviceAddressPort" ` +
            `FROM "Connection" WHERE id = ?`, [params.record.id])).rows
        if (results.length > 0) {
            let cryptoScoreUpdate = { server: results[0].serverDeviceAddressPort, client: results[0].clientDeviceAddressPort }
            params.record.deleteConnectionHookData = cryptoScoreUpdate
        }
    }
}

/**
 * This function is called before a DeviceAddressPort is added
 * @param {CUDHook} params
 */
async function preInsertDeviceAddressPort(params) {
    if (!('l4Protocol' in params.record)) {
        params.record['l4Protocol'] = allTypes['Layer4Protocol']._enum.idByName['UNKNOWN']
    }
}

/**
 * This function will be called after a Connection is deleted.
 * @param {CUDHook} params
 */
async function postDeleteConnection(params) {
    let deleteHookData = params.record.deleteConnectionHookData

    // Deleting a device
    if (params.record.rootOp['Device'] === CUD_OP_DELETE) {
        return
    }

    if (deleteHookData && deleteHookData.server) {
        let devicesToUpdate = []
        let results = (await params.session.query(`SELECT da.device AS device ` +
            `FROM "DeviceAddressPort" dap JOIN "DeviceAddress" da ON dap."deviceAddress" = da.id ` +
            `WHERE dap.id = ?`, [deleteHookData.server])).rows
        devicesToUpdate.push(results[0].device)
        await updateDeviceConnectionCounts(params, results[0].device, false)
        if (deleteHookData.client) {
            results = (await params.session.query(`SELECT da.device AS device ` +
                `FROM "DeviceAddressPort" dap JOIN "DeviceAddress" da ON dap."deviceAddress" = da.id ` +
                `WHERE dap.id = ?`, [deleteHookData.client])).rows
            devicesToUpdate.push(results[0].device)
            await updateDeviceConnectionCounts(params, results[0].device, true)
        }
        for (let deviceId of devicesToUpdate) {
            await updateCryptoScoresForDevice(deviceId, params.session)
        }
    }
}

async function preWriteConnectionTag(params) {
    await updateTagUsedDate(params)
}

exports.graphQL = {
    types: `
        enum SortableConnectionFields {
            ADDED_DATE
            BYTES_TRANSFERRED
            FROM
            FROM_IP_ADDRESS
            IMPORTANCE
            NICKNAME
            SENSITIVITY_OF_DATA
            TO
            TO_IP_ADDRESS_AND_PORT
            TO_IP_ADDRESS
            TO_PORT
        }

        input ConnectionSortingInput {
            field: SortableConnectionFields!,
            direction: SortDirection!,
        }

        type ConnectionSummary {
            id: BigInt!
            cipherSuites: [AttributeSummary!]!
            cryptoPrimitives: [AttributeSummary!]!
            protocols: [AttributeSummary!]!
            certificateAlgorithms: [AttributeSummary!]!
        }

        type FilteredConnections {
            paging: Paging!
            connections: [Connection!]!
            connectionSummaries: [ConnectionSummary!]!
            filterCategories: [FilterCategory!]!
            meta: [MetaTag!]!
        }
    `,
    queries: `
        connectionById(
            id: BigInt!
            cryptoPostureTemplate: BigInt
        ): FilteredConnections!

        filteredConnections(
            filter: String
            paging: PagingInput
            sorting: ConnectionSortingInput
            asOf: DateTime
            cryptoPostureTemplate: BigInt
        ) : FilteredConnections!
    `,
    mutations: `
        connectionUpdate(
            connections: [ConnectionInput!]!
        ) : FilteredConnections!
    `,
    root: {
        connectionById: connectionQuery,
        filteredConnections: connectionFilterQuery,
        connectionUpdate: connectionUpdateMutation,
    },
    restrictions: {
        connectionById: [roles.AUTHENTICATED],
        filteredConnections: [roles.AUTHENTICATED],
        connectionUpdate: [roles.AUTHENTICATED],
    },
    initialise
}
