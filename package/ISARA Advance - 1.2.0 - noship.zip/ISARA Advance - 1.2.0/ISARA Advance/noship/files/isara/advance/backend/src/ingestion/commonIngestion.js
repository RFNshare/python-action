/**
 * @file commonIngestion.js - 1.2.0 - 3826bc12533e078a8e37cfe70ee04d9e85c8530e
 * 
 * @copyright Copyright (C) 2016-2023, ISARA Corporation, All Rights Reserved.
 * 
 * @license The code and other content set out herein is not in the public
 * domain, is considered a trade secret and is confidential to ISARA
 * Corporation. Use, reproduction or distribution, in whole or in part, of such
 * code or other content is strictly prohibited except by express written
 * permission of ISARA Corporation. Please contact ISARA Corporation at
 * info@isara.com for more information.
 */

/**
 * This module contains common functionality used by ingestion sources.
 * @module ingestion/commonIngestion
 */

const ipAddress = require('ip-address')
const { fetchNoTree, insertRecord } = require('../isaraql/fetch')
const { buildTableWhereEquals, buildTableWhereIn } = require('../isaraql/whereUtil')
const { allTypes } = require('../isaraql/schemaDiscovery')
const { createUpdateDelete } = require('../isaraql/cud')
const jsrsasign = require('jsrsasign')
const Crypto = require('crypto')
const LazySingleton = require('../util/lazySingleton')
const { matchNetmasks, hasNetmaskZone } = require('./netmaskMatching')
const { PurgingDictionary } = require('../util/purgingDictionary')
const { Session } = require('../isaraql/session')


exports.IngestionStatus = {
    FAILED: 'FAILED',
    SUCCESS: 'SUCCESS',
    PARTIAL_SUCCESS: 'PARTIAL_SUCCESS',
    IN_PROGRESS: 'IN_PROGRESS',
    CANCELLED: 'CANCELLED'
}

exports.IngestionAuthError = class IngestionAuthError {
    constructor(message) {
        this.status = 'AUTH_FAILED'
        this.message = message
    }
}

exports.IngestionCommError = class IngestionCommError {
    constructor(message) {
        this.status = 'COMM_FAILED'
        this.message = message
    }
}

exports.updateTables = {
    Connection: true,
    ConnectionTag: true,
    ConnectionCertificate: true,
    ConnectionProtocolVariantCertificate: true,
    Device: true,
    DeviceAttribute: true,
    DeviceAddress: true,
    DeviceAddressPort: true,
    DeviceMACAddress: true,
    DeviceAddressMACAddress: true,
    DeviceSoftware: true,
    DeviceSoftwareConnection: true,
    SoftwareLibrary: true,
    DeviceSoftwareVersionLibrary: true,
    SoftwareVersion: true,
    Software: true,
    SoftwareVersionTag: true,
    DeviceTag: true,
    Tag: true,
    ConnectionProtocolVariant: true,
    ConnectionCipherSuite: true,
    ConnectionCryptoPrimitive: true,
    ProtocolVariant: true,
    CipherSuite: true,
    CryptoPrimitive: true,
    Certificate: true,
    CertificateCryptoPrimitive: true,
    ConfigurationFileCertificate: true,
    DeviceCertificate: true
}

/**
 * Padding ...
 *
 * @param value The value to be padded.
 * @param digits The number of digits to be padded to.
 * @returns {string} The result of padding.
 */
// For #2261, commented off the following as a piece of unreachable code
// function pad(value, digits) {
//     let toReturn = value.toString(16)
//     while (toReturn.length < digits) {
//         toReturn = '0' + toReturn
//     }
//     return toReturn
// }

/**
 * Returns the type of the address, ip4, ip6.
 *
 * @param address The input address.
 * @returns {number} 4 for ip4 address, 6 for ip6 address, and -1 otherwise.
 */
// For #2261, commented off the following as a piece of unreachable code
// function getIPAddressType(address) {
//     try {
//         return ipToIntArrayAndVersion(address).ipVersion
//     } catch (e) {
//         /* If it is not a valid ip address, it will throw. */
//     }
//     return -1
// }

class IPAddressClassification {
    constructor(address, isIngestible, version, addressType, zoneIn, zoneOut) {
        this.address = address
        this.isIngestible = isIngestible ?? false
        this.version = version ?? null
        this.addressType = addressType ?? null
        this.zoneIn = zoneIn ?? null
        this.zoneOut = zoneOut ?? null
    }
}

/**
 * Types of addresses that can be detected/classified.
 */
const ADDRESS_TYPE = {
    IPv4: 'IPv4',
    IPv6: 'IPv6',
    INVALID: 'Invalid IP Address',
    ADDRESS6TO4: '6to4',
    DISCARD: 'Discard-prefix',
    DOCUMENTATION: 'Documentation',
    LINK_LOCAL: 'Link-local',
    LOOPBACK: 'Loopback',
    MAPPEDv4: 'IPv4-mapped',
    ORCHIDv2: 'ORCHIDv2',
    TEREDO: 'Teredo-tunneling',
    UNSPECIFIED: 'Unspecified-address',
}

exports.ADDRESS_TYPE = ADDRESS_TYPE

/**
 * Types of addresses that can be ingested.
 */
const ACCEPTED_ADDRESS_TYPES = [
    ADDRESS_TYPE.IPv4,
    ADDRESS_TYPE.IPv6,
    ADDRESS_TYPE.MAPPEDv4,
    ADDRESS_TYPE.TEREDO
]

/**
 * How IPv6 address type is determined.
 */
const IPV6_PREDICATES = {}
IPV6_PREDICATES[ADDRESS_TYPE.LOOPBACK] = a6 => a6.isLoopback()
IPV6_PREDICATES[ADDRESS_TYPE.UNSPECIFIED] = a6 => a6.isInSubnet(new ipAddress.Address6('::/128'))
IPV6_PREDICATES[ADDRESS_TYPE.LINK_LOCAL] = a6 => a6.isLinkLocal()
IPV6_PREDICATES[ADDRESS_TYPE.DISCARD] = a6 => a6.isInSubnet(new ipAddress.Address6('100::/64'))
IPV6_PREDICATES[ADDRESS_TYPE.ORCHIDv2] = a6 => a6.isInSubnet(new ipAddress.Address6('2001:20::/28'))
IPV6_PREDICATES[ADDRESS_TYPE.DOCUMENTATION] = a6 => a6.isInSubnet(new ipAddress.Address6('2001:db8::/32'))
IPV6_PREDICATES[ADDRESS_TYPE.ADDRESS6TO4] = a6 => a6.is6to4()
IPV6_PREDICATES[ADDRESS_TYPE.TEREDO] = a6 => a6.isTeredo()
IPV6_PREDICATES[ADDRESS_TYPE.MAPPEDv4] = function (a6) {
    const canonicalForm = a6.canonicalForm()
    for (const prefix of [
        '0000:0000:0000:0000:0000:ffff',    // IPv4-mapped
        '0000:0000:0000:0000:ffff:0000',    // IPv4 translated
        '0064:ff9b:0000:0000:0000:0000',    // IPv4/IPv6 translation
    ]) {
        if (canonicalForm.startsWith(prefix)) return true
    }
    return false
}

/**
 * How IPv6-IPv4 addresses are translated
 */
const IPV6_TRANSLATORS = {}
IPV6_TRANSLATORS[ADDRESS_TYPE.TEREDO] = a6 => a6.inspectTeredo().client4
IPV6_TRANSLATORS[ADDRESS_TYPE.MAPPEDv4] = a6 => a6.to4().address

/**
 * How IPv4 address type is determined.
 */
const IPV4_PREDICATES = {}
IPV4_PREDICATES[ADDRESS_TYPE.UNSPECIFIED] = a4 => a4.isInSubnet(new ipAddress.Address4('0.0.0.0/32'))
IPV4_PREDICATES[ADDRESS_TYPE.LOOPBACK] = a4 => a4.isInSubnet(new ipAddress.Address4('127.0.0.0/8'))
IPV4_PREDICATES[ADDRESS_TYPE.LINK_LOCAL] = a4 => a4.isInSubnet(new ipAddress.Address4('169.254.0.0/16'))

let inspectIPAddressCacheServer = new PurgingDictionary('commonIngestion/inspectServer')
let inspectIPAddressCacheClient = new PurgingDictionary('commonIngestion/inspectClient')
let inspectIPAddressCacheUnknown = new PurgingDictionary('commonIngestion/inspectClient')

function inspectIPAddress(address, whichCache, matchMode) {
    let addressType = ADDRESS_TYPE.INVALID
    let version = null

    if (ipAddress.Address4.isValid(address)) {
        // IPv4
        addressType = ADDRESS_TYPE.IPv4
        version = 4
        let address4 = new ipAddress.Address4(address)
        address = address4.correctForm() // e.g. '001.002.003.004' -> '1.2.3.4'

        for (let type of Object.keys(IPV4_PREDICATES)) {
            if (IPV4_PREDICATES[type](address4)) {
                addressType = type
            }
        }
    } else if (ipAddress.Address6.isValid(address)) {
        // IPv6
        addressType = ADDRESS_TYPE.IPv6
        version = 6
        let address6 = new ipAddress.Address6(address)
        address = address6.correctForm() // e.g. 'fc00:0000:0000:0000:0000:0000:dead:beef' -> 'fc00::dead:beef'

        for (let type of Object.keys(IPV6_PREDICATES)) {
            if (IPV6_PREDICATES[type](address6)) {
                addressType = type
                if (IPV6_TRANSLATORS[type]) {
                    return whichCache.put(address, inspectIPAddress(IPV6_TRANSLATORS[type](address6), whichCache, matchMode))
                }
                break
            }
        }
    }

    let netmaskMatchedAddress = matchNetmasks(address, matchMode)
    let zoneIn = !matchMode.isServer && hasNetmaskZone(netmaskMatchedAddress,matchMode)
    let zoneOut = matchMode.isServer && hasNetmaskZone(netmaskMatchedAddress,matchMode)
    const ret = whichCache.put(address, new IPAddressClassification(
        netmaskMatchedAddress,
        ACCEPTED_ADDRESS_TYPES.includes(addressType),
        version,
        addressType,
        zoneIn && zoneIn,
        zoneOut && zoneOut))
    return ret
}

/**
 *
 * @param {String} address
 * @param {NetmaskMatchMode} netmaskMatchMode
 * @returns {IPAddressClassification}
 */
function inspectIPAddressCached(address, netmaskMatchMode) {
    if (!netmaskMatchMode) {
        throw new Error('NetmaskMatchMode required')
    }
    const isServer = netmaskMatchMode.isServer
    const whichCache = isServer === undefined ? inspectIPAddressCacheUnknown : (isServer ? inspectIPAddressCacheServer : inspectIPAddressCacheClient)
    return whichCache.get(address) ?? inspectIPAddress(address, whichCache, netmaskMatchMode)
}

exports.inspectIPAddress = inspectIPAddressCached

/**
 * Selects rows from a database table, using a specified set of key-value parameters.
 * @param {String} table The table from which to select.
 * @param {Object} values The key-values to build the where clause.
 * @param {Session} session The database session to use.
 */
async function selectByLooks(table, values, session) {
    let where = buildTableWhereEquals(table, values)
    let results = await fetchNoTree(table, where, session)
    results.map(r => {
        if (r.addedBy !== undefined) {
            // Remove addedBy property, as it can't be updated
            delete r.addedBy
        }
    })
    return results
}
exports.selectByLooks = selectByLooks

async function selectByLooksIn(table, values, session) {
    let where = buildTableWhereIn(table, values)
    return await fetchNoTree(table, where, session)
}

/**
 * Sets an object's specified key-value, assuming the value is not falsy or an empty string.
 * @param {Object} obj The object to set the key-value on.
 * @param {String} key The key to set.
 * @param {*} val The value to set.
 */
exports.setIfNotEmpty = function (obj, key, val) {
    if (val && val !== '') {
        obj[key] = val
    }
}

/**
 * Looks up or creates a device by MAC Address, Name, IP Address.
 * @param {Session} session The database session to use.
 * @param {String} deviceName The device name to look up or create.
 * @param {String[]} ipAddresses The IP Addresses to lookup.
 * @param {String[]} macAddresses The MAC Addresses to lookup.
 */
exports.findExistingOrCreateDevice = async function (session, deviceName, ipAddresses, macAddresses) {
    // TODO: GAP1613 - this function should be refactored to submit a CUD graph instead of mostly duplicating its functionality. NB:
    // this is important because the existing implementation will bypass CUD hooks, which will lead to a lot of required ops
    // not being performed such as score calculations and panel cache rebuilds.
    let existingDevice = null

    if (macAddresses && macAddresses.length > 0) {
        let deviceMacAddresses = await selectByLooksIn('DeviceMACAddress', { mac: macAddresses }, session)
        if (deviceMacAddresses.length >= 1) {
            let id = deviceMacAddresses[0].device
            existingDevice = (await selectByLooks('Device', { id }))[0]
        }
    }

    if (!existingDevice && deviceName && deviceName !== '') {
        let devices = await selectByLooks('Device', { friendlyName: deviceName }, session)
        if (devices.length === 1) {
            existingDevice = devices[0]
        }
    }

    if (!existingDevice && ipAddresses && ipAddresses.length > 0) {
        let deviceAddresses = await selectByLooksIn('DeviceAddress', { address: ipAddresses }, session)
        if (deviceAddresses.length >= 1) {
            let id = deviceAddresses[0].device
            existingDevice = (await selectByLooks('Device', { id }))[0]
        }
    }

    if (!existingDevice) {
        if (!deviceName && (!ipAddresses || !ipAddresses.length) && (!macAddresses || !macAddresses.length)) {
            throw 'Cannot lookup or create device without Name or Addresses specified.'
        } else {
            // TODO: GAP1613 - Create a device
            if (!deviceName) {
                deviceName = ''
            }
            let deviceToInsert = {
                friendlyName: deviceName,
                deviceType: allTypes['DeviceType']._enum.idByName['UNKNOWN'],
                //addedBy: request.user.uid, , // TODO: GAP1613 - Fix added by.
                lastTimeOnline: new Date() // TODO: GAP1613 - Fix lastTimeOnline.

            }

            await createUpdateDelete('Device', [deviceToInsert], {
                allowInsert: true,
                populateIDs: true,
                modifiableTables: {
                    Device: true
                },
                session
            })
            existingDevice = deviceToInsert
        }
    }

    return existingDevice
}

/**
 * Fills in tags to apply to the object in question if applicable.
 *
 * @param {string} baseObject The object to which to attach a tag association array.
 * @param {string} fieldName The name of the array (should match the corresponding association table in the database)
 * @param {undefined|null|Object[]} tags The set of tags to insert into the array. No array is created if null/empty.
 *
 */
function populateTags(baseObject, fieldName, tags) {
    if (!tags || tags.length === 0) {
        return
    }

    if (baseObject[fieldName] === undefined) {
        baseObject[fieldName] = []
    }

    for (let tag of tags) {
        baseObject[fieldName].push({ tag: tag.tag.id })
    }
}

exports.populateTags = populateTags

/**
 * Looks up or creates an operating system version.
 * @param {Session} session The database session to use.
 * @param {Object} platform The operating system platform. (Should be one of the osVendors defined below.)
 * @param {String} versionName The common name for the version.
 * @param {String} versionString The string formally denoting the version.
 * @param {Object[]|null} tags The IDs of the Tags to associate with all Devices, Connections, and Software.
 */
exports.findExistingOrCreateOSVersion = async function (session, platform, versionName, versionString, tags) {
    // TODO: GAP1613 - this function should be refactored to submit a CUD graph instead of mostly duplicating its functionality. NB:
    // this is important because the existing implementation will bypass CUD hooks, which will lead to a lot of required ops
    // not being performed such as score calculations and panel cache rebuilds.

    let { name: osName, vendor: osVendor = 'Unknown Operating System Vendor' } = platform
    const osVendors = {
        'AIX': 'IBM Corp.',
        'Linux': 'Open Source',
        'MacOS': 'Apple Inc.',
        'Solaris': 'Oracle Corp.',
        'Windows': 'Microsoft Corp.'
    }
    for (const name in osVendors) {
        if (name.toLowerCase().startsWith(osName.toLowerCase())) {
            osName = name
            osVendor = osVendors[name]
        }
    }
    const softwareTypeId = allTypes['SoftwareType']._enum.idByName['OS']

    let software = null
    let softwares = await selectByLooks('Software', { name: osName, softwareType: softwareTypeId }, session)
    if (softwares.length === 0) {
        let softwareToInsert = {
            name: osName,
            softwareVendor: osVendor,
            softwareType: softwareTypeId
        }
        let result = await insertRecord('Software', softwareToInsert, session)
        if (result.affectedRows !== 1) {
            throw `Failed to create operating system software: ${osName}`
        }
        software = (await selectByLooks('Software', { id: result.id }, session))[0]
    } else if (softwares.length === 1) {
        software = softwares[0]
    } else {
        throw `Multiple operating systems by the same name: ${osName}`
    }

    let softwareVersion = null
    let softwareVersions = await selectByLooks('SoftwareVersion', { software: software.id, version: versionString }, session)
    if (softwareVersions.length === 0) {
        let softwareVersionToInsert = {
            software: software.id,
            name: versionName,
            version: versionString,
            sortableVersion: -1 // TODO: GAP1613 - Fix sortableVersion
        }
        let result = await insertRecord('SoftwareVersion', softwareVersionToInsert, session)
        if (result.affectedRows !== 1) {
            throw `Failed to create operating system software version: ${versionName}`
        }
        softwareVersion = (await selectByLooks('SoftwareVersion', { id: result.id }, session))[0]
    } else if (softwareVersions.length === 1) {
        softwareVersion = softwareVersions[0]
    } else {
        throw `Multiple instances of the same operating system version: ${versionString}`
    }

    if (tags) {
        for (let tag of tags) {
            let tagLookup = { softwareVersion: softwareVersion.id, tag: tag.tag.id }
            let softwareTags = await selectByLooks('SoftwareVersionTag', tagLookup, session)
            if (softwareTags.length === 0) {
                let result = await insertRecord('SoftwareVersionTag', tagLookup, session)
                if (result.affectedRows !== 1) {
                    throw `Failed to create operating system software version tag: ${tag.id}`
                }
            }
        }
    }

    return softwareVersion
}

/**
 * Finds the existing certificate if it already exists so can be updated
 * @param {String} contentHash The hash of the certificate content to find.
 * @param {Session} session The database session to use.
 */
exports.findExistingCertificate = async function (contentHash, session) {
    let existingCertificate = {}

    if (contentHash !== '') {
        existingCertificate = await selectByLooks('Certificate', { contentHash: contentHash }, session)
        if (existingCertificate.length === 1) {
            return existingCertificate[0]
        }
    }
    return existingCertificate
}

/**
 * Normalizes a specified MAC Address to the expected internal format.
 * @param {String} mac The MAC Address to normalize.
 */
exports.normalizeMacAddress = function (mac) {
    if (mac) {
        return mac.replace(/-/g, ':').toLowerCase()
    }
    return null
}

/**
 * Validates a prefixed measure of units to be in an acceptable format.
 * Examples:
 *  units hz: 2000MHz, 800 K, 2400hz, 1200000
 *  units b: 16GB, 2 g, 1024B, 2048
 * @param {string} prefixed
 * @param {string} units The unit suffix pattern.
 * @returns true if pattern matches, otherwise false.
 */
exports.validatePrefixedUnit = function (prefixed, units) {
    return prefixed.match(new RegExp(`^(\\d+(\\.\\d+)?) ?(k|m|g|t|p|e)?(${units})?$`, 'i')) !== null
}

/**
 * Converts a prefixed measure of units to the unprefixed value, eg: 2300 MHz => 2300000000
 * @param {string} prefixed The value to convert.
 * @param {number} scale The scale to convery by. Defaults to 1024.
 */
exports.normalizePrefixedUnit = function (prefixed, scale) {
    scale = scale || 1024
    let regex = /(\d+(\.\d+)?) ?(k|m|g|t|p|e)?/i
    let regexMatches = regex.exec(prefixed)
    // A value was not specified
    if (!regexMatches || regexMatches.length < 2) {
        return prefixed
    }

    // No prefix found
    if (regexMatches.length < 4 || !regexMatches[3]) {
        return regexMatches[1]
    }

    let exponentMap = {
        'k': 1,
        'm': 2,
        'g': 3,
        't': 4,
        'p': 5,
        'e': 6,
    }
    let prefixedValue = parseFloat(regexMatches[1])
    let expandedValue = prefixedValue * scale ** exponentMap[regexMatches[3].toLowerCase()]
    return expandedValue.toString()
}

/**
 * Creates a Pending Scan Results entry in the database for a specified Scan.
 * @param {Object} scan The object representing the Data Source Scan.
 * @returns An object representing the Scan Results (only contains the id and runAt time)
 */
exports.createPendingScanResults = async function (scan) {
    let tables = {
        DataSourceScanResult: true
    }
    let config = {
        allowDelete: false,
        allowInsert: true,
        allowUpdate: false,
        deletableTables: {},
        modifiableTables: tables,
        checkExistingTables: tables
    }

    let dataSourceScanResult = {
        dataSourceScan: {
            id: scan.id
        },
        friendlyName: scan.friendlyName,
        runBy: scan.addedBy?.id,
        runAt: new Date(),
        summary: '',
        status: allTypes['DataSourceScanResultStatus']._enum.idByName['IN_PROGRESS']
    }

    if (dataSourceScanResult.runBy == null) { // check for undefined or null
        delete dataSourceScanResult.runBy
    }
    let ids = await createUpdateDelete('DataSourceScanResult', [dataSourceScanResult], config)
    return {
        id: ids[ids.length - 1],
        runAt: dataSourceScanResult.runAt
    }
}

/**
 * Updates the status of a Scan Results entry in the database.
 * @param {Object} results The Scan Results object to update in the database.
 * @param {string} errorMessage The status to set in the database.
 * @param {object|string} error The error message or exception object.
 */
exports.updateScanResults = async function (results, status, error) {
    let tables = {
        DataSourceScanResult: true
    }
    let config = {
        allowDelete: false,
        allowInsert: false,
        allowUpdate: true,
        deletableTables: {},
        modifiableTables: tables,
        checkExistingTables: tables
    }

    results.duration = new Date().getTime() - results.runAt.getTime()

    if (error) {
        if (typeof error === 'object') {
            if (error.response) {
                results.errorMessage = error.response.data.text || error.message
            } else if (error.message) {
                results.errorMessage = error.message
            } else {
                results.errorMessage = JSON.stringify(error)
            }
        } else if (typeof error === 'string') {
            results.errorMessage = error
        }
    }
    results.status = allTypes['DataSourceScanResultStatus']._enum.idByName[status]
    await createUpdateDelete('DataSourceScanResult', [results], config)
}

/**
 * Updates the summary of a Scan Results entry in the database.
 * @param {Object} results The Scan Results object to update in the database.
 * @param {string} summary The summary to set in the database.
 * @param {Session} session The database session to use.
 */
exports.updateScanResultSummary = async function (results, summary, session) {
    const dbSession = new Session()
    let tables = {
        DataSourceScanResult: true
    }
    let config = {
        allowDelete: false,
        allowInsert: false,
        allowUpdate: true,
        deletableTables: {},
        modifiableTables: tables,
        checkExistingTables: tables,
        session
    }
    const [scanResult] = (
        await dbSession.query(
            `SELECT id, summary, status from "advance"."DataSourceScanResult" WHERE id = ${results.id};`
        )
    ).rows
    if(Number(scanResult.status) === 5) {
        summary = scanResult.summary ? scanResult.summary.concat(',@', 'Process is canceled.') : 'Process is canceled.'

        await createUpdateDelete('DataSourceScanResult', [{ id: results.id, summary }], config)
        process.exit()
    }
    summary = scanResult.summary ? scanResult.summary.concat(',@', summary) : summary

    await createUpdateDelete('DataSourceScanResult', [{ id: results.id, summary }], config)
}

/**
 * Creates a Result Detail in the database associated with a specified Result.
 * @param {object} results The result object to associate with the Details.
 * @param {string} message The message explaining why the record could not be processed.
 * @param {string} recordId A unique-ish identifier for the record.
 * @param {string} recordType The type of record being processed. Will vary by Data Source.
 * @param {object} recordData The record that failed to be processed.
 */
exports.reportResultDetail = async function (results, message, recordId, recordType, recordData) {
    let config = {
        allowDelete: false,
        allowInsert: true,
        allowUpdate: false,
        deletableTables: {},
        modifiableTables: { DataSourceScanResultDetail: true },
        checkExistingTables: { DataSourceScanResult: true }
    }
    let details = {
        dataSourceScanResult: { id: results?.id },
        when: new Date(),
        recordId,
        message,
        recordType,
        recordData: JSON.stringify(recordData),
    }
    await createUpdateDelete('DataSourceScanResultDetail', [details], config)
}

const HOUR_IN_MSEC = 60 * 60 * 1000

/**
 *
 * @param {string} timestamp milisecond timestamp, optionally with fractional component for microseconds.
 *
 * @returns {Date} A date object representing the input time truncated to the hour. This sets the floor for our observations
 * for the purposes of aggregation (i.e. all observations within the same hour can be combined/batched)
 */
exports.getRoundedObservationTime = function (timestamp) {
    // step 1: round up because extrahop technically returns a microsecond timestamp
    // in msec.xxx format. Since Date() cannot deal with the higher precision,
    // and it really doesn't matter, discard it.
    let roundedTime = Math.round(timestamp)

    // step 2: truncate to hour granularity. We really don't need anything finer for observation purposes.
    roundedTime -= roundedTime % HOUR_IN_MSEC
    return new Date(roundedTime)
}


const oidToId = new LazySingleton(async () => {
    let primitives = allTypes['CryptoPrimitive']._enum.detailsByID
    let oidToId = {}
    for (let primitive of Object.values(primitives)) {
        // map oid and variant info to crypto primitive
        if (primitive.oid) {
            oidToId[primitive.oid] = oidToId[primitive.oid] ? oidToId[primitive.oid] : {}
            oidToId[primitive.oid][primitive.variant ? primitive.variant : 'None'] = primitive.id
        }
    }
    return oidToId
})


/**
 *
 * @param {string} certData pem input format of the certificate to parse
 * @param {Object} oidToId Lazy singleton function to convert algorithm oid to id in database.
 *
 * @returns {Object} The certificate that was parsed in graphql format to link to a device
 */

exports.parseAndInsertCertificates = async function (certData) {

    // Store in the form [size, primitive] where primitive is the primitive name to insert into the database.
    let cryptoPrimitives = []

    let cert = new jsrsasign.X509()
    cert.readCertPEM(certData)


    let basicKeyInfo = jsrsasign.X509.getPublicKeyInfoPropOfCertPEM(certData)
    let oid = jsrsasign.KJUR.asn1.ASN1Util.oidHexToInt(basicKeyInfo.algoid)
    let curve = basicKeyInfo.algparam ? jsrsasign.KJUR.asn1.ASN1Util.oidHexToInt(basicKeyInfo.algparam) : null
    const oidToIdResults = await oidToId.get()
    const standardRSA = [512, 1024, 2048, 3072, 4096, 6000]
    const standardDSAKeyLengthModulus = { 1024: [160], 2048: [224, 256], 3072: [256], 7680: [384], 15360: [512] }
    const standardDSA = Object.keys(standardDSAKeyLengthModulus).map(Number)

    try {
        let publicKey = cert.getPublicKey()
        if (publicKey.n !== undefined) {         // check if it has n field obj then it is RSA
            let size_unrounded = publicKey.n.bitLength()
            let closest = standardRSA.reduce((prev, curr) => {
                return Math.abs(curr - size_unrounded) < Math.abs(prev - size_unrounded) ? curr : prev
            })
            let size = closest > size_unrounded ? standardRSA[standardRSA.indexOf(closest) - 1] : closest
            if (standardRSA.includes(size_unrounded)) {
                cryptoPrimitives.push([undefined, `RSA_SIG_${size}`])
            }
            else {
                if (size_unrounded < standardRSA[0]) {
                    cryptoPrimitives.push([`${size_unrounded}`, `RSA_SIG_${standardRSA[0]}`])
                } else {
                    cryptoPrimitives.push([`${size_unrounded}`, `RSA_SIG_${size}`])
                }
            }
        } else if (publicKey.q !== undefined) {
            let p_size_unrounded = publicKey.p.bitLength()
            let closest = standardDSA.reduce((prev, curr) => {
                return Math.abs(curr - p_size_unrounded) < Math.abs(prev - p_size_unrounded) ? curr : prev
            })
            let p_size = closest > p_size_unrounded ? standardDSA[standardDSA.indexOf(closest) - 1] : closest
            let q_size = publicKey.q.bitLength()
            if (standardDSA.includes(p_size_unrounded)) {
                if (standardDSAKeyLengthModulus[p_size_unrounded].includes(q_size)) {
                    cryptoPrimitives.push([undefined, `DSA_DSS_${p_size}_${q_size}`])
                } else {
                    cryptoPrimitives.push([`${p_size},${q_size}`, `DSA_DSS_${p_size}_${standardDSAKeyLengthModulus[p_size_unrounded][0]}`])
                }
            } else {
                if (p_size_unrounded < standardDSA[0]) {
                    cryptoPrimitives.push([`${p_size_unrounded},${q_size}`, `DSA_DSS_${standardDSA[0]}_${standardDSAKeyLengthModulus[standardDSA[0]][0]}`])
                } else {
                    cryptoPrimitives.push([`${p_size_unrounded},${q_size}`, `DSA_DSS_${p_size}_${standardDSAKeyLengthModulus[p_size][0]}`])
                }
            }
        } else if (publicKey.ecparams !== undefined) {
            cryptoPrimitives.push([undefined, oidToIdResults[oid][curve]])
            cryptoPrimitives[cryptoPrimitives.length - 1][1] = allTypes.CryptoPrimitive._enum.nameByID[cryptoPrimitives[cryptoPrimitives.length - 1][1]]
        } else {
            // If not one of the public key/ECC algorithms we support or non-public key/not ECC algorithm we use the oid to look it up.
            throw 'error'
        }
    } catch (e) {
        // check to see if we have stored the oid in db if we can't find it then crypto primitive is unknown so we don't add one
        if (oidToIdResults[oid]) {
            if (oidToIdResults[oid][curve]) {
                cryptoPrimitives.push([undefined, oidToIdResults[oid][curve]])
            } else {
                cryptoPrimitives.push([undefined, oidToIdResults[oid]['None']])
            }
            cryptoPrimitives[cryptoPrimitives.length - 1][1] = allTypes.CryptoPrimitive._enum.nameByID[cryptoPrimitives[cryptoPrimitives.length - 1]]
        }
    }

    // TODO: GAP1613 - Get signature algorithm into crypto primitive
    // Can parse name returned by cert.getSignatureAlgorithmField() (which will return name or oid if not known to module)
    // To get size will have to look at parent cert
    // TODO: GAP370 - Parse certificate chains


    // compute hash and populate the certificate to add to device
    let contentHash = Crypto.createHash('sha256')
    contentHash.update(certData)

    let certificateToInsert = {}

    certificateToInsert.certificateContent = certData
    certificateToInsert.contentHash = contentHash.digest().toString('hex')
    certificateToInsert.issuer = cert.getIssuerString()
    certificateToInsert.subject = cert.getSubjectString()

    // Assume X509 for now.
    // TODO: GAP370 - Differentiate between normal X509 and catalyst (including parsing catalyst specific extensions)
    certificateToInsert.certificateType = 'X509'
    certificateToInsert.certificateCryptoPrimitives = cryptoPrimitives.map(primitive => {
        // check if has a key size/length
        if (primitive[0]) {
            return {
                certificate: certificateToInsert,
                cryptoPrimitive: primitive[1],
                keyLength: primitive[0]
            }
        }

        return {
            certificate: certificateToInsert,
            cryptoPrimitive: primitive[1],
        }

    })

    return certificateToInsert
}
