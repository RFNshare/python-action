/**
 * @file scheduler.js - 1.2.0 - 3826bc12533e078a8e37cfe70ee04d9e85c8530e
 * 
 * @copyright Copyright (C) 2016-2023, ISARA Corporation, All Rights Reserved.
 * 
 * @license The code and other content set out herein is not in the public
 * domain, is considered a trade secret and is confidential to ISARA
 * Corporation. Use, reproduction or distribution, in whole or in part, of such
 * code or other content is strictly prohibited except by express written
 * permission of ISARA Corporation. Please contact ISARA Corporation at
 * info@isara.com for more information.
 */

/**
 * This module is for scheduling Jobs in the system.
 * @module util/scheduler
 */

const { CronJob } = require('cron')
const log = require('../util/log')(module)

/**
 * Contains all the Jobs registered in the Scheduler.
 */
const allJobs = {}

/**
 * Schedules a Job to be run.
 * @param {string} id A uniquely identifying ID for the Job.
 * @param {string} cronTime A Cron-style schedule string.
 * @param {string} timezone The timezone used for scheduling.
 * @param {function} job The job object to schedule.
 */
async function scheduleJob(id, cronTime, timezone, job) {
    if (allJobs[id]) {
        await cancelJob(id)
    }

    try {
        log.d(`Scheduling '${id}' to run at '${cronTime} (${timezone})'`)
        let cronJob = new CronJob(cronTime, job, null, true, timezone)
        allJobs[id] = cronJob
        return true
    } catch (e) {
        log.e(`Failed to schedule job '${id}' at '${cronTime} (${timezone})' with error '${e.message}'`)
        return false
    }
}

/**
 * Cancels a Job.
 * @param {string} id The ID of the Job to cancel.
 */
async function cancelJob(id) {
    if (allJobs[id]) {
        log.d(`Unscheduling '${id}'`)
        allJobs[id].stop()
        delete allJobs[id]
        return true
    }
    log.d(`Failed to unschedule '${id}'`)
    return false
}

exports.scheduleJob = scheduleJob
exports.cancelJob = cancelJob
