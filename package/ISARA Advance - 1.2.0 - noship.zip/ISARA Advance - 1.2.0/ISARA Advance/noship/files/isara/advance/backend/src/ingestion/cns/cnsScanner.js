/**
 * @file cnsScanner.js - 1.2.0 - 3826bc12533e078a8e37cfe70ee04d9e85c8530e
 * 
 * @copyright Copyright (C) 2016-2023, ISARA Corporation, All Rights Reserved.
 * 
 * @license The code and other content set out herein is not in the public
 * domain, is considered a trade secret and is confidential to ISARA
 * Corporation. Use, reproduction or distribution, in whole or in part, of such
 * code or other content is strictly prohibited except by express written
 * permission of ISARA Corporation. Please contact ISARA Corporation at
 * info@isara.com for more information.
 */

/**
 * This module is the CNS Scanner for ingesting data produced by CNS.
 * @module ingestion/cns/cnsScanner
 */
const fs = require('fs')
const fse = require('fs-extra')
const os = require('os')
const path = require('path')
const jsrsasign = require('jsrsasign')
const isMac = require('is-mac')

const log = require('../../util/log')(module)
const { processCsvStream, getField } = require('../csvIngestionHelper')
const { CommonUpserters } = require('../commonUpserters')
const { Session } = require('../../isaraql/session')
const cryptoDataCache = require('../cryptoDataCache')
const { NetmaskMatchModes, hasNetmaskZone } = require('../netmaskMatching')
const {
    IngestionStatus,
    inspectIPAddress,
    normalizeMacAddress,
    updateScanResultSummary
} = require('../commonIngestion')

const STATUS_UPDATE_PERIOD = 100000
const CERT_CACHE_SIZE = 10000
const CERT_PURGE_WATERMARK = 8000

let cacheMaps = {
    curveOIDMap: {},
    certFingerprintMap: new Map(),
}

function processCertificate(row, cryptoPrimitivesToAdd, cryptoPrimitivesHandledVague, parsedMetadata, connectionID, isClientCert) {
    let certChain

    if (isClientCert) {
        certChain = getField(row, 'ClientCertificateChain')
    } else {
        certChain = getField(row, 'ServerCertificateChain')
    }

    if (!certChain) {
        // No cert-chain available.
        return
    }

    let certs = certChain.split(':')

    // At this point, we are only interested in entity certs.
    let certFingerprint = certs[0]
    if (!certFingerprint || certFingerprint.length < 40) {
        // Entity-cert fingerprint (which is produced by SHA1 or better) is malformed.
        log.e(`Entity-cert fingerprint ${certFingerprint} is incorrect.`)
        return
    }

    // If we have encountered this cert before, get the parsed result from
    // cache, instead of parsing and processing the cert again.
    if (cacheMaps.certFingerprintMap.has(certFingerprint)) {
        let cacheEntry = cacheMaps.certFingerprintMap.get(certFingerprint)

        if (!cacheEntry.vague || !cacheEntry.precise) {
            // If the cached crypto primitives for this cert is incomplete,
            // proceed to parsing the cert.
        } else {
            if (!isClientCert) {
                cryptoPrimitivesHandledVague.add(cacheEntry.vague)
            }

            cryptoPrimitivesToAdd.add([cacheEntry.publicKeyCryptoPrimitive, cacheEntry.publicKeyCryptoPrimitiveParameter])

            return {
                ...connectionID,
                certificateType: 'X509',
                manuallyAdded: false,
                fingerprint: certFingerprint,
                notBefore: cacheEntry.notBefore,
                notAfter: cacheEntry.notAfter,
                issuer: cacheEntry.issuer,
                subject: cacheEntry.subject,
                serial: cacheEntry.serial,
                publicKeyCryptoPrimitive: cacheEntry.publicKeyCryptoPrimitive,
                publicKeyCryptoPrimitiveParameter: cacheEntry.publicKeyCryptoPrimitiveParameter,
                issuerSigAndHash: cacheEntry.issuerSigAndHash,
            }
        }
    }

    // The first 2 hex in the fingerprint is the first level directory.
    // And, the second 2 hex in the fingerprint is the second level directory.
    // The certificate sits under the second level directory.
    let level1Dir = certFingerprint.substring(0, 2)
    let level2Dir = certFingerprint.substring(2, 4)

    let certDir = path.join(parsedMetadata.dataDir, level1Dir, level2Dir)

    if (!fs.existsSync(certDir)) {
        log.e(`${certFingerprint}: Certificate directory "${certDir}" does not exist.`)
        return
    }

    let files = fs.readdirSync(certDir)
    if (!files) {
        log.e(`${certFingerprint}: Failed to access the certificate directory "${certDir}".`)
        return
    }

    let certName = certFingerprint + '.pem'

    if (!files.includes(certName)) {
        log.e(`${certFingerprint}: Failed to find certificate file "${certName}" under certificate directory "${certDir}".`)
        return
    }

    let certPath = path.join(certDir, certName)
    let certDataPEM = fs.readFileSync(certPath, 'utf8')
    if (!certDataPEM) {
        log.e(`${certFingerprint}: Failed to read cert file "${certPath}".`)
        return
    }

    // Subject public key algorithm OID map as per RFC3279 and RFC8410.
    let certOIDMap = {
        '1.2.840.113549.1.1.1': 'RSA_SIG',
        '1.2.840.10045.2.1': 'ECDSA',
        '1.2.840.10040.4.1': 'DSA',
        '1.3.101.112': 'ECDSA_ED25519',
        '1.3.101.113': 'ECDSA_ED448',
        '1.2.840.113549.2.9':'SHA-256',
        '1.2.840.113549.1.1.4':'MD5-RSA'
    }

    try {
        // Parse the certificate:

        let entityCert = new jsrsasign.X509()
        entityCert.readCertPEM(certDataPEM)

        let entityCertSerial = entityCert.getSerialNumberHex()
        let entityCertIssuer = entityCert.getIssuerString()
        let entityCertSubject = entityCert.getSubjectString()
        let entityCertSigName = entityCert.getSignatureAlgorithmName()

        // Parse cert UTCTime as per RFC5280 section 4.1.2.5.1.
        let notBefore = entityCert.getNotBefore()
        let tmpYear = parseInt(notBefore.substring(0, 2))
        let fullYear = tmpYear >= 50 ? '19' + tmpYear : `20` + tmpYear
        let tmpDate = `${fullYear}.${notBefore.substring(2, 4)}.${notBefore.substring(4, 6)}`
        let entityCertNotBefore = (new Date(tmpDate)).toISOString()

        let notAfter = entityCert.getNotAfter()
        tmpYear = parseInt(notAfter.substring(0, 2))
        fullYear = tmpYear >= 50 ? '19' + tmpYear : `20` + tmpYear
        tmpDate = `${fullYear}.${notAfter.substring(2, 4)}.${notAfter.substring(4, 6)}`
        let entityCertNotAfter = (new Date(tmpDate)).toISOString()

        let entityCertPubkeyInfo = jsrsasign.X509.getPublicKeyInfoPropOfCertPEM(certDataPEM)
        if (!entityCertPubkeyInfo) {
            log.e(`${certFingerprint}: Failed to get entity certificate public key info.`)
            return
        }

        let algOID
        if (entityCertPubkeyInfo.algoid) {
            algOID = jsrsasign.KJUR.asn1.ASN1Util.oidHexToInt(entityCertPubkeyInfo.algoid)
            if (!Object.keys(certOIDMap).includes(algOID)) {
                log.e(`${certFingerprint}: Failed to identify entity certificate public key algorithm.`)
                return
            }
        }

        let entityCertPubkey
        let cryptoAlgo
        let pubKeyCryptoPrimitive
        let pubKeyCryptoPrimitiveParam
        let tmpArr

        switch (certOIDMap[algOID]) {
            case 'RSA_SIG': {
                entityCertPubkey = entityCert.getPublicKey()

                if (!entityCertPubkey) {
                    log.e(`${certFingerprint}: Failed to get RSA public key.`)
                    return
                }

                if (!entityCertPubkey.n) {
                    log.e(`${certFingerprint}: Failed to get RSA modulus.`)
                    return
                }

                let rsaKeySize = entityCertPubkey.n.bitLength()
                tmpArr = cryptoDataCache.cryptoPrimitiveLookup(certOIDMap[algOID], rsaKeySize)

                pubKeyCryptoPrimitive = tmpArr.primitiveName
                pubKeyCryptoPrimitiveParam = tmpArr.nonRegularSize

                cryptoAlgo = certOIDMap[algOID]
            }

                break
            case 'ECDSA': {
                let curveOID
                if (entityCertPubkeyInfo.algparam) {
                    curveOID = jsrsasign.KJUR.asn1.ASN1Util.oidHexToInt(entityCertPubkeyInfo.algparam)
                    if (!curveOID) {
                        log.e(`${certFingerprint}: Failed to get ECDSA curve.`)
                    }
                }

                pubKeyCryptoPrimitive = cacheMaps.curveOIDMap[curveOID]

                cryptoAlgo = certOIDMap[algOID]
            }

                break
            case 'DSA': {
                entityCertPubkey = entityCert.getPublicKey()

                if (!entityCertPubkey) {
                    log.e(`${certFingerprint}: Failed to get DSA public key.`)
                    return
                }

                if (!entityCertPubkey.p) {
                    log.e(`${certFingerprint}: Failed to get DSA parameter p.`)
                    return
                }

                let dsaKeySize = entityCertPubkey.p.bitLength()
                tmpArr = cryptoDataCache.cryptoPrimitiveLookup(certOIDMap[algOID], dsaKeySize)

                pubKeyCryptoPrimitive = tmpArr.primitiveName
                pubKeyCryptoPrimitiveParam = tmpArr.nonRegularSize

                cryptoAlgo = certOIDMap[algOID]
            }

                break
            case 'ECDSA_ED25519':
            case 'ECDSA_ED448':
                // ED25519 and ED448 bear different algorithm OIDs than that of ECDSA,
                // because they are technically "EdDSA" (RFC 8032). However, we have
                // decided to put them under the ECDSA umbrella because for TLS
                // EdDSA is still represented by ECDSA in TLS's cipher suites.
                pubKeyCryptoPrimitive = certOIDMap[algOID]

                cryptoAlgo = 'ECDSA'

                break
            case 'SHA-256':
            case 'RSA':
            case 'MD5-RSA': // maybe can extract more here...
                cryptoAlgo = certOIDMap[algOID]
                break
        }

        if (pubKeyCryptoPrimitive && (pubKeyCryptoPrimitive !== 'RSA_SIG' || pubKeyCryptoPrimitive !== 'DSA_DSS')) {
            if (!isClientCert) {
                // Only add cryptoAlgo to "handled-vague" if the cert being
                // processed is for server authentication, because only server
                // cert's public key type corresponds to what's specified in
                // the negotiated ciphersuite.
                //
                // Client cert for client auth can have a different public key
                // type than what's specified in the negotiated ciphersuite.
                cryptoPrimitivesHandledVague.add(cryptoAlgo)
            }

            cryptoPrimitivesToAdd.add([pubKeyCryptoPrimitive, pubKeyCryptoPrimitiveParam])

            // Cache "CERT_CACHE_SIZE" number of cert results,
            // so that if the same cert has been processed and stored
            // in cache, we can use it directly when encountering it again
            // in new records, without the need to repeatedly parse the cert.

            if (cacheMaps.certFingerprintMap.size > CERT_CACHE_SIZE) {
                const iter = cacheMaps.certFingerprintMap.keys()

                // If we have cached more than "CERT_CACHE_SIZE" number
                // of certs, we purge all certs above "CERT_PURGE_WATERMARK"
                // (those are the older certs, since Map remembers insertion
                // order).
                for (let i = 0; i < CERT_CACHE_SIZE; i++) {
                    let key = iter.next().value
                    if (i > CERT_PURGE_WATERMARK) {
                        cacheMaps.certFingerprintMap.delete(key)
                    }
                }
            }

            cacheMaps.certFingerprintMap.set(certFingerprint, {
                vague: cryptoAlgo,
                precise: pubKeyCryptoPrimitive,
                publicKeyCryptoPrimitive: pubKeyCryptoPrimitive,
                publicKeyCryptoPrimitiveParameter: pubKeyCryptoPrimitiveParam,
                notBefore: entityCertNotBefore,
                notAfter: entityCertNotAfter,
                issuer: entityCertIssuer,
                subject: entityCertSubject,
                serial: entityCertSerial,
                issuerSigAndHash: entityCertSigName
            })
        } else {
            log.e(`${certFingerprint}: Failed to get entity certificate public key algorithm parameter.`)
            pubKeyCryptoPrimitive = cryptoAlgo
        }

        return {
            ...connectionID,
            certificateType: 'X509',
            manuallyAdded: false,
            fingerprint: certFingerprint,
            notBefore: entityCertNotBefore,
            notAfter: entityCertNotAfter,
            issuer: entityCertIssuer,
            subject: entityCertSubject,
            serial: entityCertSerial,
            publicKeyCryptoPrimitive: pubKeyCryptoPrimitive,
            publicKeyCryptoPrimitiveParameter: pubKeyCryptoPrimitiveParam,
            issuerSigAndHash: entityCertSigName,
        }
    } catch (e) {
        log.e(`${certFingerprint}: Failure during certificate parsing`, e)
        return
    }
}

function processCNSRow(row, parsedMetadata) {
    let recordType = getField(row, 'ProtocolType')
    if (!recordType) {
        log.e(`Record type must be specified.`)
        throw 'Record type must be specified.'
    }

    if (recordType !== 'TLS' && recordType !== 'SSL') {
        log.e(`The record type cannot be recognized`)
        throw 'The record type cannot be recognized'
    }

    // Get server info.
    let serverAddress = getField(row, 'ServerIPAddress')
    let serverPort = getField(row, 'ServerPortNumber')
    if (!serverAddress || !serverPort) {
        log.e(`Server address and port must both be specified.`)
        throw 'Server address and port must both be specified.'
    }

    // Process server info.
    let serverAddressInfo = inspectIPAddress(serverAddress, NetmaskMatchModes.SERVER)
    if (!serverAddressInfo.isIngestible) {
        log.e(`Invalid server address specified '${serverAddress}' of type '${serverAddressInfo.addressType}'.`)
        return
    }

    let serverPortNumber = parseInt(serverPort)
    if (isNaN(serverPortNumber) || serverPortNumber <= 0 || serverPortNumber > 65535) {
        log.e(`Server port must be an integer between 1 and 65535.`)
        return
    }

    let serverMACAddress
    let mac = normalizeMacAddress(getField(row, 'ServerMACAddress'))
    if (mac) {
        if (isMac(mac)) {
            serverMACAddress = mac
        } else {
            log.e(`Invalid server MAC address specified '${mac}'`)
        }
    }

    // Get record time.
    // TODO: GAP2042 - make use of connection timestamp.
    // let recordTimestamp = getField(row, 'ConnectionTimestamp')
    // let recordDate
    // if (!recordTimestamp) {
    //     recordDate = new Date()
    // } else {
    //     // Get rid of any fractions.
    //     recordDate = new Date(Math.round(recordTimestamp))
    // }

    let observedAtTime = new Date()

    // Get client info.
    let clientAddress = getField(row, 'ClientIPAddress')
    if (!clientAddress) {
        log.e(`Client address must be specified.`)
        return
    }

    // Process client info.
    let clientAddressInfo = inspectIPAddress(clientAddress, NetmaskMatchModes.CLIENT)
    if (!clientAddressInfo.isIngestible) {
        log.e(`Invalid client address specified '${clientAddress}' of type '${clientAddressInfo.addressType}'.`)
        return
    }

    let clientMACAddress
    mac = normalizeMacAddress(getField(row, 'ClientMACAddress'))
    if (mac) {
        if (isMac(mac)) {
            clientMACAddress = mac
        } else {
            log.e(`Invalid client MAC address specified '${mac}'`)
        }
    }

    const l4Protocol = 'TCP'
    let connectionID = {
        observedAt: observedAtTime,
        serverAddress: serverAddressInfo.address,
        port: serverPortNumber,
        clientAddress: clientAddressInfo.address,
        l4Protocol: l4Protocol,
        zoneIn:  hasNetmaskZone(clientAddressInfo.address, NetmaskMatchModes.CLIENT),
        zoneOut: hasNetmaskZone(serverAddressInfo.address, NetmaskMatchModes.SERVER),
    }

    // Get protocol variant (TLS version).
    let TLSVersion = getField(row, 'TLSVersion')
    let TLSProtocol = cryptoDataCache.protocolLookup(undefined, TLSVersion)
    let TLSVariant = TLSProtocol ? TLSProtocol.name : 'TLS Unknown'

    // Get cipher suite info.
    let cipherSuiteCodePointStr = getField(row, 'CipherSuiteCodePoint')
    let cipherSuiteCodePoint
    let cipherSuiteStruct
    let cipherSuiteName
    let cipherSuiteNameSansTLS
    let cipherSuiteEntry

    if (cipherSuiteCodePointStr) {
        cipherSuiteCodePoint = parseInt(cipherSuiteCodePointStr)
        if (isNaN(cipherSuiteCodePointStr) || cipherSuiteCodePoint < 0 || cipherSuiteCodePoint > 0xFFFF) {
            log.e(`${cipherSuiteCodePointStr} is an invalid cipher suite.`)
            return
        }
    } else {
        log.e(`Cipher Suite must be specified in ${JSON.stringify(row)}.`)
        return
    }

    cipherSuiteStruct = cryptoDataCache.cipherSuiteLookup(cipherSuiteCodePoint)
    if (!cipherSuiteStruct) {
        // For unrecognized cipher suite, use the cipher suite code point directly.
        cipherSuiteName = cipherSuiteCodePointStr
    } else {
        cipherSuiteName = cipherSuiteStruct.name

        // Slice away the initial "TLS_" from the cipher suite name. This will be
        // used to get the key exchange algorithm name.
        cipherSuiteNameSansTLS = cipherSuiteName.slice(4)
    }

    if (cipherSuiteName) {
        cipherSuiteEntry = {
            ...connectionID,
            cipherSuite: cipherSuiteName,
        }
    }

    // Gather all the crypto primitives to add to the db.
    let cryptoPrimitivesToAdd = new Set()
    let cryptoPrimitivesHandledVague = new Set()
    let cryptoPrimitivesEntries

    // Add all "precise" crypto primitives (i.e., ones with parameter info)
    // defined in the cipher suite.
    //
    // For all non-precise ("vague") crypto primitives defined in the cipher
    // suite, we will try to find their precise parameter info first, and if
    // not found, add the vague ones directly.
    if (cipherSuiteStruct) {
        for (let precise of cipherSuiteStruct.cryptoPrimitives.precise) {
            cryptoPrimitivesToAdd.add([precise.name, null])
        }
    }

    // Handle TLS key exchange algorithm and parameter.
    if (TLSVariant === 'TLS 1.3') {
        // TLS 1.3 provides key exchange algos and parameters in the form of
        // named groups, which are orthogonal to cipher suite and any other
        // crypto primitives.
        let TLS13KEXCodePoint = getField(row, 'TLS13KEXNamedGroupCodePoint')

        if (TLS13KEXCodePoint) {
            let TLS13KEXNamedGroup = cryptoDataCache.TLS13KEXLookup(parseInt(TLS13KEXCodePoint))

            if (TLS13KEXNamedGroup) {
                cryptoPrimitivesToAdd.add([TLS13KEXNamedGroup, null])
            }
        }
    } else {
        // This case is for TLS 1.2, 1.1, 1.0 and SSL 3.0, where we need to
        // parse the cipher suite to get the key exchange algorithm, and then
        // use the TLSKEXParameter field to get the corresponding parameter.
        // Key exchange algos that support parameters are DH, DHE, ECDH,
        // ECDHE, and RSA.
        //
        // ECDH/ECDHE uses curves as parameters, and DH/DHE and RSA use key
        // sizes as parameters.
        let TLSKEXParamCodePoint = getField(row, 'TLSKEXParameter')

        if (TLSKEXParamCodePoint) {
            if (cipherSuiteNameSansTLS) {
                let components = cipherSuiteNameSansTLS.split('_')
                let TLSKEXAlgo = components[0]

                if (TLSKEXAlgo === 'DH' || TLSKEXAlgo === 'DHE' ||
                    TLSKEXAlgo === 'ECDH' || TLSKEXAlgo === 'ECDHE' ||
                    TLSKEXAlgo === 'RSA') {

                    if (TLSKEXAlgo === 'RSA') {
                        TLSKEXAlgo = 'RSA_KE'
                    } else if (TLSKEXAlgo === 'DHE') {
                        TLSKEXAlgo = 'FFDHE'
                    } else if (TLSKEXAlgo === 'DH') {
                        TLSKEXAlgo = 'FFDH'
                    }

                    if (!isNaN(Number(TLSKEXParamCodePoint))) {
                        let TLSKEXParam = cryptoDataCache.cryptoPrimitiveLookup(TLSKEXAlgo, parseInt(TLSKEXParamCodePoint))
                        if (TLSKEXParam.primitiveName) {
                            cryptoPrimitivesHandledVague.add(TLSKEXAlgo)
                            cryptoPrimitivesToAdd.add([TLSKEXParam.primitiveName, TLSKEXParam.nonRegularSize])
                        }
                    }
                }
            }
        }
    }

    let certificateEntries = []
    // Process server entity cert for server authentication.
    let serverCertificateEntry = processCertificate(row, cryptoPrimitivesToAdd, cryptoPrimitivesHandledVague, parsedMetadata, connectionID, false)
    if (serverCertificateEntry) {
        certificateEntries.push(serverCertificateEntry)
    }

    // If client authentication is requested, process client entity cert.
    let isClientAuth = getField(row, 'IsClientAuthRequested')
    let clientCertificateEntry

    if (isClientAuth && parseInt(isClientAuth) === 1) {
        clientCertificateEntry = processCertificate(row, cryptoPrimitivesToAdd, cryptoPrimitivesHandledVague, parsedMetadata, connectionID, true)
        if (clientCertificateEntry) {
            certificateEntries.push(clientCertificateEntry)
        }
    }

    // For all vague crypto primitives that have been handled, it means
    // that we have found their precise parameter info, so their "precise"
    // version have been added.
    //
    // For those that haven't been handled, which means that we haven't
    // been able to find their precise parameter info, add the vague version
    // (such as "RSA") directly.
    cipherSuiteStruct?.cryptoPrimitives?.vague?.forEach(vague => {
        let name = vague.name

        if (!cryptoPrimitivesHandledVague.has(name)) {
            cryptoPrimitivesToAdd.add([name, null])
        }
    })

    let createPrimitive = (p) => {
        return {
            ...connectionID,
            cryptoPrimitive: p[0],
            cryptoPrimitiveParameter: p[1],
        }
    }

    let toAddArr = Array.from(cryptoPrimitivesToAdd)
    if (toAddArr.length !== 0) {
        cryptoPrimitivesEntries = toAddArr.map(p => createPrimitive(p))
    }

    return {
        connection: {
            ...connectionID,
            serverMacAddress: serverMACAddress,
            clientMacAddress: clientMACAddress,
            friendlyName: `${clientAddressInfo.address} \u2192 ${serverAddressInfo.address}:${serverPortNumber}`,
            connectionCount: 1
        },
        server: {
            observedAt: observedAtTime,
            ipAddress: serverAddressInfo.address,
            ipVersion: serverAddressInfo.version,
            macAddress: serverMACAddress,
        },
        client: {
            observedAt: observedAtTime,
            ipAddress: clientAddressInfo.address,
            ipVersion: clientAddressInfo.version,
            macAddress: clientMACAddress,
        },
        cipherSuite: cipherSuiteEntry,
        cryptoPrimitives: cryptoPrimitivesEntries,
        protocolVariant: {
            ...connectionID,
            protocolVariant: TLSVariant,
        },
        certificates: certificateEntries,
    }
}

async function processCNSCSV(stream, scanResults, parsedMetadata) {
    let session = new Session()

    let commonUpserters = new CommonUpserters(session)
    let { connectionUpserter, deviceUpserter, cipherSuiteUpserter, protocolVariantUpserter, cryptoUpserter, deviceCertificateUpserter, certificateUpserter } = commonUpserters

    certificateUpserter.ignoreColumns(new Set([
        'certificateContent',
        'issuerCertificate',
        'internalIssuer',
        'alternateNames',
    ]))

    let processed = 0
    let success = 0
    let failure = 0
    let lastCommitPromise = undefined

    await processCsvStream(stream,
        async (queue) => {
            while (!queue.empty) {
                let row = queue.dequeue()
                if (!row) { continue }

                processed++
                if (processed % STATUS_UPDATE_PERIOD === 0) {
                    await updateScanResultSummary(scanResults, `Processed ${processed.toLocaleString()} rows...`)
                }

                let constructed = processCNSRow(row, parsedMetadata)
                if (!constructed) {
                    failure++
                    continue
                }

                let {
                    connection,
                    server,
                    client,
                    cipherSuite,
                    cryptoPrimitives,
                    protocolVariant,
                    certificates,
                } = constructed

                connectionUpserter.push(connection)
                deviceUpserter.push(server)
                deviceUpserter.push(client)
                cipherSuiteUpserter.push(cipherSuite)
                protocolVariantUpserter.push(protocolVariant)

                for (let crypto of (cryptoPrimitives || [])) {
                    cryptoUpserter.push(crypto)
                }

                for (let cert of (certificates || [])) {
                    deviceCertificateUpserter.push(cert)
                    certificateUpserter.push(cert)
                }

                success++
            }

            if (commonUpserters.needsCommit()) {
                if (lastCommitPromise) await lastCommitPromise
                let commitPromise = commonUpserters.commit()
                lastCommitPromise = commitPromise
            }
        }
    )

    if (lastCommitPromise) await lastCommitPromise
    await commonUpserters.commit()

    return [processed, success, failure]
}

async function buildCacheMaps(session, cacheMaps) {
    // Build ECC curve cache map.
    let curveVariants = await session.query(`SELECT "name", "variant" FROM "CryptoPrimitive" where "oid" = '1.2.840.10045.2.1' and "variant" is not null`)

    for (let curve of curveVariants.rows) {
        cacheMaps.curveOIDMap[curve.variant] = curve.name
    }
}

async function ingestCNS(dataSourceScan, scanResults, onFulfilled, onRejected, onFinally) {
    const parsedMetadata = JSON.parse(dataSourceScan.metadata)
    const parsedConfig = JSON.parse(dataSourceScan.configuration)

    await cryptoDataCache.init()
    await buildCacheMaps(new Session(), cacheMaps)

    try {
        if (!fs.existsSync(parsedMetadata.dataDir)) {
            throw `Data directory containing ingestion files does not exist.`
        }

        let files = fs.readdirSync(parsedMetadata.dataDir)
        if (!files) {
            throw `Failed to access the data directory containing ingestion files.`
        }

        if (files.length === 0) {
            throw `No ingestion files provided.`
        }

        let processedRows = 0
        let successRows = 0
        let failureRows = 0
        let numCSV = 0

        for (let i = 0; i < files.length; i++) {
            let filename = path.join(parsedMetadata.dataDir, files[i])
            let stat = fs.lstatSync(filename)
            if (stat.isFile()) {
                if (filename.toLowerCase().endsWith('.csv')) {
                    // Found a .csv file. Ingest it.
                    log.log(`Ingest file: ${filename}`)
                    numCSV++

                    const stream = fs.createReadStream(filename)
                    try {
                        const [processed, success, failure] = await processCNSCSV(stream, scanResults, parsedMetadata)

                        processedRows += processed
                        successRows += success
                        failureRows += failure
                    } finally {
                        stream.close()
                    }

                    await updateScanResultSummary(scanResults, `Processed ${processedRows.toLocaleString()} rows.`)
                }
            }
        }

        if (numCSV === 0) {
            throw `No ingestion files provided.`
        }

        // All records failed to be ingested.
        if (successRows === 0 && failureRows > 0) {
            throw 'No records were successfully ingested.'
        }

        if (failureRows > 0) {
            await onFulfilled(IngestionStatus.PARTIAL_SUCCESS)
        } else {
            await onFulfilled(IngestionStatus.SUCCESS)
        }
    } catch (e) {
        log.e('Failure during CNS ingestion', e)
        await onRejected(e)
    } finally {
        let fileObj = path.parse(parsedConfig.zipFile)

        // Archive the ingested zip file.
        fse.moveSync(parsedConfig.zipFile, path.join(os.tmpdir(), 'cns', 'archive', `${fileObj.name}${fileObj.ext}`), { overwrite: true })

        // Remove the unzipped data source files.
        fse.removeSync(parsedMetadata.dataDir)

        await onFinally()
    }

    return
}

module.exports = {
    name: 'ISARA Cryptographic Network Sensor',
    test: async () => { },
    scan: ingestCNS,
    processCNSRow: processCNSRow,
    processCertificate: processCertificate
}
