--
-- @file 10-11.sql - 1.2.0 - 3826bc12533e078a8e37cfe70ee04d9e85c8530e
-- 
-- @copyright Copyright (C) 2016-2023, ISARA Corporation, All Rights Reserved.
-- 
-- @license The code and other content set out herein is not in the public
-- domain, is considered a trade secret and is confidential to ISARA
-- Corporation. Use, reproduction or distribution, in whole or in part, of such
-- code or other content is strictly prohibited except by express written
-- permission of ISARA Corporation. Please contact ISARA Corporation at
-- info@isara.com for more information.
--

    /* 
    * 
    *    SCHEMA - FORWARDS 
    *    MIGRATION 10 TO 11 
    *    >FOR RELEASE X.XX.X 
    *    ORIGIN GIT HASH:e10093dab4402999c717e546d60830fb07f8fd12
    * 
    *    CREATED ON 2022-12-05T20:50:53.841Z
    * 
    */


ALTER TABLE advance."Connection" ADD COLUMN "serverMacAddress" character varying(50) NULL;
ALTER TABLE advance."Connection" ADD COLUMN "clientMacAddress" character varying(50) NULL;



ALTER TABLE advance."DeviceSoftware" ADD COLUMN "macAddress" character varying(50) NULL;

