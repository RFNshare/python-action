/**
 * @file dbutil.js - 1.2.0 - 3826bc12533e078a8e37cfe70ee04d9e85c8530e
 * 
 * @copyright Copyright (C) 2016-2023, ISARA Corporation, All Rights Reserved.
 * 
 * @license The code and other content set out herein is not in the public
 * domain, is considered a trade secret and is confidential to ISARA
 * Corporation. Use, reproduction or distribution, in whole or in part, of such
 * code or other content is strictly prohibited except by express written
 * permission of ISARA Corporation. Please contact ISARA Corporation at
 * info@isara.com for more information.
 */

const Session = require('./session').Session

const log = require('../util/log')(module)

exports.canDBConnect = async function() {
    try {
        const session = new Session()
        await session.query('select 1')
        return true
    } catch (e) {
        log.e('Failed to connect to DB',e)
        return false
    }
}

exports.getDBVersion = async function() {
    try {
        const session = new Session()
        const result = await session.query(`select value from "advance"."SystemProperty" where key = 'databaseVersion'`)        
        if (result.rows.length === 0) {
            return
        }
        return result.rows[0].value
    } catch (e) {
        log.e('Failed to query database version')
        return
    }
}

