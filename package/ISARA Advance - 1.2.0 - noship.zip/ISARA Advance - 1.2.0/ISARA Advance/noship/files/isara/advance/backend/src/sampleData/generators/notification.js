/**
 * @file notification.js - 1.2.0 - 3826bc12533e078a8e37cfe70ee04d9e85c8530e
 * 
 * @copyright Copyright (C) 2016-2023, ISARA Corporation, All Rights Reserved.
 * 
 * @license The code and other content set out herein is not in the public
 * domain, is considered a trade secret and is confidential to ISARA
 * Corporation. Use, reproduction or distribution, in whole or in part, of such
 * code or other content is strictly prohibited except by express written
 * permission of ISARA Corporation. Please contact ISARA Corporation at
 * info@isara.com for more information.
 */


var {
    notificationTypes,
    users,
    connectionRatings
} = require('../dbTypes')
const {
    dumpObjectTimingStats,
    initDbConnection,
    insertObject,
    bulkInsertRecords,
    resetObjectTimingStats
} = require('../dbHelpers')
const {
    Agent,
    AgentCertificate,
    CAIssuedCertificate,
    Certificate,
    CertificateCryptoPrimitive,
    CertificationAuthority,
    Connection,
    ConnectionCertificate,
    ConnectionCipherSuite,
    ConnectionCryptoPrimitive,
    ConnectionProtocolVariant,
    ConnectionProtocolVariantCertificate,
    ConnectionTag,
    Device,
    DeviceAddress,
    DeviceAddressMACAddress,
    DeviceAddressPort,
    DeviceCertificate,
    DeviceMACAddress,
    DeviceSoftware,
    DeviceSoftwareConnection,
    DeviceTag,
    KeyStore,
    KeyStoreKey,
    OneTimeKey,
    Netmask,
    Notification,
    NotificationAction,
    Software,
    SoftwareVersion,
    SoftwareVersionTag,
    Tag,
    User,
    UserRole,
} = require('../dbObjects')

var log = require('../../util/log')(module)
exports.insertNotifications = async function (session, data) {
    let notificationArray = []
    log.log("data", data.notificationTypes)
    notificationTypes = {...notificationTypes, ...data.notificationTypes}
    for (var i = 0; i < 100; ++i) {
        var notification = new Notification(data)
        notificationArray.push(notification.nameValues)
    }
    let results;
    try{
        results  = await bulkInsertRecords('Notification', notificationArray, session)
    }catch(e){console.log(e)}
    if (!data.notifications) data.notifications = []
    data.notifications.push(...results?.rows)
}

exports.insertNotificationActions = async function (session, notifications, users) {
    let notificationActionArray = []
    for (var notification of notifications) {
        for (var user of users) {
            if (Math.random() < 0.1) {
                var notificationAction = new NotificationAction(notification, user)
                notificationActionArray.push(notificationAction.nameValues)
            }
        }
    }
    try{
        await bulkInsertRecords('NotificationAction', notificationActionArray, session)
    }catch(e){console.log(e)}
}

