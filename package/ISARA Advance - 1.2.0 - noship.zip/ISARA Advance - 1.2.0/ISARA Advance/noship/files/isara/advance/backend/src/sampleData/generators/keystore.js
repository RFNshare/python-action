/**
 * @file keystore.js - 1.2.0 - 3826bc12533e078a8e37cfe70ee04d9e85c8530e
 * 
 * @copyright Copyright (C) 2016-2023, ISARA Corporation, All Rights Reserved.
 * 
 * @license The code and other content set out herein is not in the public
 * domain, is considered a trade secret and is confidential to ISARA
 * Corporation. Use, reproduction or distribution, in whole or in part, of such
 * code or other content is strictly prohibited except by express written
 * permission of ISARA Corporation. Please contact ISARA Corporation at
 * info@isara.com for more information.
 */



var log = require('../../util/log')(module)

let addOneTimeKey = async function (certificationAuthorities) {
    let oneTimeKeyArray = []
    for (let certificationAuthority of certificationAuthorities) {
        let oneTimeKey = new OneTimeKey(certificationAuthority)
        await oneTimeKey.populate()
        oneTimeKeyArray.push(oneTimeKey.nameValues)
    }
    await bulkInsertRecords('OneTimeKey', oneTimeKeyArray, session)
}

let addCertificationAuthority = async function (keyStoreKeys, certAuthorities) {
    let certificationAuthorityArray = []
    for (let keyStoreKey of keyStoreKeys) {
        let certificationAuthority = new CertificationAuthority(keyStoreKey)
        certificationAuthorityArray.push(certificationAuthority.nameValues)
    }
    let results = await bulkInsertRecords('CertificationAuthority', certificationAuthorityArray, session)
    for (let certificationAuthority of results.rows) {
        certAuthorities.push(certificationAuthority)
    }
    await addOneTimeKey(results.rows)
}

let addKeyStoreKey = async function (keyStores, certAuthorities) {
    let keyStoreKeyArray = []
    for (let keyStore of keyStores) {
        let keyStoreKey = new KeyStoreKey(keyStore)
        await keyStoreKey.populate()
        keyStoreKeyArray.push(keyStoreKey.nameValues)
    }
    let result = await bulkInsertRecords('KeyStoreKey', keyStoreKeyArray, session)
    await addCertificationAuthority(result.rows, certAuthorities)
}

let addKeyStore = async function (certAuthorities) {
    let caCount = Math.floor(Math.random() * 10 + 1)
    let keyStoreArray = []
    for (let i = 0; i < caCount; i++) {
        let keyStore = new KeyStore()
        keyStoreArray.push(keyStore.nameValues)
    }
    let results = await bulkInsertRecords('KeyStore', keyStoreArray, session, true)
    await addKeyStoreKey(results.rows, certAuthorities)
}


