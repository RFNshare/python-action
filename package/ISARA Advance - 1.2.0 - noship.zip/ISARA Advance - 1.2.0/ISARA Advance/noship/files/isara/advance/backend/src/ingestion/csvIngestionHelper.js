/**
 * @file csvIngestionHelper.js - 1.2.0 - 3826bc12533e078a8e37cfe70ee04d9e85c8530e
 * 
 * @copyright Copyright (C) 2016-2023, ISARA Corporation, All Rights Reserved.
 * 
 * @license The code and other content set out herein is not in the public
 * domain, is considered a trade secret and is confidential to ISARA
 * Corporation. Use, reproduction or distribution, in whole or in part, of such
 * code or other content is strictly prohibited except by express written
 * permission of ISARA Corporation. Please contact ISARA Corporation at
 * info@isara.com for more information.
 */

/**
 * This module contains helper functions for processing CSV files and zip-archives of CSV files.
 * @module ingestion/netscout/netscoutIngestionScanner
 */

const StreamZip = require('node-stream-zip')
const fastcsv = require('fast-csv')
const { sleep } = require('../util/sleep')
const { FIFOQueue } = require('../util/fifoQueue')

const log = require('../util/log')(module)

/**
 * Processes a CSV file stream as a Promise.
 * @param {Stream} stream The stream to read.
 * @param {Object} headersMap A map that will be populated with the column headers and their respective index.
 * @param {async} rowProcessFunc The function to process each row.
 * @returns
 * @deprecated processCsvStream is faster and does not need artificial delay
 */
function processCsvStreamAsPromise(stream, headersMap, rowProcessFunc) {
    let csvStream = fastcsv.parse({
        ignoreEmpty: true,
        headers: (headers) => {
            let index = 0
            headers = headers.map(header => {
                header = header.toLowerCase().trim()
                headersMap[header] = index
                ++index
                return header
            })
            return headers
        }
    })

    return new Promise((resolve, reject) => stream.pipe(csvStream).on('error', async function (e) {
        log.e('Failure during CSV file streaming', e)
        return reject()
    }).on('data', async function (row) {
        csvStream.pause()
        try {
            await rowProcessFunc(row)
        } finally {
            csvStream.resume()
        }
    }).on('end', async function () {
        // grace period to allow async 'data' event to finish
        // TODO: GAP1631 - replace with mutex or something?
        await sleep(2000)
        stream.close()
        return resolve()
    }))
}

const PREFERRED_BATCH_SIZE = 100000

/**
 * Improved async handling of CSV with batching to reduce calls.
 * @param {fs.ReadStream} stream Stream to read CSV from. Headers are expected to be in the stream.
 * @param {Function} rowProcessAsyncFunc function to call to process the next block of rows.
 * @param {[Number]} preferredBatchSize The max number of records that should be fed to rowProcessAsyncFunc. It will always be lower when there aren't enough
 * @returns
 */
async function processCsvStream(stream, rowProcessAsyncFunc, preferredBatchSize) {
    if (!stream) {
        throw new Error('Missing stream')
    }

    if (!rowProcessAsyncFunc || !(typeof rowProcessAsyncFunc === 'function')) {
        throw new Error('Missing row processing async function')
    }

    preferredBatchSize = preferredBatchSize ?? PREFERRED_BATCH_SIZE

    return new Promise((resolve, reject) => {
        let csvStream = fastcsv.parse({
            ignoreEmpty: true,
            headers: headers => headers.map(h => h.toLowerCase())
        })

        let rowBuffer = new FIFOQueue()
        let totalRows = 0

        let done = error => {
            rowBuffer.clear()
            try {
                stream.close()
            } catch (e2) {
                log.w('Consuming closing stream error', e2)
            }
            if (error) {
                reject(error)
            } else {
                resolve(totalRows)
            }
        }

        csvStream.on('error', done)
        csvStream.on('data', row => {
            rowBuffer.enqueue(row)
            totalRows++
            if (rowBuffer.length >= preferredBatchSize) {
                csvStream.pause()
                rowProcessAsyncFunc(rowBuffer).then(() => {
                    rowBuffer.clear()
                    csvStream.resume()
                }).catch(error => {
                    done(error)
                })
            }
        })
        csvStream.on('end', () => {
            if (rowBuffer.length) {
                rowProcessAsyncFunc(rowBuffer).then(() => {
                    done()
                }).catch(error => {
                    done(error)
                })
            } else {
                done()
            }
        })

        stream.pipe(csvStream)
    })
}

/**
 *
 * @param {string} zipPath The path to the zip file to stream
 * @param {function} fileFilterFunc Function used to filter files on name.
 * @param {async} fileProcessFunc Function to process each file stream.
 */
async function streamZipFile(zipPath, fileFilterFunc, fileProcessFunc) {
    const zip = new StreamZip.async({ file: zipPath })
    let retVals = []
    try {
        const entries = Object.values((await zip.entries())).filter(entry => fileFilterFunc(entry.name))
        for (var entry of entries) {
            retVals.push(await fileProcessFunc(zip.stream(entry)))
        }
    } finally {
        await zip.close()
    }
    return retVals
}

function getField(row, name, converter) {
    let value = (row[name.toLowerCase()] ?? '').trim()
    if (converter) {
        value = converter(value)
    }
    return value ? value : null
}

exports.processCsvStreamAsPromise = processCsvStreamAsPromise
exports.processCsvStream = processCsvStream
exports.streamZipFile = streamZipFile
exports.getField = getField
