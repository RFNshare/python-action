/**
 * @file sleep.js - 0.0.1045 - ea4595bfd3488684d225574ed7d4c198074d49ba
 * 
 * @copyright Copyright (C) 2016-2023, ISARA Corporation, All Rights Reserved.
 * 
 * @license The code and other content set out herein is not in the public
 * domain, is considered a trade secret and is confidential to ISARA
 * Corporation. Use, reproduction or distribution, in whole or in part, of such
 * code or other content is strictly prohibited except by express written
 * permission of ISARA Corporation. Please contact ISARA Corporation at
 * info@isara.com for more information.
 */

var _0x2418cf=_0x242b;(function(_0x19bfae,_0x2b023f){var _0x4fd9ff=_0x242b,_0x5cea14=_0x19bfae();while(!![]){try{var _0x17c411=parseInt(_0x4fd9ff(0x91))/0x1*(parseInt(_0x4fd9ff(0x94))/0x2)+parseInt(_0x4fd9ff(0x9c))/0x3*(parseInt(_0x4fd9ff(0x92))/0x4)+-parseInt(_0x4fd9ff(0x96))/0x5+-parseInt(_0x4fd9ff(0x98))/0x6*(parseInt(_0x4fd9ff(0x95))/0x7)+-parseInt(_0x4fd9ff(0x97))/0x8*(parseInt(_0x4fd9ff(0x93))/0x9)+-parseInt(_0x4fd9ff(0x9a))/0xa+parseInt(_0x4fd9ff(0x99))/0xb;if(_0x17c411===_0x2b023f)break;else _0x5cea14['push'](_0x5cea14['shift']());}catch(_0x58c53d){_0x5cea14['push'](_0x5cea14['shift']());}}}(_0x5685,0x5fc85),exports[_0x2418cf(0x9b)]=_0x2279cd=>{return new Promise(_0x1e595b=>{setTimeout(()=>_0x1e595b(),_0x2279cd);});});function _0x242b(_0x315abe,_0x20ebe8){var _0x568507=_0x5685();return _0x242b=function(_0x242be4,_0x518d6b){_0x242be4=_0x242be4-0x91;var _0xb17b31=_0x568507[_0x242be4];return _0xb17b31;},_0x242b(_0x315abe,_0x20ebe8);}function _0x5685(){var _0x1d276f=['148623eViLMS','171030UzFDKe','56ijocku','111672mZDmGh','2uOkMRP','152348noemMS','3828425WyfZjK','176MDyHEk','198VwkTRy','15770051eAceHS','1490470HqNgOn','sleep'];_0x5685=function(){return _0x1d276f;};return _0x5685();}