/**
 * @file index.js - 0.0.1045 - ea4595bfd3488684d225574ed7d4c198074d49ba
 * 
 * @copyright Copyright (C) 2016-2023, ISARA Corporation, All Rights Reserved.
 * 
 * @license The code and other content set out herein is not in the public
 * domain, is considered a trade secret and is confidential to ISARA
 * Corporation. Use, reproduction or distribution, in whole or in part, of such
 * code or other content is strictly prohibited except by express written
 * permission of ISARA Corporation. Please contact ISARA Corporation at
 * info@isara.com for more information.
 */

/*
*       Migration Helper
*
*          provides organization for migration of schema and data
*          ensures clearly marked schema and data migration and that they run in order
*
*
*/
const execOs = require('child_process').exec
const inquirer = require('inquirer')
const readline = require('readline')
const { promisify } = require('util')
const path = require('path')
const appArgs = process.argv.slice(2)
const ScriptManager = require('./script-manager')
const templates = require('./templates.json')
const pg = require('pg'),
    fs = require('fs')
const writeFileAsync = promisify(fs.writeFile)

const VersionManager = require('./version-manager')
//CONSTANTS
const generateBackwards = true
const verbose = false

const exec = (cmd) => {
    return new Promise((resolve, reject) => {
        try{
            execOs(cmd, async (error, stdout, stderr) => {
                if (error) {
                    reject(stderr)
                    return
                }
                resolve(stdout)
            })
        }catch(err){
            reject('error:')
        }
    })
}


const createFile = async (folder, v1, v2, templateString, data) => {
    const keys = Object.keys(data)
    //console.log(keys)
    const newData = keys.reduce((prev, current) => prev.split(`<${current}>`).join(data[current])
        , templateString)
    //console.log(newData)// ./entries/${now}/
    const file = `${folder}/${v1}-${v2}.sql`
    verbose && console.log(`writing ${file}`)
    writeFileAsync(file, newData
        //{ encoding:'utf-8', flag: fs.constants.W_OK}
    )
    verbose && console.log(`wrote ${file}`)
    // await exec("sleep 2")
}
let now = (new Date()).getTime()
const day = 24 * 60 * 60 * 1000
const getMigrationList = async () => {
    const entryPath = path.resolve(path.join(process.cwd(), 'entries'))
    await exec(`mkdir -p ${entryPath}/`)
    const migrationTimestamps = await exec(`ls ${entryPath}`)
    return migrationTimestamps
}
const check24h = async () => {
    const migrationTimestamps = await getMigrationList()
    const recentMigrations = migrationTimestamps.split('\n').filter(x => {
        if (parseInt(x) > (now - day)) {
            return true
        }
    })
    if (recentMigrations.length > 0) {
        console.error(`THERE ARE ${recentMigrations.length} MIGRATIONS WITHIN THE LAST 24H`)
        const r1 = readline.createInterface({
            input: process.stdin,
            output: process.stdout
        })
        r1.question('Are you sure you want to continue? (y/n)', async (response) => {
            if (response.includes('n')) {
                process.exit()
            } else if (response.includes('y')) {
                await runNew()
            }
        })
    } else {
        await runNew()
    }
}
const getParams = async () => {

    // detect latest version / current version / fetch git hash from file comments
    let lastGitHash = '', lastRelease = '';
    const scriptFiles = new ScriptManager().getList('.')
    const lastVersionData = scriptFiles.reduce((last, current) => {
        if (current && last && current.targetVersion > last.targetVersion) {
            return current
        }
        return last
    }, { targetVersion: -100 })
    const lastVersion = scriptFiles.length == 0 ? 0 : lastVersionData.targetVersion
    if (lastVersionData.path) {
        const lastTarget = fs.readFileSync(lastVersionData.path) + ''
        //get hash data
        let hash = lastTarget.substr(lastTarget.indexOf('ORIGIN GIT HASH:') + 16)
        hash = hash.substr(0, hash.indexOf('\n')).trim()
        if (!hash.includes(' ')) {
            lastGitHash = hash
        }
        //get release data
        let rel = lastTarget.substr(lastTarget.indexOf('>FOR RELEASE') + 12)
        lastRelease = rel.substr(0, rel.indexOf('\n')).trim()
    }
    // better to get it from git itself when possible
    const commitWhereMigrationAdded = await exec(`git log --diff-filter=A --format="%H" -- ${lastVersionData.path}`)
    if (commitWhereMigrationAdded.length > 0) {
        lastGitHash = commitWhereMigrationAdded.trim()
    }
    verbose && console.log(`last version is ${lastVersion}`)

    const folder = path.resolve(path.join(process.cwd(), 'entries', now + ''))
    verbose && console.log(`FOLDER PATH: ${folder}`)
    // compare with git to make sure we're in sync
    const originCommitTimestamp = await exec(`git log ${lastGitHash} -n 1 --format="%at"`)
    if ((parseInt(originCommitTimestamp) + 5000) > now) { // sanity check that it is a valid git hash
        console.error(`SOMETHING IS WRONG WITH THE GIT COMMIT HASH`)
        console.error(`or it was committed in the last 5 seconds`)
        process.exit()
    }// version is schema and data - so 2 each
    return { folder, lastVersion: lastVersion, lastGitHash, lastRelease }
}
const createTemplateFiles = async (folder, lastVersion, lastGitHash) => {
    // create files - each migration is 2 migrations (schema then data) - ensure schema first - include git hash
    console.log(`folder ${folder}`)
    console.log(`lastVersion ${Math.max(lastVersion / 2)}`)
    //schema
    await createFile(folder, lastVersion, lastVersion + 1, templates.forwards, {
        'GIT_FROM_HASH': lastGitHash,
        'DATE': (new Date()).toISOString(),
        'TYPE': 'SCHEMA - FORWARDS',
        'FROM_NUM': lastVersion,
        'TO_NUM': lastVersion + 1
    })
    //data
    await createFile(folder, lastVersion + 1, lastVersion + 2, templates.forwards, {
        'GIT_FROM_HASH': lastGitHash,
        'DATE': (new Date()).toISOString(),
        'TYPE': 'DATA - FORWARDS',
        'FROM_NUM': lastVersion + 1,
        'TO_NUM': lastVersion + 2
    })
    if (generateBackwards) {
        //data
        await createFile(folder, lastVersion + 2, lastVersion + 1, templates.forwards, {
            'GIT_FROM_HASH': lastGitHash,
            'DATE': (new Date()).toISOString(),
            'TYPE': 'DATA - BACKWARDS',
            'FROM_NUM': lastVersion + 2,
            'TO_NUM': lastVersion + 1
        })
        //schema
        await createFile(folder, lastVersion + 1, lastVersion, templates.forwards, {
            'GIT_FROM_HASH': lastGitHash,
            'DATE': (new Date()).toISOString(),
            'TYPE': 'SCHEMA - BACKWARDS',
            'FROM_NUM': lastVersion + 1,
            'TO_NUM': lastVersion
        })
    }
}
const fetchOldRefs = async (folder, lastGitHash) => {
    await exec(`git  cat-file -p ${lastGitHash}:backend/server/src/provision/DefaultData.sql > ${folder}/old-DefaultData.sql `)
    const fetchOldSchema = `git  cat-file -p ${lastGitHash}:backend/server/src/provision/DataModel.sql > ${folder}/old-DataModel.sql `
    await exec(fetchOldSchema)
}

const generateDiffs = async (folder, lastVersion) => {
    // gen diff for reference rseference
    // git diff --color  19bea2b5b79d6640c8e758e12704ef1d00d5bc14:src/provision/DataModel.sql src/provision/DataModel.sql  > migration/today/diffs/DataModel.sql
    await exec(`git diff --color  ${folder}/old-DataModel.sql ../src/provision/DataModel.sql  > ${folder}/${lastVersion}-${lastVersion + 1}-schema.diff `)
    await exec(`git diff --color  ${folder}/old-DefaultData.sql ../src/provision/DefaultData.sql  > ${folder}/${lastVersion}-${lastVersion + 1}-data.diff `)
}

const runNew = async () => {
    if (appArgs[1] && parseInt(appArgs[1]) > 100) { // use this timestamp instead
        now = parseInt(appArgs[1])
    }
    const { folder, lastVersion, lastGitHash } = await getParams()
    await exec(`mkdir -p ${folder}/`)
    /* create folders and files as:
       entries
       - timestamp
       -- 1-2.sql (schema)
       -- 1-2-schema.diff
       -- 2-3.sql (data)
       -- 2-3-data.diff
       -- 3-2.sql (backwards)
       -- 2-1.sql
       -- old-DataModel.sql
       -- old-DefaultData.sql
    */
    createTemplateFiles(folder, lastVersion, lastGitHash)
    await fetchOldRefs(folder, lastGitHash)
    await generateDiffs(folder, lastVersion)

    // output to console what path to update
    console.log(`DONE - CREATED FOLDER: ./entries/${now}`)

    if(appArgs[1] == 'show'){
        console.log('')
        console.log('')
        console.log('SCHEMA DIFF')
        console.log('===========')
        const schemaDiff = await exec(`cat ${folder}/${lastVersion}-${lastVersion + 1}-schema.diff `)
        console.log(schemaDiff)
        console.log('')
        console.log('DATA DIFF')
        console.log('===========')
        const dataDiff = await exec(`cat ${folder}/${lastVersion}-${lastVersion + 1}-data.diff `)
        console.log(dataDiff)
    }
    console.log(`REMEMBER TO UPDATE defaultData.sql FOR PROVISION TO BE IN SYNC - SET SystemProperty.databaseVersion to:${lastVersion + 2}`)
    process.exit()    //end
}
const runMigration = async (params) => {
    require('child_process').spawn('pg-migrator', params, {
        cwd: process.cwd(),
        detached: true,
        stdio: 'inherit'
    }).on('exit',()=>{
        process.exit()
    })
}
const runSelectMigrationPrompt = async (dbUrl, migrationTimestamps) => {
    const namedTimestamps = migrationTimestamps.split('\n').map(x => {
        if (x.length > 0) {
            const d = new Date(parseInt(x.trim()))
            return d.toISOString() + ' : ' + x
        }
    }).filter(Boolean)
    inquirer.prompt([{
        type: 'list',
        name: 'top',
        message: 'which version do you want to load?',
        choices: namedTimestamps
    }]).then(async (answer) => {
        const selectedTimestamp = answer.top.substr(answer.top.lastIndexOf(':') + 1).trim()
        const scriptFiles = new ScriptManager().getList(`./entries/${selectedTimestamp}`)
        const selectedVersionData = scriptFiles.reduce((last, current) => {
            if (current && last && current.targetVersion > last.targetVersion) {
                return current
            }
            return last
        }, { targetVersion: -100 })
        await runMigration([dbUrl, selectedVersionData.targetVersion])

    })
}
const checkDbExists = async(persister, dbUrl)=>{
    let value = null; // ensure db exists
    let dbExistsResult = await persister.query(`SELECT EXISTS(
        SELECT datname FROM pg_catalog.pg_database WHERE lower(datname) = 'advance'
        )`)
    if (dbExistsResult.rows[0].exists === false) {
        await persister.query(`CREATE DATABASE advance`)
        if(dbUrl){ // only using this when there is new db created
            const schemaTester = new pg.Client(dbUrl)
            try {
                await schemaTester.connect()
            } catch (err) {
                console.error(('Could not be connect to PostgreSQL, Error Detail : ' + err))
            }
            await schemaTester.query(`CREATE SCHEMA IF NOT EXISTS advance`)
        }
        console.log("database created")
        value = 'CREATED'
    } else {
        value= true;
    }
    return value;
}
const getDb = async(dbUrl)=>{
    const persister = new pg.Client(dbUrl)
    try {
        await persister.connect()
        console.log('db connected')
    } catch (err) {
        console.error(('Could not be connect to PostgreSQL, Error Detail : ' + err))
        if (err+''.includes("does not exist")){
            await handleDbExistence(dbUrl);
        }
        process.exit(1)
    }
    await checkDbExists(persister)
    return persister
}

const _executeScript = async (persister, scriptFiles, currentVersion, targetVersion) => {
    const direction = currentVersion < targetVersion ? 1 : -1;
    // Calculate the version after migration step according to direction
    const nextVersion = currentVersion + direction;
    // Get migration step file
    const scriptFile = scriptFiles.find((file) => {
        return file.baseVersion === currentVersion && file.targetVersion === nextVersion
    });
    if (!scriptFile) {
        // Migration file is not found. Probably some steps missing, stop migration
        console.log(("FILE_NOT_FOUND" + currentVersion + "-" + nextVersion + ".sql").error);
        process.exit(1);
    } else {
        // Get migration step script file content
        const scriptContent = fs.readFileSync(scriptFile.path, "utf8");
        // Execute migration step script file
        await persister.query(scriptContent);
        console.log("--------------------------------------------------".grey);
        console.log(scriptContent.white);
        console.log((currentVersion + "-" + nextVersion + ".sql executed").info);
        console.log("--------------------------------------------------".grey);
        // Update current version
        currentVersion += direction;
        if (currentVersion !== targetVersion) {
            // Recursive call until reach to target version
            await _executeScript(persister, scriptFiles, currentVersion, targetVersion);
        }
    }
}


const runInitSql = async(persister, scriptFiles, currentVersion, targetVersion, versionManager)=>{
    await persister.query("BEGIN TRANSACTION");
    await _executeScript(persister, scriptFiles, currentVersion, targetVersion);
    await versionManager.update(targetVersion);
    await persister.query("COMMIT TRANSACTION");
    await persister.end();
}
const getDbConfig = async()=>{
    const prefsPath = await exec('echo ${ADVANCE_PREFERENCES_FILE}')
    let prefs, prefsJson ;
    try{
    prefs = fs.readFileSync(prefsPath || '../sample/advance_preferences.json') + ''
    prefsJson = JSON.parse(prefs)
    }catch(e){
        console.log("using db defaults")
    }
    let toUse = prefsJson?.db?.coreDB
    if (!toUse) {
        toUse = {
            host: '127.0.0.1',
            user: 'postgres',
            password: 'password',
            port: 5432,
            database: 'advance',
        }
    }
    return toUse;
}
const setupVersioning = async()=>{
    const toUse = await getDbConfig();
    const certsPath = path.resolve(path.join(process.cwd(), '../../../tools/tls'))
    const ssl = {
        cert: `${certsPath}/postgres.crt`,
        key: `${certsPath}/postgres.key`
    }
    const dbUrl = `postgres://${toUse.user}:${toUse.password}@${toUse.host}/${toUse.database}?sslmode=no-verify&sslcert=${ssl.cert}&sslkey=${ssl.key}`
    const persister = await getDb(dbUrl)
    checkDbExists(persister)
    // make sure migrator connects to advance.SystemProperty.databaseVersion, no other changes from npm
    await exec(`cp ./version-manager.js ../node_modules/pg-migrator/src/version-manager.js`)
    console.log('started versioning')

    process.exit()
}
const handleDbExistence = async(dbUrl) =>{
    const test = new pg.Client(dbUrl.split("advance").join(""))

    await test.connect()
    const check = await checkDbExists(test, dbUrl)
    if(check === "CREATED"){ // auto start
        const version = await getCurrentFromDb(dbUrl)
        const persisterSetup = await getDb(dbUrl)
        await runInitSql(persisterSetup, [
            {path:'./entries/1658808000000/0-1.sql', baseVersion:0, targetVersion:1},
            {path:'./entries/1658808000000/1-2.sql', baseVersion:1, targetVersion:2}
        ], 0, 2,  new VersionManager(persisterSetup))
        console.log("The DB was just reset to the starting point - run migration again to update")
        process.exit()
    }
}
const getCurrentFromDb = async(dbUrl) =>{
    const persister = await getDb(dbUrl)
    const versionManager = new VersionManager(persister)
    const currentVersion = await versionManager.get()
    return currentVersion
}
const runMigrationBase = async () => {
    const db = await getDbConfig();
    const {  lastGitHash, lastRelease } = await getParams()
    const migrationTimestamps = await getMigrationList()
    const certsPath = path.resolve(path.join(process.cwd(), '../../../tools/tls'))
    const ssl = {
        cert: `${certsPath}/postgres.crt`,
        key: `${certsPath}/postgres.key`
    }
    let dbVersion;
    const dbUrl = `postgres://${db.user}:${db.password}@${db.host}/${db.database}?sslmode=no-verify&sslcert=${ssl.cert}&sslkey=${ssl.key}`
    try{
        dbVersion = await getCurrentFromDb(dbUrl)
    }catch(e){
        console.log(`error connecting to: ${dbUrl}`)
        process.exit(1)
    }
    const currentDbVersion = parseInt(dbVersion/2)// schema+data
    // version 0 is v1 - avoid confusion - show 1
    const total = (migrationTimestamps.split('\n').length) - 1;
    console.log('\x1b[32m%s\x1b[0m', `DB: ${dbUrl}`)
    console.log('\x1b[36m%s\x1b[0m', `total migrations: ${total}`)
    console.log(`last migration git origin hash: ${lastGitHash}`)
    console.log('\x1b[36m%s\x1b[0m', `last migration was for release: ${lastRelease}`)

    console.log('\x1b[32m%s\x1b[0m', `db is currently at version: ${currentDbVersion}`)
    return { dbUrl, migrationTimestamps , dbVersion, total}
}
const runSimpleMigration = async () => {
    const { dbUrl, dbVersion, total } = await runMigrationBase()
    if(dbVersion == (total*2)){
        console.log("The db is at the latest version")
        process.exit()
    } 
    inquirer.prompt([{
        type: 'list',
        name: 'top',
        message: 'Do you want to migrate?',
        choices: ['Yes', 'No']
    }]).then(async (answer) => {
        if (answer.top == 'Yes') {
            await runMigration([dbUrl])
        } else {
            process.exit()
        }
    })

}
const runMigrationPrompt = async () => {
    const { dbUrl, migrationTimestamps } = await runMigrationBase()
    inquirer.prompt([{
        type: 'list',
        name: 'top',
        message: 'what do you want to do?',
        choices: ['migrate to latest', '+1', '-1', 'select version', 'migrate to first']
    }]).then(async (answer) => {
        switch (answer.top) {
            case 'migrate to latest':
                await runMigration([dbUrl])
                break
            case '+1':
                await runMigration([dbUrl, '+2'])
                break
            case '-1':
                await runMigration([dbUrl, '-2'])
                break
            case 'select version':
                await runSelectMigrationPrompt(dbUrl, migrationTimestamps)
                break
            case 'migrate to first':
                await runMigration([dbUrl, '2'])
                break
        }
    })
}


/*
 *       STARTING POINT
 */
switch (appArgs[0]) {
    case 'new':
        check24h()
        break
    case 'migrate': // shortcut to pg-migrator with args
        if (appArgs[1] == '--more') {
            runMigrationPrompt()
        } else {
            runSimpleMigration()
        }
        break
    case 'setup':
        setupVersioning()
        break
}

