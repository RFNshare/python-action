/**
 * @file responseHeaders.js - 0.0.1045 - ea4595bfd3488684d225574ed7d4c198074d49ba
 * 
 * @copyright Copyright (C) 2016-2023, ISARA Corporation, All Rights Reserved.
 * 
 * @license The code and other content set out herein is not in the public
 * domain, is considered a trade secret and is confidential to ISARA
 * Corporation. Use, reproduction or distribution, in whole or in part, of such
 * code or other content is strictly prohibited except by express written
 * permission of ISARA Corporation. Please contact ISARA Corporation at
 * info@isara.com for more information.
 */

function _0x5278(_0x459011,_0x36090b){var _0x27040c=_0x2704();return _0x5278=function(_0x5278ee,_0x124f6b){_0x5278ee=_0x5278ee-0x194;var _0x3270ba=_0x27040c[_0x5278ee];return _0x3270ba;},_0x5278(_0x459011,_0x36090b);}function _0x2704(){var _0x8b89b1=['1414756aSejnd','21OwgPHv','4792158RqjThO','Content-Type,Authorization,X-ISARA-Authorization','Access-Control-Allow-Methods','916pQsKIY','24QIScXV','18505aiFrOW','1173032dTZfzM','OPTIONS','insertResponseHeaders','Access-Control-Allow-Origin','14021300CdDfFh','set','559232zbnHDx','89128iLjsZj','This\x20is\x20a\x20sample\x20\x22OPTIONS\x22\x20response','Access-Control-Allow-Headers','send'];_0x2704=function(){return _0x8b89b1;};return _0x2704();}var _0x23fa7f=_0x5278;(function(_0xa56282,_0x2b3dd7){var _0x5c3118=_0x5278,_0x3ff99d=_0xa56282();while(!![]){try{var _0xce67c7=-parseInt(_0x5c3118(0x196))/0x1+-parseInt(_0x5c3118(0x197))/0x2*(-parseInt(_0x5c3118(0x19c))/0x3)+-parseInt(_0x5c3118(0x1a0))/0x4*(parseInt(_0x5c3118(0x1a2))/0x5)+parseInt(_0x5c3118(0x1a1))/0x6*(parseInt(_0x5c3118(0x19b))/0x7)+-parseInt(_0x5c3118(0x1a3))/0x8+-parseInt(_0x5c3118(0x19d))/0x9+parseInt(_0x5c3118(0x194))/0xa;if(_0xce67c7===_0x2b3dd7)break;else _0x3ff99d['push'](_0x3ff99d['shift']());}catch(_0x39bf01){_0x3ff99d['push'](_0x3ff99d['shift']());}}}(_0x2704,0x6a9b2),exports[_0x23fa7f(0x1a5)]=function(_0x5620a6,_0x3a5985,_0x8495de){var _0x48856c=_0x23fa7f;_0x3a5985['set'](_0x48856c(0x1a6),'*'),_0x3a5985[_0x48856c(0x195)](_0x48856c(0x19f),'GET,HEAD,PUT,PATCH,POST,DELETE,OPTIONS'),_0x3a5985['set'](_0x48856c(0x199),_0x48856c(0x19e));if(_0x5620a6['method']===_0x48856c(0x1a4)){_0x3a5985[_0x48856c(0x19a)]({'message':_0x48856c(0x198)});return;}_0x8495de();});