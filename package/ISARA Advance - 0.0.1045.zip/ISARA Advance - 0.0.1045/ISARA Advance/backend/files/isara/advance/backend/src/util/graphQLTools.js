/**
 * @file graphQLTools.js - 0.0.1045 - ea4595bfd3488684d225574ed7d4c198074d49ba
 * 
 * @copyright Copyright (C) 2016-2023, ISARA Corporation, All Rights Reserved.
 * 
 * @license The code and other content set out herein is not in the public
 * domain, is considered a trade secret and is confidential to ISARA
 * Corporation. Use, reproduction or distribution, in whole or in part, of such
 * code or other content is strictly prohibited except by express written
 * permission of ISARA Corporation. Please contact ISARA Corporation at
 * info@isara.com for more information.
 */

function _0x3140(_0x1583b8,_0x3faf1e){var _0x2203e4=_0x2203();return _0x3140=function(_0x3140de,_0x2335b6){_0x3140de=_0x3140de-0x15b;var _0x2e2aa1=_0x2203e4[_0x3140de];return _0x2e2aa1;},_0x3140(_0x1583b8,_0x3faf1e);}(function(_0x1b8123,_0x3bf1ea){var _0x264589=_0x3140,_0x248be9=_0x1b8123();while(!![]){try{var _0x524ff5=-parseInt(_0x264589(0x163))/0x1*(parseInt(_0x264589(0x160))/0x2)+-parseInt(_0x264589(0x162))/0x3*(-parseInt(_0x264589(0x165))/0x4)+-parseInt(_0x264589(0x167))/0x5*(-parseInt(_0x264589(0x166))/0x6)+parseInt(_0x264589(0x169))/0x7+parseInt(_0x264589(0x161))/0x8*(-parseInt(_0x264589(0x16a))/0x9)+parseInt(_0x264589(0x15b))/0xa+parseInt(_0x264589(0x168))/0xb*(-parseInt(_0x264589(0x164))/0xc);if(_0x524ff5===_0x3bf1ea)break;else _0x248be9['push'](_0x248be9['shift']());}catch(_0x56111d){_0x248be9['push'](_0x248be9['shift']());}}}(_0x2203,0x6fe55));function _0x2203(){var _0x3bd42b=['5663wLdMly','12cuPykV','4CCunXj','1585104eeIhMd','5dDPFKg','10490161FdoXpq','5475561vocaYx','36EPInsK','3203510gnJuOP','selectionSet','length','selections','value','250ogSCsk','46144AXpgSd','2328495InZcDi'];_0x2203=function(){return _0x3bd42b;};return _0x2203();}function findField(_0x1c2e8a,_0x39eaf1,_0x1847f4){var _0x46b11c=_0x3140;_0x1847f4===undefined&&(_0x1847f4=0x0);var _0x4bec99=_0x39eaf1[_0x1847f4];for(var _0x531f36 of _0x1c2e8a){if(_0x531f36['name'][_0x46b11c(0x15f)]===_0x4bec99){if(_0x1847f4===_0x39eaf1[_0x46b11c(0x15d)]-0x1)return!![];return findField(_0x531f36[_0x46b11c(0x15c)][_0x46b11c(0x15e)],_0x39eaf1,_0x1847f4+0x1);}}return![];}exports['findField']=findField;