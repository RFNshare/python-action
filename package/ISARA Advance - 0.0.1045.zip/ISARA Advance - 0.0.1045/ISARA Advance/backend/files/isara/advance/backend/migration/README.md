= Migration =

We have a postgres migration setup built on top of mg-migrator

In our system we always have separate schema and data sql scripts.
This keeps migration numbers always even.


## setup

When first installing the backend, we need to prep the migrator with:
```npm run migrator:setup```

## creating migrations

To create a new migration, we may run:
```npm run migrate:new```

This will create a folder in backend/server/entries/ with the current timestamp

the folder will have some files from a template as well as references to help you write the migration

for example:
2-3.sql - schema upgrade
3-2.sql - schema downgrade
3-4.sql - data upgrade
4-3.sql - data downgrade

By using 2 in 1, we ensure the schema is always upgraded before the data, and opposite when downgrading.

You will also see the schema and data sql files from the previous migration commit and the corresponding diffs.

If it detects an existing migration within the last 24 hours, it will ask to confirm

There is also an option to create a new migration and also display the diffs in the console at the same time

For this option, we may run:
```npm run migrate:show```


## running migrations

We may run migrations with the following command:

```npm run migrator```

It will prompt the user to verify and run to latest.

Also, this displays some basic data including the db connection, how many migrations we have, and the current version.

![Run migration](img/migrate.png?raw=true "Run migration")

If the db is missing - it wil automatically recreate it to help get you started

![Missing DB](img/migrate-noDb.png?raw=true "Missing DB")

We may also use:

```npm run migrator:more```

This will give us a menu with more options, such as +1 , -1, first, and last.


It also allows selecting from a list, which migration we wish to jump to.

![Jump to a version](img/migrate-version.png?raw=true "Jump to a version")