/**
 * @file version-manager.js - 0.0.1045 - ea4595bfd3488684d225574ed7d4c198074d49ba
 * 
 * @copyright Copyright (C) 2016-2023, ISARA Corporation, All Rights Reserved.
 * 
 * @license The code and other content set out herein is not in the public
 * domain, is considered a trade secret and is confidential to ISARA
 * Corporation. Use, reproduction or distribution, in whole or in part, of such
 * code or other content is strictly prohibited except by express written
 * permission of ISARA Corporation. Please contact ISARA Corporation at
 * info@isara.com for more information.
 */

'use strict'

module.exports = class VersionManager {

    constructor(persister) {

        this._persister = persister
    }

    async get() {

        let tableExistsResult = await this._persister.query(
            "SELECT EXISTS(SELECT * FROM information_schema.tables  WHERE table_name = 'SystemProperty') as value"
            //"SELECT EXISTS(SELECT * FROM information_schema.tables  WHERE table_name = 'version') as value"
            )

        if (tableExistsResult.rows[0].value) {

            let versionResult = await this._persister.query(
                `select value from advance."SystemProperty" where key = 'databaseVersion'`
                //'SELECT value FROM advance.version'
                )

            return parseInt(versionResult.rows[0].value)

        } else {
            // This should never actually happen in a real world scenario
            await this._persister.query(
                `CREATE TABLE IF NOT EXISTS "advance"."SystemProperty" (
                    "id" bigserial PRIMARY KEY,
                    "key" varchar(100) UNIQUE NOT NULL,
                    "value" text
                );`
                //'CREATE TABLE advance.version (value integer)'
                )

            await this._persister.query(
                `INSERT INTO "advance"."SystemProperty" VALUES (DEFAULT, 'databaseVersion', '0');`
                //'INSERT INTO advance.version(value) VALUES(1)'
            )

            return 0
        }
    }

    async update(version) {
        await this._persister.query(
            `UPDATE "advance"."SystemProperty" SET value = $1 WHERE key = 'databaseVersion'`
            //'UPDATE advance.version SET value = $1'
        , [version])
    }
}