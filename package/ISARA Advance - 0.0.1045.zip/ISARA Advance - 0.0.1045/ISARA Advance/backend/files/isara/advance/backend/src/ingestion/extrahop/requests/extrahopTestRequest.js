/**
 * @file extrahopTestRequest.js - 0.0.1045 - ea4595bfd3488684d225574ed7d4c198074d49ba
 * 
 * @copyright Copyright (C) 2016-2023, ISARA Corporation, All Rights Reserved.
 * 
 * @license The code and other content set out herein is not in the public
 * domain, is considered a trade secret and is confidential to ISARA
 * Corporation. Use, reproduction or distribution, in whole or in part, of such
 * code or other content is strictly prohibited except by express written
 * permission of ISARA Corporation. Please contact ISARA Corporation at
 * info@isara.com for more information.
 */

function _0x587e(){const _0x5b0265=['944BnyxnI','6EscbOa','/api/v1/extrahop','3tECAIY','1747180UrqPyV','./extrahopRequest','618NtFTCh','7320577ALTgYH','ExtrahopTestRequest','2958412naXNDR','1182342DWEddP','2704eoSSwS','11079ebhDEL','3085350mtpxsn'];_0x587e=function(){return _0x5b0265;};return _0x587e();}const _0x3794da=_0x2b44;function _0x2b44(_0x182c38,_0x10320c){const _0x587eca=_0x587e();return _0x2b44=function(_0x2b444c,_0x2ef4cd){_0x2b444c=_0x2b444c-0x19e;let _0x3038b0=_0x587eca[_0x2b444c];return _0x3038b0;},_0x2b44(_0x182c38,_0x10320c);}(function(_0x128d14,_0x1b161e){const _0x16e603=_0x2b44,_0x5378a3=_0x128d14();while(!![]){try{const _0x4b887a=parseInt(_0x16e603(0x1a7))/0x1*(parseInt(_0x16e603(0x19f))/0x2)+parseInt(_0x16e603(0x1aa))/0x3*(parseInt(_0x16e603(0x1a2))/0x4)+parseInt(_0x16e603(0x1ab))/0x5*(parseInt(_0x16e603(0x1a8))/0x6)+-parseInt(_0x16e603(0x1a3))/0x7+-parseInt(_0x16e603(0x1a4))/0x8*(parseInt(_0x16e603(0x1a5))/0x9)+parseInt(_0x16e603(0x1a6))/0xa+-parseInt(_0x16e603(0x1a0))/0xb;if(_0x4b887a===_0x1b161e)break;else _0x5378a3['push'](_0x5378a3['shift']());}catch(_0x5eb952){_0x5378a3['push'](_0x5378a3['shift']());}}}(_0x587e,0x6b1fb));const {ExtrahopRequest}=require(_0x3794da(0x19e));class ExtrahopTestRequest extends ExtrahopRequest{constructor(_0x58de5d,_0x34638c,_0x35ddcc){const _0x4f1a13=_0x3794da;super(_0x58de5d,_0x4f1a13(0x1a9),_0x34638c,'GET','',_0x35ddcc);}}exports[_0x3794da(0x1a1)]=ExtrahopTestRequest;