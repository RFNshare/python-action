/**
 * @file scanTanium.js - 0.0.1045 - ea4595bfd3488684d225574ed7d4c198074d49ba
 * 
 * @copyright Copyright (C) 2016-2023, ISARA Corporation, All Rights Reserved.
 * 
 * @license The code and other content set out herein is not in the public
 * domain, is considered a trade secret and is confidential to ISARA
 * Corporation. Use, reproduction or distribution, in whole or in part, of such
 * code or other content is strictly prohibited except by express written
 * permission of ISARA Corporation. Please contact ISARA Corporation at
 * info@isara.com for more information.
 */

const _0x3fb328=_0x2b9b;function _0x2b9b(_0xea6150,_0x24f724){const _0x4429a2=_0x4429();return _0x2b9b=function(_0x2b9bb5,_0x43c3a1){_0x2b9bb5=_0x2b9bb5-0x136;let _0x5db6b3=_0x4429a2[_0x2b9bb5];return _0x5db6b3;},_0x2b9b(_0xea6150,_0x24f724);}function _0x4429(){const _0x47dd8a=['10nrkief','56256XRSWaj','{\x20\x22url\x22:\x20\x22https://isara-api.cloud.tanium.com\x22,\x20\x22token\x22:\x20\x22token-0bc8513a4946e32e20c5754c493509b4e8e747870604a13f3d02d6d22e\x22\x20}','onRejected\x20','63642zBWIlx','Tanium','2447333HSwwCN','./ingestion/tanium/scanner','64mtAZkG','1081638FjCimO','79737dzXTJE','onFinally','72zzEOZv','10589580xKWTYI','4047280oDtFhu','message','log'];_0x4429=function(){return _0x47dd8a;};return _0x4429();}(function(_0x34e45f,_0x5ca73f){const _0x23ad51=_0x2b9b,_0x5b54dd=_0x34e45f();while(!![]){try{const _0x18e07f=-parseInt(_0x23ad51(0x13b))/0x1+parseInt(_0x23ad51(0x13f))/0x2*(-parseInt(_0x23ad51(0x141))/0x3)+-parseInt(_0x23ad51(0x145))/0x4+parseInt(_0x23ad51(0x137))/0x5*(parseInt(_0x23ad51(0x138))/0x6)+parseInt(_0x23ad51(0x13d))/0x7+parseInt(_0x23ad51(0x143))/0x8*(parseInt(_0x23ad51(0x140))/0x9)+parseInt(_0x23ad51(0x144))/0xa;if(_0x18e07f===_0x5ca73f)break;else _0x5b54dd['push'](_0x5b54dd['shift']());}catch(_0x33451e){_0x5b54dd['push'](_0x5b54dd['shift']());}}}(_0x4429,0x8e541));const {scan}=require(_0x3fb328(0x13e));async function main(){const _0x2e6e64=_0x3fb328,_0x13373f={'configuration':'{\x20\x22computer_group\x22:\x20\x22All\x20Computers\x22\x20}','dataSource':{'softwareVersion':{'name':_0x2e6e64(0x13c)},'configuration':_0x2e6e64(0x139)}};scan(_0x13373f,null,async _0x111e6d=>{const _0x3e3a01=_0x2e6e64;console[_0x3e3a01(0x136)]('onFulfilled\x20'+_0x111e6d);},async _0x3cca56=>{const _0x5e76a3=_0x2e6e64;console[_0x5e76a3(0x136)](_0x5e76a3(0x13a)+_0x3cca56[_0x5e76a3(0x146)]);},async()=>{const _0x6d8eeb=_0x2e6e64;console[_0x6d8eeb(0x136)](_0x6d8eeb(0x142));});}main();