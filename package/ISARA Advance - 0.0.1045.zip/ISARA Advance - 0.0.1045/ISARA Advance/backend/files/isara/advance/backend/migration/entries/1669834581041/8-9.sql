--
-- @file 8-9.sql - 0.0.1045 - ea4595bfd3488684d225574ed7d4c198074d49ba
-- 
-- @copyright Copyright (C) 2016-2023, ISARA Corporation, All Rights Reserved.
-- 
-- @license The code and other content set out herein is not in the public
-- domain, is considered a trade secret and is confidential to ISARA
-- Corporation. Use, reproduction or distribution, in whole or in part, of such
-- code or other content is strictly prohibited except by express written
-- permission of ISARA Corporation. Please contact ISARA Corporation at
-- info@isara.com for more information.
--

    /* 
    * 
    *    SCHEMA - FORWARDS 
    *    MIGRATION 8 TO 9 
    *    >FOR RELEASE 0.91.0
    *    ORIGIN GIT HASH:36911e55aab42e62306b2c69392cc84b1ba3b46e
    * 
    *    CREATED ON 2022-11-30T18:56:21.213Z
    * 
    */


CREATE TABLE "advance"."CipherSuiteScore" (
    "id" bigserial PRIMARY KEY,
    "cipherSuite" varchar,
    "cryptoScore" bigint ,
    UNIQUE("cipherSuite", "cryptoScore")
);
ALTER TABLE "advance"."CipherSuiteScore" OWNER TO "postgres";

CREATE OR REPLACE VIEW "advance"."tScore" as
select s."friendlyName" as "CryptoScore",
    sc."friendlyName" as "cryptoScoreCoarse",
    sc."name" as "cryptoScoreCoarseName",
    score
from "advance"."CryptoScore" as s,
    "advance"."CryptoScoreCoarse" as sc
where (s."cryptoScoreCoarse" = sc.id);

ALTER TABLE "advance"."Certificate" ALTER COLUMN "publicKeyCryptoPrimitiveParameter" varchar(50) NULL;

ALTER TABLE "advance"."DataSource" ALTER COLUMN "addedBy" bigint REFERENCES "advance"."User";

ALTER TABLE "advance"."DataSource" ADD COLUMN "start" timestamp with time zone;

ALTER TABLE "advance"."DataSource" ADD COLUMN "end" timestamp with time zone;

COMMENT ON COLUMN "advance"."DataSource"."start" IS 'start time when the data source is run';
COMMENT ON COLUMN "advance"."DataSource"."end" IS 'End time when data source is run';

ALTER TABLE "advance"."DataSourceScan" ALTER COLUMN "addedBy" bigint REFERENCES "advance"."User";

COMMENT ON COLUMN "advance"."StreamStatus"."name" is 'The stream which these records cover';

