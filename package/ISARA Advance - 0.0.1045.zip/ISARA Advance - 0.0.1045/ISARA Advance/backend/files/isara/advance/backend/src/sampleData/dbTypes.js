/**
 * @file dbTypes.js - 0.0.1045 - ea4595bfd3488684d225574ed7d4c198074d49ba
 * 
 * @copyright Copyright (C) 2016-2023, ISARA Corporation, All Rights Reserved.
 * 
 * @license The code and other content set out herein is not in the public
 * domain, is considered a trade secret and is confidential to ISARA
 * Corporation. Use, reproduction or distribution, in whole or in part, of such
 * code or other content is strictly prohibited except by express written
 * permission of ISARA Corporation. Please contact ISARA Corporation at
 * info@isara.com for more information.
 */

var _0xf94a78=_0x5892;function _0x5892(_0x5a3599,_0xf9ad51){var _0x47cd1a=_0x47cd();return _0x5892=function(_0x5892c5,_0x3f4a47){_0x5892c5=_0x5892c5-0x116;var _0x48369d=_0x47cd1a[_0x5892c5];return _0x48369d;},_0x5892(_0x5a3599,_0xf9ad51);}function _0x47cd(){var _0x21c209=['23274650xQqeOM','2565573foWnza','protocols','allStrongCryptoPrimitives','9535064KsiYLj','protocolVariants','3156uPlBZb','layer4Protocols','weakProtocolVariants','6EdRDVv','deviceTypes','connectionRatings','allCryptoPrimitives','notificationTypes','1035dtmokX','2558826gDychb','certificateTypes','users','9dKkCNr','240348uFteLh','2790832EWNDGP','strongProtocolVariants'];_0x47cd=function(){return _0x21c209;};return _0x47cd();}(function(_0x260828,_0x13fce0){var _0x384977=_0x5892,_0x2ddc22=_0x260828();while(!![]){try{var _0x3607fb=-parseInt(_0x384977(0x128))/0x1*(-parseInt(_0x384977(0x11e))/0x2)+parseInt(_0x384977(0x116))/0x3+-parseInt(_0x384977(0x11b))/0x4*(-parseInt(_0x384977(0x123))/0x5)+parseInt(_0x384977(0x124))/0x6+parseInt(_0x384977(0x119))/0x7+parseInt(_0x384977(0x129))/0x8*(-parseInt(_0x384977(0x127))/0x9)+-parseInt(_0x384977(0x12b))/0xa;if(_0x3607fb===_0x13fce0)break;else _0x2ddc22['push'](_0x2ddc22['shift']());}catch(_0x58adc1){_0x2ddc22['push'](_0x2ddc22['shift']());}}}(_0x47cd,0xcff96),exports[_0xf94a78(0x121)]={},exports[_0xf94a78(0x118)]={},exports['allWeakCryptoPrimitives']={},exports[_0xf94a78(0x125)]={},exports['connectionCertificateTypes']={},exports[_0xf94a78(0x120)]={},exports[_0xf94a78(0x11f)]={},exports[_0xf94a78(0x122)]={},exports[_0xf94a78(0x117)]={},exports[_0xf94a78(0x11a)]={},exports[_0xf94a78(0x12a)]={},exports[_0xf94a78(0x11d)]={},exports['roles']={},exports['softwareTypes']={},exports['tagTypes']={},exports[_0xf94a78(0x11c)]={},exports[_0xf94a78(0x126)]=[]);