/**
 * @file version.js - 0.0.1045 - ea4595bfd3488684d225574ed7d4c198074d49ba
 * 
 * @copyright Copyright (C) 2016-2023, ISARA Corporation, All Rights Reserved.
 * 
 * @license The code and other content set out herein is not in the public
 * domain, is considered a trade secret and is confidential to ISARA
 * Corporation. Use, reproduction or distribution, in whole or in part, of such
 * code or other content is strictly prohibited except by express written
 * permission of ISARA Corporation. Please contact ISARA Corporation at
 * info@isara.com for more information.
 */

function _0x3832(_0x2e1418,_0x25e6f9){var _0x2dd9e2=_0x2dd9();return _0x3832=function(_0x3832e0,_0x5a0a3c){_0x3832e0=_0x3832e0-0xb1;var _0x7c84d9=_0x2dd9e2[_0x3832e0];return _0x7c84d9;},_0x3832(_0x2e1418,_0x25e6f9);}var _0x5b715d=_0x3832;(function(_0x16da20,_0x3ba4ac){var _0x3c23b5=_0x3832,_0x20d7bc=_0x16da20();while(!![]){try{var _0x550868=parseInt(_0x3c23b5(0xc4))/0x1+parseInt(_0x3c23b5(0xc0))/0x2+parseInt(_0x3c23b5(0xbc))/0x3*(-parseInt(_0x3c23b5(0xbd))/0x4)+-parseInt(_0x3c23b5(0xba))/0x5*(parseInt(_0x3c23b5(0xb5))/0x6)+-parseInt(_0x3c23b5(0xb6))/0x7*(parseInt(_0x3c23b5(0xb4))/0x8)+parseInt(_0x3c23b5(0xc3))/0x9+-parseInt(_0x3c23b5(0xbe))/0xa*(parseInt(_0x3c23b5(0xb3))/0xb);if(_0x550868===_0x3ba4ac)break;else _0x20d7bc['push'](_0x20d7bc['shift']());}catch(_0x4c36c7){_0x20d7bc['push'](_0x20d7bc['shift']());}}}(_0x2dd9,0x57ec4),exports[_0x5b715d(0xbf)]={'path':'/service/version','get':{'handler':async function(_0x5a9b38,_0x244d21){var _0x3c46e6=_0x5b715d;_0x244d21[_0x3c46e6(0xb8)](_0x3c46e6(0xb9),_0x3c46e6(0xb1)),_0x244d21[_0x3c46e6(0xb7)](JSON[_0x3c46e6(0xc2)]({'timeStamp':'2023-02-06T13:37:42.098Z','version':_0x3c46e6(0xc1),'gitVersion':_0x3c46e6(0xb2)})),_0x244d21['status'](0xc8)['end']();}}},exports[_0x5b715d(0xbb)]=!![]);function _0x2dd9(){var _0x8b346b=['bypassWrappers','3hBMJrA','756500ADZsxX','6012010KufRjq','endpoint','1155470SBNziQ','0.0.1045','stringify','4309020YNnERc','654357Idabye','application/json','ea4595bfd3488684d225574ed7d4c198074d49ba','11uCUKsc','4296JsVyRa','12GVTEFH','3248awxVQE','send','setHeader','Content-type','778115sqvxtM'];_0x2dd9=function(){return _0x8b346b;};return _0x2dd9();}