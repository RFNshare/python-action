/**
 * @file netmask.js - 0.0.1045 - ea4595bfd3488684d225574ed7d4c198074d49ba
 * 
 * @copyright Copyright (C) 2016-2023, ISARA Corporation, All Rights Reserved.
 * 
 * @license The code and other content set out herein is not in the public
 * domain, is considered a trade secret and is confidential to ISARA
 * Corporation. Use, reproduction or distribution, in whole or in part, of such
 * code or other content is strictly prohibited except by express written
 * permission of ISARA Corporation. Please contact ISARA Corporation at
 * info@isara.com for more information.
 */

const _0x3897bb=_0x1265;function _0x1265(_0x19aee3,_0x30707a){const _0x13a8a4=_0x13a8();return _0x1265=function(_0x126585,_0x2f525e){_0x126585=_0x126585-0xd1;let _0x1df736=_0x13a8a4[_0x126585];return _0x1df736;},_0x1265(_0x19aee3,_0x30707a);}(function(_0x47c78b,_0x5e523f){const _0x4fdd99=_0x1265,_0x4ab7e1=_0x47c78b();while(!![]){try{const _0x19a4f8=-parseInt(_0x4fdd99(0xd7))/0x1+-parseInt(_0x4fdd99(0xdc))/0x2+parseInt(_0x4fdd99(0xe2))/0x3+parseInt(_0x4fdd99(0xd1))/0x4*(-parseInt(_0x4fdd99(0xe1))/0x5)+parseInt(_0x4fdd99(0xde))/0x6*(parseInt(_0x4fdd99(0xe3))/0x7)+parseInt(_0x4fdd99(0xdb))/0x8+parseInt(_0x4fdd99(0xd5))/0x9*(parseInt(_0x4fdd99(0xdd))/0xa);if(_0x19a4f8===_0x5e523f)break;else _0x4ab7e1['push'](_0x4ab7e1['shift']());}catch(_0x1a2fe5){_0x4ab7e1['push'](_0x4ab7e1['shift']());}}}(_0x13a8,0x4c2ac));function _0x13a8(){const _0x520104=['insertNetmasks','nameValues','1483065FpLkYn','276807kzMaTr','308zxbTEh','4sShaiE','netmasks','Netmask','map','4589631xtCjST','../../util/log','96584KRyNSA','log','../dbHelpers','push','1746064nzvJET','573994YBpYBf','10wEEHMz','23412FObDLa'];_0x13a8=function(){return _0x520104;};return _0x13a8();}const {Netmask}=require('../dbObjects'),{dumpObjectTimingStats,initDbConnection,insertObject,bulkInsertRecords,resetObjectTimingStats}=require(_0x3897bb(0xd9));var log=require(_0x3897bb(0xd6))(module);exports[_0x3897bb(0xdf)]=async function(_0x1e54d2,_0x569e73,_0x3b71fb){const _0x59fedd=_0x3897bb;let _0x349510=[];const _0x2109c5=_0x569e73['numEmpty']||0x14;for(var _0x574990=0x0;_0x574990<_0x2109c5;++_0x574990){let _0x4c48de=new Netmask();_0x349510[_0x59fedd(0xda)](_0x4c48de[_0x59fedd(0xe0)]);}_0x569e73['named']&&_0x569e73['named'][_0x59fedd(0xd4)](_0x3acfb2=>{_0x349510['push'](_0x3acfb2);});const _0xfdd732=await bulkInsertRecords(_0x59fedd(0xd3),_0x349510,_0x1e54d2);if(!_0x3b71fb[_0x59fedd(0xd2)])_0x3b71fb[_0x59fedd(0xd2)]=[];log[_0x59fedd(0xd8)](_0xfdd732),_0x3b71fb['netmasks']=[..._0x3b71fb['netmasks'],..._0xfdd732['rows']];};