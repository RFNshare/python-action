/**
 * @file categoryConstants.js - 0.0.1045 - ea4595bfd3488684d225574ed7d4c198074d49ba
 * 
 * @copyright Copyright (C) 2016-2023, ISARA Corporation, All Rights Reserved.
 * 
 * @license The code and other content set out herein is not in the public
 * domain, is considered a trade secret and is confidential to ISARA
 * Corporation. Use, reproduction or distribution, in whole or in part, of such
 * code or other content is strictly prohibited except by express written
 * permission of ISARA Corporation. Please contact ISARA Corporation at
 * info@isara.com for more information.
 */

function _0x9098(){var _0x59fbd2=['CONNECTION','6696290zXbKkr','AGILITY','Connection\x20Crypto','Device','7002858rDLOiz','Agility','7PwNgvU','Connection','Technology','783XiNZwJ','2188920XZAnjm','DEVICECRYPTO','13568860GxgMvY','2834440bVJALN','TECHNOLOGY','117720gkmymH','Networking','2wOrcuv','filterCategoryTypes','Device\x20Crypto','509380yMAgyg','NETWORKING'];_0x9098=function(){return _0x59fbd2;};return _0x9098();}function _0x1d0a(_0x353f81,_0x3f5c68){var _0x9098e5=_0x9098();return _0x1d0a=function(_0x1d0a8d,_0x438ac6){_0x1d0a8d=_0x1d0a8d-0x99;var _0x28c55e=_0x9098e5[_0x1d0a8d];return _0x28c55e;},_0x1d0a(_0x353f81,_0x3f5c68);}var _0x1b87c4=_0x1d0a;(function(_0x39d1f3,_0x27d775){var _0x4c8d98=_0x1d0a,_0x2de913=_0x39d1f3();while(!![]){try{var _0x47dc2a=parseInt(_0x4c8d98(0x9d))/0x1*(-parseInt(_0x4c8d98(0xa0))/0x2)+parseInt(_0x4c8d98(0xad))/0x3+parseInt(_0x4c8d98(0x99))/0x4+-parseInt(_0x4c8d98(0xa3))/0x5+-parseInt(_0x4c8d98(0xa7))/0x6*(-parseInt(_0x4c8d98(0xa9))/0x7)+parseInt(_0x4c8d98(0x9b))/0x8*(parseInt(_0x4c8d98(0xac))/0x9)+-parseInt(_0x4c8d98(0xaf))/0xa;if(_0x47dc2a===_0x27d775)break;else _0x2de913['push'](_0x2de913['shift']());}catch(_0x3512f1){_0x2de913['push'](_0x2de913['shift']());}}}(_0x9098,0xa608a),exports[_0x1b87c4(0x9e)]={'AGILITY':_0x1b87c4(0xa4),'CONNECTION':_0x1b87c4(0xa2),'CONNECTIONCRYPTO':'CONNECTIONCRYPTO','DEVICE':'DEVICE','NETWORKING':_0x1b87c4(0xa1),'TECHNOLOGY':_0x1b87c4(0x9a),'DEVICECRYPTO':_0x1b87c4(0xae),'CRYPTO':'CRYPTO'},exports['filterCategoryNames']={'AGILITY':_0x1b87c4(0xa8),'CONNECTION':_0x1b87c4(0xaa),'CONNECTIONCRYPTO':_0x1b87c4(0xa5),'DEVICE':_0x1b87c4(0xa6),'NETWORKING':_0x1b87c4(0x9c),'TECHNOLOGY':_0x1b87c4(0xab),'DEVICECRYPTO':_0x1b87c4(0x9f),'CRYPTO':'Crypto'},exports['postureCategories']={'DEVICE':0x0,'CONNECTION':0x1,'SOFTWARE':0x2});