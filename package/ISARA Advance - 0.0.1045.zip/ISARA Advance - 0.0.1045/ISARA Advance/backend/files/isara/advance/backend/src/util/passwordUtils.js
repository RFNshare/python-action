/**
 * @file passwordUtils.js - 0.0.1045 - ea4595bfd3488684d225574ed7d4c198074d49ba
 * 
 * @copyright Copyright (C) 2016-2023, ISARA Corporation, All Rights Reserved.
 * 
 * @license The code and other content set out herein is not in the public
 * domain, is considered a trade secret and is confidential to ISARA
 * Corporation. Use, reproduction or distribution, in whole or in part, of such
 * code or other content is strictly prohibited except by express written
 * permission of ISARA Corporation. Please contact ISARA Corporation at
 * info@isara.com for more information.
 */

function _0x3a41(){const _0x132aff=['310075bAuwcs','argon2','8LPxsLK','argon2id','225385hSRvhq','randomSleep','hash','720489uTSDxO','crypto','7841916DYytfC','randomInt','4420101sGGVPm','1336750xxSRJY','68LjYrrn','137304OdxtVa','exports'];_0x3a41=function(){return _0x132aff;};return _0x3a41();}function _0x44a8(_0x4d8b0c,_0x2e999b){const _0x3a415a=_0x3a41();return _0x44a8=function(_0x44a824,_0x529be3){_0x44a824=_0x44a824-0x143;let _0xc26a22=_0x3a415a[_0x44a824];return _0xc26a22;},_0x44a8(_0x4d8b0c,_0x2e999b);}const _0x59aaa7=_0x44a8;(function(_0x501531,_0x159c0d){const _0x31af50=_0x44a8,_0x283327=_0x501531();while(!![]){try{const _0x48dbb4=parseInt(_0x31af50(0x150))/0x1+-parseInt(_0x31af50(0x14c))/0x2+-parseInt(_0x31af50(0x147))/0x3+parseInt(_0x31af50(0x14d))/0x4*(parseInt(_0x31af50(0x144))/0x5)+-parseInt(_0x31af50(0x14e))/0x6+parseInt(_0x31af50(0x14b))/0x7*(-parseInt(_0x31af50(0x152))/0x8)+parseInt(_0x31af50(0x149))/0x9;if(_0x48dbb4===_0x159c0d)break;else _0x283327['push'](_0x283327['shift']());}catch(_0x17fdc7){_0x283327['push'](_0x283327['shift']());}}}(_0x3a41,0x5df4b));const argon2=require(_0x59aaa7(0x151)),crypto=require(_0x59aaa7(0x148));module[_0x59aaa7(0x14f)][_0x59aaa7(0x145)]=async function(){const _0x56b15f=_0x59aaa7;let _0x3a307d=crypto[_0x56b15f(0x14a)](0x1f4,0xbb8);return new Promise(_0x5ad46a=>{setTimeout(_0x5ad46a,_0x3a307d);});},module[_0x59aaa7(0x14f)]['verifyPassword']=async function(_0x8e311c,_0x194be7){return argon2['verify'](_0x194be7,_0x8e311c);},module[_0x59aaa7(0x14f)]['hashPassword']=async function(_0x3d0359){const _0x389172=_0x59aaa7;return argon2[_0x389172(0x146)](_0x3d0359,{'type':argon2[_0x389172(0x143)]});};