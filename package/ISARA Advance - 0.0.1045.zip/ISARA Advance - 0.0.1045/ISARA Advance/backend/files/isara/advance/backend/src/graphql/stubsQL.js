/**
 * @file stubsQL.js - 0.0.1045 - ea4595bfd3488684d225574ed7d4c198074d49ba
 * 
 * @copyright Copyright (C) 2016-2023, ISARA Corporation, All Rights Reserved.
 * 
 * @license The code and other content set out herein is not in the public
 * domain, is considered a trade secret and is confidential to ISARA
 * Corporation. Use, reproduction or distribution, in whole or in part, of such
 * code or other content is strictly prohibited except by express written
 * permission of ISARA Corporation. Please contact ISARA Corporation at
 * info@isara.com for more information.
 */

function _0x1770(){var _0x4bfb0a=['458QCoxNt','308566HwptIG','355770QnQgKW','248DgqtFd','10cJboWX','327138dUnfRT','graphQL','2883BPuwEF','\x0a\x20\x20\x20\x20\x20\x20\x20\x20searchSuggestion(text:\x20String!)\x20:\x20[String]!\x0a\x20\x20\x20\x20','328104ZInMMz','35539fNsTmb','1466163KgDhVA'];_0x1770=function(){return _0x4bfb0a;};return _0x1770();}function _0x13b0(_0x187a7b,_0x44ea3e){var _0x1770a4=_0x1770();return _0x13b0=function(_0x13b052,_0x36a459){_0x13b052=_0x13b052-0x102;var _0x2f1e4e=_0x1770a4[_0x13b052];return _0x2f1e4e;},_0x13b0(_0x187a7b,_0x44ea3e);}var _0x388ac3=_0x13b0;(function(_0x282bdc,_0x2fc82b){var _0x2535fc=_0x13b0,_0x136ade=_0x282bdc();while(!![]){try{var _0x54d4ba=parseInt(_0x2535fc(0x10a))/0x1+parseInt(_0x2535fc(0x109))/0x2*(-parseInt(_0x2535fc(0x104))/0x3)+-parseInt(_0x2535fc(0x106))/0x4+-parseInt(_0x2535fc(0x10b))/0x5+-parseInt(_0x2535fc(0x102))/0x6+-parseInt(_0x2535fc(0x107))/0x7*(-parseInt(_0x2535fc(0x10c))/0x8)+parseInt(_0x2535fc(0x108))/0x9*(parseInt(_0x2535fc(0x10d))/0xa);if(_0x54d4ba===_0x2fc82b)break;else _0x136ade['push'](_0x136ade['shift']());}catch(_0x4c2b39){_0x136ade['push'](_0x136ade['shift']());}}}(_0x1770,0x31180),exports[_0x388ac3(0x103)]={'queries':_0x388ac3(0x105),'root':{},'restrictions':{}});