#!/bin/sh

# @file issue.sh - 0.0.1045 - ea4595bfd3488684d225574ed7d4c198074d49ba
# 
# @copyright Copyright (C) 2016-2023, ISARA Corporation, All Rights Reserved.
# 
# @license The code and other content set out herein is not in the public
# domain, is considered a trade secret and is confidential to ISARA
# Corporation. Use, reproduction or distribution, in whole or in part, of such
# code or other content is strictly prohibited except by express written
# permission of ISARA Corporation. Please contact ISARA Corporation at
# info@isara.com for more information.
#




set -e

cd $(dirname $0)
echo ====== Working in $(pwd)

echo ====== Creating CA >&2
if [ ! -e ca.key ]; then
    openssl req -config openssl.ca.cnf -x509 -newkey rsa:4096 -nodes -keyout ca.key -out ca.crt -days 5479 -subj "/CN=Pilot CA/L=Waterloo/ST=Ontario/C=CA/O=ISARA Advance Pilot" -extensions v3_ca
else
    echo ====== CA Certificate Already exists inside container - not regenerating
fi

for cn in www backend typesense postgres; do
    outdir=data/${cn}/files/isara/advance/tls
    key_file=${outdir}/${cn}.key
    cert_file=${outdir}/${cn}.crt

    echo ====== Creating ${cn} >&2

    for file in ${cert_file} ${key_file}; do
        if [ -e $file ]; then
            echo Will attempt to erase ${file} >&2
        fi
    done

    openssl req -newkey rsa:4096 -nodes -subj "/CN=${cn}/L=Waterloo/ST=Ontario/O=ISARA Advance Pilot" -keyout ${key_file} -out ${cn}.csr
    cat openssl.leaf.cnf.template | sed -e s/%CN%/$cn/g >openssl.leaf.cnf
    openssl x509 -extfile openssl.leaf.cnf -req -in ${cn}.csr -CA ca.crt -CAkey ca.key -CAcreateserial -out ${cert_file} -days 3652 -sha256
    rm ${cn}.csr openssl.leaf.cnf
    cat ca.crt >>${cert_file}
    cp ca.crt ${outdir}
done
