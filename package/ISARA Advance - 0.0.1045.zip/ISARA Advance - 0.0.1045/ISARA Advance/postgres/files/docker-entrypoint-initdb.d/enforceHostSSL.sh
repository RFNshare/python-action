#
# This script will attempt to enforce `hostssl` in the hba (host based authentication) configuration file.
#

FILE=/var/lib/postgresql/data/pg_hba.conf

HOSTNOSSL="

# Prevent plain text remote connections
hostnossl  all  all  0.0.0.0/0     reject
hostnossl  all  all  ::/0          reject
"

if [ -e $FILE ]; then
    CONTENT=`cat $FILE | grep -v ^hostnossl`
    echo "$CONTENT" "$HOSTNOSSL" | sed -e "s/^host *all/hostssl all/" > $FILE

    echo $0 Processed $FILE
else
    echo $0 Could not find $FILE - SSL/TLS not enabled >&2
    sleep 10
    exit 1
fi