#!/usr/bin/env bash

# @file pcap2csv.sh - 0.0.1045 - ea4595bfd3488684d225574ed7d4c198074d49ba
# 
# @copyright Copyright (C) 2016-2023, ISARA Corporation, All Rights Reserved.
# 
# @license The code and other content set out herein is not in the public
# domain, is considered a trade secret and is confidential to ISARA
# Corporation. Use, reproduction or distribution, in whole or in part, of such
# code or other content is strictly prohibited except by express written
# permission of ISARA Corporation. Please contact ISARA Corporation at
# info@isara.com for more information.
#




CNS_VERSION="1.0.4.0"
CNS_DOCKER_IMAGE="isara.cns.docker.tar"

SCRIPT_DIR=$( cd -- "$( dirname -- "${BASH_SOURCE[0]}" )" &> /dev/null && pwd )
TIMESTAMP="$(date +%Y-%m-%d_%H-%M-%S)"

function usage() {
  USAGE="Usage: ${0} -i pcap_file -o output_folder [-h]

-i file   : import data from the specified file. The file is expected to be a
            packet capture in the .pcap format.

-o folder : output will be written to the specified folder. The folder must
            already exist. Each time this utility runs, it will create a
            timestamp-named subfolder to avoid collisions with previous runs
            that use the same output folder.

-d        : Decapsulate the .pcap before converting it. This may be necessary
            if the input file contains GRE-encapsulated traffic, for example.

-h        : Print this usage statement, then exit.

The $(basename "${0}") utility is used to convert a .pcap format packet capture
into a zip file that can be imported into ISARA Advance as a
Cryptographic Network Sensor data source.

Prerequisites:
The $(basename "${0}") utility needs to be able to run the 'docker'
command. This need to be installed and available in the \$PATH.
  "
  echo "${USAGE}"
}

### Command Line Params
while getopts 'i:o:dh' opt; do
  case "$opt" in
    i)
      PCAP="${OPTARG}"
      if [[ ! -r "${PCAP}" ]]; then
        echo -e "Error: input file \"${PCAP}\" is not readable."
        exit 1
      fi
      PCAP_BASENAME=$(basename "${PCAP}")
      PCAP="$( cd -- "$( dirname -- "${PCAP}" )" &> /dev/null && pwd )/${PCAP_BASENAME}"
      ;;
    o)
      OUTPUT_DIR="${OPTARG}"
      mkdir -p "${OUTPUT_DIR}"
      if [[ ! -d "${OUTPUT_DIR}" ]]; then
        echo -e "Error: output folder \"${OUTPUT_DIR}\" does not exist."
        exit 1
      fi
      OUTPUT_DIR_TIMESTAMPED=$( cd "${OUTPUT_DIR}" &> /dev/null && pwd )
      OUTPUT_DIR_TIMESTAMPED="${OUTPUT_DIR_TIMESTAMPED}/${TIMESTAMP}"
      mkdir -p "${OUTPUT_DIR_TIMESTAMPED}"
      ;;
    d)
      DECAP="TRUE"
      ;;
    h)
      usage
      exit 0
      ;;
    *)
      usage
      exit 1
      ;;
  esac
done

shift $((OPTIND -1))

if [[ -z ${PCAP} ]]; then
    echo -e "-i <input pcap file> is mandatory."
    usage
    exit 1
fi

if [[ -z ${OUTPUT_DIR_TIMESTAMPED} ]]; then
    echo -e "-o <output folder> is mandatory."
    usage
    exit 1
fi

### Prerequisite check
if [[ ! $(command -v docker) ]]; then
  echo "Please ensure docker is installed."
  exit 1
fi

### Loading Docker Image
IMAGE_ID=$(docker image ls isara/cns:${CNS_VERSION} --quiet)
if [[ -z ${IMAGE_ID} ]]; then
  echo -e "Loading docker image ${CNS_DOCKER_IMAGE}"
  docker image load -i "${SCRIPT_DIR}/${CNS_DOCKER_IMAGE}" --quiet
  IMAGE_ID=$(docker image ls isara/cns:${CNS_VERSION} --quiet)
fi

if [[ -z ${IMAGE_ID} ]]; then
  echo -e "Error: docker image ${CNS_DOCKER_IMAGE} -> isara/cns:${CNS_VERSION} not loaded."
  docker image ls isara/cns
  exit 1
fi

### License Check
CONTAINER_LICENSE_OUTPUT=$(docker run -it --rm "${IMAGE_ID}" -L)
INVALID_LICENSE_CHECK=$(echo "${CONTAINER_LICENSE_OUTPUT}"|grep "Invalid license" )
if [[ -n ${INVALID_LICENSE_CHECK} ]]; then
  echo -e "Internal error during license check, please contact ISARA Support:\n${CONTAINER_LICENSE_OUTPUT}"
  exit 1
fi

CONTAINER_LICENSE_DATE=$(echo "${CONTAINER_LICENSE_OUTPUT}"|awk '//{print $3}')
CONTAINER_DATE=$(docker run --rm --entrypoint date "${IMAGE_ID}" +%Y-%m-%d)
if [[ ${CONTAINER_LICENSE_DATE} < ${CONTAINER_DATE} ]]; then
  echo -e "Internal license expiry, please contact ISARA Support:\n${CONTAINER_LICENSE_OUTPUT}"
  exit 1
fi

### Get supported handshake messages
MESSAGES=$(docker run \
    -it \
    --rm \
    "${IMAGE_ID}" \
    --severity info \
    --list-messages \
)
MESSAGE_IDS=$(echo "${MESSAGES}"|awk 'NR != 1 {print $1}'|xargs)

### Is ${PCAP} a valid pcap?
echo -e "Checking file type of \"${PCAP}\":"
# shellcheck disable=SC2086,SC2140
FILE_TYPE=$(
  docker run \
      -v "${OUTPUT_DIR_TIMESTAMPED}":/output \
      --mount type=bind,source="${PCAP}",target="/${PCAP_BASENAME}" \
      --entrypoint /bin/bash \
      "${IMAGE_ID}" \
      -c "/usr/bin/file --brief \"/${PCAP_BASENAME}\""
)
echo -e "Input file ${PCAP} is of type: ${FILE_TYPE}\n"
if [[ ! "${FILE_TYPE}" =~ .*"pcap capture file".* ]]; then
  echo -e "*** Warning: ${PCAP_BASENAME} might not be a valid .pcap file. ***\n"
fi

if [[ ${DECAP} = "TRUE" ]]; then
    echo -e "Decapsulating ${PCAP} to ${OUTPUT_DIR_TIMESTAMPED}/decapped-${PCAP_BASENAME}"
    docker run \
        -v "${OUTPUT_DIR_TIMESTAMPED}":/output \
        --mount type=bind,source="${PCAP}",target="/${PCAP_BASENAME}" \
        --entrypoint /usr/local/bin/decap.py \
        "${IMAGE_ID}" \
        "/${PCAP_BASENAME}" "/output/decapped-${PCAP_BASENAME}"
    PCAP="${OUTPUT_DIR_TIMESTAMPED}/decapped-${PCAP_BASENAME}"
    PCAP_BASENAME=$(basename "${PCAP}")
fi

### Convert pcap to csv
# shellcheck disable=SC2086,SC2140
echo -e "Converting ${PCAP} to ${OUTPUT_DIR_TIMESTAMPED}/csv"
docker run \
    --rm \
    -v "${OUTPUT_DIR_TIMESTAMPED}":/output \
    --mount type=bind,source="${PCAP}",target="/${PCAP_BASENAME}" \
    "${IMAGE_ID}" \
    --severity info \
    --log "/output/log" \
    --export-threshold 10000 \
    --pcap "/${PCAP_BASENAME}" \
    --output "/output/csv" \
    --certificates \
    --message ${MESSAGE_IDS} \
    --prefix "$(basename "${PCAP_BASENAME}" .pcap)"

### Zip the output
ZIP_FILE="/output/$(basename "${PCAP_BASENAME}" .pcap).zip"
HOST_ZIP_FILE="${OUTPUT_DIR_TIMESTAMPED}/$(basename "${PCAP_BASENAME}" .pcap).zip"
LOG_FOLDER="${OUTPUT_DIR_TIMESTAMPED}/log"
OUTPUT_FILES=$(
  docker run \
      -v "${OUTPUT_DIR_TIMESTAMPED}":/output \
      --mount type=bind,source="${PCAP}",target="/${PCAP_BASENAME}" \
      --entrypoint /bin/bash \
      "${IMAGE_ID}" \
      -c "/usr/bin/find /output/csv -type f 2>/dev/null"
)
if [[ -z ${OUTPUT_FILES} ]]; then
  echo -e "*** Warning: No output files. Check \"${LOG_FOLDER}\" for more info. ***\n"
  exit 1
fi

echo -e "Zipping ${OUTPUT_DIR_TIMESTAMPED}/csv to ${HOST_ZIP_FILE}"
docker run \
    -v "${OUTPUT_DIR_TIMESTAMPED}":/output \
    --mount type=bind,source="${PCAP}",target="/${PCAP_BASENAME}" \
    --entrypoint /bin/bash \
    "${IMAGE_ID}" \
    -c "cd /output/csv && /usr/bin/zip -9r \"${ZIP_FILE}\" ./*"
echo -e "\nOutput: \"${HOST_ZIP_FILE}\""

if [[ ${DECAP} = "TRUE" ]]; then
  echo -e "Deleting decapsulated copy of pcap: ${PCAP}"
  docker run \
      -v "${OUTPUT_DIR_TIMESTAMPED}":/output \
      --entrypoint /bin/bash \
      "${IMAGE_ID}" \
      -c "rm \"/output/${PCAP_BASENAME}\""
fi
