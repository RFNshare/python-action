#!/bin/bash

# @file infinite_capture_and_convert.sh - 0.0.1045 - ea4595bfd3488684d225574ed7d4c198074d49ba
# 
# @copyright Copyright (C) 2016-2023, ISARA Corporation, All Rights Reserved.
# 
# @license The code and other content set out herein is not in the public
# domain, is considered a trade secret and is confidential to ISARA
# Corporation. Use, reproduction or distribution, in whole or in part, of such
# code or other content is strictly prohibited except by express written
# permission of ISARA Corporation. Please contact ISARA Corporation at
# info@isara.com for more information.
#




# Instead of running a really long packet capture that consumes a lot of disk space
# we can instead run a series of short captures, convert to csv, and clean up.

function usage() {
  USAGE="Usage: ${0} [-i interface] [-o output_folder] [-d duration] [-h]

-i interface        : capture traffic on the specified network interface.

-o folder           : output will be written to the specified folder.

-d duration         : Duration to capture traffic before converting.

-h                  : Print this usage statement, then exit.

  "
  echo "${USAGE}"
}

### Command Line Params
while getopts 'i:o:hd:' opt; do
  case "$opt" in
    i)
      INTERFACE="${OPTARG}"
      ;;
    o)
      OUTPUT_DIR="${OPTARG}"
      mkdir -p "${OUTPUT_DIR}"
      if [[ ! -d "${OUTPUT_DIR}" ]]; then
        echo -e "Error: output folder \"${OUTPUT_DIR}\" does not exist."
        exit 1
      fi
      OUTPUT_DIR_TIMESTAMPED=$( cd "${OUTPUT_DIR}" &> /dev/null && pwd )
      OUTPUT_DIR_TIMESTAMPED="${OUTPUT_DIR_TIMESTAMPED}/${TIMESTAMP}"
      mkdir -p "${OUTPUT_DIR_TIMESTAMPED}"
      ;;
    d)
      DURATION="${OPTARG}"
      ;;
    h)
      usage
      exit 0
      ;;
    *)
      usage
      exit 1
      ;;
  esac
done

shift $((OPTIND -1))

if [[ -z ${LIST_INTERFACES} ]]; then
  if [[ -z ${INTERFACE} ]]; then
      echo -e "-i <interface> is mandatory."
      usage
      exit 1
  fi

  if [[ -z ${OUTPUT_DIR_TIMESTAMPED} ]]; then
      echo -e "-o <output folder> is mandatory."
      usage
      exit 1
  fi

  if [[ -z ${DURATION} ]]; then
      echo -e "-d <duration> is mandatory."
      usage
      exit 1
  fi
fi


trap "sudo killall --quiet tcpdump; exit" SIGINT
while true
do
    PCAP="./tcpdump_${INTERFACE}_$(date +%Y-%m-%d_%H-%M-%S).pcap"
    sudo timeout "${DURATION}" tcpdump -i "${INTERFACE}" -w "${PCAP}" -vv
    ./pcap2csv.sh -i "${PCAP}" -o "${OUTPUT_DIR_TIMESTAMPED}" -d
    sudo rm "${PCAP}"
done
