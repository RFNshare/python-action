# ISARA Cryptographic Network Sensor

The ISARA Cryptographic Network Sensor provides tools allowing users of ISARA
Advance to ingest data from their network. Two tools are provided:

1. `pcap2csv.sh` is a `bash` script that can be used to convert a `.pcap` file
   into a `.zip` file containing the CSV format understood by ISARA Advance. The
   `.pcap` file can come from any 3rd-party application that supports this
   standard format.

2. `livecapture.sh` is a `bash` script that will listen for traffic on the
   network interface specified on the command line, and produce a `.zip` file
   containing the CSV format understood by ISARA Advance.

## Prerequisites

`docker` is required for either script to run. The `isara.cns.docker.tar` file
that ships with the scripts contains a docker image in which the conversion or
capturing code runs.

`docker-compose` is required by `livecapture.sh`.

`zip` is called by both scripts to collect the output for consumption by ISARA
Advance.

## Environment

While the `bash` scripts are expected to run in any POSIX environment, and the
use of `docker` ensures the underlying implementation always runs in a
consistent environment, the use of Linux for `livecapture.sh` is strongly
recommended due to the use of `host` networking mode for capturing traffic
outside the container.
