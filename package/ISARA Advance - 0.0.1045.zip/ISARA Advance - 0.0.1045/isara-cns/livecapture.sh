#!/usr/bin/env bash

# @file livecapture.sh - 0.0.1045 - ea4595bfd3488684d225574ed7d4c198074d49ba
# 
# @copyright Copyright (C) 2016-2023, ISARA Corporation, All Rights Reserved.
# 
# @license The code and other content set out herein is not in the public
# domain, is considered a trade secret and is confidential to ISARA
# Corporation. Use, reproduction or distribution, in whole or in part, of such
# code or other content is strictly prohibited except by express written
# permission of ISARA Corporation. Please contact ISARA Corporation at
# info@isara.com for more information.
#




CNS_VERSION="1.0.4.0"
CNS_DOCKER_IMAGE="isara.cns.docker.tar"

SCRIPT_DIR=$( cd -- "$( dirname -- "${BASH_SOURCE[0]}" )" &> /dev/null && pwd )
TIMESTAMP="$(date +%Y-%m-%d_%H-%M-%S)"
DURATION=60

function usage() {
  USAGE="Usage: ${0} [-i interface] [-o output_folder] [-d duration] [-l] [-h]

-i interface        : capture traffic on the specified network interface.
                      Mandatory option unless -l is used

-o folder           : output will be written to the specified folder.
                      The folder must already exist. Each time this utility
                      runs, it will create a timestamp-named subfolder to avoid
                      collisions with previous runs that use the same output
                      folder.
                      Mandatory option unless -l is used

-d duration         : Duration, in minutes, to capture traffic before exiting.
                      Default is 60 minutes.

-l list interfaces  : Print a list of network interfaces available to the
                      packet capture docker container, then exit.

-h                  : Print this usage statement, then exit.

The $(basename "${0}") utility is used to capture live network traffic and
produce a zip file that can be imported into ISARA Advance as a
Cryptographic Network Sensor data source.

Prerequisites:
The $(basename "${0}") utility needs to be able to run the 'docker',
and 'docker-compose'. These need to be installed and available
in the \$PATH.
  "
  echo "${USAGE}"
}

### Command Line Params
while getopts 'li:o:hd:' opt; do
  case "$opt" in
    i)
      INTERFACE="${OPTARG}"
      ;;
    o)
      OUTPUT_DIR="${OPTARG}"
      mkdir -p "${OUTPUT_DIR}"
      if [[ ! -d "${OUTPUT_DIR}" ]]; then
        echo -e "Error: output folder \"${OUTPUT_DIR}\" does not exist."
        exit 1
      fi
      OUTPUT_DIR_TIMESTAMPED=$( cd "${OUTPUT_DIR}" &> /dev/null && pwd )
      OUTPUT_DIR_TIMESTAMPED="${OUTPUT_DIR_TIMESTAMPED}/${TIMESTAMP}"
      mkdir -p "${OUTPUT_DIR_TIMESTAMPED}"
      ;;
    l)
      LIST_INTERFACES=true
      ;;
    d)
      DURATION="${OPTARG}"
      ;;
    h)
      usage
      exit 0
      ;;
    *)
      usage
      exit 1
      ;;
  esac
done

shift $((OPTIND -1))

if [[ -z ${LIST_INTERFACES} ]]; then
  if [[ -z ${INTERFACE} ]]; then
      echo -e "-i <interface> is mandatory."
      usage
      exit 1
  fi

  if [[ -z ${OUTPUT_DIR_TIMESTAMPED} ]]; then
      echo -e "-o <output folder> is mandatory."
      usage
      exit 1
  fi
fi

### Prerequisite check
if [[ ! $(command -v docker) ]]; then
  echo "Please ensure docker is installed."
  exit 1
fi

if [[ ! $(command -v docker-compose) ]]; then
  echo "Please ensure docker-compose is installed."
  exit 1
fi

### Loading Docker Image
IMAGE_ID=$(docker image ls isara/cns:${CNS_VERSION} --quiet)
if [[ -z ${IMAGE_ID} ]]; then
  echo -e "Loading docker image ${CNS_DOCKER_IMAGE}"
  docker image load -i "${SCRIPT_DIR}/${CNS_DOCKER_IMAGE}" --quiet
  IMAGE_ID=$(docker image ls isara/cns:${CNS_VERSION} --quiet)
fi

if [[ -z ${IMAGE_ID} ]]; then
  echo -e "Error: docker image ${CNS_DOCKER_IMAGE} -> isara/cns:${CNS_VERSION} not loaded."
  docker image ls isara/cns
  exit 1
fi

### License Check
CONTAINER_LICENSE_OUTPUT=$(docker run -it --rm "${IMAGE_ID}" -L)
INVALID_LICENSE_CHECK=$(echo "${CONTAINER_LICENSE_OUTPUT}"|grep "Invalid license" )
if [[ -n ${INVALID_LICENSE_CHECK} ]]; then
  echo -e "Internal error during license check, please contact ISARA Support:\n${CONTAINER_LICENSE_OUTPUT}"
  exit 1
fi

CONTAINER_LICENSE_DATE=$(echo "${CONTAINER_LICENSE_OUTPUT}"|awk '//{print $3}')
CONTAINER_DATE=$(docker run --rm --entrypoint date "${IMAGE_ID}" +%Y-%m-%d)
if [[ ${CONTAINER_LICENSE_DATE} < ${CONTAINER_DATE} ]]; then
  echo -e "Internal license expiry, please contact ISARA Support:\n${CONTAINER_LICENSE_OUTPUT}"
  exit 1
fi

### Get supported handshake messages
MESSAGES=$(docker run \
    -it \
    --rm \
    "${IMAGE_ID}" \
    --severity info \
    --list-messages \
)
MESSAGE_IDS=$(echo "${MESSAGES}"|awk 'NR != 1 {print $1}'|xargs)

### List available interfaces
if [[ -n ${LIST_INTERFACES} ]]; then
  INTERFACES=$(
    docker run \
      -it \
      --rm \
      --network host \
      "${IMAGE_ID}" \
      --severity info \
      --list-interfaces
  )
  TARGET_INTERFACE=$(
    echo "${INTERFACES}" |\
    grep -v "lo" |\
    grep -v veth |\
    grep -v br- |\
    grep -v docker |\
    grep -v vmnet |\
    grep -v services |\
    awk '{split($0, fields); print fields[2]}' |\
    head -n 1
  )
  echo -e "Network interfaces available to docker container:\n${INTERFACES}\n"
  if [[ -z ${TARGET_INTERFACE} ]]; then
      TARGET_INTERFACE="eth0"
  fi
  echo -e "Example usage: ./$(basename "${0}") -i ${TARGET_INTERFACE} -o ./output"
  exit 0
fi

### Run the listening container via docker-compose
COMPOSE_FILE="${OUTPUT_DIR_TIMESTAMPED}/isara_cns/docker-compose.yml"
mkdir -p "$(dirname "${COMPOSE_FILE}")"
cat > "${COMPOSE_FILE}" <<EOF
version: '3.3'
services:
    isara_cns:
        container_name: isara_cns_listener
        network_mode: host
        volumes:
            - '${OUTPUT_DIR_TIMESTAMPED}:/output'
        image: "${IMAGE_ID}"
        entrypoint: isara_cns \
          --severity info \
          --log "/output/log" \
          --export-threshold 10000 \
          --export-duration 60 \
          --interface "${INTERFACE}" \
          --output "/output/csv" \
          --prefix "${INTERFACE}" \
          --certificates \
          --message ${MESSAGE_IDS}
EOF

docker-compose -f "${COMPOSE_FILE}" up -d --build

while ((DURATION > 0));do
  echo -e "Capturing traffic on ${INTERFACE} for ${DURATION} minutes."
  sleep 60
  ((DURATION--))
done

### Stop the listener
docker exec -it isara_cns_listener killall -SIGINT isara_cns

## Trigger an additional connection to force the listener to flush and exit
CONTAINER_STATE=$(docker inspect --format="{{.State.Running}}" isara_cns_listener)
CONTAINER_EXISTS=$?
if [[ ${CONTAINER_EXISTS} -eq 0 ]]; then
  if [[ ${CONTAINER_STATE} == "true" ]]; then
    docker exec -it isara_cns_listener curl --silent --output /dev/null https://localhost >/dev/null
  fi
fi

docker-compose -f "${COMPOSE_FILE}" down

### Zip the output
ZIP_FILE="/output/${INTERFACE}.zip"
HOST_ZIP_FILE="${OUTPUT_DIR_TIMESTAMPED}/${INTERFACE}.zip"
LOG_FOLDER="${OUTPUT_DIR_TIMESTAMPED}/log"
OUTPUT_FILES=$(
  docker run \
      -v "${OUTPUT_DIR_TIMESTAMPED}":/output \
      --entrypoint /bin/bash \
      "${IMAGE_ID}" \
      -c "/usr/bin/find /output/csv -type f 2>/dev/null"
)
if [[ -z ${OUTPUT_FILES} ]]; then
  echo -e "*** Warning: No output files. Check \"${LOG_FOLDER}\" for more info. ***\n"
  exit 1
fi

docker run \
    -v "${OUTPUT_DIR_TIMESTAMPED}":/output \
    --entrypoint /bin/bash \
    "${IMAGE_ID}" \
    -c "cd /output/csv && /usr/bin/zip -9r \"${ZIP_FILE}\" ./*"
echo -e "\nOutput: \"${HOST_ZIP_FILE}\""
