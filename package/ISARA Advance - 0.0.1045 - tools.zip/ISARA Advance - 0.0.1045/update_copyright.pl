#! /usr/bin/env perl
#
# Update the copyright date "Copyright xxxx" or "Copyright yyyy-xxxx" to
# "Copyright xxxx-zzzz" or "Copyright yyyy-zzzz" where "zzzz" will be the
# current year.
#
# Run this once a year, feeding it a list of files to update.

use strict;
use warnings;

use Time::Piece;

local $^I = '.orig';
my $t = Time::Piece->new();
my $this_year = $t->year;

# AsciiDoctor docs - Copyright (C) 2015-2020, ISARA
# AsciiDoctor docs - Copyright (C) 2020, ISARA
# Copyright (C) 2020, ISARA
# Copyright (C) 2015-2020, ISARA
# Version.txt - Copyright ⓒ 2016-2020 ISARA
# version.rc.in - Copyright \251 2016-2020, ISARA
LINE:
    while (<>) {
        s/Copyright (\(C\))?\s?(20\d\d),? ISARA/Copyright (C) $2-$this_year, ISARA/p;
        s/Copyright (\(C\))?\s?(20\d\d)-20..,? ISARA/Copyright (C) $2-$this_year, ISARA/p;
        s/Copyright (20\d\d),? ISARA/Copyright (C) $1-$this_year, ISARA/p;
        s/Copyright (20\d\d)-20..,? ISARA/Copyright (C) $1-$this_year, ISARA/p;
        s/Copyright ⓒ (20\d\d)-20..,? ISARA/Copyright ⓒ $1-$this_year, ISARA/p;
        s/Copyright \\251 (20\d\d)-20..,? ISARA/Copyright \\251 $1-$this_year, ISARA/p;
        print;
    }
