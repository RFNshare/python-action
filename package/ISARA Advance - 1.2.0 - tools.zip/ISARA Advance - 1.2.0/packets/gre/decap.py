#!/usr/bin/python3

"""

This code attempts to decapsulate GRE encapsulated ethernet packets from a standard PCAP file.

"""

import sys

DEBUG = True


def debug(message):
    if DEBUG:
        print(message)


def readOrRaise(input, length):
    toReturn = input.read(length)
    if len(toReturn) != length:
        raise ImDone()
    return toReturn


class ImDone(Exception):
    pass


class FragmentCache:
    def __init__(self):
        self.cache = {}

    def add(self, key, offset, data):
        # print("Adding a fragment",key,offset,len(data), data)
        if not key in self.cache:
            # print("Adding empty array")
            self.cache[key] = b''

        if len(self.cache[key]) == offset:
            self.cache[key] += data
        else:
            raise Exception(
                "Out of order fragmented packets not handled at this time")

    def get(self, key):
        if key in self.cache:
            toReturn = self.cache[key]
            del self.cache[key]
            return toReturn
        return None


fragmentCache = FragmentCache()


class PacketHeader:
    def __init__(self, input, packetIndex):
        self.packetIndex = packetIndex

        byteArray = readOrRaise(input, 16)

        if len(byteArray) < 16:
            raise ImDone()

        self.seconds = uint32(byteArray, 0)
        self.subSeconds = uint32(byteArray, 4)
        self.capturedLength = uint32(byteArray, 8)
        self.actualLength = uint32(byteArray, 12)

        self.packetData = readOrRaise(input, self.capturedLength)

        self.processOffset = 0

    def read(self, count):
        if len(self.packetData) - self.processOffset < count:
            raise Exception("Reached end of packet early %d" %
                            self.packetIndex)

        toReturn = self.packetData[self.processOffset:self.processOffset+count]
        self.processOffset += count
        return toReturn

    def extractGRE(self, output):
        # Consume initial ethernet packet
        ethernet = self.read(14)

        if ethernet[12] != 8 or ethernet[13] != 0:
            debug("This packet is not IPV4 %d" % self.packetIndex)
            return

        ipHeader = self.read(1)
        self.processOffset -= 1
        ipHeaderLength = (ipHeader[0] & 0xf) * 4
        ipHeader = self.read(ipHeaderLength)

        ipTotalLength = ipHeader[2] << 8 | ipHeader[3]
        ipFlagsAndFragment = ipHeader[6] << 8 | ipHeader[7]

        ipFlags = ipFlagsAndFragment >> 13
        ipFragmentOffset = (ipFlagsAndFragment & 0b1111111111111) * 8

        ipID = ipHeader[4:6]
        ipSource = ipHeader[12:16]
        ipDestination = ipHeader[16:20]
        
        protocol = ipHeader[9]

        if protocol != 47:
            debug("This packet is not GRE %d" % self.packetIndex)
            return

        ipFragmentKey = "%s:%s:%s" % (
            self.dump(ipID), self.dump(ipSource), self.dump(ipDestination))

        payload = self.packetData[self.processOffset:]
        actualLengthToWrite = self.actualLength

        if (ipFlags & 1) != 0:
            # This bit being set means there are more fragments
            if self.capturedLength != self.actualLength:
                debug("Dropping incompletely captured fragmented packet")
                return
            fragmentCache.add(ipFragmentKey, ipFragmentOffset, payload)
            return

        output.write(uint32ToBytes(self.seconds))
        output.write(uint32ToBytes(self.subSeconds))
        # Captured length
        output.write(uint32ToBytes(len(payload)))
        # Actual length
        output.write(uint32ToBytes(actualLengthToWrite))
        # Payload
        output.write(payload)

    def dump(self, bytes):
        toReturn = ""
        for i in range(len(bytes)):
            # if i!=0 and i%2 == 0:
            #     toReturn = toReturn + " "
            toReturn += "%02X" % bytes[i]
        return toReturn


def uint32(byteArray, offset):
    toReturn = 0
    for i in range(0, 4):
        toReturn |= byteArray[i+offset] << (i*8)
    return toReturn


def uint32ToBytes(value):
    toReturn = bytearray()
    for i in range(0, 4):
        toReturn.append(value & 0xff)
        value >>= 8
    return toReturn


def processPacket(input, output, packetIndex):
    packetHeader = PacketHeader(input, packetIndex)
    packetHeader.extractGRE(output)


def processPCAP(input, output):
    pcapHeader = readOrRaise(input, 24)

    if (pcapHeader[0] == 0xd4 or pcapHeader[0] == 0x4d) and \
            pcapHeader[1] == 0xc3 and \
            pcapHeader[2] == 0xb2 and \
            pcapHeader[3] == 0xa1:
        debug("Read PCAP header")
        pass
    else:
        raise Exception("Bad PCAP Header")

    output.write(pcapHeader)

    packetIndex = 1

    try:
        while True:
            processPacket(input, output, packetIndex)
            packetIndex += 1
    except ImDone:
        debug("End of file reached")


inputFileName = "input.pcap"
if len(sys.argv) > 1:
    inputFileName = sys.argv[1]

outputFileName = "output.pcap"
if len(sys.argv) > 2:
    outputFileName = sys.argv[2]

try:
    debug("About to open %s for input" % inputFileName)
    with open(inputFileName, "rb") as input:
        debug("About to open %s for output" % outputFileName)

        with open(outputFileName, "wb") as output:

            try:
                processPCAP(input, output)
            except Exception as e:
                print("Failed packet processing",e)
except FileNotFoundError:
    print("Could not open files")
    print("Usage: %s [<input File Name> [<output File Name>]]" % sys.argv[0])
    print("    input file name defaults to input.pcap")
    print("    output file name defaults to output.pcap")
