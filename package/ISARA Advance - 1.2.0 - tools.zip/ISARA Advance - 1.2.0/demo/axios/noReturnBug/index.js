/**
 * This demo will attempt to fetch data from a laggy webserver with three different APIs,
 * 1. AXIOS
 * 2. Node's built in http
 * 3. follow-redirects (a library mostly compatible with Node's built in http, but it supports
 *    redirects)
 * 
 * Note that AXIOS is fixed, but follow-redirects is not. AXIOS's internal handling of follow-redirects
 * is what has fixed things.
 */
const express = require('express')
const http = require('http')
const follow = require('follow-redirects')
const fs = require('fs');

const axios = require('axios')

async function sleep(ms) {
    return new Promise(accept => {
        setTimeout(accept, ms)
    })
}


function startLaggyWebServer() {
    const expressApp = express()
    expressApp.use(async (request, response) => {
        console.log('>>> got a request')
        response.write('this is a chunk')
        await sleep(1000)
        response.write('this is another chunk')
        response.end()
        // console.log('>>> finished request')
    })
    expressApp.listen(4000)
    console.log('Listening on 4000')
}

const events = ['abort', 'close', 'connect', 'continue', 'drain', 'error', 'finish', 'information', 'pipe', 'response', 'socket', 'timeout']
const rejects = ['error']
const accepts = ['close']

async function doAxios() {
    for (let breakPromise of [false, true]) {
        const request = { url: 'http://localhost:4000' }
        if (breakPromise) {
            request.timeout = 100
        }

        try {
            console.log('About to axios, expecting it to break promise (unless patched):', breakPromise)
            await axios(request)
        } finally {
            console.log('Finally (AXIOS accepted or rejected)')
        }
    }
}

async function callWithTimeout(func, timeoutMS) {
    return new Promise((accept, reject) => {
        setTimeout(() => {
            reject(new Error('Timed out function call - this implies the function/promises were never fulfilled'))
        }, timeoutMS)
        func().then(accept).catch(reject)
    })
}

const responseEvents = ['data', 'close', 'end', 'error']

async function doHttp(name, http) {
    return new Promise((accept, reject) => {
        const request = http.get('http://localhost:4000', res => {
            for (let event of responseEvents) {
                res.on(event, a => console.log('response event', event, a))
            }
        })

        request.on("socket", socket => {
            socket.setTimeout(100, () => {
                console.log('Socket timeout')
                socket.destroy()
            })
        })

        for (let event of events) {
            const myEvent = event
            request.on(myEvent, a => {
                console.log(name, myEvent)
                if (rejects.includes(myEvent)) {
                    reject(a)
                } else if (accepts.includes(myEvent)) {
                    accept()
                }
            })
        }
    })
}



async function main() {
    const ABORT_FUNCTION_MS = 8000
    try {
        startLaggyWebServer()

        try {
            await callWithTimeout(doAxios, ABORT_FUNCTION_MS)
            console.log('+++ Proceeded normally')
        } catch (error) {
            console.log('=== Axios call error:', error)
        }

        for (let which of [['node http', http], ['follow-redirects', follow.http]]) {
            let name = which[0]
            let api = which[1]
            try {
                console.log('========== About to', name)
                await callWithTimeout(async () => await doHttp(name, api), ABORT_FUNCTION_MS)
                console.log('+++ Proceeded normally')
            } catch (e) {
                console.log('==========', name, 'call error:', e)
            } finally {
                console.log('========== Finished', name)
            }
        }
    } catch (error) {
        console.log("There was an error - i'm not printing it because it was huge: " + error)
        // console.log(error)
    } finally {
        process.exit(0)
    }
}

main()
