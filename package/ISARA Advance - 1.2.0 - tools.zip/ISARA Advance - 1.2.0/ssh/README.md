# Test SSH Server

These docker files create an SSH server configured to use limited
cryptographic algorithms.

The `ssh` command can list supported algorithms try running:
`ssh -Q help` and if you're interested in key exchange, try
running `ssh -Q kex`

## User

A user named `test` is created in the image whose password is `password`

## Example Usage

Starting an SSH server on port 40022:

`PORT=40022 docker compose -f docker-compose.yml up -d`
