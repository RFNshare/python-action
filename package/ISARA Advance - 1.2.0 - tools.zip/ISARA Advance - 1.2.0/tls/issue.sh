#!/bin/sh

set -e

echo ====== Creating CA
if [ ! -e ca.key ]; then
	openssl req -config openssl.ca.cnf -x509 -newkey rsa:4096 -nodes -keyout ca.key -out ca.crt -days 5479 -subj "/CN=Development CA/L=Waterloo/ST=Ontario/C=CA/O=ISARA Corp/OU=ISARA Advance Development Team" -extensions v3_ca
else
	echo ALREADY EXISTS >&2
fi

for cn in www backend typesense postgres; do
	echo ====== Creating ${cn}
	if [ ! -e ${cn}.key ]; then
		openssl req -newkey rsa:4096 -nodes -subj "/CN=${cn}/L=Waterloo/ST=Ontario/O=ISARA Corp/OU=ISARA Advance Development Team" -keyout ${cn}.key -out ${cn}.csr
                cat openssl.leaf.cnf.template | sed -e s/%CN%/$cn/g > openssl.leaf.cnf
		openssl x509 -extfile openssl.leaf.cnf -req -in ${cn}.csr -CA ca.crt -CAkey ca.key -CAcreateserial -out ${cn}.crt -days 3652 -sha256
		rm ${cn}.csr openssl.leaf.cnf
        	cat ca.crt >> ${cn}.crt
	else
		echo ALREADY EXISTS >&2
	fi
done
