const { default: axios } = require('axios')
const { Agent } = require('https')
const http = require('http')
const net = require('net')
const path = require('path')

const CONTENTLENGTH = 'content-length: '

const RETRY_TIMEOUT_MS = 20 * 1000

const httpsAgent = new Agent({ rejectUnauthorized: false, keepAlive: true, keepAliveMsecs: 15 * 60 * 1000, maxSockets: 64 })
const httpAgent = new http.Agent({ keepAlive: true, keepAliveMsecs: 15 * 60 * 1000, maxSockets: 64 })

function log() {
    console.log(new Date(), ...arguments)
}

class Wrapper {
    /**
     * @type {net.Socket}
     */
    #socket

    #headers
    #headersAsText = ''
    /**
     * @type {Array<String>}
     */
    #headersAsLines = []
    #headersOffset = 0
    #message
    #messageOffset = 0
    #contentLength = 0

    #state = 0

    #host
    #port

    #retry = true

    #toURL

    #postsInProgress = 0

    #headersDictionary = {}

    constructor(host, port, toURL) {
        if (!host || !port || !toURL) {
            throw new Error('Missing required args')
        }
        this.#headers = Buffer.alloc(5000, 0)
        this.#message = Buffer.alloc(100000, 0)

        this.#host = host
        this.#port = port

        this.#toURL = toURL

        this.createSocket()
    }

    createSocket() {
        /**
         * @var {net.Socket}
         */
        this.#socket = net.createConnection(this.#port, this.#host)

        this.#socket.on('close', (hadError) => this.onClose(hadError))
        this.#socket.on('data', buffer => this.onData(buffer))
        this.#socket.on('error', error => this.onError(error))
    }

    /**
     * @param {Buffer} buffer 
     */
    onData(buffer) {
        for (let i = 0; i < buffer.length;) {
            if (this.#state === 0) {
                this.#headers[this.#headersOffset] = buffer[i]
                this.#headersOffset++
                this.checkHeaders()
                ++i
            } else {
                const toConsume = Math.min(this.#contentLength - this.#messageOffset, buffer.length - i)
                if (toConsume > 0) {
                    buffer.copy(this.#message, this.#messageOffset, i, i + toConsume)
                    this.#messageOffset += toConsume
                    i += toConsume
                }
                if (this.#messageOffset === this.#contentLength) {
                    this.gotMessage()
                }
            }
        }
    }

    checkHeaders() {
        if (this.#headersOffset >= 4) {
            let a = this.#headersOffset - 4
            if (this.#headers[a++] === 13 && this.#headers[a++] === 10 && this.#headers[a++] == 13 && this.#headers[a++] === 10) {
                this.#headersAsText = this.#headers.toString('utf8', 0, this.#headersOffset)
                this.#headersAsLines = this.#headersAsText.split('\r\n')
                for (let header of this.#headersAsLines) {
                    const lc = header.toLowerCase()
                    const colonSpace = lc.indexOf(': ')
                    if (colonSpace !== -1) {
                        const headerName = lc.substring(0, colonSpace)
                        if (headerName) {
                            // Not using the lower case value - especially for tokens.
                            const headerValue = header.substring(colonSpace + 2)
                            if (headerValue) {
                                this.#headersDictionary[headerName] = headerValue
                            }
                        }
                    }
                    if (lc.startsWith(CONTENTLENGTH)) {
                        this.#contentLength = parseInt(lc.substring(CONTENTLENGTH.length))
                    }
                }
                this.#state = 1
            } else if (this.#headersOffset === this.#headers.length) {
                // Garbage coming from client, disconnect.
                this.close()
            }
        }
    }

    close() {
        this.#retry = false

        this.#socket.end()
    }

    gotMessage() {
        log('Message')

        if (this.#messageOffset !== 0) {
            const bufferToSend = Buffer.alloc(this.#messageOffset)
            this.#message.copy(bufferToSend, 0, 0, this.#messageOffset)
            if (this.#postsInProgress < 500) {
                axios({ method: 'post', url: this.#toURL, data: bufferToSend, httpsAgent, httpAgent, headers: this.#headersDictionary })
                    .catch(e => log(e.toString())).finally(() => {
                        this.#postsInProgress--
                    })
            } else {
                log('Dropping')
            }
        }

        this.resetState()
    }

    resetState() {
        this.#state = 0
        // Clear headers.
        this.#headersOffset = 0
        this.#headersAsText = ''
        this.#headersAsLines = []

        // Clear message.
        this.#messageOffset = 0

        this.#contentLength = -1
    }

    onError(error) {
        log('Error', error)
    }

    onClose(hadError) {
        log('Close', hadError)

        if (this.#retry) {
            setTimeout(() => this.createSocket(), RETRY_TIMEOUT_MS)
        }
    }

}

function usage() {
    console.error('Unexpected arguments', process.argv.join(' '))
    log('Usage: node', path.basename(process.argv[1]), '<from [source:]port> <to url>')
    process.exit(1)
}

if (process.argv.length !== 4) {
    usage()
}

let sourceHost = 'localhost'
let sourcePort = undefined

let sourceParts = process.argv[2].split(':')
if (sourceParts.length > 2) {
    usage()
}

if (sourceParts.length == 2) {
    sourceHost = sourceParts[0]
}

sourcePort = parseInt(sourceParts[sourceParts.length - 1])

if (isNaN(sourcePort)) {
    usage()
}

new Wrapper(sourceHost, sourcePort, process.argv[3])
