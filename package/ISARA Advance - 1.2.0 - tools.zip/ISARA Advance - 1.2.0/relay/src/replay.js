const { default: axios } = require('axios')
const http = require('http')
const https = require('https')
const path = require('path')

const argv = require('minimist')(process.argv.slice(2))

const fs = require('fs').promises

const PREFIX = 'messages'

function usage() {
    console.error('Usage: [-d <delayMS>] <destination server>')
}

function log() {
    console.log(new Date(),...arguments)
}

function sleep(ms) {
    return new Promise((resolve) => {
        setTimeout(resolve, ms)
    })
}

async function replay() {

    const delayMS = parseInt(argv.d ?? 500)
    delete argv.d

    const mainArgs = argv._
    delete argv._

    if (mainArgs.length !== 1 || Object.keys(argv).length !== 0) {
        usage()
        return
    }

    const httpAgent = new http.Agent({})
    const httpsAgent = new https.Agent({ rejectUnauthorized: false })

    const ax = axios.create({ httpsAgent, httpAgent, baseURL: mainArgs[0] })


    const outputs = (await fs.readdir(PREFIX)).filter(a => a.endsWith('.bin')).map(item => path.join(PREFIX, item))
    // eslint-disable-next-line no-constant-condition
    while (true) {
        for (let file of outputs) {
            send(ax, file)
            await sleep(delayMS)
        }
    }
}

const CRLF = Buffer.from('\r\n\r\n')

async function send(ax, file) {
    try {
        const message = await fs.readFile(file)

        const endOfHeaders = message.indexOf(CRLF)

        if (endOfHeaders === -1) {
            throw new Error(`message bin file does not have header terminator: ${file}`)
        }

        const headersBuffer = message.slice(0, endOfHeaders + 4)
        const payloadBuffer = message.slice(endOfHeaders + 4)

        let headers = headersBuffer.toString('utf8').replace(/\r\n\r\n/g, '').split('\r\n')
        let [method, url] = headers[0].split(' ')
        method = method.toLocaleLowerCase()
        headers.splice(0, 1)
        const headerDictionary = { 'content-type': 'application/json' }

        headers.forEach(line => {
            const parts = line.split(': ')
            headerDictionary[parts[0]] = parts[1]
        })

        // eslint-disable-next-line no-inner-declarations
        async function doIt() {
            try {
                await ax({ method, url, data: payloadBuffer, headers: headerDictionary })
                log('Sent')
            } catch (e) {
                log('Exception during send', e.message, e.stacktrace)
            }
        }
        doIt()  // no await
    } catch (e) {
        log(e)
    }
}

replay().catch(e => {
    log(e)
    process.exit(1)
}).then(() => {
    log('Done')
    process.exit(0)
})

