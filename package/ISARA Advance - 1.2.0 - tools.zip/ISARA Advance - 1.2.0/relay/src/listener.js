const express = require('express')
const net = require('net')
const app = express()
const fs = require('fs')
const https = require('https')
const path = require('path')
const minimist = require('minimist')

const argv = minimist(process.argv.slice(2))

let httpsServerPort = 9000
let relayPort = 9001

let badArgs = false

let dumpMessages = false

try {

    if ('h' in argv) {
        httpsServerPort = parseInt(argv.h)
        delete argv.h
    }

    if ('r' in argv) {
        relayPort = parseInt(argv.r)
        delete argv.r
    }

    if ('dump' in argv) {
        dumpMessages = true
        log('Dumping messages')
        delete argv.dump
    }

    if (argv._.length === 0) {
        delete argv._
    } else {
        badArgs = true
    }

    if (Object.keys(argv).length !== 0) {
        badArgs = true
    }

} catch (e) {
    console.log(e)
    badArgs = true
}

if (badArgs) {
    console.log('Usage: node', path.basename(module.filename), '[-h <httpServerPort>] [-r <relayServerPort>] [--dump]')
    console.log()
    process.exit(1)
}

function log() {
    console.log(new Date(), ...arguments)
}

let serverOptions = {
    key: fs.readFileSync('../tls/www.key'),
    cert: fs.readFileSync('../tls/www.crt'),
    minVersion: 'TLSv1.3',
}

app.use(express.raw({ type: () => true }))

const targets = []

app.use('*', async (req, res) => {
    const headers = { ...req.headers }
    log('Record', req.method, req.originalUrl, headers)
    delete headers['host']

    res.send('Allright')

    if (req.body && req.body.length && req.body.length > 0) {

        if (!('content-length' in headers)) {
            let bodyLength = req.body.length
            if (!bodyLength) {
                bodyLength = 0
            }
            headers['content-length'] = bodyLength
        }
        let headersAsString = [`${req.method} ${req.originalUrl} HTTP/${req.httpVersion}`]
        for (let headerKey in headers) {
            headersAsString.push(`${headerKey}: ${headers[headerKey]}`)
        }
        headersAsString.push('\r\n')
        headersAsString = headersAsString.join('\r\n')
        const headersAsBuffer = Buffer.from(headersAsString)

        const outputMessage = Buffer.alloc(headersAsBuffer.length + req.body.length)
        headersAsBuffer.copy(outputMessage, 0, 0, headersAsBuffer.length)
        req.body.copy(outputMessage, headersAsBuffer.length, 0, req.body.length)

        if (dumpMessages) {
            fs.writeFileSync(path.join('messages', `message.${Date.now()}.${(Math.random() * 1000).toFixed(0)}.bin`), outputMessage)
        }

        for (let target of targets) {
            target.write(outputMessage)
        }
    }
})


const httpsServer = https.createServer(serverOptions, app)
httpsServer.listen(httpsServerPort, () => log('Listening for https on', httpsServerPort))

httpsServer.headersTimeout = 15 * 60 * 1000
httpsServer.keepAliveTimeout = Math.floor(15.1 * 60 * 1000)


const serverSocket = net.createServer()
serverSocket.on('close', () => log('Server Socket Closed'))
serverSocket.on('connection', client => {
    log('Client connected', client)
    client.on('close', () => {
        let where = targets.indexOf(client)
        if (where !== -1) {
            targets.splice(where, 1)
            log('Removed a client')
        }
    })
    client.on('error', () => { })
    targets.push(client)
})
serverSocket.on('error', error => log(error))
serverSocket.on('listening', () => log('Listening for relay on', relayPort))

serverSocket.listen(relayPort)
