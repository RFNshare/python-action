/**
 * This file implements a very basic https proxy which throttles connection attempts to
 * the same host. They are throttled by CONNECTION_THROTTLE_MS. Note that it is connection
 * attempts. Ongoing connections, termination of connections or other events are not considered.
 * 
 * This proxy primarily exists to allow sphinx document validation to connect to the US Patent Office
 * without being rejected (due to what is likely DOS countermeasures).
 * 
 * When run with no arguments, it just starts a throttling proxy. When run with arguments
 * the code:
 * - starts the proxy
 * - sets the HTTPS_PROXY environment variable. The python standard libraries use this variable
 *   to find https proxy configuration
 * - attempts to start the arguments as a command
 * - exits when the command exits, returning the code of the child process
 * 
 * This proxy would not automatically work with something that is not python - as other platforms
 * may not expect the same env variable for proxy configuration.
 */
import child_process from 'child_process'
import net from 'net'

const CRLF = '\r\n'
const CRLF2 = CRLF + CRLF

let connectionThrottleNextTime = {}
const CONNECTION_THROTTLE_MS = 750

/**
 * Blocks until another connection is permitted.
 * @returns 
 */
async function connectionThrottle(host) {
    let now = Date.now()
    let myTime = connectionThrottleNextTime[host] ?? -1
    if (now > myTime) {
        print(`Starting immediately for ${host}`)
        connectionThrottleNextTime[host] = now + CONNECTION_THROTTLE_MS
    } else {
        connectionThrottleNextTime[host] = connectionThrottleNextTime[host] + CONNECTION_THROTTLE_MS
        let sleepTime = myTime - now
        print(`Sleeping for ${sleepTime}ms for ${host}`)
        return new Promise((accept, reject) => {
            setTimeout(accept, sleepTime)
        })
    }
}

const server = net.createServer((
    /** @type net.Socket */
    clientConnection) => {
    let remoteConnection = null

    let readingHeaders = true
    let headerBlock = ''
    let headers = null

    let cleanUp = () => {
        try {
            if (clientConnection) {
                clientConnection.close()
            }
        } catch (e) {

        }
        try {
            if (remoteConnection) {
                remoteConnection.close()
            }
        } catch (e) {

        }
    }

    let processHeaders = async () => {
        /**
         * @type net.Socket
         */
        readingHeaders = false
        headers = headerBlock.split(CRLF).filter(h => h !== '')
        try {
            const request = headers[0].split(' ')
            if (request.length < 2) {
                throw new Error('Not enough lines in request')
            }
            if (request[0] !== 'CONNECT') {
                throw new Error('Not being used a https proxy')
            }
            const remoteHostAndPort = request[1].split(':')

            const remoteHost = remoteHostAndPort[0]
            const remotePort = Number(remoteHostAndPort[1])

            await connectionThrottle(remoteHost)

            remoteConnection = net.connect(remotePort, remoteHost)
            remoteConnection.on('connect', () => {
                clientConnection.write('HTTP/1.0 200 OK\r\nthrottlingProxy: true\r\n\r\n')
                clientConnection.pipe(remoteConnection)
                remoteConnection.pipe(clientConnection)
            })
            remoteConnection.on('error', (error) => {
                print(error)
                cleanUp()
            })
        } catch (error) {
            print(error)
            cleanUp()
        }
    }

    clientConnection.on('end', () => {
        cleanUp()
    });
    clientConnection.on('data', (data) => {
        if (readingHeaders) {
            headerBlock += data.toString()
            if (headerBlock.includes(CRLF2)) {
                processHeaders()
            }
        }
    })
    clientConnection.on('error', error => {
        cleanUp()
    })
})


let port = 30000
const PORT_MAX = 30050

function print() {
    const messageLines = [...arguments].join(' ').split('\n')
    for (let line of messageLines) {
        console.log(`TP === ${new Date().toISOString()} = `, line)
    }
}

server.on('error', (error) => {
    print('Could not listen on', port)
    ++port
    if (port >= PORT_MAX) {
        print('Failed to find a server port for throttling proxy')
        process.exit(1)
    } else {
        tryListening()
    }
})

function startChild(commandAndArgs, { retries }) {
    retries = retries ?? 0
    const env = { ...process.env }
    const proxyURL = `http://localhost:${port}`
    // Many examples on the internet show upper and many show lower case for these variables - setting both
    env['https_proxy'] = proxyURL
    env['HTTPS_PROXY'] = proxyURL
    print('Setting the proxy to', proxyURL)
    const options = { env, stdio: 'inherit' }
    print('Retries', retries, 'Starting', ...commandAndArgs)
    const child = child_process.spawn(commandAndArgs[0], commandAndArgs.slice(1), options)
    child.on('close', code => {
        if (code === 0) {
            process.exit(code)
        } else if (retries <= 0) {
            process.exit(code)
        } else {
            print('Restarting child process - trying again')
            setTimeout(() => startChild(commandAndArgs, { retries: retries - 1 }), 1000)
        }
    })
    child.on('error', error => {
        print(error)
        process.exit(1)
    })
}

server.on('listening', () => {
    print()
    print('================================================')
    print('  You are being throttled via', port)
    print('================================================')
    print()
    if (process.argv.length > 2) {
        let retries = 0
        let args = process.argv.slice(2)

        if (args[0].startsWith('--retries=')) {
            retries = Number(args[0].split('=')[1])
            args = args.slice(1)
        }
        startChild(args, { retries })
    }
})

function tryListening() {
    print('Attempting to listen on port', port)
    server.listen(port, 'localhost')
}

tryListening()

