/**
 * @file streamTokenQL.js - 0.0.1045 - ea4595bfd3488684d225574ed7d4c198074d49ba
 * 
 * @copyright Copyright (C) 2016-2023, ISARA Corporation, All Rights Reserved.
 * 
 * @license The code and other content set out herein is not in the public
 * domain, is considered a trade secret and is confidential to ISARA
 * Corporation. Use, reproduction or distribution, in whole or in part, of such
 * code or other content is strictly prohibited except by express written
 * permission of ISARA Corporation. Please contact ISARA Corporation at
 * info@isara.com for more information.
 */

/**
 * This module contains queries for stream tokens.
 * @module graphql/streamTokenQL
 */

const { createUpdateDelete } = require('../isaraql/cud')
const { Session } = require('../isaraql/session')
const { roles } = require('./commonQL')
const crypto = require('crypto')
const { broadcastStatus } = require('../express/systemStatus')

const TOKEN_LENGTH_BYTES = 48

exports.STREAM_TOKEN_SYSTEM_STATUS_EVENT_NAME = 'com.isara.advance.backend.systemStatus.streamToken.update'

async function streamTokens(fields) {
    const session = new Session()
    const futureOnly = fields?.futureOnly ?? true

    let query = `select * from "StreamToken" `
    if (futureOnly) {
        query += `where "expires" > now() or expires is null`
    }
    const tokens = (await session.query(query)).rows
    return tokens
}

async function streamTokenUpdate(fields) {
    for (let token of fields.streamTokens) {
        if ('token' in token) {
            // base64 length check
            if (token.token.length < (TOKEN_LENGTH_BYTES * 8 / 6)) {
                throw new Error('Rejecting short token')
            }
            const tokenAsBuffer = Buffer.from(token.token, 'base64')
            if (tokenAsBuffer.length < TOKEN_LENGTH_BYTES) {
                throw new Error('Rejecting Decoded base 64 too short')
            }
        }
    }
    const config = {
        modifiableTables: { StreamToken: true },
        deletableTables: { StreamToken: true },
        checkExistingTables: { StreamToken: true },
        allowInsert: true,
        allowUpdate: true,
        allowDelete: true,
    }
    await createUpdateDelete('StreamToken', fields.streamTokens, config)
    broadcastStatus(exports.STREAM_TOKEN_SYSTEM_STATUS_EVENT_NAME)

    return streamTokens(fields)
}

async function streamTokenRandom() {
    const buffer = await new Promise((resolve, reject) => {
        crypto.randomBytes(TOKEN_LENGTH_BYTES, (error, buffer) => {
            if (error) {
                reject(error)
            } else {
                resolve(buffer)
            }
        })
    })
    return buffer.toString('base64')
}

async function streamStatus() {
    const session = new Session()
    return {
        currentTime: Date.now(),
        streamStatus: (await session.query('select * from "StreamStatus" order by "name" asc')).rows
    }
}

exports.graphQL = {
    types: `
        type CurrentTimeAndStreamStatus {
            currentTime: BigInt!
            streamStatus: [StreamStatus!]!
        }
    `,
    mutations: `
        streamTokenUpdate(streamTokens: [StreamTokenInput!]!, futureOnly: Boolean) : [StreamToken!]!
    `,
    queries: `
        streamTokens(futureOnly: Boolean) : [StreamToken!]!
        streamTokenRandom : String!
        streamStatus: CurrentTimeAndStreamStatus!
    `,
    root: {
        streamTokens,
        streamTokenUpdate,
        streamTokenRandom,
        streamStatus,
    },
    restrictions: {
        streamTokens: [roles.AUTHENTICATED],
        streamTokenUpdate: [roles.AUTHENTICATED],
        streamTokenRandom: [roles.UNAUTHENTICATED],
        streamStatus: [roles.UNAUTHENTICATED],
    }
}