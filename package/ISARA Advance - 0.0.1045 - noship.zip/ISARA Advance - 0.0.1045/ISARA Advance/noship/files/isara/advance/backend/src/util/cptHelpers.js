/**
 * @file cptHelpers.js - 0.0.1045 - ea4595bfd3488684d225574ed7d4c198074d49ba
 * 
 * @copyright Copyright (C) 2016-2023, ISARA Corporation, All Rights Reserved.
 * 
 * @license The code and other content set out herein is not in the public
 * domain, is considered a trade secret and is confidential to ISARA
 * Corporation. Use, reproduction or distribution, in whole or in part, of such
 * code or other content is strictly prohibited except by express written
 * permission of ISARA Corporation. Please contact ISARA Corporation at
 * info@isara.com for more information.
 */

const { Session } = require('../isaraql/session')
const { getRequestState } = require('./requestState')
const log = require('../util/log')(module)

const isaraCPTName = 'ISARA'

let systemDefault

let isaraCPTID = -1

let activeCPTs = [

]

async function getActiveCPTID() {
    if (isaraCPTID < 0) {
        let session = new Session()
        let result = await session.query('SELECT * FROM "CryptoPostureTemplate"')
        for (let row of result.rows) {
            if (row.name === isaraCPTName) {
                isaraCPTID = result.rows[0].id
            }
            activeCPTs.push({ id: row.id, name: row.name })
        }

        if (isaraCPTID < 0) {
            throw 'Unable to load system posture template.'
        }
    }

    return isaraCPTID
}

async function getCptSystemDefault() {

    if (systemDefault !== undefined) {
        return systemDefault
    }

    try {
        const session = new Session()
        const result = await session.query(`select value, key from "SystemProperty" where key = 'cptGlobalDefault'`)
        if (result.rows.length === 0) {
            return
        }
        systemDefault = result.rows[0]
        return systemDefault
    } catch (e) {
        log.e('Failed to query CPT Global Default')
        return
    }
}

async function setCptSystemDefault(cptId) {
    try {
        const session = new Session()
        const result = await session.query(`INSERT INTO "SystemProperty" (key, value)
            VALUES ('cptGlobalDefault', ?)
            ON CONFLICT (key)
            DO UPDATE SET value = ? where "SystemProperty".key = 'cptGlobalDefault' RETURNING key, value`, [cptId, cptId])
        if (result.rows.length === 0) {
            return
        }
        systemDefault = result.rows[0]
        return (await getCptSystemDefault()).value
    } catch (e) {
        log.e('Failed to query CPT Global Default')
        return
    }
}

/**
 * Fetch the CPT Id for the current user, or default if unset
 * @param {*} override - if provided, override will be returned
 * @returns 
 */
async function getCptForRequest(override) {
    if (override) {
        return override
    }

    const state = getRequestState()
    return await (state.user?.cryptoPostureTemplate ? state.user.cryptoPostureTemplate.id : getActiveCPTID())
}

exports.isaraCPTName = isaraCPTName
exports.activeCPTs = activeCPTs
exports.getActiveCPTID = getActiveCPTID
exports.getCptSystemDefault = getCptSystemDefault
exports.setCptSystemDefault = setCptSystemDefault
exports.getCptForRequest = getCptForRequest
