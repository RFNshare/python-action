/**
 * @file extrahopUtils.js - 0.0.1045 - ea4595bfd3488684d225574ed7d4c198074d49ba
 * 
 * @copyright Copyright (C) 2016-2023, ISARA Corporation, All Rights Reserved.
 * 
 * @license The code and other content set out herein is not in the public
 * domain, is considered a trade secret and is confidential to ISARA
 * Corporation. Use, reproduction or distribution, in whole or in part, of such
 * code or other content is strictly prohibited except by express written
 * permission of ISARA Corporation. Please contact ISARA Corporation at
 * info@isara.com for more information.
 */

// /**
//  * This module contains utility helper functions for the extrahop scanner.
//  * @module scanners/extrahop/extrahopUtils
//  */

// const { SQLUpdateOp } = require('../../isaraql/fetch')

// const { getRoundedObservationTime } = require('../commonIngestion')

// const extrahopDiscoveryKey = 'extrahop.discovery_id'
// exports.extrahopDiscoveryKey = extrahopDiscoveryKey

// /**
//  * Sets the observedAt and manuallyAdded properties on a particular object.
//  *
//  * @param {Object} input The object to set fields on
//  * @param {Date} [date] Optional date to set observedAt to. If omitted, defaults to now.
//  */
// function populateObservedFields(input, date) {
//     input.manuallyAdded = new SQLUpdateOp('=', false, false)
//     if (date === undefined) {
//         date = getRoundedObservationTime(Date.now())
//     }
//     input.observedAt = new SQLUpdateOp('=', date, date)
// }

// exports.populateObservedFields = populateObservedFields
