/**
 * @file software.js - 0.0.1045 - ea4595bfd3488684d225574ed7d4c198074d49ba
 * 
 * @copyright Copyright (C) 2016-2023, ISARA Corporation, All Rights Reserved.
 * 
 * @license The code and other content set out herein is not in the public
 * domain, is considered a trade secret and is confidential to ISARA
 * Corporation. Use, reproduction or distribution, in whole or in part, of such
 * code or other content is strictly prohibited except by express written
 * permission of ISARA Corporation. Please contact ISARA Corporation at
 * info@isara.com for more information.
 */

const {
    Software,
    SoftwareVersion,
} = require('../dbObjects')
const {
    dumpObjectTimingStats,
    initDbConnection,
    insertObject,
    bulkInsertRecords,
    resetObjectTimingStats
} = require('../dbHelpers')

const {
    pickOne,
    randomBelow,
    randomCompany,
    randomName,
} = require('../sampleHelpers')


var log = require('../../util/log')(module)
exports.populateSoftware = async (session, data) => {
    for (let typeName of Object.keys(data.softwareTypes)) {
        if (data.sampleSoftware[typeName]) {
            for (let softwareName of data.sampleSoftware[typeName]) {
                if (!(softwareName in Object.keys(data.allSoftware))) {
                    let software = new Software(softwareName, randomCompany(), data.softwareTypes[typeName].id, data)
                    await insertObject(software)
                    data.allSoftware[softwareName] = software
                    let versionsCount = randomBelow(7, 1)
                    for (let k = 0; k < versionsCount; ++k) {
                        let softwareVersion = new SoftwareVersion(software.id, softwareName, k)
                        await insertObject(softwareVersion)
                        if (!Object.keys(data.allSoftwareVersions).includes(typeName)) {
                            data.allSoftwareVersions[typeName] = []
                        }
                        data.allSoftwareVersions[typeName].push(softwareVersion)
                    }
                }
            }
        }
    }

    const softwareKeys = Object.keys(data.sampleSoftware)

    const connectionQuery = `select c."serverAddress", c."port" from advance."Connection" as c group by 1,2 limit 1000`
    const connectionData = (await session.query(connectionQuery)).rows

    if (connectionData.length > 0) {
        const deviceSw = connectionData.map((row) => {
            const shuffledKeys = softwareKeys.sort(() => 0.5 - Math.random()) // Shuffle software keys
            const [randomKey] = shuffledKeys.slice(0, 1) // Get sub-array of first n elements after shuffled
            const softwares = sampleSoftware[randomKey]
            var software = softwares[Math.floor(Math.random() * softwares.length)]

            return {
                user: 'root',
                sortableVersion: 0,
                version: '0.0',
                name: software,
                type: 'UNKNOWN',
                device: row.serverAddress,
                port: row.port,
                observedAt: new Date()
            }
        })

        try {
            await bulkInsertRecords('DeviceSoftware', deviceSw, session)
            log.log(`Success`)
        } catch (err) {
            log.log(`Device softwares not inserted. ${err}`)
        }
    }

}

