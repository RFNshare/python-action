/**
 * @file instantSearchQL.js - 0.0.1045 - ea4595bfd3488684d225574ed7d4c198074d49ba
 * 
 * @copyright Copyright (C) 2016-2023, ISARA Corporation, All Rights Reserved.
 * 
 * @license The code and other content set out herein is not in the public
 * domain, is considered a trade secret and is confidential to ISARA
 * Corporation. Use, reproduction or distribution, in whole or in part, of such
 * code or other content is strictly prohibited except by express written
 * permission of ISARA Corporation. Please contact ISARA Corporation at
 * info@isara.com for more information.
 */

/**
 * This module contains queries to interact with the search provider.
 * @module graphql/instantSearchQL
 */

const { initSearchIndexExport, unscheduleExport, scheduleExport } = require('../ingestion/searchIndex')
const { createUpdateDelete, registerHook, CUD_OP_UPDATE, CUD_OP_POST } = require('../isaraql/cud')
const { fetchWanted } = require('../isaraql/fetch')
const { getClientAccessKey } = require('../isaraql/instantSearchProvider')
const { Session } = require('../isaraql/session')
const { graphQLStateToWanted } = require('../isaraql/wantedUtil')
const { roles } = require('./commonQL')
const log = require('../util/log')(module)


/**
 * Mutation to kick off an export
 * @param {*} fields
 * @param {*} request
 * @param {*} graphQLState
 */
async function exportToSearchProvider(fields/*, request, graphQLState*/) {
    return initSearchIndexExport(fields.asOf)
}

/**
 * Fetch export list
 * @param {*} fields
 * @param {*} request
 * @param {*} graphQLState
 * @returns
 */
async function searchIndexExportResultsQuery(fields, request, graphQLState) {
    try {
        let tableName = 'SearchIndexExport'
        let wpcs = {
            SearchIndexExport: {
                where: {
                    and: []
                },
                sort: ['id desc']
            }
        }
        let session = new Session()
        
        if (fields.ids && fields.ids.length !== 0) {
            wpcs[tableName].where.and.push({ in: { column: 'id', value: fields.ids } })
        }

        if (fields.paging) {
            wpcs[tableName].paging = fields.paging
        } else {
            wpcs[tableName].paging = { offset: 0n, limit: 5n }
        }

        var wanted = graphQLStateToWanted(graphQLState)
        wanted = wanted[Object.keys(wanted)[0]]

        if (wanted.paging && wanted.paging.count) {
            wpcs[tableName].count = true
        }


        var searchExportResults = await fetchWanted(tableName, wanted.searchExportResults, wpcs, session)
        var toReturn = { searchExportResults }
        if (wanted.paging) {
            toReturn.paging = { count: wpcs[tableName].count[0] }
        }
        return toReturn
    } catch (e) {
        log.e(e)
    }
}

async function getSearchIndexExportSchedule(fields, request, graphQLState) {
    try {
        let tableName = 'SearchIndexExportSchedule'
        let wpcs = {
            SearchIndexExportSchedule: {
            }
        }
        let session = new Session()

        var wanted = graphQLStateToWanted(graphQLState)
        wanted = wanted[Object.keys(wanted)[0]]

        return (await fetchWanted(tableName, wanted, wpcs, session))[0]
    } catch (e) {
        log.e(e)
    }
}

async function updateSearchIndexExportSchedule(fields, request, graphQLState) {
    var {schedule} = fields
    var config = {
        allowDelete: false,
        allowInsert: false,
        allowUpdate: true,
        checkExistingTables: {},
        deletableTables: {},
        modifiableTables: {
            SearchIndexExportSchedule: true
        }
    }
    await createUpdateDelete('SearchIndexExportSchedule', [schedule], config)
    return await getSearchIndexExportSchedule(fields, request, graphQLState)
}

/**
 * This function will be called after the schedule is updated
 * @param {CUDHook} params
 */
async function postModifySearchExportSchedule(params) {
    await unscheduleExport()
    await scheduleExport(params.record)
}

function initialise() {
    registerHook('SearchIndexExportSchedule', CUD_OP_UPDATE, CUD_OP_POST, postModifySearchExportSchedule)
}

async function fetchApiKey() {
    return getClientAccessKey()
}

exports.graphQL = {
    types: `
        type PagedSearchIndexExportResults {
            paging: Paging!
            searchExportResults: [SearchIndexExport!]!
        }

        type SearchIndexItem {
            id: BigInt
            message: String
        }
    `,
    queries: `
        searchIndexExportResultsQuery(
            ids: [BigInt!]
            paging: PagingInput,
        ): PagedSearchIndexExportResults!

        getSearchIndexExportSchedule: SearchIndexExportSchedule

        fetchApiKey: String!
        `,
    mutations: `
        """
            Trigger an export of data to the search provider.
        """
        exportToSearchProvider(asOf: DateTime,): SearchIndexItem

        updateSearchIndexExportSchedule(schedule: SearchIndexExportScheduleInput!): SearchIndexExportSchedule!
        `,
    root: {
        exportToSearchProvider,
        searchIndexExportResultsQuery,
        getSearchIndexExportSchedule,
        updateSearchIndexExportSchedule,
        fetchApiKey
    },
    restrictions: {
        exportToSearchProvider: [roles.ADMIN],
        searchIndexExportResultsQuery: [roles.ADMIN],
        getSearchIndexExportSchedule: [roles.ADMIN],
        updateSearchIndexExportSchedule: [roles.ADMIN],
        fetchApiKey: [roles.AUTHENTICATED]
    },
    initialise
}
