/**
 * @file searchIndex.js - 0.0.1045 - ea4595bfd3488684d225574ed7d4c198074d49ba
 * 
 * @copyright Copyright (C) 2016-2023, ISARA Corporation, All Rights Reserved.
 * 
 * @license The code and other content set out herein is not in the public
 * domain, is considered a trade secret and is confidential to ISARA
 * Corporation. Use, reproduction or distribution, in whole or in part, of such
 * code or other content is strictly prohibited except by express written
 * permission of ISARA Corporation. Please contact ISARA Corporation at
 * info@isara.com for more information.
 */


/**
 * This module is the schedulable Ingestion Job for Data Source Scans.
 * @module ingestion/ingestionJob
 */

const log = require('../util/log')(module)
const scheduler = require('../util/scheduler')
const { Session } = require('../isaraql/session')
const { getInstantClient, getInstantSearchConfiguration } = require('../isaraql/instantSearchProvider')
const {
    mapConnectionToSchema,
    mapDeviceToSchema,
    mapDeviceSoftwareToSchema
} = require('../provision/instantSchema')
const { isMainThread } = require('worker_threads')
const axios = require('axios')
 
const SCHEDULED_EXPORT_PREFIX = 'ScheduledExport-'
const DEFAULT_CRON_STRING = '*/15 * * * *'
// const FAILED_ROWS_CHUNK_SIZE = 20
 
const { ChattyTimer } = require('../util/chattyTimer')
const { HeapMonitor } = require('../util/heapMonitor')
const { instantSearchSchemas } = require('../provision/instantSchema')
const { ResponseCounter } = require('./streaming/responseCounter')
const Cursor = require('pg-cursor')
const { CursorToReadable } = require('./streaming/cursorToReadable')
 
exports.ExportStatus = {
    CREATED: 'CREATED',
    IN_PROGRESS: 'IN_PROGRESS',
    FAILED: 'FAILED',
    COMPLETE: 'COMPLETE',
}
 
function timeFunction(name, asyncFunction) {
    return async function() {
        const timer = new ChattyTimer(name)
        timer.start()
        try {
            return await asyncFunction(...arguments)
        } catch (e) {
            log.e('Error in',name,e)
            throw e
        } finally {
            timer.stop()
        }
    }
}

/**
 * Create missing collections.
 * 
 * NB: This does not attempt to correct collections where the schema is wrong.
 */
async function createCollections() {
    const instantClient = await getInstantClient()
    for(let schema of instantSearchSchemas) {
        const exists = await instantClient.collections(schema.name).exists()

        // Create new if it didn't exist
        if (!exists) {
            log.log(`Creating instant search schema: ${schema.name}`)
            await instantClient.collections().create(schema)
        }
    }
}

exports.createCollections = createCollections 
 
async function initSearchIndexExport(asOf) {
    const session = new Session()
    let response = { id: null, message: null }
    try {
        await createCollections()
    } catch(e) {
        log.e(`Error while creating instant search schema ${e}`)
        response.message = 'Error while creating instant search schema'
        return response
    }
 
    // Check for a running export
    const lastExport = (
        await session.query(
            `SELECT * from "advance"."SearchIndexExport" WHERE status != 'FAILED' ORDER BY "addedAt" DESC LIMIT 1;`
        )
    ).rows
 
    // if still running, exit
    if (lastExport.length > 0 && lastExport[0].status === 'IN_PROGRESS') {
        log.log(
            `Previous export job id=${lastExport[0].id} is still running. Skipping.`
        )
        response.message = 'Previous export job is still running. Skipping export.'
        return response
    }

    const runningDatalogResult = (
        await session.query(
            `select ds."id" from advance."DataSourceScanResult" ds where ds."status" = 2`
        )
    ).rows

    if(runningDatalogResult.length) {
        log.log(`One of the ingestion is still in progess, Skipping export.`)
        response.message = 'One of the ingestion is still in progess, Skipping export.'
        return response
    }

    const [streamData] = (
        await session.query(
            `SELECT * from "advance"."StreamStatus" ORDER BY "id" DESC LIMIT 1;`
        )
    ).rows
    const {good: {lastActivity} = ''} = streamData ? JSON.parse(streamData?.lastStatus) : {}

    if(!asOf) {
        const datalogResult = (
            await session.query(
                `select ds."id" from advance."DataSourceScanResult" ds where ds."status" != 1`
            )
        ).rows

        if(!datalogResult.length && (!lastActivity || (lastActivity && lastExport.length && new Date(lastActivity) < new Date(lastExport[0].addedAt)))) {
            log.log(`No new ingested data detected. Skipping Search export processing.`)
            response.message = 'No new ingested data detected. Skipping Search export processing.'
            return response
        }
    }
 
    if (!asOf && lastExport.length > 0 && lastExport[0].status === exports.ExportStatus.COMPLETE) {
        const scanResult = (
            await session.query(
                `select ds."id" from advance."DataSourceScanResult" ds where ds."runAt" >= '${new Date(lastExport[0].addedAt).toISOString()}' and ds."status" IN (4,3)`
            )
        ).rows

        if((!scanResult.length && (!lastActivity || (lastActivity && new Date(lastActivity) < new Date(lastExport[0].addedAt))))) {
            log.log(`No new ingested data detected. Skipping Search export processing.`)
            response.message = 'No new ingested data detected. Skipping Search export processing.'
            return response
        }
    }
 
    // If not running, create new dump record
    const newExport = (
        await session.query(
            `INSERT INTO "SearchIndexExport" ("addedAt", status, summary) VALUES (NOW(), '${exports.ExportStatus.IN_PROGRESS}', 'Export running') RETURNING id`
        )
    ).rows[0]
 
    let startTime = lastExport.length ? lastExport[0].addedAt : new Date()
    // Override start time
    if (asOf) {
        startTime = new Date(asOf)
    }
 
    const { runInWorker } = require('../util/worker')
    await runInWorker({ requireName: __filename, functionName: 'runSearchIndexExport', args: { startTime, newExport } })
    response.id = newExport.id
    return response
}
 
const runSearchIndexExport = timeFunction('runSearchIndexExport',async function ({ startTime, newExport }) {
    if (isMainThread) {
        throw new Error('This function should not be called in the main thread')
    }
 
    const heapMonitor = new HeapMonitor()
 
    const session = new Session()
    try {
        // Kick-off
        const instantClient = await getInstantClient()
     
        // Pre-process scoring calculations
        try {
            await preProcessCryptoScores(session, startTime, newExport.id)
        } catch (e) {
            log.log('Failure during preprocessing CryptoScores', e)
            await updateExportStatus(
                session,
                newExport.id,
                exports.ExportStatus.FAILED,
                null,
                e.message
            )
            return
        }
 
        try {
            await loadStages(session, newExport.id)
            // await loadConnectionStage(session, newExport.id)
            // await loadDeviceStage(session, newExport.id)
            // await loadDeviceSWStage(session, newExport.id)
        } catch (e) {
            log.log('Failure during Staging Process', e)
            await updateExportStatus(
                session,
                newExport.id,
                exports.ExportStatus.FAILED,
                null,
                e.message
            )
            return
        }
 
        const [totalRowsDeviceSw, failedRowsDeviceSw] = await exportDeviceSoftware(
            session,
            newExport.id,
            instantClient,
            startTime
        )
        const failedDeviceSwLength = failedRowsDeviceSw ? Array.isArray(failedRowsDeviceSw) ? failedRowsDeviceSw.length : failedRowsDeviceSw : 0
       
        await updateExportStatus(
            session,
            newExport.id,
            exports.ExportStatus.IN_PROGRESS,
            `Exported ${totalRowsDeviceSw} device softwares with ${failedDeviceSwLength} failures`
        )
       
        const [totalRowsConnection, failedRowsConnection] = await exportConnections(
            session,
            newExport.id,
            instantClient,
            startTime
        )
        const failedConnectionsLength = failedRowsConnection ? Array.isArray(failedRowsConnection) ? failedRowsConnection.length : failedRowsConnection : 0
        await updateExportStatus(
            session,
            newExport.id,
            exports.ExportStatus.IN_PROGRESS,
            `Exported ${totalRowsConnection} connections with ${failedConnectionsLength} failures`
        )
       
        const [totalRowsDevice, failedRowsDevice] = await exportDevices(
            session,
            newExport.id,
            instantClient,
            startTime
        )
        const failedDevicesLength = failedRowsDevice ?  Array.isArray(failedRowsDevice) ? failedRowsDevice.length : failedRowsDevice : 0
       
        await updateExportStatus(
            session,
            newExport.id,
            exports.ExportStatus.IN_PROGRESS,
            `Exported ${totalRowsDevice} devices with ${failedDevicesLength} failures`
        )
       
        const totalRecords = totalRowsDevice + totalRowsConnection + totalRowsDeviceSw
        const totalFailedRecords = failedDevicesLength + failedConnectionsLength + failedDeviceSwLength
       
        await updateExportStatus(
            session,
            newExport.id,
            exports.ExportStatus.COMPLETE,
            `Exported ${totalRecords} records with ${totalFailedRecords} failures`
        )
    } catch (e) {
        log.log(`Search index export failed`, e)
        await updateExportStatus(
            session,
            newExport.id,
            exports.ExportStatus.FAILED,
            null,
            e.message
        )
    } finally {
        heapMonitor.stop()
    }
})
 
const getTypesenseURL = async () => {
    const config = await getInstantSearchConfiguration()
    const { nodes: [typesenseNode] } = config
    return `${typesenseNode.protocol}://${typesenseNode.host}:${typesenseNode.port}`
}
 
/**
  * Before exporting to Typesense, recalculate scores
  * @param {*} session 
  * @param {*} startTime 
  * @param {*} exportId 
  */
const preProcessCryptoScores = timeFunction('preProcessCryptoScores', async (session, startTime, exportId) => {
    await insertCryptoScores(session, startTime, exportId)
    await insertDeviceCryptoScores(session, startTime, exportId)
    // await updateCryptoScores(session, startTime, exportId)
})
 
const insertCryptoScores = timeFunction('insertCryptoScores', async (session, startTime, exportId) => {
    const scoreQuery = `
     -- combined cryptoprimitive and protocolvariant Cryptocore calculation   
     insert into "ConnectionScore" ("serverAddress", "clientAddress", "port",  "l4Protocol","cryptoScore" )
     select  "serverAddress", "clientAddress", "port",  "l4Protocol", min(score)
     from
     (
     (select ccp."serverAddress", ccp."clientAddress",ccp."port", ccp."l4Protocol",score
         from
         "CryptoPrimitiveScore" as cps,
         "CryptoScore" as cs,
         "CryptoPrimitive" as cp,
         "ConnectionCryptoPrimitive" as ccp
         where
          ccp."cryptoPrimitive" = cp.name
          and  cp.id = cps."cryptoPrimitive"
           and cps."cryptoScore" = cs.id)
      Union
      (select cpv."serverAddress", cpv."clientAddress",cpv."port", cpv."l4Protocol", score
         from
         "CryptoScore" as cs,
         "ProtocolVariantScore" as pvs,
           "ProtocolVariant" as pv,
         "ConnectionProtocolVariant" as cpv
         where
         cpv."protocolVariant"=pv.name
         and pv."id" = pvs."protocolVariant"
         and pvs."cryptoScore" = cs.id)
         ) as sc
       group by 1,2,3,4  
      
       on conflict("serverAddress", "clientAddress", "port",  "l4Protocol")  
       DO UPDATE   SET "cryptoScore" =  EXCLUDED."cryptoScore"
          where "ConnectionScore"."cryptoScore" > EXCLUDED."cryptoScore" ; `
    const result = await session.query(scoreQuery)
    await updateExportStatus(session, exportId, exports.ExportStatus.IN_PROGRESS, `Updated ${result.rowCount} Connection Cryptoscores`)
})
 
const insertDeviceCryptoScores = timeFunction('insertDeviceCryptoScores', async (session, startTime, exportId) => {
    const clientscoreQuery = `
         insert into "DeviceScore" ("ipAddress", "cryptoScore" )
         select "clientAddress", min("cryptoScore")  from   "ConnectionScore" group by 1 
         on conflict("ipAddress" ) DO UPDATE 
         SET "cryptoScore" =  EXCLUDED."cryptoScore"  where "DeviceScore"."cryptoScore" > EXCLUDED."cryptoScore" 
         `
 
    const result = await session.query(clientscoreQuery)
 
    const serverscoreQuery = `
   insert into "DeviceScore" ("ipAddress", "cryptoScore" )
   select "serverAddress", min("cryptoScore") from   "ConnectionScore" group by 1 
   on conflict("ipAddress" ) DO UPDATE 
   SET "cryptoScore" =  EXCLUDED."cryptoScore"  where "DeviceScore"."cryptoScore" > EXCLUDED."cryptoScore" 
   `
    await session.query(serverscoreQuery)
 
    await updateExportStatus(session, exportId, exports.ExportStatus.IN_PROGRESS, `Updated ${result.rowCount} Device Cryptoscores`)
})
 
const loadStages = timeFunction('loadStages', async (session, exportId) => {
    await loadConnectionStage(session, exportId)
    await loadDeviceStage(session, exportId)
    await loadDeviceSWStage(session, exportId)
})
 
const createConnectionStageTable = timeFunction('createConnectionStageTable',async (session) => {
    await session.query(`DROP TABLE IF EXISTS "advance"."ConnectionStage"`)
    const createQuery = `CREATE unlogged TABLE "advance"."ConnectionStage" (
     "id" bigint,
     "advanceId" bigint,
     "observedAt" timestamp,
     "clientAddress" varchar NULL ,
     "port" varchar NULL, 
     "serverAddress" varchar NULL, 
     "l4Protocol" varchar NULL, 
     "protocol" varchar NULL, 
     "keyExchange" varchar NULL, 
     "bulkEncryption" varchar NULL, 
     "modeOfOperation" varchar NULL, 
     "signature" varchar NULL,
     "hash" varchar NULL,
     "mac" varchar NULL,
     "cryptoScore" varchar NULL,
     "cryptoScoreCoarse" varchar NULL,
     "technology" varchar NULL,
     "connectionCount" varchar NULL,
     "scryptoScore" varchar NULL,
     "scryptoScoreCoarse" varchar NULL,
     "ccryptoScore" varchar NULL,
     "ccryptoScoreCoarse" varchar NULL,
     "cipherSuite" varchar NULL,
     "issuer" text NULL,
     "fingerprint" text NULL,
     "serveros" varchar NULL,
     "clientos" varchar NULL,
     "application" varchar NULL,
     "cryptoStrength" varchar NULL,
     "scryptoStrength" varchar NULL,
     "ccryptoStrength" varchar NULL,
     "zoneIn" varchar NULL,
     "zoneOut" varchar NULL,
     UNIQUE("serverAddress", "port", "clientAddress", "l4Protocol"));
     create unique index "CS_idx" on "ConnectionStage" (id);
     `
 
    await session.query(createQuery)
})
 
const loadConnectionStage = timeFunction('loadConnectionStage', async (session, exportId) => {
    await createConnectionStageTable(session)
    const protocolQuery = `insert into "ConnectionStage" (id, "serverAddress", "clientAddress", port, "l4Protocol", protocol, "observedAt", 
     "connectionCount" , "cipherSuite", "zoneIn", "zoneOut")
     select c."id", c."serverAddress", c."clientAddress",  c."port"  , c."l4Protocol", json_agg(p."protocolVariant") as "protocolVariant",
     c."observedAt", c."connectionCount", json_agg("cipherSuite"), c."zoneIn", c."zoneOut" 
     from advance."Connection" as c, "ConnectionProtocolVariant" as p, "ConnectionCipherSuite" as ccs
     where
     (c."serverAddress",c."clientAddress",c.port)=(p."serverAddress",p."clientAddress" , p.port) and
     (c."serverAddress",c."clientAddress",c.port)=(ccs."serverAddress",ccs."clientAddress" , ccs.port)
     group by 1,2,3,4,5,7,8 ;`
 
    const protocolResult = await session.query(protocolQuery)
    await updateExportStatus(session, exportId, exports.ExportStatus.IN_PROGRESS, `Added ${protocolResult.rowCount} protocols`)
 
 
    const ciphersuiteQuery = `
        insert into "ConnectionStage" ( "serverAddress"  , "clientAddress",  "port"  , "l4Protocol",  
        signature, "bulkEncryption", hash, "keyExchange",mac,"modeOfOperation") 
select  cp."serverAddress"  , cp."clientAddress",  cp."port"  , cp."l4Protocol",  
json_agg(distinct pr."friendlyName") FILTER (WHERE cpp.id = 1)  as signature, json_agg(distinct  pr."friendlyName") FILTER (WHERE cpp.id = 2)   as "bulkEncryption",
  json_agg( distinct  pr."friendlyName") FILTER (WHERE cpp.id = 3)  as hash,    json_agg( distinct  pr."friendlyName") FILTER (WHERE cpp.id = 4)  as key_exchange,
  json_agg( distinct  pr."friendlyName") FILTER (WHERE cpp.id = 5)  as mac,    json_agg( distinct  pr."friendlyName") FILTER (WHERE cpp.id = 6)  as mode_of_operation  
  from "ConnectionCryptoPrimitive" cp, advance."CryptoPrimitive" pr, "CryptoPrimitivePurpose" as cpp
  where cp."cryptoPrimitive" = pr.name and pr.purpose=cpp.id 
  group by 1,2,3,4
on conflict("serverAddress", "clientAddress", "port",  "l4Protocol")
DO UPDATE  SET  "signature" =  EXCLUDED."signature", "bulkEncryption" =  EXCLUDED."bulkEncryption", "hash" =  EXCLUDED."hash",
"keyExchange" =  EXCLUDED."keyExchange", "mac" =  EXCLUDED."mac", "modeOfOperation" =  EXCLUDED."modeOfOperation"

        
        `


    const ciphersuiteResult = await session.query(ciphersuiteQuery)
    await updateExportStatus(session, exportId, exports.ExportStatus.IN_PROGRESS, `Added ${ciphersuiteResult.rowCount} ciphersuites`)
 
 
    const cryptoscoreQuery = `insert into "ConnectionStage" ( "serverAddress"  , "clientAddress",  "port"  , "l4Protocol",  "cryptoScoreCoarse"  , "cryptoScore" , "cryptoStrength")
     select  c."serverAddress"  , c."clientAddress",  c."port"  , c."l4Protocol",  score."cryptoScoreCoarse"  , score."CryptoScore" , 
     to_json(array[score."cryptoScoreCoarse", score."CryptoScore"]) as cryptoStrength
     from advance."Connection" as c,
     "ConnectionScore" as cs,  
     "tScore" as score where
     (c."serverAddress",c."clientAddress",c.port, c."l4Protocol" )=(cs."serverAddress",cs."clientAddress" , cs.port,  cs."l4Protocol")
     and cs."cryptoScore" = score."score"
     on conflict("serverAddress", "clientAddress", "port",  "l4Protocol")
     DO UPDATE  SET "cryptoScoreCoarse" =  EXCLUDED."cryptoScoreCoarse", "cryptoScore" =  EXCLUDED."cryptoScore",
     "cryptoStrength" =  EXCLUDED."cryptoStrength"   `
 
    const cryptoscoreResult = await session.query(cryptoscoreQuery)
    await updateExportStatus(session, exportId, exports.ExportStatus.IN_PROGRESS, `Added ${cryptoscoreResult.rowCount} cryptoscore calc`)
 
    const clientServerCryptoQuery = `insert into "ConnectionStage" ("serverAddress", "clientAddress", "port", "l4Protocol",
     "serveros",
     "clientos", "technology")
     select c."serverAddress", c."clientAddress",  c."port", c."l4Protocol",
     sd."osType" as "os",
     cd."osType",  sd."osType" as "technology"
     from advance."Connection" as c,
      "Device" as sd,  "Device" as cd
     where (c."serverAddress" = sd."ipAddress")  and (c."clientAddress" = cd."ipAddress")
     on conflict("serverAddress", "clientAddress", "port",  "l4Protocol")
     DO UPDATE  SET "serveros" =  EXCLUDED."serveros",
     "clientos" =  EXCLUDED."clientos",  "technology" =  EXCLUDED."technology";`
 
    const clientServerCryptoResult = await session.query(clientServerCryptoQuery)
    await updateExportStatus(session, exportId, exports.ExportStatus.IN_PROGRESS, `Added ${clientServerCryptoResult.rowCount} client and server cryptoscores`)
 
    const certificateQuery = `insert into "ConnectionStage" ("serverAddress"  , "clientAddress",  "port"  , "l4Protocol",
     "issuer",   "fingerprint")
     select  c."serverAddress"  , c."clientAddress",  c."port"  , c."l4Protocol",
     json_agg(distinct dc.issuer) as issuer, json_agg(distinct dc.fingerprint) as fingerprint
     from advance."Connection" as c, "DeviceCertificate" as dc
     where (c."serverAddress",c."clientAddress",c.port, c."l4Protocol")=(dc."serverAddress",dc."clientAddress" , dc.port, dc."l4Protocol")
     Group by 1,2,3,4
     on conflict("serverAddress", "clientAddress", "port",  "l4Protocol")   DO UPDATE  
     SET "issuer" =  EXCLUDED."issuer", "fingerprint" =  EXCLUDED."fingerprint" ;`
 
    const certificateResult = await session.query(certificateQuery)
    await updateExportStatus(session, exportId, exports.ExportStatus.IN_PROGRESS, `Added ${certificateResult.rowCount} certificates`)
  
    const applicationQuery = `insert into "ConnectionStage" ("serverAddress"  , "clientAddress",  "port"  , "l4Protocol", "application")
   select  c."serverAddress"  , c."clientAddress",  c."port"  , c."l4Protocol", 
   COALESCE(json_agg(distinct dsw."name") FILTER (WHERE dsw."name" IS NOT NULL), '[]') as "application"
   from advance."Connection" as c ,
   "DeviceSoftware" as dsw 
   Where (c."serverAddress" = dsw."device") 
   group by 1,2,3,4
   on conflict("serverAddress", "clientAddress", "port",  "l4Protocol")   DO UPDATE  
   SET "application" =  EXCLUDED."application"; 
   
   `
 
    const applicationResult = await session.query(applicationQuery)
    await updateExportStatus(session, exportId, exports.ExportStatus.IN_PROGRESS, `Added ${applicationResult.rowCount} applications`)
})
 
const createDeviceStageTable = timeFunction('createDeviceStageTable', async (session) => {
    await session.query(`DROP TABLE IF EXISTS "advance"."DeviceStage"`)
    const query = `CREATE unlogged TABLE "DeviceStage" (
         "id" bigint,
         "observedAt" timestamp,
         "ipAddress" varchar NULL,
         "cryptoScore" varchar NULL,
         "cryptoScoreCoarse" varchar NULL,
         "ipVersion" varchar NULL,
         "taniumName" varchar NULL,
         "macAddress" varchar NULL,
         "osType" varchar NULL,
         "application" varchar NULL,
         "protocol" varchar NULL,
         "keyExchange" varchar NULL, 
         "bulkEncryption" varchar NULL, 
         "modeOfOperation" varchar NULL, 
         "signature" varchar NULL,
         "hash" varchar NULL,
         "mac" varchar NULL,
         "cipherSuite" varchar NULL,
         "listenport" varchar NULL,
         "cryptoprimitives" varchar NULL,
         "cryptoStrength" varchar NULL,
         UNIQUE ("ipAddress") ) `
    await session.query(query)
})
 
const loadDeviceStage = timeFunction('loadDeviceStage', async (session, exportId) => {
    await createDeviceStageTable(session)
 
    const cryptoscoreQuery = `insert into "DeviceStage"
     ("id", "observedAt", "taniumName", "ipAddress", "ipVersion", "macAddress", "osType" ,"cryptoScore", "cryptoScoreCoarse" , "cryptoStrength" )
  select d."id", d."observedAt", d."taniumName", d."ipAddress", d."ipVersion",  d."macAddress",  d."osType",
  "CryptoScore", "cryptoScoreCoarse" , to_json(array["CryptoScore", "cryptoScoreCoarse"]) as "cryptoStrength"
  from   "Device" as d left join  "DeviceScore" as ds on d."ipAddress" = ds."ipAddress" 
  left join   "tScore"  as ts on (ds."cryptoScore" = ts.score)`
 
    const cryptoscoreResult = await session.query(cryptoscoreQuery)
    await updateExportStatus(session, exportId, exports.ExportStatus.IN_PROGRESS, `Added ${cryptoscoreResult.rowCount} cryptoscores to device stage`)
 
    const updateQuery = `update "DeviceStage" set "cryptoScore" = 'Pending', "cryptoScoreCoarse" ='Unknown' , "cryptoStrength" = to_json(array['Pending', 'Unknown']) 
     where  "cryptoScore" is NULL`
 
    const updateResult = await session.query(updateQuery)
    await updateExportStatus(session, exportId, exports.ExportStatus.IN_PROGRESS, `Updated ${updateResult.rowCount} missing tanium devices to device stage`)
 
    const cryptoprimitiveQuery = `insert into "DeviceStage" ( "ipAddress" , 
     signature, "bulkEncryption", hash, "keyExchange",mac,"modeOfOperation")
       select ipaddress, json_agg(distinct "fname") FILTER (WHERE pid = 1)  as signature, json_agg(distinct  "fname") FILTER (WHERE pid = 2)   as "bulkEncryption",
       json_agg( distinct  "fname") FILTER (WHERE pid = 3)  as hash,    json_agg( distinct  "fname") FILTER (WHERE pid = 4)  as key_exchange,
       json_agg( distinct  "fname") FILTER (WHERE pid = 5)  as mac,    json_agg( distinct  "fname") FILTER (WHERE pid = 6)  as mode_of_operation
      from 
      (
       select cp."serverAddress"  as ipaddress,  pr."friendlyName" as "fname", cpp.id as pid
         from "ConnectionCryptoPrimitive" cp, advance."CryptoPrimitive" pr, "CryptoPrimitivePurpose" as cpp
       where cp."cryptoPrimitive" = pr.name and pr.purpose=cpp.id 
           Union
       select cp."clientAddress"  as ipaddress,  pr."friendlyName" as "fname", cpp.id as pid
         from "ConnectionCryptoPrimitive" cp, advance."CryptoPrimitive" pr, "CryptoPrimitivePurpose" as cpp
       where cp."cryptoPrimitive" = pr.name and pr.purpose=cpp.id 
       ) as deviceprims
       group by 1
    on conflict("ipAddress") 
    DO UPDATE  SET 
    "signature" =  EXCLUDED."signature", "bulkEncryption" =  EXCLUDED."bulkEncryption", "hash" =  EXCLUDED."hash", 
    "keyExchange" =  EXCLUDED."keyExchange", "mac" =  EXCLUDED."mac", "modeOfOperation" =  EXCLUDED."modeOfOperation"`
 
    const cryptoprimitiveResult = await session.query(cryptoprimitiveQuery)
    await updateExportStatus(session, exportId, exports.ExportStatus.IN_PROGRESS, `Updated ${cryptoprimitiveResult.rowCount} cryptoprimitives to device stage`)
 
    const ciphersuiteQuery = `insert into "DeviceStage" ("ipAddress", "cipherSuite", "protocol" )
     select "ipAddress", json_agg(distinct "cipherSuite" ), json_agg(distinct "protocolVariant" )
     from
     (select d."ipAddress"  as "ipAddress",  "cipherSuite" , "protocolVariant"
     from "Device" as d, "ConnectionCipherSuite" as ccs, "ConnectionProtocolVariant" as cp
     where
     (d."ipAddress"=ccs."serverAddress") and (d."ipAddress"=cp."serverAddress")
     UNION
     select d."ipAddress"  , "cipherSuite"  , "protocolVariant"
     from "Device" as d, "ConnectionCipherSuite" as ccs, "ConnectionProtocolVariant" as cp
     where
    
     (d."ipAddress"=ccs."clientAddress")  and (d."ipAddress"=cp."clientAddress"))
     as device  group by 1
      on conflict("ipAddress")   DO UPDATE  SET "cipherSuite" =  EXCLUDED."cipherSuite",  "protocol" =  EXCLUDED."protocol"`
 
    const ciphersuiteResult = await session.query(ciphersuiteQuery)
    await updateExportStatus(session, exportId, exports.ExportStatus.IN_PROGRESS, `Updated ${ciphersuiteResult.rowCount} ciphersuites to device stage`)
  
    const portQuery = `insert into "DeviceStage" ("ipAddress", "listenport" )
     select "serverAddress" as "ipAddress", json_agg(distinct "port" ) as "port"
     from "Connection" as c
     group by 1
     on conflict("ipAddress")   DO UPDATE  SET "listenport" =  EXCLUDED."listenport"`
 
    const portResult = await session.query(portQuery)
    await updateExportStatus(session, exportId, exports.ExportStatus.IN_PROGRESS, `Updated ${portResult.rowCount} ports to device stage`)
    const dsportQuery = `insert into "DeviceStage" ("ipAddress", "listenport") 
    select distinct v."ipAddress", jsonb_agg(distinct v."port") as port from 
    (select distinct "device" as "ipAddress", "port"  as "port"
    from "DeviceSoftware" as d
    UNION select distinct "serverAddress" as "ipAddress", "port" as "port"
    from "Connection" as c) v group by 1
    on conflict("ipAddress")   DO UPDATE  SET "listenport" =  EXCLUDED."listenport"`

    // const dsportQuery = `insert into "DeviceStage" ("ipAddress", "listenport") 
    // select distinct "device" as "ipAddress", jsonb_agg(distinct "port" ) as "port"
    // from "DeviceSoftware" as d
    // group by 1
    // UNION select "serverAddress" as "ipAddress", jsonb_agg(distinct "port" ) as "port"
    // from "Connection" as c group by 1
    // on conflict("ipAddress")   DO UPDATE  SET "listenport" =  EXCLUDED."listenport"`

    const dsportResult = await session.query(dsportQuery)
    await updateExportStatus(session, exportId, exports.ExportStatus.IN_PROGRESS, `Updated ${dsportResult.rowCount} ports to device stage`)

    const applicationQuery = `insert into "DeviceStage" ("ipAddress", "application" )
     select  d."ipAddress"  ,  COALESCE(json_agg(distinct dsw."name") FILTER (WHERE dsw."name" IS NOT NULL), '[]') as "application"
     from "Device" as d , "DeviceSoftware" as dsw 
     Where (d."ipAddress" = dsw."device") 
     group by 1
     on conflict("ipAddress")   DO UPDATE  SET "application" =  EXCLUDED."application"`
 
    const applicationResult = await session.query(applicationQuery)
    await updateExportStatus(session, exportId, exports.ExportStatus.IN_PROGRESS, `Updated ${applicationResult.rowCount} applications to device stage`)
 
})
 
/**
  * 
  * @param {Session} session 
  * @param {BigInt} exportId 
  * @param {Client} instantClient 
  * @param {Date} startTime 
  * @returns []
  */
const exportDevices = timeFunction('exportDevices', async(session, exportId, instantClient, startTime) => {
    return await exportTheThings({session, exportId, instantClient, startTime, 
        name: 'Export Devices', 
        collection: 'devices', 
        cursorFunc: fetchDeviceBatch, 
        converter: mapDeviceToSchema,
    })
})
 
/**
  * 
  * @param {Session} session 
  * @param {BigInt} exportId 
  * @param {Client} instantClient 
  * @param {Date} startTime 
  * @returns []
  */
const exportConnections = timeFunction('exportConnections', async(session, exportId, instantClient, startTime)  => {
    return await exportTheThings({session, exportId, instantClient, startTime,
        name: 'Export Connections', 
        collection:'connections', 
        cursorFunc: fetchConnectionBatch, 
        converter: mapConnectionToSchema,
    })
})
 
/**
  * 
  * @param {Session} session 
  * @param {BigInt} exportId 
  * @param {Client} instantClient 
  * @param {Date} startTime 
  * @returns []
  */
const exportDeviceSoftware = timeFunction('exportDeviceSoftware', async (session, exportId, instantClient, startTime) => {
    return await exportTheThings({session, exportId, instantClient, startTime,
        name: 'Export Device Software', 
        collection:'deviceSoftware',
        cursorFunc: fetchDeviceSoftwareBatch, 
        converter: mapDeviceSoftwareToSchema,
    })
})
 
/**
  * Generic thing exporter.
  * @param {Object} params
  * @property {Session} params.session Postgres session.
  * @property {Number} params.exportId The current export ID (used for updates)
  * @property {Client} params.instantClient Typesense client. (Not significantly used)
  * @property {Number} params.startTime Time to start data collection from. (Ignored by current cursor functions)
  * @property {String} params.name Name of the export.
  * @property {String} params.collection Typesense correct name of the collection.
  * @property {function} params.cursorFunc Function that will return a Cursor as a data source.
  * @property {function} params.converter Function that will convert the postgres output from the cursor to a typesense correct object.
  * @returns 
  */
async function exportTheThings({session, exportId, instantClient, startTime, name, collection, cursorFunc, converter}) {
    let lastId = 0
    let successRows = 0
    let failedRows = 0
    let totalRows = 0
    const axiosTimer = new ChattyTimer(`${name} -> axios -> typesense`)
    const typesenseURL = await getTypesenseURL()
    const isCollectionExists = await instantClient.collections(collection).exists()
    if (!isCollectionExists) {
        throw new Error(`The collection ${collection} does not exist. Is Typesense provisioned?`)
    }
    const cursor = await cursorFunc(session, startTime, lastId)
    try {
        let cursorToReadable
        do {
            cursorToReadable = new CursorToReadable({cursor, converter})
 
            axiosTimer.start()
 
            try {
                const { data } = await axios.post(`${typesenseURL}/collections/${collection}/documents/import?action=upsert&batch_size=50000`,
                    cursorToReadable,
                    {
                        headers: {'X-TYPESENSE-API-KEY': process.env.INSTANT_SEARCH_ADMIN_API_KEY ?? 'xyz'},
                        maxContentLength: Infinity,
                        maxBodyLength: Infinity,
                        responseType: 'stream'
                    })
                const counted = await new ResponseCounter(data).wait()
                successRows += counted.success
                failedRows += counted.failure + cursorToReadable.failedRowCount
            } catch (e) {
                log.e(`Exception exporting to ${collection}`, e)
                failedRows += cursorToReadable.failedRowCount
                throw e
            } finally {
                axiosTimer.stop()
            }
 
            totalRows += cursorToReadable.cusorRead
 
            await updateExportStatus(
                session,
                exportId,
                exports.ExportStatus.IN_PROGRESS,
                `Exported ${successRows} of ${totalRows} ${collection} with ${failedRows} to instant search provider`
            )
        } while (!cursorToReadable.cursorFinished)
    } finally {
        try {
            cursor.close(()=>{ log.d('Cursor closed')})
        } catch (cursorCloseError) {
            log.e('Error when closing cursor',cursorCloseError)
        }
    }
    return [totalRows, failedRows]
}
 
const fetchConnectionBatch = timeFunction('fetchConnectionBatch', async (session /*, startTime, lastId */) => {
    const connectionStageQuery = `select cs."id", cs."observedAt", cs."clientAddress", cs."port", 
       cs."serverAddress", cs."protocol", cs."keyExchange", cs."bulkEncryption", cs."modeOfOperation", 
       cs."signature", cs."hash", cs."mac", cs."cryptoScore", cs."cryptoScoreCoarse", cs."technology", 
       cs."connectionCount", cs."scryptoScore", cs."scryptoScoreCoarse", 
       cs."ccryptoScore", cs."ccryptoScoreCoarse", cs."cipherSuite", cs."issuer", cs."fingerprint",  cs."serveros", cs."clientos", 
       cs."application", cs."cryptoStrength", cs."scryptoStrength", cs."ccryptoStrength", cs."zoneIn", cs."zoneOut" 
       from advance."ConnectionStage" as cs 
       where cs.id is not null
       order by cs.id`
 
    return await session.query(new Cursor(connectionStageQuery))
})
 
const fetchDeviceBatch = timeFunction('fetchDeviceBatch', async (session /*, startTime, lastId */) => {

    const query = `select d."id", d."observedAt", d."ipAddress", d."ipVersion", d."taniumName",  
     d."macAddress", d."osType", d."cryptoScoreCoarse", d."cryptoScore", d."application",
     d."protocol", d."cipherSuite", d."listenport", d."cryptoprimitives", d."cryptoStrength", d."keyExchange",
     d."bulkEncryption", d."modeOfOperation", d."signature", d."hash", d."mac" 
     from "DeviceStage"  as d 
     where d."id" NOTNULL
     order by d.id`
 
    return await session.query(new Cursor(query))
})
 
 
const createDeviceSwStageTable = async (session) => {
    await session.query(`DROP TABLE IF EXISTS "advance"."DeviceSoftwareStage" `)
    const query = `CREATE TABLE "advance"."DeviceSoftwareStage" (
     "id" bigint,
     "observedAt" timestamp,
     "user" varchar NULL,
     "version" varchar NULL,
     "DeviceCount" integer NULL,
     "device" varchar NULL,
     "name" varchar NULL,
     "type" varchar NULL,
     "port" varchar NULL,
     "cipherSuite" varchar NULL,
     "protocol" varchar NULL,
     "keyExchange" varchar NULL, 
     "bulkEncryption" varchar NULL, 
     "modeOfOperation" varchar NULL, 
     "signature" varchar NULL,
     "hash" varchar NULL,
     "mac" varchar NULL,
     "osType" varchar NULL,
     "connectionCount" integer NULL,
     UNIQUE("name")
   )`
    await session.query(query)
} 
 
const loadDeviceSWStage = async (session, exportId) => {
    await createDeviceSwStageTable(session)
    let query = `
    insert into "DeviceSoftwareStage" (id, name, "user", version, port, "observedAt",  "DeviceCount", "device")
    select min(id), name, json_agg(distinct user ), json_agg(distinct version ), json_agg(distinct port),  max("observedAt"), count(*), json_agg(distinct device) 
    from "DeviceSoftware"
    group by 2 ;
 
 insert into "DeviceSoftwareStage" ("name", "cipherSuite", "connectionCount" )
 (select d."name"  as "name", json_agg(distinct "cipherSuite") as cipherSuite, count(*)
 from "DeviceSoftware" as d, "ConnectionCipherSuite" as ccs
 where
 (d."device")=(ccs."serverAddress") 
 group by 1 )
 on conflict("name")   DO UPDATE  SET "cipherSuite" =  EXCLUDED."cipherSuite", "connectionCount" =  EXCLUDED."connectionCount";
 
 insert into "DeviceSoftwareStage" ("name", "protocol" )
 select "name", json_agg(distinct "protocolVariant" ) as "protocol" 
 from "DeviceSoftware" as d, "ConnectionProtocolVariant" as cp
 where
 (d."device")=(cp."serverAddress") 
 group by 1
 on conflict("name")   DO UPDATE  SET "protocol" =  EXCLUDED."protocol" ;
 
 
 -- Add in the Cryptoprimitives for the software by purpose
 insert into "DeviceSoftwareStage" ( "name" , signature, "bulkEncryption", hash, "keyExchange",mac,"modeOfOperation")
     select d."name", json_agg(distinct pr."friendlyName") FILTER (WHERE cpp.id = 1)  as signature, json_agg(distinct  pr."friendlyName") FILTER (WHERE cpp.id = 2)   as "bulkEncryption",
     json_agg( distinct  pr."friendlyName") FILTER (WHERE cpp.id = 3)  as hash,    json_agg( distinct  pr."friendlyName") FILTER (WHERE cpp.id = 4)  as key_exchange,
     json_agg( distinct  pr."friendlyName") FILTER (WHERE cpp.id = 5)  as mac,    json_agg( distinct  pr."friendlyName") FILTER (WHERE cpp.id = 6)  as mode_of_operation
    from "ConnectionCryptoPrimitive" cp, advance."CryptoPrimitive" pr, "CryptoPrimitivePurpose" as cpp, "DeviceSoftware" as d
     where cp."cryptoPrimitive" = pr.name and pr.purpose=cpp.id and cp."serverAddress" =d."device"
     group by 1
  on conflict("name") 
  DO UPDATE  SET 
  "signature" =  EXCLUDED."signature", "bulkEncryption" =  EXCLUDED."bulkEncryption", "hash" =  EXCLUDED."hash", 
  "keyExchange" =  EXCLUDED."keyExchange", "mac" =  EXCLUDED."mac", "modeOfOperation" =  EXCLUDED."modeOfOperation";
 `
    let queryResult = await session.query(query)
    await updateExportStatus(session, exportId, exports.ExportStatus.IN_PROGRESS, `Added ${queryResult.rowCount} Application to Staging`)
 
}
 
const fetchDeviceSoftwareBatch = timeFunction('fetchDeviceSoftwareBatch', async (session /*, startTime, lastId*/) => {
    const query = `
     select dsw."id", dsw."user", dsw."device", dsw."name", dsw."type", dsw."port",  dsw."observedAt", 
     dsw."protocol", dsw."cipherSuite",  dsw."keyExchange",
     dsw."bulkEncryption", dsw."modeOfOperation", dsw."signature", dsw."hash", dsw."mac", dsw."version",
     dsw."DeviceCount", dsw."connectionCount" 
     from "DeviceSoftwareStage" as dsw
         order by dsw."id"   `
    return await session.query(new Cursor(query))
})
 
async function updateExportStatus(
    session,
    id,
    status,
    summary = null,
    errorMessage = null
) {
    let query = 'Update "SearchIndexExport" SET status = ? '
    let queryParams = [status]
    if (!summary && errorMessage) {
        summary = 'Export failed'
    }
    const [result] = (
        await session.query(
            `SELECT id, summary, "addedAt" from "advance"."SearchIndexExport" WHERE id = ${id};`
        )
    ).rows
    if (summary) {
        summary = result.summary ? result.summary.concat(',@', summary) : summary
     
        query += ', summary = ?'
        queryParams.push(summary)
    } 
    if (errorMessage) {
        query += ', "errorMessage" = ?'
        queryParams.push(errorMessage)
    }
    if(status === exports.ExportStatus.COMPLETE) {
        let currentDate = new Date()
        let duration = currentDate.getTime() - result.addedAt.getTime()
        query += ', "completedAt" = ?, duration = ?'
        queryParams.push(currentDate, duration)
    }
    query += ' where id = ?'
    queryParams.push(id)
 
    await session.query(query, queryParams)
}
 
/**
  * 
  * @returns 
  */
const cleanupStaleExports = timeFunction('cleanupStaleExports', async ()=> {
    const session = new Session()
    const errorMessage = 'Service terminated.'
    const summaryMessage = 'Service terminated while Export in progress.'
    await session.query(`
     UPDATE "SearchIndexExport"
     SET
       "status" = 'FAILED',
       "errorMessage" = '${errorMessage}',
       "summary" = '${summaryMessage}'
     WHERE
       "status" = 'IN_PROGRESS'
     `)
})
 
/**
  * Schedules an export.
  */
async function scheduleExport(schedule = null) {
    const session = new Session()
 
    if (!schedule) {
        schedule = (await session.query(`select timezone, cronish from "advance"."SearchIndexExportSchedule"`)).rows[0]
    }
 
    let error =
     !(await scheduler.scheduleJob(
         `${SCHEDULED_EXPORT_PREFIX}-default`,
         schedule.cronish || DEFAULT_CRON_STRING,
         schedule.timezone,
         async function () {
             try {
                 await initSearchIndexExport()
             } catch (e) {
                 let message = e.message || e
                 log.e(`Exception running Scan: ${message}`)
             }
         }
     ))
    return !error
}
 
async function unscheduleExport() {
    return await scheduler.cancelJob(`${SCHEDULED_EXPORT_PREFIX}-default`)
}
 
/**
  * Initializes the Export Jobs in the scheduler. Intended to be used on system startup.
  */
async function initializeInstantSearchExports() {
    await cleanupStaleExports()
    return await scheduleExport()
}
 
exports.initializeInstantSearchExports = initializeInstantSearchExports
exports.initSearchIndexExport = initSearchIndexExport
exports.runSearchIndexExport = runSearchIndexExport
exports.scheduleExport = scheduleExport
exports.unscheduleExport = unscheduleExport