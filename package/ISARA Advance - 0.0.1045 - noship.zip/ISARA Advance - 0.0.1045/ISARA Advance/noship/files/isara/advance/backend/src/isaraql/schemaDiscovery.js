/**
 * @file schemaDiscovery.js - 0.0.1045 - ea4595bfd3488684d225574ed7d4c198074d49ba
 * 
 * @copyright Copyright (C) 2016-2023, ISARA Corporation, All Rights Reserved.
 * 
 * @license The code and other content set out herein is not in the public
 * domain, is considered a trade secret and is confidential to ISARA
 * Corporation. Use, reproduction or distribution, in whole or in part, of such
 * code or other content is strictly prohibited except by express written
 * permission of ISARA Corporation. Please contact ISARA Corporation at
 * info@isara.com for more information.
 */

/**
 * Code to load the Maria schema in to memory.
 * @module isaraql/schemaDiscovery
 */

/**
 * Each discovered table will be here as a type.
 */
const allTypes = {}

const {
    Session
} = require('./session')

const log = require('../util/log.js')(module)

const sortedJSON = require('../util/sortedJSON')

/**
 * (Currently) simple mapping of MariaDB type to GraphQL type.
 */
const sqlToGraphQLType = {
    'bigint': 'BigInt',
    'blob': 'String',
    'boolean': 'Boolean',
    'bytea': 'String',
    'character': 'String',
    'character varying': 'String',
    'datetime': 'DateTime',
    'integer': 'Int',
    'smallint': 'Boolean',
    'text': 'String',
    'timestamp with time zone': 'DateTime',
    'timestamp without time zone': 'DateTime'
}

/**
 * Constant indicating that a foreign key is inbound, ie: refers to this table.
 */
const FK_INBOUND = 'fkInbound'

/**
 * Constant indicating that a foreign key is outbound, ie: refers to a (normally) different table.
 */
const FK_OUTBOUND = 'fkOutbound'

/**
 * Convert a MariaDB column (represented as a row) to a GraphQL type. This will include the optionality.
 *
 * @param row {object} A row from {information_schema.columns}
 * @return A GraphQL type, including optionality.
 */
async function toGraphQLType(row) {
    var sqlType = row['data_type']
    var nullable = row.is_nullable === 'YES'

    if (sqlType in sqlToGraphQLType) {
        sqlType = sqlToGraphQLType[sqlType]
    } else {
        log.e('Missing type for', sqlType)
    }

    var graphQLType = sqlType + (nullable ? '' : '!')
    return graphQLType
}

/**
 * Get all of the enum values from a table. The table must have id and name columns.
 *
 * @param {*} session A connected database session.
 * @param {*} tableName The table name to fetch from.
 *
 * An object containing all of the values, IDs and lookup dictionaries.
 */
async function getAllEnumValues(session, tableName) {
    var toReturn = { detailsByName: {}, detailsByID: {}, idByName: {}, nameByID: {}, names: [], ids: [] }

    var rows = await session.query(`select * from "${tableName}"`)
    if (rows.length === 0) {
        throw `Database missing records for enum designated type ${tableName}.`
    }
    for (var row of rows.rows) {
        var name = row.name
        var id = row.id
        toReturn.idByName[name] = id
        toReturn.nameByID[id] = name
        toReturn.detailsByName[name] = row
        toReturn.detailsByID[id] = row
        toReturn.names.push(name)
        toReturn.ids.push(id)
    }

    toReturn.names.sort()
    return toReturn
}

const GRAPHQL_ENUM_ANNOTATION = '@graphQL.enum'
const GRAPHQL_HIDE_ANNOTATION = '@graphQL.hide'
const GRAPHQL_READONLY_ANNOTATION = '@graphQL.readOnly'
const GRAPHQL_NO_TRAVERSE = '@graphQL.noTraverse'

/**
 * Discover the schema for the given table. Recursively discovery any tables that have
 * foreign keys to or from that table.
 *
 * @param session {Session} A connected database session.
 * @param tableName {string} The table whose schema should be discovered.
 *
 * @return nothing. The discovered tables are placed into {allTypes}
 */
async function discoverForTable(session, tableName) {
    log.d('Discovering', tableName)

    var toGenerate = []

    try {
        if (tableName in allTypes) {
            return
        }

        var isEnum = false
        var traverse = true
        var typeIsReadOnly = false

        var commentRows = await session.query("select pg_catalog.obj_description(c.oid, 'pg_class') AS comment FROM pg_catalog.pg_class"
      + " c WHERE c.relkind IN('r', 'p', 's') AND c.relname = $1 AND c.relnamespace = (select oid FROM pg_catalog.pg_namespace "
      + " WHERE nspname = 'advance')", [tableName])
        for (var commentRow of commentRows.rows) {
            var comment = commentRow.comment
            if (comment !== null && comment.length > 0) {
                var comments = comment.split('\n')
                for (var line of comments) {
                    line = line.trim()
                    // Note: Not breaking out of the loop, as we expect more annotations in the future.
                    if (line === GRAPHQL_ENUM_ANNOTATION) {
                        isEnum = true
                    } else if (line === GRAPHQL_NO_TRAVERSE) {
                        traverse = false
                    } else if (line === GRAPHQL_HIDE_ANNOTATION) {
                        throw `Hiding a table from GraphQL is not supported ${tableName} has ${GRAPHQL_HIDE_ANNOTATION}`
                    } else if (line === GRAPHQL_READONLY_ANNOTATION) {
                        log.d('Skipping input type generation for ', tableName)
                        typeIsReadOnly = true
                    }
                }
            }
        }

        var columns = await session.query("select *, col_description(concat('\"', table_schema, '\".\"', table_name, '\"')::regClass,"
      + " ordinal_position) as comment from information_schema.columns where table_schema = 'advance' AND table_name = $1",
        [tableName])

        var type = {}
        var byColumn = {}
        var simpleTypes = {}
        var hidden = {}
        var readOnly = {}

        allTypes[tableName] = type
        type._meta = { _isEnum: isEnum, _simpleTypes: simpleTypes, _typeIsReadOnly: typeIsReadOnly, _hidden: hidden, _traverse: traverse, _readOnly: readOnly }

        if (isEnum) {
            type._enum = await getAllEnumValues(session, tableName)
        }

        for (var column of columns.rows) {
            var name = column.column_name
            type[name] = await toGraphQLType(column)
            byColumn[name] = column
            comment = column.comment
            if (comment !== null && comment.length > 0) {
                comments = comment.split('\n')
                for (line of comments) {
                    line = line.trim()
                    // Note: Not breaking out of the loop as we expect more annotations in the future.
                    if (line === GRAPHQL_HIDE_ANNOTATION) {
                        hidden[name] = true
                        log.d('Choosing to hide ', name)
                    } else if (line === GRAPHQL_ENUM_ANNOTATION) {
                        throw `Enum does not make sense for a column. ${tableName} ${name} ${GRAPHQL_ENUM_ANNOTATION}`
                    } else if (line === GRAPHQL_READONLY_ANNOTATION) {
                        readOnly[name] = true
                    }
                }
            }
        }

        const foreignKeysOut = await session.query(`SELECT
        kcu.column_name, ccu.table_name AS foreign_table_name, ccu.column_name AS foreign_column_name
      FROM
        information_schema.table_constraints tc
      JOIN
        information_schema.key_column_usage AS kcu ON tc.constraint_name = kcu.constraint_name
          AND tc.table_schema = kcu.table_schema
      JOIN
        information_schema.constraint_column_usage AS ccu ON ccu.constraint_name = tc.constraint_name
          AND ccu.table_schema = tc.table_schema
      WHERE
        tc.table_name=$1 AND tc.constraint_type='FOREIGN KEY' AND tc.table_schema='advance'`, [tableName])
        for (let row of foreignKeysOut.rows) {

            let columnName = row.column_name
            let referencedTableName = row.foreign_table_name

            toGenerate.push(referencedTableName)

            type[columnName] = referencedTableName + ((byColumn[columnName].is_nullable === 'YES') ? '' : '!')
            simpleTypes[columnName] = referencedTableName
            type._meta[columnName] = {
                dir: FK_OUTBOUND,
                table: referencedTableName,
                column: row.foreign_column_name,
                isNullable: byColumn[columnName].is_nullable === 'YES'
            }
        }

        const foreignKeysIn = await session.query(`SELECT
        tc.table_name AS foreign_table_name, kcu.column_name AS foreign_column_name, ccu.table_name AS table_name,
        ccu.column_name AS column_name
      FROM
        information_schema.table_constraints tc
      JOIN
        information_schema.key_column_usage AS kcu ON tc.constraint_name = kcu.constraint_name
          AND tc.table_schema = kcu.table_schema
      JOIN
        information_schema.constraint_column_usage AS ccu ON ccu.constraint_name = tc.constraint_name
          AND ccu.table_schema = tc.table_schema
      WHERE
        ccu.table_name=$1 AND tc.constraint_type='FOREIGN KEY' AND tc.table_schema='advance'`, [tableName])
        for (let row of foreignKeysIn.rows) {
            let originTableName = row.foreign_table_name

            let columnName = row.foreign_column_name
            let columnNameLC = columnName.toLowerCase()
            let tableNameLC = tableName.toLowerCase()

            let plural = originTableName
            if (columnName.toLowerCase() !== tableNameLC) {
                let whereInName = columnNameLC.indexOf(tableNameLC)
                if (whereInName === 0) {
                    plural = columnName.substring(tableNameLC.length) + originTableName
                } else if (whereInName !== -1) {
                    plural = columnName.substring(0, columnName.length - tableNameLC.length) + originTableName
                }
            }

            if (plural[plural.length - 1] === 's') {
                plural = plural + 'es'
            } else {
                plural = plural + 's'
            }

            plural = plural.substring(0, 1).toLowerCase() + plural.substring(1)


            type[plural] = `[${originTableName}!]!`
            type._meta[plural] = {
                dir: FK_INBOUND,
                table: originTableName,
                column: columnName
            }

            toGenerate.push(originTableName)
        }


        const tableUniqueness = await session.query(`
    SELECT
      tc.constraint_name AS constraintName,
      tc.constraint_type AS constraintType,
      string_agg('"'||kcu.column_name::text||'"', ',') AS columns,
      array_agg(kcu.column_name) AS columnsarray
    FROM
      information_schema.table_constraints tc
          JOIN
            information_schema.key_column_usage AS kcu ON tc.constraint_name = kcu.constraint_name
              AND tc.table_schema = kcu.table_schema
    WHERE
        tc.constraint_type in ('UNIQUE') AND
      tc.table_schema='advance' AND
      tc.table_name = $1
    GROUP BY 1,2`, [tableName])

        type._meta['_uniqueConstraints'] = []

        for (let row of tableUniqueness.rows) {
            let {constraintname, constrainttype, columns, columnsarray} = row

            columnsarray = columnsarray.replace(/[{-}]/g, '').split(',')

            type._meta['_uniqueConstraints'].push({
                table: tableName,
                constraintname, constrainttype, columns, columnsarray
            })
        }


    } catch (e) {
        log.e('Could not discover for table', e)
        throw e
    } finally {
    // cool
    }

    for (var i = 0; i < toGenerate.length; ++i) {
        await discoverForTable(session, toGenerate[i])
    }
}

/**
 * Convert all discovered types (in {allTypes}) to GraphQL schema.
 *
 * @return {string} All of the discovered types as a GraphQL schema.
 */
async function allTypesToGraphQLSchema() {
    var toReturn = ''
    var keys = Object.keys(allTypes)
    keys.sort()
    for (var i = 0; i < keys.length; ++i) {
        var item = allTypes[keys[i]]
        if (item._meta._isEnum) {
            toReturn += `enum ${keys[i]} {\n`
            toReturn += item._enum.names.join(',')
            toReturn += `\n}\n`
        }

        const name = `${keys[i]}${item._meta._isEnum ? 'Enum' : ''}`

        toReturn += `type ${name}  {\n`
        var properties = []
        for (var property in item) {
            if (property.startsWith('_')) {
                continue
            }
            if (property in item._meta._hidden) {
                continue
            }
            if (!item._meta._isEnum || !(property in item._meta) || item._meta[property].dir === FK_OUTBOUND) {
                properties.push(`    ${property}: ${item[property]}`)
            }
        }
        properties.sort()
        toReturn += properties.join(',\n')
        toReturn += `\n}`
    }
    return toReturn
}

async function allTypesToGraphQLInputSchema() {
    var toReturn = '# Input variation of core database tables.\n\n\n'
    var keys = Object.keys(allTypes)
    keys.sort()
    for (var key of keys) {
        var item = allTypes[key]
        if (item._meta._typeIsReadOnly) {
            continue
        } else if (item._meta._isEnum) {
            // No need - enums are good for input or output
        } else {
            toReturn += `input ${key}Input {\n`
            var properties = []

            properties.push('    DELETE: Boolean')

            for (var property in item) {
                if (property.startsWith('_')) {
                    continue
                }
                if (property in item._meta._hidden) {
                    continue
                }
                if (property in item._meta._readOnly) {
                    continue
                }
                if (property in item._meta) {
                    var relationShip = item._meta[property]
                    var typeToAdd = relationShip.table
                    if (allTypes[typeToAdd]._meta._typeIsReadOnly) {
                        continue
                    }
                    if (!allTypes[typeToAdd]._meta._isEnum) {
                        typeToAdd += 'Input'
                    }
                    if (relationShip.dir == FK_INBOUND) {
                        properties.push(`    ${property}: [${typeToAdd}!]`)

                    } else {
                        properties.push(`    ${property}: ${typeToAdd}`)
                    }
                } else {
                    var propertyType = item[property]
                    propertyType = propertyType.replace(/!$/, '')
                    properties.push(`    ${property}: ${propertyType}`)
                }
            }
            properties.sort()
            toReturn += properties.join('\n')
            toReturn += '\n}'
        }
    }
    return toReturn
}

/**
 * Dictionary of all discovered types. Will be empty if {discoverSchema} has not been called.
 */
exports.allTypes = allTypes

/**
 * GraphQL schema for all discovered types as a {string}. Will be invalid if {discoverSchema} has not been called.
 */
exports.schema = 'You need to call build schema first'

/**
 * Discover the schema. The list of starting tables is fixed. Note that if any new tables are added that are not discoverable
 * via recursive traversal from the current set of starting tables, these will need to be added.
 *
 * {allTypes} and {schema} will be empty / invalid until this has been called.
 */
exports.discoverSchema = async function () {
    let tables = ['Device', 'Connection', 'DataSource', 'Netmask', 'IgnoredPort', 'SearchIndexExport', 'SearchIndexExportSchedule', 'StreamToken', 'StreamStatus', 'CipherSuiteScore']
    log.d('discoverSchema for', tables)
    for (var table of tables) {
        await discoverForTable(new Session(), table)
    }
    exports.schema = await allTypesToGraphQLSchema() + await allTypesToGraphQLInputSchema()
}

/**
 * A cache of discovered paths so that we don't need to discover them again.
 */
var previouslyDiscoveredPaths = {}

/**
 * @typedef DiscoveredPath
 * @property {string} from The originating table
 * @property {string} to The destination table
 * @property {string[]} paths The paths followed to find a route
 * @property {string[]} queries The queries followed to implement this route
 */

/**
 * Report on all the discovered paths in the system.
 *
 * @return {Object.<string,DiscoveredPath>}
 */
exports.discoveredPaths = function () {
    return JSON.parse(sortedJSON.stringify(previouslyDiscoveredPaths))
}

/**
 * Find (a subset of) the paths between two database tables.
 * @param {object} args
 * @param {string} args.from The origin table
 * @param {string} args.to The destination table
 * @param {object} [args.excludes] Optional object, where the keys are tables to exclude from built paths
 * @param {object} [args.includes] Optional object, where the keys are tables to explicitly include in the built paths
 * @param {number} [args.maxLength] The maximum length path to produce. Default will be 10 if not specified
 *
 * @return {Array[string[]]} Array of paths describing how to reach the target table from the source table.
 * This array will be `null` if you've asked for a path from a table to itself.
 */
exports.pathGraphs = function (args) {
    if (!args) {
        throw 'Missing args'
    }
    if (!args.from) {
        throw 'Missing args.from'
    }
    if (!args.to) {
        throw 'Missing args.to'
    }

    const from = args.from
    const to = args.to
    const maxLength = args.maxLength ? args.maxLength : 10
    const excludes = args.excludes ? args.excludes : null
    const includes = args.includes ? args.includes : null

    let paths

    paths = []
    let probes = []

    // Starting with this makes the breadth first search work, but we need to remove it later.
    let initialProbe = [{ to: from }]
    initialProbe.touched = { [from]: true }
    probes.push(initialProbe)
    let linksFollowed = {}

    for (let i = 0; i < maxLength; ++i) {
        let newProbes = []
        let linksFollowedThisRound = {}
        for (let probe of probes) {
            let last = probe[probe.length - 1]
            let tableInfo = allTypes[last.to]
            const isAnInclude = includes && last.to in includes
            if (!tableInfo._meta._traverse && !isAnInclude) {
                continue
            }
            for (let metaKey in tableInfo._meta) {
                let metaValue = tableInfo._meta[metaKey]
                if (typeof (metaValue) === 'object' && 'dir' in metaValue) {
                    metaValue = Object.assign({}, metaValue) // clone metaValue - don't expose the real one

                    if (excludes && (excludes[metaValue.table] === true
                            || excludes[metaValue.table] === metaKey
                            || excludes[`${metaValue.table}.${metaValue.column}`])) {
                        continue
                    }

                    if (!(metaValue.table in probe.touched)) {
                        var linkSummary = `${last.to}-${metaValue.table}-${metaKey}-${metaValue.dir}-${metaValue.column}`
                        if (!(linkSummary in linksFollowed)) {
                            linksFollowedThisRound[linkSummary] = true
                            let link = { from: last.to, to: metaValue.table, join: metaValue, name: metaKey }
                            let asProbe = [...probe]
                            asProbe.push(link)
                            asProbe.touched = Object.assign({}, probe.touched)
                            asProbe.touched[metaValue.table] = true
                            if (link.to === to) {
                                paths.push(asProbe)
                            } else {
                                newProbes.push(asProbe)
                            }
                        }
                    }
                }
            }
        }
        linksFollowed = Object.assign(linksFollowed, linksFollowedThisRound)
        probes = newProbes
    }

    // This is to remove the initial probe that started the breadth first search.
    paths.forEach(path => path.shift())

    return paths
}

/**
 * Find (a subset of) the paths between two database tables.
 * @param {object} args
 * @param {string} args.from The origin table
 * @param {string} args.to The destination table
 * @param {object} [args.excludes] Optional object, where the keys are tables to exclude from built paths
 * @param {object} [args.includes] Optional object, where the keys are tables to explicitly include in the built paths
 * @param {number} [args.maxLength] The maximum length path to produce. Default will be 10 if not specified
 * @param {string} [args.finalTableExtraCondition] An optional extra condition to add to the generated SQL.
 *
 * @return {string[]} Array of SQL describing how to reach the target table from the source table.
 * This array will be `null` if you've asked for a path from a table to itself.
 */
exports.paths = function (args) {
    if (!args) {
        throw 'Missing args'
    }
    if (!args.from) {
        throw 'Missing args.from'
    }
    if (!args.to) {
        throw 'Missing args.to'
    }

    const from = args.from
    const to = args.to
    const maxLength = args.maxLength ? args.maxLength : 10
    const finalTableExtraCondition = args.finalTableExtraCondition ? args.finalTableExtraCondition : ''
    const excludes = args.excludes ? args.excludes : null
    const includes = args.includes ? args.includes : null

    if (from === to) {
        return null
    }

    if (!(from in allTypes)) {
        throw `Unknown table ${from}`
    }

    if (!(to in allTypes)) {
        throw `Unknown table ${to}`
    }

    const rawKey = { from, to, maxLength, finalTableExtraCondition, excludes, includes }

    let key = sortedJSON.stringify(rawKey)

    if (key in previouslyDiscoveredPaths) {
        return previouslyDiscoveredPaths[key].queries
    }

    let queries
    let paths

    if (finalTableExtraCondition !== '') {
        const basisRawKey = { ...rawKey }
        basisRawKey.finalTableExtraCondition = ''
        let basisKey = sortedJSON.stringify(basisRawKey)
        if (!(basisKey in previouslyDiscoveredPaths)) {
            exports.paths(basisRawKey)
        }
        if (basisKey in previouslyDiscoveredPaths) {
            queries = [...(previouslyDiscoveredPaths[basisKey].queries)]
            paths = [...(previouslyDiscoveredPaths[basisKey].paths)]
        }
    }

    if (!queries) {
        paths = exports.pathGraphs(args)
        queries = paths.map(path => {
            var query = ` from "${from}"`
            for (var link of path) {
                query += `\n    JOIN "${link.to}" ON `
                if (link.join.dir === FK_INBOUND) {
                    query += ` "${link.from}".id = "${link.to}"."${link.join.column}" `
                } else {
                    query += ` "${link.from}"."${link.name}" = "${link.to}".id `
                }
            }
            return query
        })
    }

    if (finalTableExtraCondition !== '') {
        queries = queries.map(query => {
            if (finalTableExtraCondition.trim() !== '') {
                query += `\n    AND ${finalTableExtraCondition} `
            }
            return query
        })
    }

    previouslyDiscoveredPaths[key] = { from, to, paths, queries, finalTableExtraCondition }

    return previouslyDiscoveredPaths[key].queries
}

exports.FK_INBOUND = FK_INBOUND
exports.FK_OUTBOUND = FK_OUTBOUND
