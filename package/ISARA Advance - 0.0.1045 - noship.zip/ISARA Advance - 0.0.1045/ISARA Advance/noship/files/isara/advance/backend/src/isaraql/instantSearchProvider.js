/**
 * @file instantSearchProvider.js - 0.0.1045 - ea4595bfd3488684d225574ed7d4c198074d49ba
 * 
 * @copyright Copyright (C) 2016-2023, ISARA Corporation, All Rights Reserved.
 * 
 * @license The code and other content set out herein is not in the public
 * domain, is considered a trade secret and is confidential to ISARA
 * Corporation. Use, reproduction or distribution, in whole or in part, of such
 * code or other content is strictly prohibited except by express written
 * permission of ISARA Corporation. Please contact ISARA Corporation at
 * info@isara.com for more information.
 */

/**
 * A module that exposes connection to the Instant Search Provider
 * @module isaraql/instantSearchProvider
 **/

const systemPreferences = require('../util/systemPreferences')
const { Client } = require('typesense')
const LazySingleton = require('../util/lazySingleton')
const { default: axios } = require('axios')
const { Agent } = require('https')
const { loadCACertificates } = require('../util/certificates')

async function createClient() {
    const configuration = await getInstantSearchConfigurationInternal()
    const { nodes: [{ protocol, host, port }] } = configuration
    const url = `${protocol}://${host}:${port}`
    const agent = new Agent({
        ca: await loadCACertificates()
    })

    axios.interceptors.request.use(
        config => {
            try {
                if (config.url?.startsWith(url)) {
                    config.httpsAgent = agent
                }
                return config
            } catch (e) {
                console.log(e)
                throw e
            }
        }
    )

    try {
        return new Client(configuration)
    } catch (e) {
        throw 'Unable to initialize instant search connection'
    }
}

/**
 * The instant client
 * @private
 * @type LazySingleton
 */
var instantClient = new LazySingleton(createClient)

var clientKey = null

/**
 * Get Instant Provider Client
 * @returns {Client} client
 */
exports.getInstantClient = async function () {
    return await instantClient.get()
}

/**
 * Get the instant search configuration from system prefereneces, environment variables, of defaults
 * @returns the instant search provider configuration
 */
async function getInstantSearchConfigurationInternal() {
    const preferences = await systemPreferences()
    let toUse = null

    if (!('db' in preferences) || !('instantSearch' in preferences.db)) {
        toUse = {
            nodes: [
                {
                    host: process.env.INSTANT_SEARCH_HOST ?? '127.0.0.1',
                    port: parseInt(process.env.INSTANT_SEARCH_PORT ?? 8108),
                    protocol: process.env.INSTANT_SEARCH_PROTOCOL ?? 'https',
                },
            ],
            apiKey: process.env.INSTANT_SEARCH_ADMIN_API_KEY ?? 'xyz',
            connectionTimeoutSeconds: parseInt(process.env.INSTANT_SEARCH_TIMEOUT ?? 25),
        }
    } else {
        toUse = preferences.db.instantSearch
    }

    if (toUse?.nodes?.[0]?.protocol !== 'https') {
        throw new Error('This environment is not configured correctly - https mandated for typesense')
    }

    return JSON.parse(JSON.stringify(toUse))
}

/**
 * Get the instant search configuration from system prefereneces, environment variables, of defaults
 * @returns the instant search provider configuration
 */
exports.getInstantSearchConfiguration = async () => {
    await instantClient.get() // installs TLS interceptor/agent for the typesense URL via AXIOS
    return getInstantSearchConfigurationInternal()
}

/**
 * Create a new client token.
 * Cache the result - this is the only time the full token is returned
 * @returns 
 */
exports.createClientAccessKey = async () => {
    const client = await exports.getInstantClient()
    const resp = await client
        .keys()
        .create({
            description: 'Advance Client Key',
            actions: ['documents:search', 'documents:get', 'collections:get','documents:export'],
            collections: ['connections', 'devices', 'deviceSoftware']
        })
    clientKey = resp
    return resp.value
}

/**
 * Returns an existing key token.
 * If the cached key is expired, create a new one
 * @returns 
 */
exports.getClientAccessKey = async () => {
    if (clientKey) {
        // Fetch key and validate its expiry
        const accessKey = await (await exports.getInstantClient())
            .keys(clientKey.id)
            .retrieve()
        const expiry = new Date(accessKey.expires_at * 1000)

        // Generate a new key if the existing one is expired
        if (expiry > new Date()) {
            return clientKey.value
        } else {
            return exports.createClientAccessKey()
        }
    } else {
        return exports.createClientAccessKey()
    }


}
