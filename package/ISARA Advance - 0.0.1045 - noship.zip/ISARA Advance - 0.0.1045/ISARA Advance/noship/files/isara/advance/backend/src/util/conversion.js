/**
 * @file conversion.js - 0.0.1045 - ea4595bfd3488684d225574ed7d4c198074d49ba
 * 
 * @copyright Copyright (C) 2016-2023, ISARA Corporation, All Rights Reserved.
 * 
 * @license The code and other content set out herein is not in the public
 * domain, is considered a trade secret and is confidential to ISARA
 * Corporation. Use, reproduction or distribution, in whole or in part, of such
 * code or other content is strictly prohibited except by express written
 * permission of ISARA Corporation. Please contact ISARA Corporation at
 * info@isara.com for more information.
 */

/**
 * Collection of functions to convert between different types.
 * @module util/conversion
 */

const integerNumberRegex = /^[-+]?[0-9]+$/
const floatNumberRegex = /^[-+]?[0-9]*\.[0-9]+$/

/**
 * Strictly parse an integer - the entire input value must be part of the integer. Base 10 only. Optionally checks bounds.
 * @param {string} value The value to convert to an integer.
 * @param {number} [min] Minimum acceptable value
 * @param {number} [max] Maximum acceptable value
 * @returns {number} The value converted to an integer, or `NaN`.
 * @throws If the value is out of range of `min` or `max`.
 */
exports.parseIntStrict = function (value, min, max) {
    if (integerNumberRegex.test(value)) {
        var toReturn = parseInt(value)
        if (min !== undefined && toReturn < min) {
            throw `Out of bounds ${toReturn} < ${min}`
        }
        if (max !== undefined && toReturn > max) {
            throw `Out of bounds ${toReturn} > ${max}`
        }
        return toReturn
    } else {
        return NaN
    }
}

/**
 * Strictly parse an integer - the entire input value must be part of the integer. Base 10 only. Optionally checks bounds.
 * @param {string} value  The value to convert to an integer.
 * @param {number} [min] Minimum acceptable value
 * @param {number} [max] Maximum acceptable value
 * @returns {number} The value converted to an integer.
 * @throws If value does not comprise a valid integer, inside optional range.
 */
exports.parseIntStrictThrow = function (value, min, max) {
    var toReturn = exports.parseIntStrict(value, min, max)
    if (isNaN(toReturn)) {
        throw `'${value}' is not a correct integer`
    }
    return toReturn
}

/**
 * Strictly parse a float - the entire input value must be part of the float. Base 10 only. Optionally checks bounds.
 * @param {string} value The value to convert to a float.
 * @param {number} [min] Minimum acceptable value
 * @param {number} [max] Maximum acceptable value
 * @returns {number} The value converted to a float, or `NaN`.
 * @throws If the value is out of range of `min` or `max`.
 */
exports.parseFloatStrict = function (value, min, max) {
    if (floatNumberRegex.test(value)) {
        return parseFloatAndCheckRange(value, min, max)
    } else {
        return NaN
    }
}

/**
 * Strictly parse a numeric value (integer or float) - the entire input value must be part of the number.
 * Base 10 only. Optionally checks bounds.
 * @param {string} value The value to convert to a number.
 * @param {number} [min] Minimum acceptable value
 * @param {number} [max] Maximum acceptable value
 * @returns {number} The value converted to a number, or `NaN`.
 * @throws If the value is out of range of `min` or `max`.
 */
exports.parseNumericStrict = function (value, min, max) {
    if (integerNumberRegex.test(value)) {
        return parseIntAndCheckRange(value, min, max)
    } else if (floatNumberRegex.test(value)) {
        return parseFloatAndCheckRange(value, min, max)
    } else {
        return NaN
    }
}

function parseFloatAndCheckRange(value, min, max) {
    var toReturn = parseFloat(value)
    if (min !== undefined && toReturn < min) {
        throw `Out of bounds ${toReturn} < ${min}`
    }
    if (max !== undefined && toReturn > max) {
        throw `Out of bounds ${toReturn} > ${max}`
    }
    return toReturn
}

function parseIntAndCheckRange(value, min, max) {
    var toReturn = parseInt(value)
    if (min !== undefined && toReturn < min) {
        throw `Out of bounds ${toReturn} < ${min}`
    }
    if (max !== undefined && toReturn > max) {
        throw `Out of bounds ${toReturn} > ${max}`
    }
    return toReturn
}
