/**
 * @file ipUtils.js - 0.0.1045 - ea4595bfd3488684d225574ed7d4c198074d49ba
 * 
 * @copyright Copyright (C) 2016-2023, ISARA Corporation, All Rights Reserved.
 * 
 * @license The code and other content set out herein is not in the public
 * domain, is considered a trade secret and is confidential to ISARA
 * Corporation. Use, reproduction or distribution, in whole or in part, of such
 * code or other content is strictly prohibited except by express written
 * permission of ISARA Corporation. Please contact ISARA Corporation at
 * info@isara.com for more information.
 */

/**
 * Collection of functions for managing IP addresses.
 * @module util/ipUtils
 */

var log = require('./log')(module)
var conversion = require('./conversion')

/**
 * Toggle (set or clear) the trailing bits of the given address, to find the lower or upper bound of a netmask.
 * @param {IntArrayAndVersion} arrayAndVersion The address to toggle.
 * @param {number} [bits] The number of bits in the mask. This is the *opposite* of the maximum number of bits you'd expect to see changed. If `bits` is not passed in,
 * it will default to all bits, which means no bits will be toggled.
 * @param {number} setTo `0` or `1` - setting a bit to something other than `0` or `1` is not supported.
 * @returns {undefined}
 */
function toggleMaskedBits(arrayAndVersion, bits, setTo) {
    if (setTo !== 0 && setTo !== 1) {
        throw 'setTo must be 0 or 1'
    }

    var arrayCopy = [...arrayAndVersion.array]

    var wordSize = arrayAndVersion.ipVersion == 4 ? 8 : 16
    var totalBits = arrayAndVersion.ipVersion == 4 ? 32 : 128
    var wordMax = (1 << wordSize) - 1

    if (bits === undefined) {
        bits = totalBits
    }

    if (bits < 0) {
        throw 'Cannot set negative number of bits'
    }
    if (bits > totalBits) {
        throw 'Cannot set more bits than the address supports'
    }

    while (arrayCopy.length < totalBits / wordSize) {
        arrayCopy.push(0)
    }

    if (arrayCopy.length > totalBits / wordSize) {
        throw 'Wrong number of words in array'
    }

    var index = arrayCopy.length - 1
    var bitsToToggle = totalBits - bits

    while (bitsToToggle > 0) {
        var bitsThisGo = Math.min(bitsToToggle, wordSize)
        if (bitsThisGo === wordSize) {
            if (setTo) {
                arrayCopy[index] = wordMax
            } else {
                arrayCopy[index] = 0
            }
        } else {
            var mask = (1 << bitsThisGo) - 1

            if (setTo) {
                arrayCopy[index] |= mask
            } else {
                arrayCopy[index] &= (wordMax ^ mask)
            }
        }
        bitsToToggle -= bitsThisGo
        index--
    }

    return arrayToHex(arrayCopy, wordSize / 4)
}

const hexDigits = '0123456789abcdef'

/**
 * @typedef HexAndVersion
 * @property {string} hex The address as hex.
 * @property {string} address The original address.
 * @property {number} version The IP address version.
 */

/**
 * Convert an array of integers to hex.
 * @param {number[]} intArray An array of (hopefully) integers.
 * @param {number} hexPad How many characters long the hex response should be.
 * @returns {string} A string conversion of the `intArray` to hex.
 */
function arrayToHex(intArray, hexPad) {
    var toReturn = ''
    for (var value of intArray) {
        for (var i = 0; i < hexPad; ++i) {
            var shift = (hexPad - i - 1) * 4
            toReturn += hexDigits[(value >> shift) & 0xf]

        }
    }
    return toReturn
}

exports.arrayToHex = arrayToHex

/**
 * Holds the IP address as a words in an array, and an indication of the IP version of this address.
 * @typedef {Object} IntArrayAndVersion
 * @property {number} ipVersion The IP version of the address in the array.
 * @property {number[]} array The address represented as an array of word sized numbers.
 */

const ipV6NetmaskRegex = /^[0-9a-f]{0,4}(:[0-9a-f]{0,4}){0,7}(\/[0-9]+)?$/

const ipV4NetmaskRegex = /^[0-9]+(\.[0-9]+){0,3}(\/[0-9]+)?$/

/**
 * Break an IP address into an `IntArrayAndVersion`.
 * @param {string} ip A valid IPv4 or IPv6 address. Not that it may be truncated. 192.168/16 is a valid netmask, so 192.168 must be treated as a valid address.
 * @returns {IntArrayAndVersion}
 * @throws If the address is invalid, this includes a range check on all values in the address. (eg: 192.256.257.1024 is bad)
 */
function ipToIntArrayAndVersion(ip) {
    if (ip.indexOf('.') !== -1 || !isNaN(conversion.parseIntStrict(ip))) {
        var parts = ip.split('.')
        if (parts.length > 4) {
            throw `Invalid IPv4 address ${ip}`
        }
        return {
            array: parts.map(part => conversion.parseIntStrictThrow(part, 0, 255)),
            ipVersion: 4
        }
    } else if (ip.indexOf(':') !== -1) {
        // ensure there is one or no instance of ::
        var shorthand = (ip.match(/::/g) || []).length
        if (shorthand > 1) {
            throw `Invalid IPv6 address (bad shorthand) ${ip}`
        }

        parts = ip.split(':')

        if ((shorthand == 0) && (parts.length < 8)) {
            throw `Invalid IPv6 address (too short) ${ip}`
        }

        if (parts.length > 8) {
            throw `Invalid IPv6 address (too long) ${ip}`
        }

        var hexDigitArray = parts.map(part => parseInt(part, 16))
        var nancount = hexDigitArray.reduce(function(n, val) {
            return n + (Number.isNaN(val) ? 1 : 0)
        }, 0)

        if ((ip.indexOf('::') == 0) || (ip.indexOf('::') == ip.length - 2)) {
            /* Special case where an extra NaN is at the beginning or end of hexDigitArray. */
            nancount -= 1
            if (ip.indexOf('::') == 0) {
                hexDigitArray.splice(0, 1)
            } else {
                hexDigitArray.splice(hexDigitArray.length - 1, 1)
            }
        }

        if (nancount - shorthand != 0) {
            throw `Invalid IPv6 address (not hex) ${ip}`
        }

        if (shorthand == 1) {
            var zeroes_needed = 8 - hexDigitArray.length + 1
            var nanind = hexDigitArray.findIndex(Number.isNaN)
            var zeroes = Array.apply(null, new Array(zeroes_needed)).map(Number.prototype.valueOf,0)
            hexDigitArray.splice(nanind, 1, zeroes)
            hexDigitArray = hexDigitArray.flat()
        }

        return {
            array: hexDigitArray,
            ipVersion: 6
        }
    }
}

exports.ipToIntArrayAndVersion = ipToIntArrayAndVersion

/**
 * Carries an array of numbers.
 * @typedef {Object} ArrayAndBits
 * @property {IntArrayAndVersion} array Holds the address as word sized numbers making up the address, and the IP version.
 * @property {number} bits The number of bits set in the netmask.
 */

/**
 * Convert a netmask to an array containing the address as an array of word sized ints.
 * @param {string} netmask The IPv4 or IPv6 netmask to convert
 * @return {ArrayAndBits}
 */
function netmaskToArrayAndBits(netmask) {
    netmask = netmask.trim()

    if (ipV4NetmaskRegex.test(netmask) || ipV6NetmaskRegex.test(netmask)) {
        var addressAndBits = netmask.split('/')
        var array = ipToIntArrayAndVersion(addressAndBits[0])
        var bits = undefined

        if (addressAndBits.length > 1) {
            bits = conversion.parseIntStrictThrow(addressAndBits[1])
            if (bits < 0 || array.ipVersion == 4 && bits > 32 || array.ipVersion == 6 && bits > 128) {
                throw `Invalid number of bits in netmask ${bits}`
            }
        }
    } else {
        throw `Netmask failed regex test`
    }

    return { array, bits }
}


/**
 * Type containing a netmask represented as a HEX range of addresses.
 * @typedef NetmaskHexRange
 * @property {string} min The lower end of the masked address range.
 * @property {string} max The upper end of the masked address range.
 * @property {number} ipVersion `4` for IPv4, `6` for IPv6.
 */
/**
 * Convert an IPv4 or IPv6 netmask, to a range of HEX addresses.
 * @param {string} netmask A single netmask.
 * @returns {NetmaskHexRange}
 * @throws If the `netmask` is not a valid IPv4 or IPv6 netmask.
 */
exports.netmaskToHexRange = function (netmask) {
    var { bits, array } = netmaskToArrayAndBits(netmask)

    var min = toggleMaskedBits(array, bits, 0)
    var max = toggleMaskedBits(array, bits, 1)

    return { min, max, ipVersion: array.ipVersion }
}

/**
 * Validate a given (single) netmask. It will be trimmed - so any leading or trailing space will not be a problem.
 * @param {string} netmask IPv4 or IPv6 netmask
 * @param {boolean} [throwOnFail] Indicates if failures should throw (instead of normal return)
 * @returns {boolean} `true` if the netmask is valid. `false` if the netmask is not valid.
 * @throws Various descriptive errors if `throwOnFail` is `truthy`.
 */
exports.validateNetmask = function (netmask, throwOnFail) {
    try {
        netmaskToArrayAndBits(netmask)
        return true
    } catch (e) {
        if (throwOnFail) {
            throw e
        }
        return false
    }
}

if (require.main === module) {
    log.e(arrayToHex([0x1, 0xfa, 0xface], 4))
    for (var i = 0; i <= 32; ++i) {
        // log.e(i, exports.netmaskToHexRange(`255.255.255.255/${i}`))
        log.e(i, exports.netmaskToHexRange(`192.168.10/${i}`))
    }
    log.e(exports.validateNetmask('192.168.3.2538'))
}
