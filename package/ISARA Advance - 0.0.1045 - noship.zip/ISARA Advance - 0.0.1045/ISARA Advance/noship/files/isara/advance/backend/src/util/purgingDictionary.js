/**
 * @file purgingDictionary.js - 0.0.1045 - ea4595bfd3488684d225574ed7d4c198074d49ba
 * 
 * @copyright Copyright (C) 2016-2023, ISARA Corporation, All Rights Reserved.
 * 
 * @license The code and other content set out herein is not in the public
 * domain, is considered a trade secret and is confidential to ISARA
 * Corporation. Use, reproduction or distribution, in whole or in part, of such
 * code or other content is strictly prohibited except by express written
 * permission of ISARA Corporation. Please contact ISARA Corporation at
 * info@isara.com for more information.
 */

const log = require('./log')(module)

const PURGE_OVER = 5000000
const MILESTONE = 100000

class PurgingDictionary {
    #count = 0
    #cache = {}
    #name = ''

    constructor(name) {
        this.#name = name
    }

    put(key, value) {
        if (!(key in this.#cache)) {
            if (this.#count === PURGE_OVER) {
                this.purge()
            }
            this.#count++
            if (this.#count === 1 || this.#count % MILESTONE === 0) {
                log.log(`Purging Dictionary name ${this.#name} now holding ${this.#count}`)
            }
        }
        this.#cache[key] = value
        return value
    }

    has(key) {
        return key in this.#cache
    }
    
    purge() {
        log.log(`Purging dictionary named ${this.#name}`)
        this.#count = 0
        this.#cache = {}
    }

    get(key) {
        return this.#cache[key]
    }
}

exports.PurgingDictionary = PurgingDictionary