/**
 * @file valuesQL.js - 0.0.1045 - ea4595bfd3488684d225574ed7d4c198074d49ba
 * 
 * @copyright Copyright (C) 2016-2023, ISARA Corporation, All Rights Reserved.
 * 
 * @license The code and other content set out herein is not in the public
 * domain, is considered a trade secret and is confidential to ISARA
 * Corporation. Use, reproduction or distribution, in whole or in part, of such
 * code or other content is strictly prohibited except by express written
 * permission of ISARA Corporation. Please contact ISARA Corporation at
 * info@isara.com for more information.
 */

/**
 * This module contains queries to see known values.
 * @module graphql/valuesQL
 */

const { graphQLStateToWanted } = require('../isaraql/wantedUtil')
const { fetchWanted } = require('../isaraql/fetch')
const { roles } = require('./commonQL')
const { Session } = require('../isaraql/session')

async function getValues(table, fields, request, graphQLState, wpcs) {
    const wanted = graphQLStateToWanted(graphQLState)
    const thisQueryName = Object.keys(wanted)[0]
    return fetchWanted(table, wanted[thisQueryName], wpcs)
}

async function getCipherSuites(fields, request, graphQLState) {
    return getValues('CipherSuite', fields, request, graphQLState)
}

async function getProtocolVariants(fields, request, graphQLState) {
    const wpcs = { ProtocolVariant: { sort: ['protocol ASC', 'name DESC'] }}
    return getValues('ProtocolVariant', fields, request, graphQLState, wpcs)
}

async function getCipherSuiteScores() {
    let session = new Session()
    const scores = (
        await session.query(
            `select * from "CipherSuiteScore" css, "tScore" ts 
            where css."cryptoScore" = ts."score" order by "cryptoScore"`
        )
    ).rows
    return scores
}

exports.graphQL = {
    types: `
        type ciphersuiteScoreList {
            id: BigInt!
            cipherSuite: String!
            cryptoScore: BigInt!
            CryptoScore: String!
            cryptoScoreCoarse: String!
            cryptoScoreCoarseName: String!
        }
    `,
    queries: `
        """
            Get the known cipher suites
        """     
        getCipherSuites : [CipherSuite!]!

        """
            Get the supported protocols.
        """
        getProtocolVariants : [ProtocolVariant!]!

        """
            Get the known cipher suite scores
        """     
        getCipherSuiteScores : [ciphersuiteScoreList!]!
     `,
    root: {
        getCipherSuites,
        getProtocolVariants,
        getCipherSuiteScores
    },
    restrictions: {
        getCipherSuites: [roles.UNAUTHENTICATED],
        getProtocolVariants: [roles.UNAUTHENTICATED],
        getCipherSuiteScores: [roles.UNAUTHENTICATED],
    },
}
