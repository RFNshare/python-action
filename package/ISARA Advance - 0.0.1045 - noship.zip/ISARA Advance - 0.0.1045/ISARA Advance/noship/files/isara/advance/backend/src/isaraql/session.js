/**
 * @file session.js - 0.0.1045 - ea4595bfd3488684d225574ed7d4c198074d49ba
 * 
 * @copyright Copyright (C) 2016-2023, ISARA Corporation, All Rights Reserved.
 * 
 * @license The code and other content set out herein is not in the public
 * domain, is considered a trade secret and is confidential to ISARA
 * Corporation. Use, reproduction or distribution, in whole or in part, of such
 * code or other content is strictly prohibited except by express written
 * permission of ISARA Corporation. Please contact ISARA Corporation at
 * info@isara.com for more information.
 */

/**
 * Wrapper class for handling database connectivity.
 *
 * @module isaraql/session
 */

const { getPool } = require('./dbPool')

var types = require('pg').types

const log = require('../util/log')(module)
const Cursor = require('pg-cursor')

/**
 * Rewrite a select statement for positional placeholders.
 *
 * For simplicity, while generating queries, ? placeholders are used until all of a query's pieces have been assembled. This
 * function takes such a finalized statement as input, and remaps each placeholder to its appropriate postgres positional
 * placeholder.
 *
 * @param {string} selectStatement The statement to rewrite
 * @returns {string} The statement with placeholders replaced.
 */
function remapPlaceholders(selectStatement) {
    let index = 1
    return selectStatement.replace(/\?/g, () => `$${index++}`)
}

class Session {
    /**
     * Simple constructor.
     */
    constructor() {
        this.ignore = false
    }

    /**
     * Initialise the pool - not needed for transactions.
     * @private
     */
    async init() {
        this.tempNameCounter = 1
        this.pool = await getPool()
        // handle bigints
        types.setTypeParser(20, function (val) {
            return BigInt(val)
        })
        types.setTypeParser(1114, function (val) {
            // make sure returned string is denoted as utc
            return new Date(val + '+0000')
        })
    }

    get historyEnabled() {
        return this._historyEnabled
    }

    /**
     * Execute a query. If the `Session` isn't already inside a transaction, it will do a single
     * query against the pool.
     * 
     * If the first argument is a Cursor instance, that Cursor will be queried and returned.
     */
    async query() {
        try {
            if (arguments.length > 1) {
                arguments[0] = remapPlaceholders(arguments[0])
            }

            if (this.connection) {
                return await this.connection.query(...arguments)
            } else if (!this.pool) {
                await this.init()
            }
            if (arguments[0]?.constructor === Cursor) {
                this.pool.query(...arguments) // not awaiting cursor operation
                return arguments[0]
            }
            return await this.pool.query(...arguments)
        } catch (e) {
            log.e('Exception in query', ...arguments, e)
            throw e
        }
    }

    /**
     * Asks the Session object to reuse a single connection from the pool rather than each query going to a random one.
     * If this is already the case, this call is a no-op.
     */
    async reuseConnection(asyncFunction) {
        if (!this.pool) {
            await this.init()
        }

        if (!this.connection) {
            this.connection = await this.pool.connect()
            this._reuseLevel = 1
        } else {
            this._reuseLevel++
        }

        try {
            var toReturn = await asyncFunction(this)
            return toReturn
        } catch (e) {
            log.d('Error during single-connection session', e)
            throw e
        } finally {
            this._reuseLevel--
            if (this._reuseLevel === 0) {
                try {
                    delete this._reuseLevel
                    delete this._historyEnabled
                    // ensure any temp tables that were created in this session are destroyed.
                    await this.connection.query('DISCARD TEMP')
                    // reset all session variables in case history was configured.
                    await this.connection.query('RESET ALL')
                    await this.connection.release()
                } catch (e) {
                    log.e('Error releasing connection', e)
                }
                delete this.connection
            }
        }
    }

    /**
     * Configures the current session to use historical queries based on the provided time.
     * Throws if called without being in the context of a reused connection.
     *
     * @param {Object|null} period   // Period (null if not provided)
     * @param {Number} period.offset
     * @param {String} period.period Postgres supported interval period. eg: DAY, WEEK
     * @param {Date} [asOf] The date the period and offset is relative to. If not provided, will use `current_timestamp`.
     * @returns {Promise<Date>} In case the caller needed the result of the time calculation.
     */
    async configureHistory(/*period, asOf*/) {
        // TODO: 1981 - Cleanup/Redesign Database Timetravel Capabilities
        throw `History Tables have been disabled!`

        // For #2261, commented off the following as a piece of unreachable code 
        // if (!this.connection) {
        //     throw 'History configuration must be used within the context of a specific connection.'
        // }
        //
        // const intervalStr = period ? ` + interval '${period.offset} ${period.period}'` : ''
        // const baseTime = asOf ? `timestamp with time zone '${asOf.toISOString()}' ` : 'current_timestamp'
        // let result = await this.query(`SELECT (${baseTime}${intervalStr})::text AS offset`)
        // await this.query(`SET search_path='timetravel'`)
        // await this.query(`SET history.timestamp='${result.rows[0].offset}'`)
        // this._historyEnabled = new Date(result.rows[0].offset)
        // return this._historyEnabled
    }

    /**
     * Attempt to run the given function inside a database transaction. Any thrown errors will
     * rollback the transaction. The transaction will be committed if the code does not throw.
     * @param {function} asyncFunction The `async function` to run inside the transaction.
     * @returns {any} Returns the value from awaiting `asyncFunction`.
     * @throws If `asyncFunction` throws, or with any other database error.
     */
    async asTransaction(asyncFunction) {
        if (!this._transactionLevel) {
            this._transactionLevel = 1
        } else {
            this._transactionLevel++
        }

        return this.reuseConnection(async () => {
            try {
                if (this._transactionLevel == 1) {
                    await this.connection.query('BEGIN')
                }
                var toReturn = await asyncFunction(this)
                if (this._transactionLevel == 1) {
                    await this.connection.query('COMMIT')
                }
                return toReturn
            } catch (e) {
                log.d('Error during transaction', e)
                this._rollbackNeeded = true
                throw e
            } finally {
                this._transactionLevel--
                try {
                    if (this._rollbackNeeded && this._transactionLevel == 0) {
                        delete this._rollbackNeeded
                        await this.connection.query('ROLLBACK')
                    }
                } catch (e) {
                    log.e('Error rolling back', e)
                }

                if (this._transactionLevel == 0) {
                    delete this._transactionLevel
                }
            }
        })
    }

    /**
     * Generates a unique temporary table in the current session.
     *
     * @param {string} baseName A prefix to use for the name of the table. This should provide enough information to help identify
     * its purpose in case of error messages. Must conform to SQL naming restrictions.
     * @param {string} query The query to generate the temp table from.
     * @returns {string} The generated table name
     * @throws An exception is thrown if either table creation fails, or this function is called outside of the context of an
     * explicit connection (reuseConnection and/or asTransaction).
     */
    async generateTempTable(baseName, query, params) {
        if (!this.connection) {
            throw 'Temp table creation must be performed within a session.'
        } else if (baseName === undefined || baseName.length === 0) {
            throw 'A non-empty base table name must be provided.'
        } else if (query === undefined || query.length === 0) {
            throw 'A query must be supplied to generate a temp table.'
        }

        let tempTableName = `${baseName}_${this.tempNameCounter++}`
        let sqlStatement = `CREATE TEMPORARY TABLE "${tempTableName}" ${this.inTransaction ? 'ON COMMIT DROP' : ''} AS (${query})`
        await this.query(sqlStatement, params)
        return tempTableName
    }

    get inTransaction() {
        return this._transactionLevel !== undefined && this._transactionLevel > 0
    }
}

exports.Session = Session