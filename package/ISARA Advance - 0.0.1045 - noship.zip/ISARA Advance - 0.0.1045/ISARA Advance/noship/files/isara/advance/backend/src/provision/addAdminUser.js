/**
 * @file addAdminUser.js - 0.0.1045 - ea4595bfd3488684d225574ed7d4c198074d49ba
 * 
 * @copyright Copyright (C) 2016-2023, ISARA Corporation, All Rights Reserved.
 * 
 * @license The code and other content set out herein is not in the public
 * domain, is considered a trade secret and is confidential to ISARA
 * Corporation. Use, reproduction or distribution, in whole or in part, of such
 * code or other content is strictly prohibited except by express written
 * permission of ISARA Corporation. Please contact ISARA Corporation at
 * info@isara.com for more information.
 */

/**
 * @module provision/addAdminUser Module to add an admin user.
 */

const { insertRecord } = require('../isaraql/fetch')
const { allTypes, discoverSchema } = require('../isaraql/schemaDiscovery')
const { checkPasswordRequirements } = require('../graphql/userAdministrationQL')
var log = require('../util/log')(module)
const {
    Session
} = require('../isaraql/session')
const { hashPassword } = require('../util/passwordUtils')

const PRODUCTION_LOG_FILE_NAME = '/var/log/isara/advance.addadminuser.log'

/**
 * Log usage message.
 */
function usage() {
    log.e('Usage: addAdminUser <options> -n <name> -p <password>')
    log.e('With the following mandatory arguments:')
    log.e('    -n <name>            Set new admin user\'s name')
    log.e('    -p <password>        Set new admin user\'s password')
    log.e('And the following optional arguments:')
    log.e('    -f <friendly name>   Set new admin user\'s real name')
}

/**
 * Function to add admin user as specified by the command line arguments mentioned in `usage`.
 * @returns undefined
 */
async function main() {
    log.logFile = PRODUCTION_LOG_FILE_NAME

    const argv = require('minimist')(process.argv.slice(2))

    let humanName = argv.f
    let userName = argv.n
    let password = argv.p

    delete argv.f
    delete argv.n
    delete argv.p

    if (userName === undefined || password === undefined || argv._.length > 0 || Object.keys(argv).length !== 1) {
        usage()
        return
    }

    userName = userName.trim()

    if (userName === '') {
        log.e('Cannot use empty name as a user name')
        return
    }

    if (userName.includes(' ')) {
        log.e('Cannot use spaces in user name')
        return
    }

    for (let i = 0; i<userName.length; ++i) {
        if (userName.charCodeAt(i) < ' '.charCodeAt(0)) {
            log.e('Invalid characters in user name')
            return
        }
    }

    if (!checkPasswordRequirements(password)) {
        log.e('Password does not meet password complexity requirements')
        return
    }

    humanName = humanName || userName

    const user = {
        userName,
        humanName,
        passwordExpiry: new Date(), // expiry is disabled system wide
        lockedOut: false,
        hidden: false,
        passwordHash: await hashPassword(password)
    }

    await discoverSchema()

    const session = new Session()
    await session.asTransaction(async () => {

        const existingCheck = await session.query('select * from "User" where "userName" = ?', [userName])
        if (existingCheck.rowCount !== 0) {
            log.e(`${userName} already exists`)
            return
        }

        let userId = (await insertRecord('User', user)).id

        await insertRecord('UserRole', { user: userId, role: allTypes['Role']._enum.idByName['ADMIN'] })

        log.log('Success')
    })

}

if (require.main === module) {
    main().then(() => {
        process.exit(0)
    }).catch(error => {
        log.e('Fatal Error', error)
        process.exit(1)
    })
}
