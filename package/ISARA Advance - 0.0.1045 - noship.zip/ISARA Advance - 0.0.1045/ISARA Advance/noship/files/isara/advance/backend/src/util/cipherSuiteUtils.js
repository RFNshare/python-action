/**
 * @file cipherSuiteUtils.js - 0.0.1045 - ea4595bfd3488684d225574ed7d4c198074d49ba
 * 
 * @copyright Copyright (C) 2016-2023, ISARA Corporation, All Rights Reserved.
 * 
 * @license The code and other content set out herein is not in the public
 * domain, is considered a trade secret and is confidential to ISARA
 * Corporation. Use, reproduction or distribution, in whole or in part, of such
 * code or other content is strictly prohibited except by express written
 * permission of ISARA Corporation. Please contact ISARA Corporation at
 * info@isara.com for more information.
 */

/**
 * This module parses cipherSuite to CryptoPrimitives and map them
 * @module util/cipherSuiteUtils
 */

const kexPrimitiveNamesMap = {
    DH: 'FFDH',
    DHE: 'FFDHE',
    ECDH: 'ECDH',
    ECDHE: 'ECDHE',
    ECCPWD: 'ECCPWD',
    ECMQV: 'ECMQV',
    FORTEZZA: 'FORTEZZA',
    FFDH: 'FFDH',
    FFDHE: 'FFDHE',
    GOSTR341112: 'GOSTR341112',
    HMQV: 'HMQV',
    KRB: 'KRB',
    KRB5: 'KRB5',
    KRB5_EXPORT: 'KRB5_EXPORT',
    KYBER: 'KYBER',
    MQV: 'MQV',
    NHDH: 'NHDH',
    PSK: 'PSK_KE',
    RSA: 'RSA_KE',
    RSA_EXPORT: 'RSA_EXPORT',
    SABER: 'SABER',
    SIKE: 'SIKE',
    SRP: 'SRP',
    VKO_GOST: 'VKO_GOST',
    NULL: 'NULL_KE',
}



// (It seems like including some like BLOWFISH_<128 may not make sense since that's not the way it
// it would appear in ciphersuite name)
const encPrimitiveNamesMap = {
    '3DES': 'TDES',
    AES_128: 'AES_128',
    AES_192: 'AES_192',
    AES_256: 'AES_256',
    ARIA_128: 'ARIA_128',
    ARIA_256: 'ARIA_256',
    BASE64: 'BASE64',
    /*
    "BLOWFISH_<128",
    "BLOWFISH_128-256",
    "BLOWFISH_>256",
    */
    CAMELLIA_128: 'CAMELLIA_128',
    CAMELLIA_192: 'CAMELLIA_192',
    CAMELLIA_256: 'CAMELLIA_256',
    CAST5: 'CAST_5',
    /* CHACHA_20: "CHACHA_20", */
    CHACHA20_POLY1305: 'CHACHA_20_POLY1305',
    DES_CBC: 'DES_56',
    DES40: 'DES_40',
    DES56: 'DES_56',
    DSS_Export: 'DSS_Export',
    /* "FORTEZZA", */
    FORTEZZA_CBC: 'FORTEZZA_CBC',
    FORTEZZA_RC4: 'FORTEZZA_RC4',
    IDEA: 'IDEA',
    /* "RC", */
    RC2_40: 'RC2_40',
    RC2_CBC_40: 'RC2_40',
    RC2_56: 'RC2_56',
    RC2_128: 'RC2_128',
    RC4_40: 'RC4_40',
    RC4_56: 'RC4_56',
    RC4_128: 'RC4_128',
    SEED: 'SEED',
    NULL: 'NULL_ENC',
    SM4: 'SM4'
}

// Similar to above. (It seems that they may not have been included because are not useful for parsing ciphersuite
// since sizes are generally not included in name for signature algorithms)
const signaturePrimitiveNamesMap = {
    DILM: 'DILITHIUM',
    DSS: 'DSA',
    ECDSA: 'ECDSA',
    /*
    ECDSA_p256,
    ECDSA_p384,
    ECDSA_p251,
    EDDSA,
    EDDSA_448,
    EDDSA_25519,
    FSB,
    GR0STL,
    HAS,
    HAS_160,
    HAVAL_128,
    HAVAL_256,
    HSS,
    JH,
    */
    KEA: 'KEA',
    PSK: 'PSK_AUTH',
    /*
    MD6: "MD_6",
    RADIO_GATUN,
    RIPEMD,
    RIPEMD_128,
    RIPEMD_160,
    RIPEMD_320,
    */
    RSA: 'RSA_SIG',
    anon: 'ANON',
    /*
    SKEIN,
    SNEFRU,
    SNEFRU_128,
    SNEFRU_256,
    SPECTRAL_HASH,
    STREEBOG,
    STREEBOG_256,
    STREEBOG_512,
    SWIFFT,
    TIGER,
    WHIRLPOOL,
    XMSS,
    XMSSMT
    */
    NULL: 'NULL_SIG'
}

const hashPrimitiveList = [
    { tlsName: 'MD5', name: 'MD5', mac: 'HMAC_MD5_LT_128' },
    { tlsName: 'SHA1', name: 'SHA_1', mac: 'HMAC_SHA1_LT_160' },
    { tlsName: 'SHA224', name: 'SHA_224', mac: 'HMAC_SHA2_224' },
    { tlsName: 'SHA256', name: 'SHA_256', mac: 'HMAC_SHA2_256' },
    { tlsName: 'SHA384', name: 'SHA_384', mac: 'HMAC_SHA2_384' },
    { tlsName: 'SHA512', name: 'SHA_512', mac: 'HMAC_SHA2_512' },
    { tlsName: 'SHA', name: 'SHA_1', mac: 'HMAC_SHA1_LT_160' }, // In cipher suites, "SHA" represents SHA1.
    { tlsName: 'NULL', name: 'NULL_HASH', mac: null },
    { tlsName: 'SM3', name: 'SM3', mac: null },
]

const modeOfOperationList = [
    { modeName: 'CBC', name: 'CBC' },
    { modeName: 'CTR', name: 'CTR' },
    { modeName: 'CCM', name: 'CCM' },
    { modeName: 'GCM', name: 'GCM' },
]

function parseCipherSuite(cipherSuite) {
    let cipherInfo = null
    if (cipherSuite.startsWith('TLS_')) {
        cipherInfo = parseTLSCipherSuiteName(consume(cipherSuite, 'TLS_'))
        cipherInfo.protocol = 'TLS'
        return cipherInfo
    }
    else if (cipherSuite.startsWith('SSL_')) {
        cipherInfo = parseTLSCipherSuiteName(consume(cipherSuite, 'SSL_'))
        cipherInfo.protocol = 'TLS'
        return cipherInfo
    }
    else if (cipherSuite.startsWith('PLAIN_TEXT')) {
        return {
            kemPrimitives: [], hashPrimitives: [], encPrimitives: ['PLAIN_TEXT'], sigPrimitives: [], modeOfOperation: [],
            anon: false, export: false, renegotiation: false, fallback: false, protocol: 'PLAIN_TEXT'
        }
    }
    else {
        return {
            kemPrimitives: [], hashPrimitives: [], encPrimitives: [], sigPrimitives: [], modeOfOperation: [],
            anon: false, export: false, renegotiation: false, fallback: false, protocol: 'SSH'
        }
    }
}
exports.parseCipherSuite = parseCipherSuite

function parseTLSCipherSuiteName(cipherSuite) {
    // Parse IANA TLS/SSL cipher strings
    const withRegex = /_WITH_/
    let sliceIndex = cipherSuite.search(withRegex)
    let cipherInfo = {
        kemPrimitives: [], hashPrimitives: [], encPrimitives: [], sigPrimitives: [], modeOfOperation: [],
        anon: false, export: false, renegotiation: false, fallback: false
    }
    // Special cases
    if (cipherSuite.includes('RENEGOTIATION')) {
        cipherInfo.renegotiation = true
        return cipherInfo
    } else if (cipherSuite.includes('FALLBACK')) {
        cipherInfo.fallback = true
        return cipherInfo
    } else {
        if (sliceIndex > 0) {
            // KEM is specified, slice string at "WITH"
            let kemStrings = cipherSuite.slice(0, sliceIndex).split('_')
            cipherSuite = cipherSuite.slice(sliceIndex)
            for (let kemStr of kemStrings) {
                // Get KEM strings
                if (kexPrimitiveNamesMap[kemStr]) {
                    // Some primitives like RSA can be used for both key exchange and authentication
                    if (cipherInfo.kemPrimitives.length == 0 && kemStrings.length === 1 && signaturePrimitiveNamesMap[kemStr]) {
                        cipherInfo.kemPrimitives.push(kexPrimitiveNamesMap[kemStr])
                        cipherInfo.sigPrimitives.push(signaturePrimitiveNamesMap[kemStr])
                    } else if (cipherInfo.kemPrimitives.length > 0 && signaturePrimitiveNamesMap[kemStr]) {
                        cipherInfo.sigPrimitives.push(signaturePrimitiveNamesMap[kemStr])
                    } else {
                        cipherInfo.kemPrimitives.push(kexPrimitiveNamesMap[kemStr])
                    }
                } else if (signaturePrimitiveNamesMap[kemStr]) {
                    cipherInfo.sigPrimitives.push(signaturePrimitiveNamesMap[kemStr])
                } else if (kemStr === 'anon') {
                    cipherInfo.anon = true
                    if (cipherInfo.sigPrimitives.length) {
                        cipherInfo.sigPrimitives = []
                    }
                } else if (kemStr === 'EXPORT') {
                    cipherInfo.export = true
                }
            }
            cipherSuite = consume(cipherSuite, '_WITH_')
        }

        // Parse encryption primitive
        for (let [key, value] of Object.entries(encPrimitiveNamesMap)) {
            if (cipherSuite.includes(key)) {
                cipherInfo.encPrimitives.push(value)
                cipherSuite = consume(cipherSuite, key)
                break
            }
        }

        // Parse hash primitive
        for (let hash of hashPrimitiveList) {
            if (cipherSuite.includes(hash.tlsName)) {
                cipherInfo.hashPrimitives.push(hash.name)

                // Add the corresponding HMAC, which is used
                // for MAC or PRF in TLS.
                if (hash.mac !== null) {
                    cipherInfo.hashPrimitives.push(hash.mac)
                }

                break
            }
        }

        for (let mode of modeOfOperationList) {
            if (cipherSuite.includes(mode.modeName)) {
                cipherInfo.modeOfOperation.push(mode.name)
                break
            }
        }
    }

    return cipherInfo
}

function consume(str, toConsume) {
    if (str.startsWith(toConsume)) {
        return str.substr(toConsume.length)
    } else {
        throw `Unexpected token: ${str}`
    }
}