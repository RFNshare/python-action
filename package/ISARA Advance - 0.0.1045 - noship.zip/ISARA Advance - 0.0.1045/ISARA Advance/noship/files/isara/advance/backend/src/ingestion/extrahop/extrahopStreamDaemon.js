/**
 * @file extrahopStreamDaemon.js - 0.0.1045 - ea4595bfd3488684d225574ed7d4c198074d49ba
 * 
 * @copyright Copyright (C) 2016-2023, ISARA Corporation, All Rights Reserved.
 * 
 * @license The code and other content set out herein is not in the public
 * domain, is considered a trade secret and is confidential to ISARA
 * Corporation. Use, reproduction or distribution, in whole or in part, of such
 * code or other content is strictly prohibited except by express written
 * permission of ISARA Corporation. Please contact ISARA Corporation at
 * info@isara.com for more information.
 */

const PRODUCTION_LOG_FILE_NAME = '/var/log/isara/advance.extrahop.stream.log'

const log = require('../../util/log')(module)
log.logFile = PRODUCTION_LOG_FILE_NAME

const { init } = require('../cryptoDataCache')

const EXTRAHOP_STREAM_DAEMON_PORT = 4001

const express = require('express')
const { Session } = require('../../isaraql/session')
const { ExtraHopBatchProcessor } = require('./extrahopBatchProcessors')
const { loadNetmasks } = require('../netmaskMatching')
const { canDBConnect, getDBVersion } = require('../../isaraql/dbutil')
const app = express()
const { sleep } = require('../../util/sleep')
const { prepareHTTPSServer } = require('../../util/certificates')
const { validateToken, TOKEN_HEADER_NAME, StreamStatusTracker } = require('../streaming/streamTokens')

const COMMIT_MAX_DELAY_MS = 2 * 60 * 1000

/**
 * @type Number
 */
let timeOfLastCommit = -1

const QUEUE_GROWTH_MAX = 50

/**
 * A T-800 cannot self terminate. This code can. Take that skynet.
 */
const SELF_TERMINATE_SLEEP_MS = 2 * 60 * 1000

async function selfTerminate(reason) {
    log.e('Terminating in 2m', reason)
    await sleep(SELF_TERMINATE_SLEEP_MS)
    process.exit(1)
}

async function main() {
    app.use(express.raw({ type: () => true }))

    if (!await canDBConnect()) {
        await selfTerminate('Cannot connect to DB')
    }
    if (!await getDBVersion()) {
        await selfTerminate('DB does not have expected tables')
    }

    const session = new Session()
    const ehbp = new ExtraHopBatchProcessor(session)
    const messageQueue = { records: [] }

    async function processQueue() {
        try {
            ehbp.processConnections(messageQueue, true)
        } catch (error) {
            log.e('Errors processing the connections.', error)
        }
        messageQueue.records.length = 0
        if (ehbp.needsCommit() || Date.now() - timeOfLastCommit > COMMIT_MAX_DELAY_MS) {
            timeOfLastCommit = Date.now()
            try {
                log.d(`About to commit from extrahopStreamDaemon`)
                await ehbp.commit()
            } catch (error) {
                log.e('Error commiting', error)
            }
        }
    }

    await init()
    await loadNetmasks()

    const tracker = new StreamStatusTracker('ExtraHop Stream')
    await tracker.init()

    app.use('*', async (req, res) => {
        try {
            const token = req.headers[TOKEN_HEADER_NAME]
            if (!validateToken(token)) {
                log.e('Request received without valid token')
                res.status(401)
                res.send('Bad token')
                tracker.bump(false)
                return
            }
            log.d('Received')
            tracker.bump(true)
            messageQueue.records.push({ _source: JSON.parse(req.body) })
            if (messageQueue.records.length > QUEUE_GROWTH_MAX) {
                setTimeout(processQueue, 0)
            }
            res.send('OK')
        } catch (error) {
            tracker.bump(false)
            log.e('Error processing incoming message', error)
            try {
                res.send('ERROR')
            } catch (errorError) {
                // consume
            }
        }
    })

    await prepareHTTPSServer(EXTRAHOP_STREAM_DAEMON_PORT, app, 'backend')
}

main().catch(error => {
    log.e(error)
    process.exit(1)
})


