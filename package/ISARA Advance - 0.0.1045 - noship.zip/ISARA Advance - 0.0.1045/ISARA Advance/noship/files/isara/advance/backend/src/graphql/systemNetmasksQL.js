/**
 * @file systemNetmasksQL.js - 0.0.1045 - ea4595bfd3488684d225574ed7d4c198074d49ba
 * 
 * @copyright Copyright (C) 2016-2023, ISARA Corporation, All Rights Reserved.
 * 
 * @license The code and other content set out herein is not in the public
 * domain, is considered a trade secret and is confidential to ISARA
 * Corporation. Use, reproduction or distribution, in whole or in part, of such
 * code or other content is strictly prohibited except by express written
 * permission of ISARA Corporation. Please contact ISARA Corporation at
 * info@isara.com for more information.
 */

/**
 * This module contains queries relating to Netmasks.
 * @module graphql/systemNetmasksQL
 */

let {
    roles
} = require('./commonQL')

let {
    Session
} = require('../isaraql/session')

let {
    fetchWanted
} = require('../isaraql/fetch')

const { graphQLStateToWanted } = require('../isaraql/wantedUtil')
const { createUpdateDelete } = require('../isaraql/cud')
const { getMatch } = require('ip-matching')
const { loadNetmasks } = require('../ingestion/netmaskMatching')

const log = require('../util/log')(module)

async function netmaskByID(fields, request, response, session) {
    let id = fields.id
    if (id === undefined) {
        throw new Error('Missing ID')
    }
    let wanted = graphQLStateToWanted(response).netmaskByID
    let wpcs = { 'Netmask': { where: { equals: { column: 'id', value: id } } } }

    if (!session) {
        session = new Session()
    }

    let netmasks = await fetchWanted('Netmask', wanted, wpcs, session)
    if (netmasks.length > 0) {
        log.log('Returning',netmasks[0])
        return netmasks[0]
    }
    log.log('Returning null')
    return null
}

/**
 * Return Netmasks to caller.
 * @param {Object} fields
 * @param {Object} request
 * @param {Object} response
 * @param {Session} session
 */
async function netmasks(fields, request, response, session) {
    let sort = ['"sortOrder" asc', '"name" asc', '"netmask" asc']

    let wpcs = { 'Netmask': { sort } }

    if (session === undefined) {
        session = new Session()
    }

    let wanted = graphQLStateToWanted(response)
    wanted = wanted.netmasks ? wanted.netmasks : wanted.netmaskUpdate

    let netmasks = await fetchWanted('Netmask', wanted, wpcs, session)

    log.log('Sending', netmasks)

    return netmasks
}

/**
 * Attempt CUD on netmasks.
 * @param {*} fields
 * @param {*} request
 * @param {*} response
 * @param {*} session
 * @returns (calls) netmasks
 */
async function netmaskUpdate(fields, request, response, session) {
    const toUpdate = fields?.netmasks
    log.log('Updating netmasks')
    if (toUpdate?.length > 0) {
        if (!session) {
            session = new Session()
        }

        const tables = { Netmask: true }

        const config = {
            allowDelete: true,
            allowUpdate: true,
            allowInsert: true,
            checkExistingTables: tables,
            deletableTables: tables,
            modifiableTables: tables,
            session,
        }

        fields?.netmasks.forEach(nm => {
            if (nm.netmask) {
                let rawNetmasks = nm.netmask.split(',').map(n => n.trim())
                rawNetmasks.map(n => getMatch(n))
                nm.netmask = rawNetmasks.join(',')
            }
        })

        await createUpdateDelete('Netmask', fields.netmasks, config)
        await loadNetmasks(session)
    }
    return netmasks(fields, request, response, session)
}

async function initialise() {
    // NEXT DIFF: Sorting
    await loadNetmasks()
}

exports.graphQL = {
    types: `
    `,
    queries: `
        """
         Get the existing Netmasks.
        """
        netmasks: [Netmask!]!

        """
         Get a single Netmask by ID
        """
        netmaskByID(id: BigInt!) : Netmask
    `,
    mutations: `
        """
         Create update or delete Netmask records.
        """
        netmaskUpdate(
            netmasks: [NetmaskInput]!
        ): [Netmask!]!
    `,
    root: {
        netmasks,
        netmaskUpdate,
        netmaskByID,
    },
    restrictions: {
        netmasks: roles.UNAUTHENTICATED,
        netmaskUpdate: roles.UNAUTHENTICATED,
        netmaskByID: roles.UNAUTHENTICATED,
    },
    initialise
}
