/**
 * @file sortedJSON.js - 0.0.1045 - ea4595bfd3488684d225574ed7d4c198074d49ba
 * 
 * @copyright Copyright (C) 2016-2023, ISARA Corporation, All Rights Reserved.
 * 
 * @license The code and other content set out herein is not in the public
 * domain, is considered a trade secret and is confidential to ISARA
 * Corporation. Use, reproduction or distribution, in whole or in part, of such
 * code or other content is strictly prohibited except by express written
 * permission of ISARA Corporation. Please contact ISARA Corporation at
 * info@isara.com for more information.
 */

/**
 * A replacer intended for use with `JSON.stringify`. It will re-create any objects so 
 * that its keys are inserted in alphabetical order making the encoding be alphabetical (
 * and therefore more easy to compare)
 * 
 * @param {string} ignoredKey This key is ignored.
 * @param {value} value The value to replace.
 * @return The original value if not an `object`, a shallow copy with the keys created in
 *         alphabetical order if it is an `object`.
 */
exports.replacer = (ignoredKey, value) => {
    if (!value || Array.isArray(value) || (typeof value !== 'object')) {
        return value
    }
    const keys = Object.keys(value)
    keys.sort()
    const toReturn = {}
    for (const key of keys) {
        toReturn[key] = value[key]
    }
    return toReturn
}

/**
 * Alphabetically sorted object encoding version of `JSON.stringify`
 * @param {any} value The value to encoding
 * @param {number} [spacing] How to format the JSON. 
 */
exports.stringify = (value, spacing) => JSON.stringify(value, exports.replacer, spacing)