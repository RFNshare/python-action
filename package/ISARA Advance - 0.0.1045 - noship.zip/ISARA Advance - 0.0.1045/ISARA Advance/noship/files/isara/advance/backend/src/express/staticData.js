/**
 * @file staticData.js - 0.0.1045 - ea4595bfd3488684d225574ed7d4c198074d49ba
 * 
 * @copyright Copyright (C) 2016-2023, ISARA Corporation, All Rights Reserved.
 * 
 * @license The code and other content set out herein is not in the public
 * domain, is considered a trade secret and is confidential to ISARA
 * Corporation. Use, reproduction or distribution, in whole or in part, of such
 * code or other content is strictly prohibited except by express written
 * permission of ISARA Corporation. Please contact ISARA Corporation at
 * info@isara.com for more information.
 */

/**
 * This module defines the static data endpoint.
 * @module express/staticData
 */


const fs = require('fs')
const path = require('path')
const crypto = require('crypto')
const express = require('express')
const { roles } = require('../graphql/commonQL')

let appRoot = '/isara/'
if (!fs.existsSync(appRoot)) {
    appRoot = process.cwd()
}

exports.dataDirectory = path.join(appRoot, '/data/')
exports.dataUrlPath = '/service/data'

const expressStatic = express.static(exports.dataDirectory)

const accessControlMap = {}

exports.endpoint = {
    path: exports.dataUrlPath,
    use: {
        path: exports.dataUrlPath,
        handler: async function (req, res, next) {
            if (req.path in accessControlMap) {
                if (req.query.access === accessControlMap[req.path]) {
                    expressStatic(req, res, next)
                    return
                }
            }

            res.sendStatus(403)
        },
        restrictions: [roles.UNAUTHENTICATED]
    },
}

exports.requestAccessToken = async function(path) {
    if (!accessControlMap[path]) {
        accessControlMap[path] = crypto.randomUUID()
    }

    return accessControlMap[path]
}
