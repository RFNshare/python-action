/**
 * @file cryptoDataCache.js - 0.0.1045 - ea4595bfd3488684d225574ed7d4c198074d49ba
 * 
 * @copyright Copyright (C) 2016-2023, ISARA Corporation, All Rights Reserved.
 * 
 * @license The code and other content set out herein is not in the public
 * domain, is considered a trade secret and is confidential to ISARA
 * Corporation. Use, reproduction or distribution, in whole or in part, of such
 * code or other content is strictly prohibited except by express written
 * permission of ISARA Corporation. Please contact ISARA Corporation at
 * info@isara.com for more information.
 */

const { Session } = require('../isaraql/session')

const curveDictionary = { prime256v1: 'secp256r1' }

const curveIANADictionary = {}
curveIANADictionary[1] = `SECT163k1`
curveIANADictionary[2] = `SECT163r1`
curveIANADictionary[3] = `SECT163r2`
curveIANADictionary[4] = `SECT193r1`
curveIANADictionary[5] = `SECT193r2`
curveIANADictionary[6] = `SECT233k1`
curveIANADictionary[7] = `SECT233r1`
curveIANADictionary[8] = `SECT239k1`
curveIANADictionary[9] = `SECT283k1`
curveIANADictionary[10] = `SECT283r1`
curveIANADictionary[11] = `SECT409k1`
curveIANADictionary[12] = `SECT409r1`
curveIANADictionary[13] = `SECT571k1`
curveIANADictionary[14] = `SECT571r1`
curveIANADictionary[15] = `SECP160k1`
curveIANADictionary[16] = `SECP160r1`
curveIANADictionary[17] = `SECP160r2`
curveIANADictionary[18] = `SECP192k1`
curveIANADictionary[19] = `SECP192r1`
curveIANADictionary[20] = `SECP224k1`
curveIANADictionary[21] = `SECP224r1`
curveIANADictionary[22] = `SECP256k1`
curveIANADictionary[23] = `SECP256r1`
curveIANADictionary[24] = `SECP384r1`
curveIANADictionary[25] = `SECP521r1`
curveIANADictionary[26] = `BRAINPOOL_P256r1`
curveIANADictionary[31] = `BRAINPOOL_P256r1`
curveIANADictionary[27] = `BRAINPOOL_P384r1`
curveIANADictionary[32] = `BRAINPOOL_P384r1`
curveIANADictionary[28] = `BRAINPOOL_P512r1`
curveIANADictionary[33] = `BRAINPOOL_P512r1`
curveIANADictionary[29] = `x25519`
curveIANADictionary[30] = `x448`
curveIANADictionary[34] = `GC256A`
curveIANADictionary[35] = `GC256B`
curveIANADictionary[36] = `GC256C`
curveIANADictionary[37] = `GC256D`
curveIANADictionary[38] = `GC512A`
curveIANADictionary[39] = `GC512B`
curveIANADictionary[40] = `GC512C`
curveIANADictionary[41] = `CurveSM2`

// TLS 1.3 key exchange named group code point (https://tools.ietf.org/html/rfc8446#section-4.2.7).
const TLS13KEXDictionary = {}
TLS13KEXDictionary[0x17] = `ECDHE_SECP256r1`
TLS13KEXDictionary[0x18] = `ECDHE_SECP384r1`
TLS13KEXDictionary[0x19] = `ECDHE_SECP521r1`
TLS13KEXDictionary[0x1d] = `ECDHE_x25519`
TLS13KEXDictionary[0x1e] = `ECDHE_x448`
TLS13KEXDictionary[0x1f] = `ECDHE_BRAINPOOL_P256r1_TLS13`
TLS13KEXDictionary[0x20] = `ECDHE_BRAINPOOL_P384r1_TLS13`
TLS13KEXDictionary[0x21] = `ECDHE_BRAINPOOL_P512r1_TLS13`
TLS13KEXDictionary[0x100] = `FFDHE_2048`
TLS13KEXDictionary[0x101] = `FFDHE_3072`
TLS13KEXDictionary[0x102] = `FFDHE_4096`
TLS13KEXDictionary[0x103] = `FFDHE_6144`
TLS13KEXDictionary[0x104] = `FFDHE_8192`

const sigHashIANADictionary = (() => {
    const toReturn = {}
    const add = (values, name) => {
        values.forEach(value => toReturn[value] = name)
    }

    add([
        0x0201,  // rsa_pkcs1_sha1
        0x0203, // ecdsa_sha1
    ], 'SHA_1')
    add([
        0x0401, // rsa_pkcs1_sha256
        0x0403, // ecdsa_secp256r1_sha256
        0x0420, // rsa_pkcs1_sha256_legacy
        0x0704, // eccsi_sha256
        0x0804, // rsa_pss_rsae_sha256
        0x0809, // rsa_pss_pss_sha256
        0x081A, // ecdsa_brainpoolP256r1tls13_sha256
    ], 'SHA_256')
    add([
        0x0501, // rsa_pkcs1_sha384
        0x0503, // ecdsa_secp384r1_sha384
        0x0520, // rsa_pkcs1_sha384_legacy
        0x0805, // rsa_pss_rsae_sha384
        0x080A, // rsa_pss_pss_sha384
        0x081B, // ecdsa_brainpoolP384r1tls13_sha384
    ], 'SHA_384')
    add([
        0x0601, // rsa_pkcs1_sha512
        0x0603, // ecdsa_secp521r1_sha512
        0x0620, // rsa_pkcs1_sha512_legacy
        0x0806, // rsa_pss_rsae_sha512
        0x080B, // rsa_pss_pss_sha512
        0x081C, // ecdsa_brainpoolP512r1tls13_sha512
    ], 'SHA_512')
    add([
        0x0708, // sm2sig_sm3
    ], 'SM3')
    add([
        0x0709, // gostr34102012_256a
        0x070A, // gostr34102012_256b
        0x070B, // gostr34102012_256c
        0x070C, // gostr34102012_256d
        0x070D, // gostr34102012_512a
        0x070E, // gostr34102012_512b
        0x070F, // gostr34102012_512c
        // IETF "draft-smyshlyaev-tls13-gost-suites", section 4.2.
    ], 'GOST_HASH')

    return toReturn
})()

function variantCanoniser(variant) {
    if (!variant) return ''
    let canonizedVariant = variant.toLowerCase().replace(/[ .v_-]*/g, '')

    /* Some data sources, such as CNS, use "SSLv3.0"
     * as protocol version, which has an extra "0" at
     * the end compared to what Advance has in DB.
     */
    if (canonizedVariant == 'ssl30') {
        canonizedVariant = 'ssl3'
    }

    return canonizedVariant
}

function curveCanoniser(curve) {
    if (typeof curve === 'number') {
        curve = curveIANADictionary[curve]
    }
    if (!curve) return ''
    let dictionaryLookup = curveDictionary[curve]
    if (dictionaryLookup) {
        return dictionaryLookup
    }
    return curve.toLowerCase().replace(/[ ._-]*/g, '')
}

/**
 * @typedef CryptoPrimitive
 * @property {BigInt} cryptoAlgorithm
 * @property {String} friendlyName
 * @property {BigInt} id
 * @property {Boolean} isDefault
 * @property {String} name
 * @property {[String]} oid
 * @property {BigInt} purpose
 * @property {[String]} variant
 */

/**
 * @typedef CipherSuiteCryptoPrimitives
 * @property {Object<String, CryptoPrimitive>} allByName
 * @property {CryptoPrimitive[]} precise
 * @property {Object<String, CryptoPrimitive} preciseByName
 * @property {CryptoPrimitive[]} vague
 * @property {Object<String, CryptoPrimitive} vagueByName
 */

/**
 * @typedef CipherSuiteDetail
 * @property {Number} codePoint
 * @property {CipherSuiteCryptoPrimitives} cryptoPrimitives
 * @property {BigInt} id
 * @property {String} name
 * @property {BigInt} protocol
 */

/**
 * A protocol variant, such as "TLSv1.2"
 * @param {String} variant
 */
function protocolLookup(codePoint, version) {
    if (codePoint !== undefined) {
        return protocolsByCodePoint[codePoint]
    } else if (version !== undefined) {
        return protocolsByCanonicalName[variantCanoniser(version)]
    }
    return null
}

/**
 *
 * @param {Object} params
 * @param {[String]} params.name
 * @param {[Number]} params.codePoint
 * @returns {CiperSuiteDetail} Details of the given cipher suite.
 */
function cipherSuiteLookup(codePoint, name) {
    if (codePoint != undefined) {
        return cipherSuitesAndPrimitivesByCodePoint[codePoint]
    }
    if (name != undefined) {
        return cipherSuitesAndPrimitivesByCipherSuiteName[name]
    }
    return null
}

function cryptoPrimitiveLookup(algorithm, param) {
    if (algorithm === 'EC') algorithm = 'ECDSA'
    if (algorithm === 'DSA') algorithm = 'DSA_DSS'
    if (algorithm === 'DSS') algorithm = 'DSA_DSS'
    let primitiveName
    let nonRegularSize
    let isRegular = false

    if (algorithm in primitiveLookups) {
        let lookup = primitiveLookups[algorithm]
        if (lookup.useSize) {
            param = parseInt(param)

            for (let i = 0; i < lookup.length; i++) {
                if (param === lookup[i].size) {
                    isRegular = true
                    break
                }
            }

            if (!isRegular) {
                nonRegularSize = param
            }

            for (let i = 0; i < lookup.length; i++) {
                if (param < lookup[i].size) {
                    if (i === 0) {
                        primitiveName = lookup[i].name
                    } else {
                        primitiveName = lookup[i - 1].name
                    }

                    break
                }
            }

            if (!primitiveName) {
                primitiveName = lookup[lookup.length - 1].name
            }

            return {
                primitiveName: primitiveName,
                nonRegularSize: nonRegularSize
            }
        } else {
            param = curveCanoniser(param)
            if (param in lookup) {
                return {
                    primitiveName: lookup[param].name,
                    nonRegularSize: nonRegularSize
                }
            }
        }
    }

    return {
        primitiveName: algorithm,
        nonRegularSize: nonRegularSize
    }
}

function sigHashLookup(codePoint) {
    return sigHashIANADictionary[codePoint]
}

function TLS13KEXLookup(codePoint) {
    return TLS13KEXDictionary[codePoint]
}

async function loadAll() {
    if (protocolList.length === 0) {
        await loadProtocolData()
    }
    if (cipherSuiteList.length == 0) {
        await loadCipherSuiteData()
    }
    buildCryptoPrimitiveLookups()
}

async function loadProtocolData() {
    let session = new Session()

    let protocols = (await session.query(`select * from "ProtocolVariant"`)).rows
    protocols.forEach(protocol => {
        protocolsByCanonicalName[variantCanoniser(protocol.name)] = protocol
        protocolsByCodePoint[protocol.codePoint] = protocol
    })
    protocolList = protocols
}

function buildCryptoPrimitiveLookups() {
    for (let curveAlg of ['ECDSA', 'ECDH', 'ECDHE']) {
        primitiveLookups[curveAlg] = buildCryptoPrimitiveCurveLookup(curveAlg)
    }

    for (let sizeAlg of ['RSA_KE', 'RSA_SIG', 'DSA_DSS', 'FFDH', 'FFDHE']) {
        primitiveLookups[sizeAlg] = buildCryptoPrimitiveSizeLookup(sizeAlg)
    }
}

function buildCryptoPrimitiveCurveLookup(prefix) {
    let toReturn = {}
    prefix = `${prefix}_`
    for (let cryptoPrimitive of cryptoPrimitives) {
        /**
         * @type String
         */
        let name = cryptoPrimitive.name
        if (name.startsWith(prefix)) {
            let key = name.substring(prefix.length)
            key = curveCanoniser(key)
            toReturn[key] = cryptoPrimitive
        }
    }
    return toReturn
}

function buildCryptoPrimitiveSizeLookup(prefix) {
    let toReturn = []
    prefix = `${prefix}_`
    for (let cryptoPrimitive of cryptoPrimitives) {
        /**
         * @type String
         */
        let name = cryptoPrimitive.name
        if (name.startsWith(prefix)) {
            let size = 0
            if (name.substring(prefix.length) === 'toosmall') {
                // We use size 0 to signify that the key length is too small.
            } else {
                size = parseInt(name.substring(prefix.length))
            }

            toReturn.push({ size, name })
        }
    }
    toReturn.sort((a, b) => a.size < b.size)
    toReturn.useSize = true
    return toReturn
}

async function loadCipherSuiteData() {
    let session = new Session()

    let cipherSuites = (await session.query(`select cs.* from "CipherSuite" cs join "Protocol" p on (cs.protocol = p.id and p.name='TLS')`)).rows
    cipherSuites.forEach(cs => {
        cipherSuitesByDBID[cs.id] = cs
        cipherSuitesAndPrimitivesByCodePoint[cs.codePoint] = cs
        cipherSuitesAndPrimitivesByCipherSuiteName[cs.name] = cs
        cs.cryptoPrimitives = { allByName: {}, precise: [], preciseByName: {}, vague: [], vagueByName: {} }
    })
    let cryptoPrimitivesQuery = (await session.query('select * from "CryptoPrimitive"')).rows
    cryptoPrimitivesQuery.forEach(cp => {
        cryptoPrimitivesByDBID[cp.id] = cp
        cryptoPrimitives.push(cp)
    })
    let cipherSuiteCryptoPrimitives = (await session.query('select * from "CipherSuiteCryptoPrimitive"')).rows
    cipherSuiteCryptoPrimitives.forEach(cscp => {
        let cipherSuiteID = cscp.cipherSuite
        let cryptoPrimitiveID = cscp.cryptoPrimitive

        let cipherSuite = cipherSuitesByDBID[cipherSuiteID]
        let cryptoPrimitive = cryptoPrimitivesByDBID[cryptoPrimitiveID]

        cipherSuite.cryptoPrimitives.allByName[cryptoPrimitive.name] = cryptoPrimitive
        let destArray = cipherSuite.cryptoPrimitives.precise
        let destDictionary = cipherSuite.cryptoPrimitives.preciseByName

        if (cryptoPrimitive.isDefault) {
            destArray = cipherSuite.cryptoPrimitives.vague
            destDictionary = cipherSuite.cryptoPrimitives.vagueByName
        }

        if (!(cryptoPrimitive.name in destDictionary)) {
            destDictionary[cryptoPrimitive.name] = cryptoPrimitive
            destArray.push(cryptoPrimitive)
        }
    })

    cipherSuiteList = cipherSuites
}

let cipherSuiteList = []
let protocolList = []
let cryptoPrimitives = []
const primitiveLookups = {}

const cipherSuitesByDBID = {}
const cryptoPrimitivesByDBID = {}

const cipherSuitesAndPrimitivesByCodePoint = {}
const cipherSuitesAndPrimitivesByCipherSuiteName = {}

const protocolsByCanonicalName = {}
const protocolsByCodePoint = {}

exports.init = loadAll
exports.protocolLookup = protocolLookup
exports.cipherSuiteLookup = cipherSuiteLookup
exports.cryptoPrimitiveLookup = cryptoPrimitiveLookup
exports.sigHashLookup = sigHashLookup
exports.TLS13KEXLookup = TLS13KEXLookup
