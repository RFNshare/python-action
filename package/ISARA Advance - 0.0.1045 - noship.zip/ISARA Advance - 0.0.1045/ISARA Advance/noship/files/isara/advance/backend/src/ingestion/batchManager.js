/**
 * @file batchManager.js - 0.0.1045 - ea4595bfd3488684d225574ed7d4c198074d49ba
 * 
 * @copyright Copyright (C) 2016-2023, ISARA Corporation, All Rights Reserved.
 * 
 * @license The code and other content set out herein is not in the public
 * domain, is considered a trade secret and is confidential to ISARA
 * Corporation. Use, reproduction or distribution, in whole or in part, of such
 * code or other content is strictly prohibited except by express written
 * permission of ISARA Corporation. Please contact ISARA Corporation at
 * info@isara.com for more information.
 */

/**
 * This module is for managing bulk upserts into the database during data ingestions.
 * @module ingestion/batchManager
 */

const log = require('../util/log')(module)

// If we switch to stream copies then there would be no parameter limit.?
const PSQL_PARAM_LIMIT = 65535
const DEFAULT_BATCH_SIZE = 4000

class BatchManager {
    /**
     * Initializes a queue manager for batch upserting objects into the database.
     * @param {Session} session The database session to use.
     * @param {String} tableName The name of the table to upsert into.
     * @param {String[]} columns The names of columns in the database. Must include the key columns.
     * @param {String[]} keyColumns The column names to use to determine a unique row.
     * @param {Object} updateMap Dictionary of how to update rows in the database when a conflict is found.
     * @param {function} reduceFunc Function for combining two entities into one, if there is a collision.
     * @param {Number} limit The number of objects to queue before committing to the database.
     */
    constructor(session, tableName, columns, keyColumns, updateMap, reduceFunc, limit) {
        for (let candidate of [columns, keyColumns]) {
            if (!Array.isArray(candidate)) {
                throw new Error('BatchManager requires columns and keyColumns be arrays')
            }

            for (let column of candidate) {
                if (typeof column !== 'string') {
                    throw new Error('BatchManager requires columns and keyColumns be arrays of strings')
                }
            }
        }

        for (let key of keyColumns) {
            if (!columns.includes(key)) {
                throw new Error('BatchManager requires that all key columns also be listed in columns')
            }
        }

        this.session = session
        this.tableName = tableName
        this.columns = columns
        this.keyColumns = keyColumns || []
        this.updateMap = updateMap || {}
        this.reduceFunc = reduceFunc || ((a, b) => b)
        this.limit = limit || DEFAULT_BATCH_SIZE
        this.everPushed = false

        // This holds a set of aggregated rows to be batch committed to the db.
        this.batchQueue = []
        // This maps unique row identifier to the index of the row in batchQueue.
        this.batchQueueIndexMap = {}

        this.keySelector = v => this.keyColumns.reduce((k, c) => {
            // Unlikely separator between columns to reduce chance of key collisions.
            return `${k}@|${v[c]}`
        }, '')

        let safeLimit = Math.floor(PSQL_PARAM_LIMIT / columns.length)
        if (this.limit > safeLimit) {
            log.w(`Limit of ${this.limit} exceeds safe limit of ${safeLimit}. Using safe limit.`)
            this.limit = safeLimit
        }
    }

    /**
     * Not all data sources have the same columns - this helper lets you disable some after construction.
     * @param {Array.<String>} columnsToIgnore
     */
    ignoreColumns(columnsToIgnore) {
        this.columns = this.columns.filter(column => !columnsToIgnore.has(column))
    }


    /**
     * Pushes an object into the database commit queue. Commits queued objects if the queue limit is reached.
     * @param {*} object The object to enqueue.
     * @returns The number of items committed to the database; 0 if object was enqueued, null if there was no object.
     */
    push(object) {
        if (!object) {
            return null
        }
        this.everPushed = true

        let key = this.keySelector(object)
        if (!key) {
            this.batchQueue.push(object)
        } else {
            let index = this.batchQueueIndexMap[key]
            if (index === undefined) {
                this.batchQueueIndexMap[key] = this.batchQueue.length
                this.batchQueue.push(object)
            } else {
                // TODO: Why is this a replace with new third object instead of an update the existing?
                this.batchQueue[index] = this.reduceFunc(this.batchQueue[index], object)
            }
        }

        return 0
    }

    needsCommit() {
        return this.batchQueue.length >= this.limit
    }

    /**
     * Commits the object queue to the database.
     * @param {[Promise]} blocker An optional promise that controls when the commit should actually
     *                            proceed. This is used to clear all of the internal state.
     * @returns The number of items committed to the database; 0 if the queue was empty.
     */
    async commit(blocker) {
        if (this.batchQueue.length === 0) {
            return 0
        }

        let count = 0

        let fullBatch = this.batchQueue
        this.batchQueue = []
        this.batchQueueIndexMap = {}

        if (blocker) {
            log.d('Recevied blocker in commit, going to await')
            await blocker
            log.d('Have been unblocked')
        }

        let upsertClause = ''
        if (this.keyColumns.length) {
            let conflictClause = `ON CONFLICT ( ${this.keyColumns.map(c => `"${c}"`).join(', ')} ) DO`
            let updateClause = `NOTHING`
            let updateColumns = Object.keys(this.updateMap)
            if (updateColumns.length) {
                updateClause = `UPDATE SET ${updateColumns.map(c => `"${c}" = ${this.updateMap[c](`EXCLUDED."${c}"`)}`).join(', ')}`
            }
            upsertClause = `${conflictClause} ${updateClause}`
        }

        // build query...
        let columnNames = this.columns
        let insertClause = `INSERT INTO "${this.tableName}" ( ${columnNames.map(c => `"${c}"`).join(', ')} ) VALUES`
        let params = []

        while (fullBatch.length > 0) {
            let batch = fullBatch.splice(0, this.limit)

            let questionMarks = `( ${new Array(columnNames.length).fill('?').join(', ')} )` // '( ?, ?, ?, ... )'
            let query = `${insertClause} ${new Array(batch.length).fill(questionMarks).join(',')} ${upsertClause}`

            for (let row of batch) {
                if (this.tableName === 'Certificate' && !row['fingerprint']) {
                    log.e(`fingerprint is missing in the given ${JSON.stringify(row)}`)
                    continue
                }

                for (let columnName of columnNames) {
                    params.push(row[columnName])
                }
            }

            if (params.length > 0) {
                await this.session.query(query, params)
                params.length = 0
            }

            count += batch.length
        }

        return count
    }
}

exports.BatchManager = BatchManager
