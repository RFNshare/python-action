/**
 * @file scoreHelpers.js - 0.0.1045 - ea4595bfd3488684d225574ed7d4c198074d49ba
 * 
 * @copyright Copyright (C) 2016-2023, ISARA Corporation, All Rights Reserved.
 * 
 * @license The code and other content set out herein is not in the public
 * domain, is considered a trade secret and is confidential to ISARA
 * Corporation. Use, reproduction or distribution, in whole or in part, of such
 * code or other content is strictly prohibited except by express written
 * permission of ISARA Corporation. Please contact ISARA Corporation at
 * info@isara.com for more information.
 */

/**
 * This module calculates the crypto score of crypto primitives and cipher suites.
 * @module util/scoreHelpers
 */
const { Session } = require('../isaraql/session')
const log = require('../util/log')(module)
const flatFacetHelpers = require('../util/flatFacetHelpers')

async function getDefaultScoreForTemplate(session, cptId) {
    let result = await session.query('SELECT score FROM "CryptoScore" WHERE "cryptoPostureTemplate"=? AND "isDefault"',
        [cptId])

    if (result.rows.length === 0) {
        throw `Unable to find default score for CPT ${cptId}`
    }

    return result.rows[0].score
}

async function updateCryptoScoresForTemplate(session, cptId) {
    if (!session) {
        session = new Session()
    }

    await updateCryptoScoresForType(session, 'Device', cptId)
    await updateCryptoScoresForType(session, 'Connection', cptId)
    await flatFacetHelpers.rebuildAllFlatFacetTables(false)
}

/**
 * For every Connection and Device, recalculate the Crypto Score for the given CPT
 * @param {*} session
 * @param {*} typeName
 * @param {*} cptId
 */
async function updateCryptoScoresForType(session, typeName, cptId) {

    // clear out the existing scores so we can just do simple INSERTS
    await session.query(`DELETE FROM "${typeName}Score" WHERE "cryptoPostureTemplate"=?
        AND ${typeName} in (select id from "${typeName}")`, [cptId])

    let lastId = 0
    do {
        var ids = (await session.query(`SELECT id FROM "${typeName}" WHERE id > ${lastId} ORDER BY id LIMIT 10000`)).rows.map(({id}) => id)
        let promises = []
        let failures = []

        for (let i = 0; i < ids.length; i++) {
            promises.push(typeName === 'Device' ?
                updateCryptoScoreForDevice(ids[i], cptId) : updateCryptoScoreForConnection(ids[i], cptId))
            // Batch promises
            if (promises.length >= 50) {
                failures.concat((await Promise.allSettled(promises)).filter(({status}) => status === 'rejected'))
                promises = []
            }
        }
        lastId = ids[ids.length - 1]
        failures.concat((await Promise.allSettled(promises)).filter(({status}) => status === 'rejected'))
        if (ids.length > 0) {
            log.log(`Processed ${ids.length} ${typeName}s with ${failures.length} failures.`)
        }
    } while (ids.length > 0)
}

exports.updateCryptoScoresForTemplate = updateCryptoScoresForTemplate

/**
 * Updates the crypto score for a given connection ID, as well as for all associated devices.
 * @param {Int} connectionId The ID of the connection to update crypto score for.
 * @param {Session} [session] Optional Session object.
 * @returns {Int} The updated crypto score value.
 */
async function updateCryptoScoreForConnection(connectionId, cptId, session) {
    try {
        if (!session) {
            session = new Session()
        }
        let score = await calculateScoreByConnectionId(connectionId, cptId, session)

        let scoreId = await session.query('SELECT id FROM "CryptoScore" where score=? and "cryptoPostureTemplate"=?',
            [score, cptId])
        if (scoreId.rows.length !== 1) {
            throw `Unable to find ID for score ${score} of CPT ${cptId}`
        }
        scoreId = scoreId.rows[0].id

        let updateCryptoScore = async function () {
            await session.query(`INSERT INTO "ConnectionScore" (connection, "cryptoScore", "cryptoPostureTemplate") VALUES (?,?,?)
                ON CONFLICT (connection, "cryptoPostureTemplate") DO UPDATE SET "cryptoScore"=?
                `, [connectionId, scoreId, cptId, scoreId])

            // Now update the device score for each device associated with this connection
            var connectionResult = await session.query(
                `SELECT "clientDeviceAddressPort","serverDeviceAddressPort" FROM "Connection" WHERE id=$1`,
                [connectionId]
            )

            var deviceResults = null
            if (connectionResult.rows[0].clientDeviceAddressPort) {
                deviceResults = await session.query(
                    `SELECT da.device as device FROM "DeviceAddressPort" dap JOIN "DeviceAddress" da ON dap."deviceAddress" = da.id
                    WHERE dap.id IN ($1, $2)`,
                    [connectionResult.rows[0].serverDeviceAddressPort, connectionResult.rows[0].clientDeviceAddressPort]
                )
            } else {
                deviceResults = await session.query(
                    `SELECT da.device as device FROM "DeviceAddressPort" dap JOIN "DeviceAddress" da ON dap."deviceAddress" = da.id
                    WHERE dap.id = $1`,
                    [connectionResult.rows[0].serverDeviceAddressPort]
                )
            }

            // Update every device's crypto score that is related to the given connection
            for (var deviceRes of deviceResults.rows) {
                await updateCryptoScoreForDevice(deviceRes.device, cptId, session)
            }
            return score
        }

        if (session.inTransaction) {
            return await updateCryptoScore()
        }
        // If not currently in a transaction, complete in a transaction.
        return await session.asTransaction(updateCryptoScore)
    } catch (e) {
        throw `Failed to update cryptoScore for connection id=${connectionId}: ${e}`
    }
}
exports.updateCryptoScoreForConnection = updateCryptoScoreForConnection

async function updateCryptoScoresForConnection(connectionId, session) {
    if (!session) {
        session = new Session()
    }

    let cpts = await session.query('SELECT id FROM "CryptoPostureTemplate"')

    // clear out the existing score array, so the calculation functions only have to worry about adding new ones, rather than
    // attempting to find/match the existing ones against the corresponding CPT to determine which one to replace.
    await session.query('DELETE FROM "ConnectionScore" WHERE connection=?', [connectionId])
    let promises = []
    for (let cpt of cpts.rows) {
        promises.push(updateCryptoScoreForConnection(connectionId, cpt.id, session))
    }

    await Promise.all(promises)
}

exports.updateCryptoScoresForConnection = updateCryptoScoresForConnection

async function calculateScoreByDeviceId(deviceId, cptId, session) {
    try {
        // Get the score for every connection related to this device
        if (!session) {
            session = new Session()
        }

        // TODO: GAP1600 - this query needs to be a bit more sophisticated, possibly as separate queries ; scenarios can arise where the
        // returned primitives include both a generic and specific variant of the same primitive. In scenarios such as this, the
        // specific variant should take precedence.
        var minScoreResult = await session.query(
            `SELECT MIN(t1.score) as "minScore" FROM (
                SELECT cs."score" AS score FROM "DeviceAddress" da
                    JOIN "DeviceAddressPort" dap ON dap."deviceAddress" = da.id
                    JOIN "Connection" c ON (c."clientDeviceAddressPort" = dap.id OR c."serverDeviceAddressPort" = dap.id)
                    JOIN "ConnectionScore" ccs ON ccs."connection" = c.id
                    JOIN "CryptoScore" cs ON ccs."cryptoScore" = cs.id
                    WHERE cs."cryptoPostureTemplate" = ? AND da.device = ? AND c."clientDeviceAddressPort" IS NOT NULL
                    AND dap.port NOT IN(select port FROM "IgnoredPort")
                UNION SELECT cs."score" as score FROM "DeviceCertificate" dc
                    JOIN "Certificate" cert ON dc.certificate = cert.id
                    JOIN "CertificateCryptoPrimitive" ccp on cert.id = ccp.certificate
                    JOIN "CryptoPrimitive" cp on cp.id = ccp."cryptoPrimitive"
                    JOIN "CryptoPrimitiveScore" cps ON cps."cryptoPrimitive" = cp.id
                    JOIN "CryptoScore" cs ON cps."cryptoScore" = cs.id
                    WHERE dc.device = ? AND cs."cryptoPostureTemplate" = ?) t1`,
            [cptId, deviceId, deviceId, cptId]
        )
        if (!minScoreResult.rows.length || minScoreResult.rows[0].minScore === null || minScoreResult.rows[0].minScore < 0) {
            // No related connection was found

            return await getDefaultScoreForTemplate(session, cptId)
        }

        return minScoreResult.rows[0].minScore
    } catch (e) {
        throw `Unable to calculate crypto score for device ID ${deviceId}: ${e}`
    }
}

/**
 * Updates the crypto score for a given device ID.
 * @param {Int} deviceId The ID of the device to update crypto score for.
 * @param {Session} [session] Optional Session object.
 * @returns {Int} The updated crypto score value.
 */
async function updateCryptoScoreForDevice(deviceId, cptId, session) {
    try {
        if (!session) {
            session = new Session()
        }
        let score = await calculateScoreByDeviceId(deviceId, cptId, session)

        let scoreId = await session.query('SELECT id FROM "CryptoScore" WHERE score=? AND "cryptoPostureTemplate"=?',
            [score, cptId])
        if (scoreId.rows.length !== 1) {
            throw `Unable to find ID for score ${score} of template ${cptId}`
        }
        scoreId = scoreId.rows[0].id


        await session.query(`INSERT INTO "DeviceScore" (device, "cryptoScore", "cryptoPostureTemplate") VALUES (?,?,?)
        ON CONFLICT (device, "cryptoPostureTemplate") DO UPDATE SET "cryptoScore"=?
        `, [deviceId, scoreId, cptId, scoreId])

        return score
    } catch (e) {
        throw `Failed to update cryptoScore for device id=${deviceId}: ${e}`
    }
}
exports.updateCryptoScoreForDevice = updateCryptoScoreForDevice

async function updateCryptoScoresForDevice(deviceId, session) {
    if (!session) {
        session = new Session()
    }

    let cpts = await session.query('SELECT id FROM "CryptoPostureTemplate"')

    let promises = []
    for (let cpt of cpts.rows) {
        promises.push(updateCryptoScoreForDevice(deviceId, cpt.id, session))
    }

    await Promise.all(promises)
}

exports.updateCryptoScoresForDevice = updateCryptoScoresForDevice


/**
 * Calculates the crypto score for a given connection ID.
 * @param {connectionId} connectionId The ID of the connection to calculate crypto score for
 * @param {Session} [session] Optional Session object.
 * @returns {Int} The crypto score.
 */
async function calculateScoreByConnectionId(connectionId, cptId, session) {
    try {
        if (!session) {
            session = new Session()
        }

        let maxScore = (await session.query('SELECT max(score) AS score from "CryptoScore" WHERE "cryptoPostureTemplate"=?',
            [cptId])).rows[0].score

        let params = { certCrypto: [], connectionCrypto: [], defaultPrimitives: [] }
        let cipherSuiteResults = await session.query(
            `SELECT csp."cryptoPrimitive" AS id, cp."isDefault", cps.score, cp."cryptoAlgorithm"
            FROM "ConnectionCipherSuite" ccs
            JOIN "CipherSuite" cs ON ccs."cipherSuite" = cs.id
            JOIN "CipherSuiteCryptoPrimitive" csp ON cs."id"= csp."cipherSuite"
            JOIN "CryptoPrimitive" cp on csp."cryptoPrimitive"=cp.id
            JOIN "CryptoPrimitiveScore" cpsc ON cpsc."cryptoPrimitive"=cp.id
            JOIN "CryptoScore" cps ON cpsc."cryptoScore" = cps.id
            WHERE ccs.connection = ? AND cps."cryptoPostureTemplate"=?`, [connectionId, cptId])

        let protocolResults = await session.query(
            `SELECT cs.score FROM "ConnectionProtocolVariant" cpv
            JOIN "ProtocolVariantScore" pvs on pvs."protocolVariant" = cpv."protocolVariant"
            JOIN "CryptoScore" cs ON pvs."cryptoScore" = cs.id
            WHERE cpv.connection = ? AND cs."cryptoPostureTemplate"=?`, [connectionId, cptId])

        let certificateCryptoResults = await session.query(
            `SELECT ccp."cryptoPrimitive" as id, cp."cryptoAlgorithm", cs.score, cp."isDefault"
            FROM "ConnectionCertificate" cc
            JOIN "Certificate" ce ON  cc."certificate" = ce.id
            JOIN "CertificateCryptoPrimitive" ccp  ON  ce.id = ccp."certificate"
            JOIN "CryptoPrimitive" cp ON ccp."cryptoPrimitive" = cp.id
            JOIN "CryptoPrimitiveScore" cps ON cps."cryptoPrimitive" = cp.id
            JOIN "CryptoScore" cs ON cps."cryptoScore" = cs.id
            where cc.connection = ? AND cs."cryptoPostureTemplate"=?`, [connectionId, cptId])


        for (let row of certificateCryptoResults.rows) {
            params.certCrypto.push({
                id: row.id,
                cryptoAlgorithm: row.cryptoAlgorithm,
                score: row.score,
                isDefault: row.isDefault
            })
        }

        let connectionCryptoResults = await session.query(
            `SELECT ccp."cryptoPrimitive" as id,cp."cryptoAlgorithm", cs.score,cp."isDefault"
            FROM "ConnectionCryptoPrimitive" ccp
            JOIN "CryptoPrimitive" cp ON ccp."cryptoPrimitive" = cp.id
            JOIN "CryptoPrimitiveScore" cps ON cps."cryptoPrimitive" = cp.id
            JOIN "CryptoScore" cs ON cps."cryptoScore" = cs.id WHERE ccp.connection = ? AND cs."cryptoPostureTemplate"=?`,
            [connectionId, cptId])

        params.defaultPrimitives = (await session.query(
            `SELECT cpd.id, cpd."cryptoPrimitive", cpd."defaultPrimitive", cs.score from "CryptoPrimitive" cp
                JOIN "CryptoPrimitiveScore" cps ON cps."cryptoPrimitive" = cp.id
                JOIN "CryptoScore" cs on cs.id = cps."cryptoScore"
                JOIN "CryptoPrimitiveDefault" cpd on cp.id = cpd."defaultPrimitive"
                WHERE cpd."cryptoPrimitive" != cpd."defaultPrimitive"`)).rows



        for (let row of connectionCryptoResults.rows) {
            params.connectionCrypto.push({
                id: row.id,
                cryptoAlgorithm: row.cryptoAlgorithm,
                score: row.score,
                isDefault: row.isDefault
            })
        }

        let protocolScores = []
        for (let row of protocolResults.rows) {
            protocolScores.push(row.score)
        }

        let minScore = maxScore
        let allScores = [...protocolScores]
        if (cipherSuiteResults.rows.length) {
            for (let row of cipherSuiteResults.rows) {
                params.connectionCrypto.push({
                    id: row.id,
                    cryptoAlgorithm: row.cryptoAlgorithm,
                    score: row.score,
                    isDefault: row.isDefault
                })

                let resScore = await calculateCipherSuiteCryptoScore(params)

                allScores.push(resScore)
            }
            minScore = Math.min(minScore, ...allScores)
            return minScore
        } else if (protocolScores.length || connectionCryptoResults.rows.length || certificateCryptoResults.rows.length) {

            let resScore = await calculateCipherSuiteCryptoScore(params)
            allScores.push(resScore)
            minScore = Math.min(minScore, ...allScores)
            return minScore
        } else {
            minScore = await getDefaultScoreForTemplate(session, cptId)
            return minScore
        }

    } catch (e) {
        throw `Unable to get CipherSuite crypto score for connection: ${e}`
    }
}
exports.calculateScoreByConnectionId = calculateScoreByConnectionId


function calculateCipherSuiteCryptoScore(params) {

    function collectScore(scoreLists, cryptoPrimitivelist) {
        let primitiveList = []
        let unknownList = []
        let defaultValues = []
        for (let primitive of cryptoPrimitivelist) {
            if (!primitive.isDefault) {
                primitiveList.push(primitive.cryptoAlgorithm)
                scoreLists.push(primitive.score)
            } else {
                unknownList.push(primitive.cryptoAlgorithm)
                defaultValues.push(primitive)
            }
        }
        for (let defValue of defaultValues) {
            const matchedDefault = params.defaultPrimitives.find(dp => dp.cryptoPrimitive === defValue.id)

            if (!primitiveList.includes(defValue.cryptoAlgorithm)) {
                if(matchedDefault != undefined){
                    if(defValue.id === matchedDefault.cryptoPrimitive) {
                        const defaultPrimitiveScore = matchedDefault.score
                        scoreLists.push(defaultPrimitiveScore)
                    }
                } else {
                    scoreLists.push(defValue.score)
                }
            }

        }
    }

    try {
        let cryptoPrimitivelist = []
        for (let primitive of params.connectionCrypto) {
            cryptoPrimitivelist.push(primitive)
        }
        for (let primitive of params.certCrypto) {
            cryptoPrimitivelist.push(primitive)
        }

        let Score = []
        collectScore(Score, cryptoPrimitivelist)

        return Math.min(...Score)
    } catch (e) {
        throw `Unable to calculate crypto score: ${e}`
    }
}

/*
// For debugging/testing
if (argv._.length) {
    for (let j=0; j < argv._.length; j++) {
        calculateScoreByConnectionId(parseInt(argv._[j])).then(function(score) {
            console.log(`Score: ${score}`)
        }).catch(function(e) {
            console.error(e)
        })
        // let cipherSuiteInfo = parseCipherSuite(argv._[j])
        // console.log(JSON.stringify(cipherSuiteInfo, null, 2))
        // calculateCipherSuiteCryptoScore(cipherSuiteInfo).then(score => {
        //     console.log(`Score: ${score}`)
        // })
    }
}
*/
