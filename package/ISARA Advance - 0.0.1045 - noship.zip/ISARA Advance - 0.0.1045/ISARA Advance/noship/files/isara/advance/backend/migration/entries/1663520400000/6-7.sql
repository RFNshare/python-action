--
-- @file 6-7.sql - 0.0.1045 - ea4595bfd3488684d225574ed7d4c198074d49ba
-- 
-- @copyright Copyright (C) 2016-2023, ISARA Corporation, All Rights Reserved.
-- 
-- @license The code and other content set out herein is not in the public
-- domain, is considered a trade secret and is confidential to ISARA
-- Corporation. Use, reproduction or distribution, in whole or in part, of such
-- code or other content is strictly prohibited except by express written
-- permission of ISARA Corporation. Please contact ISARA Corporation at
-- info@isara.com for more information.
--

    /* 
    * 
    *    SCHEMA - FORWARDS 
    *    MIGRATION 6 TO 7 
    *    >FOR RELEASE 0.86.0
    *    ORIGIN GIT HASH:3df549aa2b52c72bd39c5889c25bc626090b2742
    * 
    *    CREATED ON 2022-09-18T17:00:00.000Z
    * 
    */




ALTER TABLE "advance"."SearchIndexExport" ADD COLUMN IF NOT EXISTS "completedAt" timestamp with time zone NULL;

ALTER TABLE "advance"."SearchIndexExport" ADD COLUMN IF NOT EXISTS "duration" integer NOT NULL DEFAULT 0;

COMMENT ON COLUMN "advance"."SearchIndexExport"."completedAt" IS 'The elapsed time of the search export';
COMMENT ON COLUMN "advance"."SearchIndexExport"."duration" IS 'Units: milliseconds';

COMMENT ON TABLE "advance"."DataSourceScanResult" IS NULL;


ALTER TABLE "advance"."CryptoPostureReport" ADD COLUMN IF NOT EXISTS "repeat" bigint NULL;

COMMENT ON COLUMN "advance"."CryptoPostureReport"."name" IS 'The schedule repeat like daily, weekly, monthly.';

COMMENT ON COLUMN "advance"."CryptoPostureReport"."name" IS NULL;
COMMENT ON COLUMN "advance"."CryptoPostureReport"."addedAt" IS NULL;

COMMENT ON COLUMN "advance"."CryptoPostureReport"."lastModified" IS NULL;

COMMENT ON COLUMN "advance"."ReportSnapshot"."snapshot" IS 'Stores the snapshot in base64 format';
COMMENT ON COLUMN "advance"."ReportSnapshot"."addedAt" IS 'Records the date this snapshot was initially added.
@graphQL.readOnly';
COMMENT ON COLUMN "advance"."ReportSnapshot"."lastModified" IS 'The time the snapshot was last modified.
@graphQL.readOnly';
CREATE TABLE IF NOT EXISTS "advance"."ReportSchedule" (
    "id" bigserial PRIMARY KEY,
    "metadata" varchar NULL,
    "currentRefinement" varchar NULL,
    "addedAt" timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "lastModified" timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "cryptoPostureReport" BIGINT NULL REFERENCES "advance"."CryptoPostureReport"
);
ALTER TABLE "advance"."ReportSchedule" OWNER TO "postgres";
COMMENT ON TABLE "advance"."ReportSchedule" IS 'Stores scheduled reports. ';
COMMENT ON COLUMN "advance"."ReportSchedule"."id" IS 'The primary key.';
COMMENT ON COLUMN "advance"."ReportSchedule"."metadata" IS 'Stores the typesense response';
COMMENT ON COLUMN "advance"."ReportSchedule"."currentRefinement" IS 'Stores current refinement';
COMMENT ON COLUMN "advance"."ReportSchedule"."addedAt" IS 'Records the date this schedule was initially added.
@graphQL.readOnly';
COMMENT ON COLUMN "advance"."ReportSchedule"."lastModified" IS 'The time the schedule was last modified.'

