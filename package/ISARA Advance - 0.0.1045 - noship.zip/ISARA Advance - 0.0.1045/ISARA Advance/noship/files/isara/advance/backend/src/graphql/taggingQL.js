/**
 * @file taggingQL.js - 0.0.1045 - ea4595bfd3488684d225574ed7d4c198074d49ba
 * 
 * @copyright Copyright (C) 2016-2023, ISARA Corporation, All Rights Reserved.
 * 
 * @license The code and other content set out herein is not in the public
 * domain, is considered a trade secret and is confidential to ISARA
 * Corporation. Use, reproduction or distribution, in whole or in part, of such
 * code or other content is strictly prohibited except by express written
 * permission of ISARA Corporation. Please contact ISARA Corporation at
 * info@isara.com for more information.
 */

/**
 * This module contains queries relating to Tagging.
 * @module graphql/taggingQL
 */

var {
    AUTHENTICATED
} = require('./commonQL').roles

const {
    Session
} = require('../isaraql/session')

var {
    fetchForColumns, insertRecord, updateRecord, deleteRecordsWPCS, fetchWanted
} = require('../isaraql/fetch')

var {
    allTypes, FK_INBOUND
} = require('../isaraql/schemaDiscovery')

const {registerHook, CUD_OP_INSERT, CUD_OP_PRE } = require('../isaraql/cud')

var {
    buildTableWhereEquals, buildAnd, buildIn, buildEquals, buildTableWhere
} = require('../isaraql/whereUtil')

const { graphQLStateToWanted } = require('../isaraql/wantedUtil')

const CUSTOM = 'CUSTOM'

/**
 * This is a mapping of which column, in which table would have the ID set in `tagThings`
 */
var attributesToTagTables = [
    { table: 'DeviceTag', idField: 'device', sourceArray: 'devices' },
    { table: 'SoftwareVersionTag', idField: 'softwareVersion', sourceArray: 'softwareVersions' },
    { table: 'ConnectionTag', idField: 'connection', sourceArray: 'connections' }
]

/**
 * Add tags to the given devices.
 * @param {string} tagTypeAsString The existing tag type.
 * @param {string} tagValue The value on the tag. eg: Skylake
 * @param {Object} whatToTag
 * @param {number[]} [whatToTag.devices] Array of IDs of Devices to tag.
 * @param {number[]} [whatToTag.connections] Array of IDs of Connections to tag.
 * @param {number[]} [whatToTag.softwareVersions] Array of IDs of Software to tag.
 * @param {Session} [session] Database session.
 */
async function tagThings(tagTypeAsString, tagValue, whatToTag, session) {
    if (!tagTypeAsString) {
        throw 'Missing tag type'
    }
    if (!tagValue) {
        throw 'Missing tag value'
    }
    if (!whatToTag || (!whatToTag.devices && !whatToTag.connections && !whatToTag.softwareVersions)) {
        throw 'Missing whatToTag'
    }

    // If nothing to tag then this function is just a noop
    if (!(whatToTag.devices && whatToTag.devices.length) && !(whatToTag.connections && whatToTag.connections.length)
        && !(whatToTag.softwareVersions && whatToTag.softwareVersions.length)) {
        return 0
    }

    var tagType = allTypes['TagType']._enum.idByName[tagTypeAsString]
    if (!tagType) {
        throw `Unknown tag type ${tagTypeAsString}`
    }

    async function addTags(session) {
        function parseNumericWithUnits(value) {
            function updateMetricUnit(value, numeric) {
                const metricUnitPrefixValues = {
                    p: 0.000000000001,
                    n: 0.000000001,
                    u: 0.000001,
                    m: 0.001,
                    k: 1000,
                    K: 1000,
                    M: 1000000,
                    G: 1000000000,
                    T: 1000000000000,
                }
                let unitStr = value.match(/[A-Za-z]+/)
                if (unitStr && unitStr[0].charAt(0) in metricUnitPrefixValues) {
                    let unitValue = metricUnitPrefixValues[unitStr[0].charAt(0)]
                    numeric = unitValue * numeric
                }
                return numeric
            }
            if (/^[-+]?[0-9]+\s*[A-Za-z]*$/.test(value)) {
                let numeric = parseInt(value)
                return updateMetricUnit(value, numeric)
            } else if (/^[-+]?[0-9]*\.[0-9]+\s*[A-Za-z]*$/.test(value)) {
                let numeric = parseFloat(value)
                return updateMetricUnit(value, numeric)
            } else {
                return NaN
            }
        }

        var isNumeric = allTypes['TagType']._enum.detailsByID[tagType].isNumeric
        if (isNumeric) {
            // Make sure input value is a numeric value.
            tagValue = tagValue.trim()
            let tagNumericValue = parseNumericWithUnits(tagValue)
            if (isNaN(tagNumericValue)) {
                throw `Numeric tag type did not receive a valid numeric value`
            }
            tagValue = `${tagNumericValue}`
        }

        var newTag = { tagType, value: tagValue }
        session.ignore = true

        let currentTags = await fetchForColumns('Tag', ['id'], buildTableWhereEquals('Tag', newTag), session)

        if (currentTags.length) {
            newTag.id = currentTags[0].id
        } else {
            newTag.lastUsed = new Date()
            let result = await insertRecord('Tag', newTag, session)
            newTag.id = result.id
        }

        var totalUpdates = 0

        for (var which of attributesToTagTables) {
            if (whatToTag[which.sourceArray]) {
                var newTags = whatToTag[which.sourceArray].map(value => ({ tag: newTag.id, [which.idField]: value }))
                let result = await insertRecord(which.table, newTags, session)
                totalUpdates += result.affectedRows
            }
        }

        if (totalUpdates > 0) {
            await updateRecord('Tag', { id: newTag.id }, { lastUsed: new Date() }, session)
        }

        return totalUpdates
    }

    if (session) {
        return await addTags(session)
    } else {
        session = new Session()
        return await session.asTransaction(addTags)
    }

}
exports.tagThings = tagThings

/**
 * Untag the given things from the given tag.
 * @param {number} tagId The existing tag id
 * @param {Object} whatToUntag
 * @param {number[]} [whatToUntag.devices] Array of IDs of Devices to untag.
 * @param {number[]} [whatToUntag.connections] Array of IDs of Connections to untag.
 * @param {number[]} [whatToUntag.softwareVersions] Array of IDs of Software to untag.
 * @param {Session} [session] database session
 */
async function untagThings(tagId, whatToUntag, session) {
    if (tagId === undefined) {
        throw 'Missing tagId'
    }
    if (!whatToUntag || (!whatToUntag.devices && !whatToUntag.connection && !whatToUntag.softwareVersions)) {
        throw 'Missing what to untag'
    }

    // If nothing to untag then this function is just a noop
    if (!(whatToUntag.devices && whatToUntag.devices.length) && !(whatToUntag.connections && whatToUntag.connections.length)
        && !(whatToUntag.softwareVersions && whatToUntag.softwareVersions.length)) {
        return 0
    }

    async function removeTags(session) {
        var totalDeleted = 0
        for (var mapping of attributesToTagTables) {
            if (whatToUntag[mapping.sourceArray]) {
                var inPart = buildIn(mapping.idField, whatToUntag[mapping.sourceArray])
                var tagPart = buildEquals({ tag: tagId })

                var wpcs = buildTableWhere(mapping.table, buildAnd(inPart, tagPart))

                totalDeleted += await deleteRecordsWPCS(mapping.table, wpcs, session)
            }
        }

        return totalDeleted
    }

    if (session) {
        return await removeTags(session)
    } else {
        session = new Session()
        return await session.asTransaction(removeTags)
    }
}
exports.untagThings = untagThings

function generateTagCountQuery() {
    let meta = allTypes['Tag']._meta
    let queries = []
    for (let key of Object.keys(meta)) {
        let relation = meta[key]
        if (relation.dir == FK_INBOUND) {
            queries.push(`SELECT "${relation.column}" AS id FROM "${relation.table}"`)
        }
    }

    return `${queries.join(' UNION ALL ')}`
}

function initialise() {
    // Set lastUsed for CUD operations
    registerHook('Tag', CUD_OP_INSERT, CUD_OP_PRE, writeTag)
}

async function writeTag(params) {
    params.record.lastUsed = new Date()
}

async function getTagsQL(fields, request, graphQLState) {
    let session = new Session()
    let query = ''
    let orderByClause = ''
    let whereClause = ` "tagType" = ? `
    let tagTypeMeta = allTypes['TagType']._enum
    let params = [tagTypeMeta.idByName['CUSTOM']]
    if (fields.sort && fields.sort === 'MOST_USED') {
        query = `SELECT "Tag".*, count(*) AS count FROM "Tag" JOIN (${generateTagCountQuery()}) t1 USING (id) `
        orderByClause = ' GROUP BY id,value,"tagType","lastUsed" ORDER BY count'
    }
    else if (fields.sort && fields.sort === 'ALPHABETICAL') {
        query = 'SELECT * FROM "Tag"'
        orderByClause = 'ORDER BY "value"'
    }
    else { // MOST_RECENT
        query = 'SELECT * FROM "Tag"'
        orderByClause = ' ORDER BY "lastUsed"'
    }

    if (fields.filter) {
        whereClause += ` AND value ILIKE '%' || ? || '%' `
        params.push(fields.filter)
    }
    if (fields.sort && fields.sort === 'ALPHABETICAL')
        query += ` WHERE ${whereClause}${orderByClause}, value`
    else
        query += ` WHERE ${whereClause}${orderByClause} DESC, value`
    return session.reuseConnection(async () => {
        if (fields.asOf) {
            await session.configureHistory(null, new Date(fields.asOf))
        }

        const sortedTags = (await session.query(query, params)).rows
        // If no tags were found we can just return empty
        if (sortedTags.length === 0) {
            return []
        }

        const wanted = graphQLStateToWanted(graphQLState).getTags
        let goDeep = false
        for (let key in wanted) {
            if (typeof wanted[key] === 'object') {
                goDeep = true
                break
            }
        }

        if (goDeep) {
            const value = sortedTags.map(tag => tag.id)
            const wpcs = {
                'Tag': { 'where': { in: { column: 'id', value } } }
            }

            const withGraph = await fetchWanted('Tag', wanted, wpcs, session)
            const withGraphByID = {}
            withGraph.forEach(item => withGraphByID[item.id] = item)
            for (let i = 0; i < sortedTags.length; ++i) {
                sortedTags[i] = withGraphByID[sortedTags[i].id]
            }
        } else {
            for (let row of sortedTags) {
                row['tagType'] = tagTypeMeta.nameByID[row['tagType']]
            }
        }
        return sortedTags
    })
}

/**
 * Add a tag to some things.
 * @param {object} fields
 * @param {string} fields.type The type of the tag. eg: CUSTOM, CPUFAMILY
 * @param {string} fields.value The value for the tag. eg: 'this is my favourite tag'
 * @param {number[]} [fields.connections] Optional array of connection IDs to tag.
 * @param {number[]} [fields.devices] Optional array of device IDs to tag.
 * @param {number[]} [fields.softwareVersions] Optional array of software IDs to tag.
 * @param {object} request GraphQL request
 * @param {object} response GraphQL state
 */
async function tagThingsQL(fields/*, request, response*/) {
    return await tagThings(fields.type, fields.value, { devices: fields.devices, connections: fields.connections, softwareVersions: fields.softwareVersions })
}

/**
 * Remove a tag from some things.
 * @param {object} fields
 * @param {number} fields.tag The id of the existing tag.
 * @param {number[]} [fields.connections] Optional array of connection IDs to tag.
 * @param {number[]} [fields.devices] Optional array of device IDs to tag.
 * @param {number[]} [fields.softwareVersions] Optional array of software IDs to tag.
 * @param {object} request GraphQL request
 * @param {object} response GraphQL state
 */
async function untagThingsQL(fields/*, request, response*/) {
    return await untagThings(fields.tag, { devices: fields.devices, connections: fields.connections, softwareVersions: fields.softwareVersions })
}

exports.commonTagTypes = { custom: CUSTOM }

exports.graphQL = {
    types: `
enum TagSort {
    MOST_RECENT
    MOST_USED
    ALPHABETICAL
}
`,
    queries: `
getTags(filter: String, sort: TagSort, asOf: DateTime): [Tag!]!
    `,
    mutations: `
        """
            Add a tag to devices, connections and softwareVersions at the same time.

            Returns the number of things newly tagged. (ie: second run should return 0)
        """
        tagThings(
            """
                The tag value.
            """
            value: String!
            """
                The tag type.
            """
            type: TagType!
            """
                Optional array of device IDs to tag.
            """
            devices:[BigInt!]
            """
                Optional array of connection IDs to tag.
            """
            connections:[BigInt!]
            """
                Optional array of software versions to tag.
            """
            softwareVersions:[BigInt!]
        ) : Int!

        """
            Remove tags from things.

            Returns the number of things newly untagged. (ie: second run should return 0)
        """
        untagThings(
            """
                The ID of the tag to remove.
            """
            tag: BigInt!
            """
                Optional array of devices to untag.
            """
            devices:[BigInt!]
            """
                Optional array of connections to untag.
            """
            connections:[BigInt!]
            """
                Optional array of software versions to untag.
            """
            softwareVersions:[BigInt!]
        ) : Int!
    `,
    root: {
        getTags: getTagsQL,
        tagThings: tagThingsQL,
        untagThings: untagThingsQL
    },
    restrictions: {
        getTags: AUTHENTICATED,
        tagThings: AUTHENTICATED,
        untagThings: AUTHENTICATED
    },
    initialise
}
