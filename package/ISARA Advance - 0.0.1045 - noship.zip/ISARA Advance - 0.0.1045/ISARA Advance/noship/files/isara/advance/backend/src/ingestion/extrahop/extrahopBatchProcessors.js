/**
 * @file extrahopBatchProcessors.js - 0.0.1045 - ea4595bfd3488684d225574ed7d4c198074d49ba
 * 
 * @copyright Copyright (C) 2016-2023, ISARA Corporation, All Rights Reserved.
 * 
 * @license The code and other content set out herein is not in the public
 * domain, is considered a trade secret and is confidential to ISARA
 * Corporation. Use, reproduction or distribution, in whole or in part, of such
 * code or other content is strictly prohibited except by express written
 * permission of ISARA Corporation. Please contact ISARA Corporation at
 * info@isara.com for more information.
 */

const { CommonUpserters } = require('../commonUpserters')
const { protocolLookup, cipherSuiteLookup, cryptoPrimitiveLookup, sigHashLookup, TLS13KEXLookup } = require('../cryptoDataCache')
const log = require('../../util/log')(module)
log.debug = true

const { FIFOQueue } = require('../../util/fifoQueue')
const { inspectIPAddress } = require('../commonIngestion')
const { NetmaskMatchModes } = require('../netmaskMatching')

const ISARA_TLS_MAIN = ['isara_tls_main', 'isara_tls_main_combined'] // temporaily allow both
const ISARA_TLS_PARAMS_TCP = ['isara_tls_params_tcp', 'isara_tls_params_tcp_combined']
const TODO_XXX = 'SHOULD NOT BE SEEN' // TODO: decision on columns using this

/**
 * This is the number of subsequent records to wait before processing without the pair.
 */
const UNPAIRED_RECORD_WAIT_COUNT = 350

function secondTimestampToISODate(timestampSeconds) {
    if (!timestampSeconds) {
        throw new Error('Timestamp missing')
    }
    var date = new Date()
    date.setTime(timestampSeconds * 1000) // seconds to milliseconds
    return date.toISOString()
}

function alternateNamesToText(names) {
    if (!names) {
        return ''
    }
    if (Array.isArray(names)) {
        names.sort()
        return names.join(', ')
    }
    return names
}

class ExtraHopBatchProcessor extends CommonUpserters {
    #waitingConnectionFlows = {}
    #connectionFlowQueue = new FIFOQueue()

    /**
     * @param {Session} session
     * @param {Object} preferences
     */
    constructor(session, preferences) {
        super(session, preferences)
        this.certificateUpserter.ignoreColumns(new Set([
            'certificateContent',
            'issuerCertificate',
            'internalIssuer',
        ]))
    }

    processConnections(result, acceptAll = false) {
        let anyErrors = []
        let processed = 0
        if (result?.records) {
            for (let record of result.records) {
                let source = record._source
                let type = source.isaraRecordType ?? record._type
                if (!acceptAll && ![...ISARA_TLS_MAIN, ...ISARA_TLS_PARAMS_TCP].includes(type)) {
                    log.log(`unexpected record type ${type}`)
                }
                if (ISARA_TLS_MAIN.includes(type)) {
                    source._hasMain = true
                } else if (ISARA_TLS_PARAMS_TCP.includes(type)) {
                    source._hasParamsTCP = true
                }
                let flowID = source.isaraFlowID
                if (flowID in this.#waitingConnectionFlows) {
                    Object.assign(this.#waitingConnectionFlows[flowID], source)
                } else {
                    this.#waitingConnectionFlows[flowID] = source
                    this.#connectionFlowQueue.enqueue(flowID)
                }
            }
        }

        let unpairedWaitCount = result ? UNPAIRED_RECORD_WAIT_COUNT : 0
        while (this.#connectionFlowQueue.length > unpairedWaitCount) {
            let flowID = this.#connectionFlowQueue.dequeue()
            if (flowID) {
                let record = this.#waitingConnectionFlows[flowID]
                if (record) {
                    delete this.#waitingConnectionFlows[flowID]

                    try {
                        this.#processConnection(record)
                    } catch (error) {
                        anyErrors.push(error)
                    }
                    processed += 1
                }
            }
        }

        if (anyErrors.length > 0) {
            log.e('There were', anyErrors.length, 'thrown during processing first was', anyErrors[0])
            throw anyErrors[0]
        }

        return processed
    }

    #processConnection(record) {
        if (record._hasMain !== true) {
            // Silently ignore records where no main was received.
            return
        }

        const observedAt = new Date().toISOString()

        const clientAddress = inspectIPAddress((record.isaraClientIPAddress ?? record.clientAddr).value, NetmaskMatchModes.CLIENT)
        const serverAddress = inspectIPAddress((record.isaraServerIPAddress ?? record.serverAddr).value, NetmaskMatchModes.SERVER)

        const clientDevice = {
            ipAddress: clientAddress.address,
            ipVersion: clientAddress.version,
            observedAt
        }

        const serverDevice = {
            ipAddress: serverAddress.address,
            ipVersion: serverAddress.version,
            observedAt
        }

        this.deviceUpserter.push(clientDevice)
        this.deviceUpserter.push(serverDevice)

        const connectionID = {
            serverAddress: serverDevice.ipAddress,
            clientAddress: clientDevice.ipAddress,
            port: (record.isaraServerPortNumber ?? record.serverPort),
            l4Protocol: 'TCP',
            observedAt,
        }

        const connection = {
            ...connectionID,
            friendlyName: TODO_XXX,
            connectionCount: 1,
        }

        this.connectionUpserter.push(connection)

        let protocol
        if (record.isaraTLSVersionCodePoint) {
            protocol = protocolLookup(record.isaraTLSVersionCodePoint)
        } else if (record.isaraTLSVersion) {
            protocol = protocolLookup(undefined, record.isaraTLSVersion)
        }

        if (protocol) {
            const connectionProtocolVariant = {
                ...connectionID,
                protocolVariant: protocol.name
            }

            this.protocolVariantUpserter.push(connectionProtocolVariant)
        }

        let cipherSuite
        if (record.isaraCipherSuiteCodePoint != undefined) {
            cipherSuite = cipherSuiteLookup(record.isaraCipherSuiteCodePoint)
        } else if (record.isaraCipherSuite != undefined) {
            cipherSuite = cipherSuiteLookup(undefined, record.isaraCipherSuite)
        }

        let certificates = this.#processCertificates(record, connectionID)

        if (cipherSuite) {
            const connectionCipherSuite = {
                ...connectionID,
                cipherSuite: cipherSuite.name
            }

            this.cipherSuiteUpserter.push(connectionCipherSuite)
            this.#processCryptoPrimitives(record, cipherSuite, connectionID, certificates)
        }

        for (let certificatePurpose in certificates) { // client or server
            let certificate = certificates[certificatePurpose]
            if (!certificate['fingerprint']) {
                log.e(`fingerprint is missing for the given certificate ${JSON.stringify(certificate)}`)
                continue
            }
            this.certificateUpserter.push(certificate)
            this.deviceCertificateUpserter.push(certificate)
        }
    }

    #processCertificates(record, connectionID) {
        let toReturn = {}

        for (let server of [true, false]) {
            const prefix = `${server ? 'isaraServer' : 'isaraClient'}Cert`
            const destination = server ? 'server' : 'client'

            if (record[`${prefix}CreationDate`]) {
                const certificate = {
                    ...connectionID,
                    certificateType: 'X509',
                    manuallyAdded: false,
                    fingerprint: record[`${prefix}Fingerprint`],
                    notAfter: secondTimestampToISODate(record[`${prefix}ExpirationDate`]),
                    notBefore: secondTimestampToISODate(record[`${prefix}CreationDate`]),
                    issuer: record[`${prefix}IssuerCN`],
                    subject: record[`${prefix}SubjectCN`],
                    alternateNames: alternateNamesToText(record[`${prefix}SubjectAN`]),
                    serial: record[`${prefix}SerialNumber`],
                    publicKeyCryptoPrimitive: '',
                    publicKeyCryptoPrimitiveParameter: '',
                    issuerSigAndHash: record[`${prefix}SignatureAlgorithm`],
                }

                if (server) {
                    // Client address only used for client certificates
                    delete certificate.clientAddress
                }

                toReturn[destination] = certificate
            }
        }
        return toReturn
    }

    /**
     *
     * @param {*} record
     * @param {import("../cryptoDataCache").ExtraHopCiperSuiteDetail} cipherSuite
     * @param {*} connectionID
     * @returns
     */
    #processCryptoPrimitives(record, cipherSuite, connectionID, certificates) {
        if (!record || !cipherSuite || !connectionID) {
            return
        }

        let cryptoPrimitivesToAdd = new Set()

        for (let precise of cipherSuite.cryptoPrimitives.precise) {
            cryptoPrimitivesToAdd.add([precise.name, null])
        }

        var handledVague = new Set()

        this.#processCertificateCrypto(true, record, cipherSuite, handledVague, cryptoPrimitivesToAdd, certificates?.server)
        this.#processCertificateCrypto(false, record, cipherSuite, handledVague, cryptoPrimitivesToAdd, certificates?.client)

        this.#processAuthSigScheme(record, handledVague, cryptoPrimitivesToAdd)

        this.#processKEX(record, cipherSuite, handledVague, cryptoPrimitivesToAdd)


        cipherSuite.cryptoPrimitives.vague.forEach(vague => {
            let name = vague.name

            // When processing DSA certificates, we map DSA or DSS to
            // DSA_DSS if size info is available, as this is how parameterized
            // DSA primitives are defined in CryptoPrimitive table.
            if (name === 'DSA' || name === 'DSS') {
                name = 'DSA_DSS'
            }

            if (!handledVague.has(name)) {
                if (name === 'DSA_DSS') {
                // If we haven't handled "vague" DSA, add "DSA" instead of
                // "DSA_DSS" to ConnectionCryptoPrimitive, otherwise, we
                // won't be able to properly calculate the score.
                // Perhaps a better way of handling this is GAP2650.
                    cryptoPrimitivesToAdd.add(['DSA', null])
                } else {
                    cryptoPrimitivesToAdd.add([name, null])
                }
            }
        })

        this.#processLowerVersionTLSAuthHash(record, cryptoPrimitivesToAdd)

        let primitiveArr = Array.from(cryptoPrimitivesToAdd)
        for (let primitive of primitiveArr) {
            if (primitive[0]) {
                const connectionCryptoPrimitive = {
                    ...connectionID,
                    cryptoPrimitive: primitive[0],
                    cryptoPrimitiveParameter: primitive[1],
                }
                this.cryptoUpserter.push(connectionCryptoPrimitive)
            }
        }
    }

    #processLowerVersionTLSAuthHash(record, toAdd) {
        if (record.isaraTLSVersionCodePoint == '768' ||  // SSL 3.0 code point
            record.isaraTLSVersionCodePoint == '769' ||  // TLS 1.0 code point
            record.isaraTLSVersionCodePoint == '770') {  // TLS 1.1 code point
            if (record.isaraServerCertPublicKeyType === 'RSA' || record.isaraClientCertPublicKeyType === 'RSA') {
                toAdd.add(['MD5', null])
            }
        }
    }

    #processAuthSigScheme(record, handledVague, toAdd) {
        if (record.isaraServerAuthSigSchemeCodePoint) {
            toAdd.add([sigHashLookup(record.isaraServerAuthSigSchemeCodePoint), null])
        }
        if (record.isaraClientAuthSigSchemeCodePoint) {
            toAdd.add([sigHashLookup(record.isaraClientAuthSigSchemeCodePoint), null])
        }
    }

    #processKEX(record, cipherSuite, handledVague, toAdd) {
        if (record.isaraTLSKEXParameter) {
            let algorithm = record.isaraKEXAlgorithm
            let param = record.isaraTLSKEXParameter
            let ephemeral = cipherSuite.name.includes('DHE_')
            if (ephemeral && algorithm[algorithm.length] != 'E') {
                algorithm = `${algorithm}E`
            }
            let mapped = cryptoPrimitiveLookup(algorithm, param)
            if (mapped.primitiveName) {
                handledVague.add(algorithm)
                toAdd.add([mapped.primitiveName, mapped.nonRegularSize])
            }
        } else if (record.isaraTLS13KEXNamedGroupCodePoint) {
            let namedGroup = TLS13KEXLookup(parseInt(record.isaraTLS13KEXNamedGroupCodePoint))
            toAdd.add([namedGroup, null])
        }
    }

    /**
     *
     * @param {Boolean} isServer
     * @param {Object} record
     * @param {import("../cryptoDataCache").ExtraHopCiperSuiteDetail} cipherSuite
     * @param {Set} handledVague
     * @param {Set} algorithmsFound
     * @param {[Object]} certificate Certificate to update the crypto in
     */
    #processCertificateCrypto(isServer, record, cipherSuite, handledVague, algorithmsFound, certificate) {
        let prefix = `isara${isServer ? 'Server' : 'Client'}Cert`
        let keyType = record[`${prefix}PublicKeyType`]
        if (!keyType) {
            return
        }
        let keySize = record[`${prefix}PublicKeySize`]
        let keyCurve = record[`${prefix}PublicKeyCurveName`]

        if (!keySize && !keyCurve) {
            if (!isServer) {
                // TODO: add a client sig record
            }
            return
        }

        let mapped
        switch (keyType) {
            case 'EC':
                mapped = cryptoPrimitiveLookup('ECDSA', keyCurve)
                if (mapped.primitiveName) {
                    if (isServer && mapped.primitiveName !== 'ECDSA') {
                        handledVague.add('ECDSA')
                    }
                    algorithmsFound.add([mapped.primitiveName, null])
                }
                if (certificate) {
                    certificate.publicKeyCryptoPrimitive = mapped.primitiveName
                    certificate.publicKeyCryptoPrimitiveParameter = null
                }
                break
            case 'RSA': {
                let mode
                if (isServer && cipherSuite.name.startsWith('TLS_RSA')) {
                    mode = 'RSA_KE'
                } else {
                    mode = 'RSA_SIG'
                }
                mapped = cryptoPrimitiveLookup(mode, keySize)
                if (mapped.primitiveName && mapped.primitiveName !== mode) {
                    if (isServer) {
                        handledVague.add(mode)
                    }
                    algorithmsFound.add([mapped.primitiveName, mapped.nonRegularSize])
                }
                if (certificate) {
                    certificate.publicKeyCryptoPrimitive = mapped.primitiveName.replace('_KE', '_SIG')
                    certificate.publicKeyCryptoPrimitiveParameter = mapped.nonRegularSize
                }
                break
            }
            case 'DSA':
                mapped = cryptoPrimitiveLookup('DSA_DSS', keySize)
                if (mapped.primitiveName && mapped.primitiveName !== 'DSA_DSS') {
                    if (isServer) {
                        handledVague.add('DSA_DSS')
                    }
                    algorithmsFound.add([mapped.primitiveName, mapped.nonRegularSize])
                }
                if (certificate) {
                    certificate.publicKeyCryptoPrimitive = mapped.primitiveName
                    certificate.publicKeyCryptoPrimitiveParameter = mapped.nonRegularSize
                }
                break
            default:
                log.e('Unknown key type in certificate', keyType)
        }
    }
}

exports.ExtraHopBatchProcessor = ExtraHopBatchProcessor
