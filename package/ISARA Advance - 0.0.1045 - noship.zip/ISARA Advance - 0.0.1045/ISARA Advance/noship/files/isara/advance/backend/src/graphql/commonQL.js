/**
 * @file commonQL.js - 0.0.1045 - ea4595bfd3488684d225574ed7d4c198074d49ba
 * 
 * @copyright Copyright (C) 2016-2023, ISARA Corporation, All Rights Reserved.
 * 
 * @license The code and other content set out herein is not in the public
 * domain, is considered a trade secret and is confidential to ISARA
 * Corporation. Use, reproduction or distribution, in whole or in part, of such
 * code or other content is strictly prohibited except by express written
 * permission of ISARA Corporation. Please contact ISARA Corporation at
 * info@isara.com for more information.
 */

/**
 * This module contains shared (common) functions.
 * @module graphql/commonQL
 */

var {
    generatePlaceholders, AdvancedSort
} = require('../isaraql/fetch')

var {
    CUD_OP_INSERT,
    createUpdateDelete
} = require('../isaraql/cud')

const { facets } = require('../filterql/facets')
var { paths, allTypes } = require('../isaraql/schemaDiscovery')
const { getRequestState } = require('./../util/requestState')
const { flatFacetIDMap, cacheTablespace } = require('../util/flatFacetHelpers')
const log = require('../util/log')(module)

const flatFacets = ['cryptoprim', 'concryptoscore', 'devicecryptoscore', 'devicetype', 'os', 'protocolvariant']

async function pathsToAggregates(listIDs, paths, session, startTable, destinationTable) {
    var joinedPaths = paths.map(path => ` (SELECT "${startTable}".id AS id, "${destinationTable}".name AS name ${path} WHERE "${startTable}".id IN (${generatePlaceholders(listIDs)}) ) `).join(' UNION ALL ')
    var params = listIDs
    var query = `SELECT id AS id, name AS name, COUNT(*) AS count FROM (${joinedPaths}) IgnoredName GROUP BY 1,2`
    var result = await session.query(query, params)
    return result.rows
}

async function flatAggregate(startTable, listIDs, facet, attributeName, session, destinationTable, resultsByID) {
    const mapping = allTypes[destinationTable]._enum.nameByID
    let results = await session.query(`SELECT object_id, value, count(*) AS count FROM "${cacheTablespace}"."${startTable}Flat" WHERE facet=${flatFacetIDMap[facet]} AND object_id IN (${generatePlaceholders(listIDs)}) GROUP BY 1,2`, listIDs)
    results.rows.forEach(result => resultsByID[result.object_id][attributeName].push({ name: mapping[result.value], count: result.count }))
}

exports.pathsToAggregates = pathsToAggregates

exports.collectAggregateResults = async function (startTable, destinationTable, excludes, includes, listIDs, resultsByID, attributeName, session) {
    var countingPaths = paths({ from: startTable, to: destinationTable, excludes, includes })
    var results = await pathsToAggregates(listIDs, countingPaths, session, startTable, destinationTable)
    results.forEach(result => resultsByID[result.id][attributeName].push({ name: result.name, count: result.count }))
}
exports.collectAggregateResultsLikeFacet = async function (startTable, destinationTable, theFacetName, listIDs, resultsByID, attributeName, session) {
    let start
    if (log.debug) {
        start = Date.now()
    }
    if (!session.historyEnabled && flatFacets.includes(theFacetName)) {
        await flatAggregate(startTable, listIDs, theFacetName, attributeName, session, destinationTable, resultsByID)
        log.d(`Retrieved flat facet ${theFacetName} in ${Date.now() - start} msec`)
    } else {
        var countingPaths = facets.attributesByName[theFacetName].paths[startTable]
        var results = await pathsToAggregates(listIDs, countingPaths, session, startTable, destinationTable)
        results.forEach(result => resultsByID[result.id][attributeName].push({ name: result.name, count: result.count }))
        log.d(`Retrieved complex facet ${theFacetName} in ${Date.now() - start} msec`)
    }
}

exports.populateAddedBy = function (params) {
    if (params.record.addedBy) {
        throw Error('"addedBy" should be implied by access token shouldn\'t be explicitly set')
    }
    // If someone inserts specify which user did the insertion
    if (params.operation === CUD_OP_INSERT) {
        let requestState = getRequestState()
        if (requestState?.user?.uid != null) {
            params.record.addedBy = requestState.user.uid
        }
    }
}

function replaceTemplates(template, sortDirection) {
    let directionPattern = /%DIR%/
    let nullsPattern = /%NULLS%/
    return template
        .replace(nullsPattern, sortDirection === 'asc' ? ' NULLS LAST' : '')
        .replace(directionPattern, sortDirection)
}

exports.getSort = async function (sortDictionary, sorting) {
    let template = sortDictionary[sorting.field]
    if (!template) {
        throw `Unexpected sorting field specified: ${sorting.field}`
    }

    let direction = SORT_DIRECTION_ENUM.graphQLToInternal[sorting.direction]
    if (typeof template === 'string') {
        return replaceTemplates(template, direction)
    } else if (template instanceof AdvancedSort) {
        return new AdvancedSort(
            template.joins,
            template.groups,
            template.orderBys.map(s => replaceTemplates(s, direction)),
            template.params
        )
    }

    throw `Unexpected Sorting Type Configured: ${typeof template}/${template.constructor.name}`
}

exports.updateTagUsedDate = async function (params) {
    await params.session.query('UPDATE "Tag" set "lastUsed" = ? where id = ?', [new Date(), params.record.tag])
}


exports.roles = {
    UNAUTHENTICATED: 0,
    AUTHENTICATED: 1,
    ADMIN: 2,
    TOKEN: -1, // Note: lowest number as a token does not imply greater than ADMIN.
}

/**
 * This dictionary names tables which should be modifiable by all posture/network updates.
 */
exports.postureModifiableTables = {
    Certificate: true,
    CertificateCryptoPrimitive: true,
    ConfigurationFileCertificate: true,
    Connection: true,
    ConnectionCertificate: true,
    ConnectionCipherSuite: true,
    ConnectionCryptoPrimitive: true,
    ConnectionProtocolVariant: true,
    ConnectionScore: true,
    ConnectionProtocolVariantCertificate: true,
    ConnectionTag: true,
    Device: true,
    DeviceAddress: true,
    DeviceAddressMACAddress: true,
    DeviceAddressPort: true,
    DeviceCertificate: true,
    DeviceMACAddress: true,
    DeviceSoftware: true,
    DeviceScore: true,
    DeviceSoftwareConnection: true,
    DeviceTag: true,
    Software: true,
    SoftwareVersion: true,
    SoftwareVersionTag: true,
    Tag: true,
}

/**
 * This class maps GraphQL enum values to internal values.
 * @property {string[]} graphQLValues All the GraphQL values of the enum.
 * @property {string[]} internalValues All the internal values of the enum.
 * @property {Object} graphQLToInternal Dictionary mapping GraphQL values to internal values
 * @property {Object} internalToGraphQL Dictionary mapping internal values to GraphQL values
 */
class GraphQLEnum {
    /**
     *
     * @param {string} name The name of the GraphQL enum.
     * @param {(string|string[])} fields If a single string, it is converted from camel case to upper underscore. If an array, the first is taken as the internal value, the second is taken as the GraphQL value.
     */
    constructor(name, fields) {
        this.name = name
        this.graphQLValues = []
        this.internalValues = []
        this.graphQLToInternal = {}
        this.internalToGraphQL = {}

        for (var arg of fields) {
            var internalArg = arg
            var graphQLArg = ''
            if (typeof arg === 'string') {
                var lastLower = false
                for (var i = 0; i < internalArg.length; ++i) {
                    var nextChar = internalArg[i]
                    var nextCharUpper = nextChar.toUpperCase()
                    if (nextChar === nextCharUpper && lastLower) {
                        graphQLArg += '_'
                    }
                    if (nextChar !== nextCharUpper) {
                        lastLower = true
                    }
                    graphQLArg += nextCharUpper
                }
            } else if (Array.isArray(arg)) {
                internalArg = arg[0]
                graphQLArg = arg[1]
            }
            this.graphQLValues.push(graphQLArg)
            this.internalValues.push(internalArg)

            this.graphQLToInternal[graphQLArg] = internalArg
            this.internalToGraphQL[internalArg] = graphQLArg
        }
    }

    /**
     * Get the GraphQL Schema for this enum.
     */
    toGraphQL() {
        var toReturn = `enum ${this.name} {\n`
        this.graphQLValues.forEach(v => {
            toReturn += `    ${v}\n`
        })

        toReturn += `}\n`
        return toReturn
    }
}
exports.GraphQLEnum = GraphQLEnum

/**
 * This dictionary names tables which should be checked for existing matches by all posture/network updates.
 */
exports.postureCheckExistingTables = {
    CipherSuite: true,
    ConnectionTag: true,
    DeviceTag: true,
    ProtocolVariant: true,
    Software: true,
    SoftwareVersion: true,
    SoftwareVersionTag: true,
    Tag: true,
}

// map from the user role type strings present in access tokens to their corresponding values as a security role.
exports.userRoleMapping = {
    'USER': 1,
    'ADMIN': 2
}

exports.updateDeviceConnectionCounts = async function (params, deviceId, isClient) {
    let countQuery = (column) => {
        return (
            `SELECT COUNT(c.id)
            FROM "Connection" c
            JOIN "DeviceAddressPort" dap on dap.id = c."${column}"
            JOIN "DeviceAddress" da on da.id = dap."deviceAddress"
            WHERE da.device = ?;`
        )
    }

    let updateConfig = {
        allowUpdate: true,
        session: params.session,
        modifiableTables: { Device: true }
    }

    if (deviceId) {
        let count = (await params.session.query(isClient ?
            countQuery`clientDeviceAddressPort` : countQuery`serverDeviceAddressPort`,
        [deviceId])
        ).rows
        await createUpdateDelete('Device', [{
            id: deviceId,
            ...(isClient && {outgoingConnectionCount: count[0].count}),
            ...(!isClient && {incomingConnectionCount: count[0].count}),
        }], updateConfig)
    }
}


async function cryptoScoreCoarseDetailsQuery() {
    var coarse = allTypes.CryptoScoreCoarse
    var toReturn = Object.entries(coarse._enum.detailsByID).map(value => {
        value = value[1]
        return {
            id: value.id,
            order: value.id,
            cryptoScoreCoarse: value.name,
            friendlyName: value.friendlyName
        }
    })
    return toReturn
}

async function cryptoPrimitivePurposeQuery() {
    var toReturn = Object.entries(allTypes['CryptoPrimitive']._enum.detailsByName).map(primitive => {
        primitive = primitive[1]
        return {
            cryptoPrimitive: primitive.name,
            purpose: allTypes['CryptoPrimitivePurpose']._enum.nameByID[primitive.purpose]
        }
    })
    return toReturn
}



const SORT_DIRECTION_ENUM = new GraphQLEnum('SortDirection', [['asc', 'ASCENDING'], ['desc', 'DESCENDING']])
exports.SORT_DIRECTION_ENUM = SORT_DIRECTION_ENUM

exports.graphQL = {
    types: `
        scalar Upload

        ${SORT_DIRECTION_ENUM.toGraphQL()}

        enum DeltaPeriod {
            DAY
            WEEK
            MONTH
            YEAR
        }

        enum StringComparator {
            EQUALS
            CONTAINS
        }

        type File {
            filename: String!
            mimetype: String!
            encoding: String!
        }

        type Paging {
            count: BigInt!
        }

        type Result {
            success: Boolean!
            messages: [ResultMessage!]
        }

        type ResultMessage {
            key: String!
            message: String!
        }

        input DateTimeComparison {
            before: DateTime
            after: DateTime
        }

        input PagingInput {
            offset: BigInt!,
            limit: BigInt!,
        }

        input StringComparison {
            comparator: StringComparator!
            string: String!
        }

        type MetaTag {
            key: String!
            name: String!
            value: BigInt!
        }

        type AttributeSummary {
            name: String!
            count: BigInt!
        }

        # the following definitions are for all queries that return a set of filter categories.
        enum FilterCategoryType {
            AGILITY
            CONNECTION
            CONNECTIONCRYPTO
            DEVICE
            NETWORKING
            TECHNOLOGY
            DEVICECRYPTO
            CRYPTO
        }

        type Filter {
            id: String!
            facet: String!
            name: String!
            value: BigInt!
        }

        type FilterGroup {
            id: String!
            groupName: String!
            filters: [Filter!]!
        }

        type FilterCategory {
            id: FilterCategoryType!
            categoryName: String!
            filterGroups: [FilterGroup!]!
        }

        """
	Carries detail for a CryptoScore
	"""
	type CryptoScoreDetail {
            cryptoScore: CryptoScore!
            cryptoScoreCoarse: CryptoScoreCoarse!
            id: Int!
            order: Int!
            friendlyName: String!
            shortName: String!
        }

	"""
	Carries detail for a CryptoScoreCoarse
	"""
        type CryptoScoreCoarseDetail {
            cryptoScoreCoarse: CryptoScoreCoarse!
            id: Int!
            order: Int!
            friendlyName: String!
        }
    """
    Carries detail for a CryptoPrimitive Purpose
    """
        type CryptoPrimitiveAndPurpose {
            cryptoPrimitive: CryptoPrimitive
            purpose: CryptoPrimitivePurpose
        }
    `,
    queries: `
    """
	See details of the CryptoScoreCoarse enum.
	"""
        cryptoScoreCoarseDetails: [CryptoScoreCoarseDetail!]!
    """
     See details of the CryptoPrimitive Purpose.
    """
    cryptoPrimitivePurpose: [CryptoPrimitiveAndPurpose!]!
    `,
    root: {
        cryptoScoreCoarseDetails: cryptoScoreCoarseDetailsQuery,
        cryptoPrimitivePurpose: cryptoPrimitivePurposeQuery
    },
    restrictions: {
        cryptoScoreDetails: [exports.roles.UNAUTHENTICATED],
        cryptoScoreCoarseDetails: [exports.roles.UNAUTHENTICATED],
        cryptoPrimitivePurpose: [exports.roles.UNAUTHENTICATED],

    }
}
