/**
 * @file certificates.js - 0.0.1045 - ea4595bfd3488684d225574ed7d4c198074d49ba
 * 
 * @copyright Copyright (C) 2016-2023, ISARA Corporation, All Rights Reserved.
 * 
 * @license The code and other content set out herein is not in the public
 * domain, is considered a trade secret and is confidential to ISARA
 * Corporation. Use, reproduction or distribution, in whole or in part, of such
 * code or other content is strictly prohibited except by express written
 * permission of ISARA Corporation. Please contact ISARA Corporation at
 * info@isara.com for more information.
 */

const path = require('path')
const fs = require('fs/promises')
const https = require('https')
const log = require('./log')(module)

const tlsCache = {}

const productionPath = '/isara/advance/tls'
const devPath = path.join('..', '..', 'tools', 'tls')

const KEEP_ALIVE_TIMEOUT_MS = 15 * 60 * 1000

async function loadTLSFile(which) {
    if (tlsCache[which]) {
        return tlsCache[which]
    }
    for (let source of [path.join(devPath, which), path.join(productionPath, which)]) {
        try {
            const toReturn = await fs.readFile(source)
            log.log('Loaded', source)
            return toReturn
        } catch (error) {
            // could not load - trying alternate path
        }
    }
    throw new Error(`Could not load ${which}`)
}

async function loadCACertificates() {
    return await loadTLSFile('ca.crt')
}

async function loadCertificate(name) {
    return await loadTLSFile(`${name}.crt`)
}

/**
 * @typedef CertificateAndPrivateKey
 * @property {String|Buffer} certificate
 * @property {String|Buffer} privateKey
 */

/**
 * @param {String} name The name of the certificate and private key that your'e trying to load.
 * @returns {CertificateAndPrivateKey} The loaded certificate and private key raw PEM files.
 */
async function loadCertificateAndPrivateKey(name) {
    return {
        certificate: await loadCertificate(name),
        privateKey: await loadTLSFile(`${name}.key`)
    }
}

/**
 * Connects a https server to the given expressApp using the given key par name.
 * @param {number} port The port to listen on.
 * @param {ExpressApp} expressApp 
 * @param {string} keyName 
 * @returns An https server.
 */
async function prepareHTTPSServer(port, expressApp, keyName) {
    try {
        const credentials = await loadCertificateAndPrivateKey(keyName)
        let options = {
            key: credentials.privateKey,
            cert: credentials.certificate,
            minVersion: 'TLSv1.3',
        }

        const server = https.createServer(options, expressApp)
        server.keepAliveTimeout = Math.floor(KEEP_ALIVE_TIMEOUT_MS)
        server.headersTimeout = Math.floor(KEEP_ALIVE_TIMEOUT_MS)


        await new Promise((resolve, reject) => {
            server.listen(port, () => {
                resolve()
            })
    
            server.on('error', error => reject(error))
        })
    
        return server
    } catch (error) {
        log.e(error)
    }
    throw new Error('Could not load TLS credentials')
}

exports.loadCACertificates = loadCACertificates
exports.loadCertificate = loadCertificate
exports.loadCertificateAndPrivateKey = loadCertificateAndPrivateKey
exports.prepareHTTPSServer = prepareHTTPSServer
