/**
 * @file ISARATLSMainRecord.js - 0.0.1045 - ea4595bfd3488684d225574ed7d4c198074d49ba
 * 
 * @copyright Copyright (C) 2016-2023, ISARA Corporation, All Rights Reserved.
 * 
 * @license The code and other content set out herein is not in the public
 * domain, is considered a trade secret and is confidential to ISARA
 * Corporation. Use, reproduction or distribution, in whole or in part, of such
 * code or other content is strictly prohibited except by express written
 * permission of ISARA Corporation. Please contact ISARA Corporation at
 * info@isara.com for more information.
 */

// /**
//  * Handling for ISARA Custom TLS Main record. Attempts to pull out ciphersuite
//  * and protocol variant metadata.
//  *
//  * @module extrahop/records/ISARATLSMainRecord
// */

// const _ = require("lodash");
// const { writeToString } = require('@fast-csv/format')

// const { RecordBase } = require('./RecordBase')
// const { allTypes } = require('../../../isaraql/schemaDiscovery')

// const { populateObservedFields } = require('../extrahopUtils')

// const log = require('../../../util/log')(module)

// class ISARATLSMainRecord extends RecordBase {
//     constructor(record, cacheMaps) {
//         super(record, cacheMaps)

//         let cryptoPrimitives = allTypes['CryptoPrimitive']._enum.idByName

//         if (cacheMaps.ecdsaCurveMap === undefined) {
//             this.buildECDSACurveMap(cacheMaps)
//         }

//         this.flowID = record._source.isaraFlowID

//         this.tlsVersionCodePoint = record._source.isaraTLSVersionCodePoint
//         let protocolVariant = this.cacheMaps.tlsCodepointIDMap[this.tlsVersionCodePoint]

//         if (protocolVariant !== undefined) {
//             this.protocolVariant = protocolVariant.variant
//             this.protocol = protocolVariant.protocol
//         } else {
//             // TODO: GAP1617 - unknown SSL/TLS version
//         }

//         let cipherSuiteCodepoint = record._source.isaraCipherSuiteCodePoint
//         if (cipherSuiteCodepoint === null || cipherSuiteCodepoint === undefined) {
//             return
//         }

//         this.cipherSuiteCodepoint = cipherSuiteCodepoint

//         let suiteInfo = this.cacheMaps.cipherSuiteCodepointIDMap[cipherSuiteCodepoint]
//         if (suiteInfo !== undefined) {
//             this.cipherSuiteID = suiteInfo
//         } else {
//             // TODO: GAP1617 - unrecognized/custom cipherSuite
//         }

//         if (record._source.isaraSNI !== undefined) {
//             // TODO: GAP1617 - use this somewhere
//             this.SNI = record._source.isaraSNI
//         }

//         if (record._source.isaraTLS13KEXNamedGroupCodePoint) {
//             let kexID = this.getTLS13KEXPrimitive(record._source.isaraTLS13KEXNamedGroupCodePoint)
//             if (kexID !== null && kexID !== undefined) {
//                 this.kexID = kexID
//             }
//         }

//         // Determine and store if we are using ephemeral key exchange for later use when processing
//         // params records.
//         let matches = record._source.isaraCipherSuite.match(/_(EC)?DH(?<ephemeral>[E])?_/i)
//         this.ephemeral = matches !== null && matches.groups !== undefined && matches.groups.ephemeral !== undefined

//         this.serverAuthHashID = []
//         this.clientAuthHashID = []

//         // Get hash algorithm for entity authentication for TLS 1.1, 1.0, and SSL 3.0
//         let serverPubKeyType = record._source.isaraServerCertPublicKeyType
//         let clientPubKeyType = record._source.isaraClientCertPublicKeyType

//         if (serverPubKeyType !== undefined) {
//             this.getLowerVersionTLSAuthHash(serverPubKeyType, true)
//         }

//         if (clientPubKeyType !== undefined) {
//             this.getLowerVersionTLSAuthHash(clientPubKeyType, false)
//         }

//         // Look for server certificate details. These will not always be available.
//         if (record._source.isaraServerCertSubjectCN) {
//             this.serverCertificate = {
//                 subject: record._source.isaraServerCertSubjectCN,
//                 // TODO: GAP1617 - look up issuer to see if we have a cert for them in order
//                 // to foreign key link them.
//                 issuer: record._source.isaraServerCertIssuerCN,
//                 // TODO: GAP1617 - Catalyst.
//                 certificateType: allTypes['CertificateType']._enum.idByName['X509'],
//                 serial: record._source.isaraServerCertSerialNumber,
//                 notBefore: new Date(record._source.isaraServerCertCreationDate * 1000),
//                 notAfter: new Date(record._source.isaraServerCertExpirationDate * 1000)
//             }

//             populateObservedFields(this.serverCertificate, this.observationTime)

//             if (record._source.isaraServerCertSubjectAN) {
//                 this.serverCertificate.alternateNames = record._source.isaraServerCertSubjectAN
//             }

//             // TODO: GAP1617 - match by purpose once available from primitives table.
//             // in the long term, should be matched by OID if/when we can get it from Extrahop.
//             let serverPubkeyType = record._source.isaraServerCertPublicKeyType
//             if (serverPubkeyType) {
//                 let keySize = record._source.isaraServerCertPublicKeySize
//                 let serverPubkeyParam
//                 switch (serverPubkeyType) {
//                     case 'EC':
//                         serverPubkeyParam = cacheMaps.ecdsaCurveMap[record._source.isaraServerCertPublicKeyCurveName]
//                         break
//                     case 'RSA':
//                         serverPubkeyParam = cryptoPrimitives[`RSA_SIG_${keySize}`]
//                         if (this.kexID === undefined && record._source.isaraCipherSuite.startsWith('TLS_RSA_')) {
//                             let rsaKex = cryptoPrimitives[`RSA_KE_${keySize}`]
//                             if (rsaKex !== undefined) {
//                                 this.kexID = rsaKex
//                             }
//                         }
//                         break
//                     case 'DSA':
//                         serverPubkeyParam = this.getDSAPrimitive(keySize);
//                         break
//                     default:
//                         // log unknown?
//                         break
//                 }

//                 if (serverPubkeyParam !== null && serverPubkeyParam !== undefined) {
//                     this.serverCertificate.certificateCryptoPrimitives = [{ cryptoPrimitive: serverPubkeyParam }]
//                 }
//             }
//         }

//         // Look for client certificate details. These will not always be available.
//         if (record._source.isaraClientCertSubjectCN) {
//             this.clientCertificate = {
//                 subject: record._source.isaraClientCertSubjectCN,
//                 // TODO: GAP1617 - look up issuer to see if we have a cert for them in order
//                 // to foreign key link them.
//                 issuer: record._source.isaraClientCertIssuerCN,
//                 // TODO: GAP1617 - Catalyst.
//                 certificateType: allTypes['CertificateType']._enum.idByName['X509'],
//                 serial: record._source.isaraClientCertSerialNumber,
//                 notBefore: new Date(record._source.isaraClientCertCreationDate * 1000),
//                 notAfter: new Date(record._source.isaraClientCertExpirationDate * 1000)
//             }

//             populateObservedFields(this.clientCertificate, this.observationTime)

//             if (record._source.isaraClientCertSubjectAN) {
//                 this.clientCertificate.alternateNames = record._source.isaraClientCertSubjectAN
//             }

//             // TODO: GAP1617 - match by purpose once available from primitives table.
//             // in the long term, should be matched by OID if/when we can get it from Extrahop.
//             let clientPubkeyType = record._source.isaraClientCertPublicKeyType
//             if (clientPubkeyType) {
//                 let keySize = record._source.isaraClientCertPublicKeySize
//                 let clientPubkeyParam
//                 switch (clientPubkeyType) {
//                     case 'EC':
//                         clientPubkeyParam = cacheMaps.ecdsaCurveMap[record._source.isaraClientCertPublicKeyCurveName]
//                         break
//                     case 'RSA':
//                         clientPubkeyParam = cryptoPrimitives[`RSA_SIG_${keySize}`]
//                         break
//                     case 'DSA':
//                         clientPubkeyParam = this.getDSAPrimitive(keySize);
//                         break
//                     default:
//                         // log unknown?
//                         break
//                 }

//                 if (clientPubkeyParam !== null && clientPubkeyParam !== undefined) {
//                     this.clientCertificate.certificateCryptoPrimitives = [{ cryptoPrimitive: clientPubkeyParam }]
//                 }
//             }
//         }

//         if (record._source.isaraServerDHCPName) {
//             this.serverDHCPName = record._source.isaraServerDHCPName
//         }

//         if (record._source.isaraServerDNSNames) {
//             this.serverDNSNames = record._source.isaraServerDNSNames
//         }

//         if (record._source.isaraClientDHCPName) {
//             this.clientDHCPName = record._source.isaraClientDHCPName
//         }

//         if (record._source.isaraClientDNSNames) {
//             this.clientDNSNames = record._source.isaraClientDNSNames
//         }
//     }

//     getTLS13KEXPrimitive(codePoint) {
//         // codepoints - c.f. https://tools.ietf.org/html/rfc8446#section-4.2.7
//         let primitives = allTypes['CryptoPrimitive']._enum.idByName
//         switch (codePoint) {
//             // ECDHE
//             case 0x17: // p256
//                 return primitives['ECDHE_SECP256r1']
//             case 0x18: // p384
//                 return primitives['ECDHE_SECP384r1']
//             case 0x19: // p521
//                 return primitives['ECDHE_SECP521r1']
//             case 0x1d: // x25519
//                 return primitives['ECDHE_x25519']
//             case 0x1e: // x448
//                 return primitives['ECDHE_x448']

//             // FFDHE
//             case 0x100: // ffdhe2048
//                 return primitives['FFDHE_2048']
//             case 0x101: // ffdhe3072
//                 return primitives['FFDHE_3072']
//             case 0x102: // ffdhe4096
//                 return primitives['FFDHE_4096']
//             case 0x103: // ffdhe6144
//                 return primitives['FFDHE_6144']
//             case 0x104: // ffdhe8192
//                 return primitives['FFDHE_8192']
//             default:
//                 return null
//         }
//     }

//     getDSAPrimitive(keySize) {
//         let primitives = allTypes['CryptoPrimitive']._enum.idByName
//         switch (keySize) {
//             case 1024:
//                 return primitives['DSA_DSS_1024_160']
//             case 2048:
//                 return primitives['DSA_DSS_2048_224']
//             case 3072:
//                 return primitives['DSA_DSS_3072_256']
//             case 7680:
//                 return primitives['DSA_DSS_7680_384']
//             case 15360:
//                 return primitives['DSA_DSS_15360_512']
//             default:
//                 return null
//         }
//     }

//     buildECDSACurveMap(cacheMaps) {
//         let primitives = allTypes['CryptoPrimitive']._enum.idByName
//         cacheMaps.ecdsaCurveMap = {
//             brainpoolP160r1: primitives['ECDSA_BRAINPOOL_P160r1'],
//             brainpoolP160t1: primitives['ECDSA_BRAINPOOL_P160t1'],
//             brainpoolP192r1: primitives['ECDSA_BRAINPOOL_P192r1'],
//             brainpoolP192t1: primitives['ECDSA_BRAINPOOL_P192t1'],
//             brainpoolP224r1: primitives['ECDSA_BRAINPOOL_P224r1'],
//             brainpoolP224t1: primitives['ECDSA_BRAINPOOL_P224t1'],
//             brainpoolP256r1: primitives['ECDSA_BRAINPOOL_P256r1'],
//             brainpoolP256t1: primitives['ECDSA_BRAINPOOL_P256t1'],
//             brainpoolP320r1: primitives['ECDSA_BRAINPOOL_P320r1'],
//             brainpoolP320t1: primitives['ECDSA_BRAINPOOL_P320t1'],
//             brainpoolP384r1: primitives['ECDSA_BRAINPOOL_P384r1'],
//             brainpoolP384t1: primitives['ECDSA_BRAINPOOL_P384t1'],
//             brainpoolP512r1: primitives['ECDSA_BRAINPOOL_P521r1'],
//             brainpoolP512t1: primitives['ECDSA_BRAINPOOL_P521t1'],
//             secp160k1: primitives['ECDSA_SECP160k1'],
//             secp160r1: primitives['ECDSA_SECP160r1'],
//             secp160r2: primitives['ECDSA_SECP160r2'],
//             secp192k1: primitives['ECDSA_SECP192k1'],
//             secp224k1: primitives['ECDSA_SECP224k1'],
//             secp224r1: primitives['ECDSA_SECP224r1'],
//             secp256k1: primitives['ECDSA_SECP256k1'],
//             secp256r1: primitives['ECDSA_SECP256r1'],
//             prime256v1: primitives['ECDSA_SECP256r1'],
//             secp384r1: primitives['ECDSA_SECP384r1'],
//             secp521r1: primitives['ECDSA_SECP521r1'],
//             sect163k1: primitives['ECDSA_SECT163k1'],
//             sect163r1: primitives['ECDSA_SECT163r1'],
//             sect163r2: primitives['ECDSA_SECT163r2'],
//             sect193r1: primitives['ECDSA_SECT193r1'],
//             sect193r2: primitives['ECDSA_SECT163r2'],
//             sect233k1: primitives['ECDSA_SECT233k1'],
//             sect233r1: primitives['ECDSA_SECT233r1'],
//             sect239k1: primitives['ECDSA_SECT239k1'],
//             sect283k1: primitives['ECDSA_SECT283k1'],
//             sect283r1: primitives['ECDSA_SECT283r1'],
//             sect409k1: primitives['ECDSA_SECT409k1'],
//             sect409r1: primitives['ECDSA_SECT409r1'],
//             sect571k1: primitives['ECDSA_SECT571k1'],
//             sect571r1: primitives['ECDSA_SECT571r1'],
//             SM2: primitives['ECDSA_CurveSM2']
//         }
//     }

//     /*
//      * Derive the hash algorithm used for server and client auth, when the
//      * session is TLS 1.1, 1.0, or SSL 3.0. (TLS 1.2 case is handled in
//      * processParamsTCPRecords(), and in the case of TLS 1.3 negotiated
//      * hash algorithm is not available because that info is encrypted.)
//      *
//      * For TLS 1.1, 1.0, and SSL 3.0, the hash algorithm is not negotiated
//      * but fixed to SHA1, MD5+SHA1, or intrinsic depending on the signature
//      * algorithm used.
//      *
//      * For RSA, it's MD5+SHA1. For DSA, it's SHA1:
//      * select (SignatureAlgorithm) {
//      *   case rsa:
//      *     digitally-signed struct {
//      *     opaque md5_hash[16];
//      *     opaque sha_hash[20];
//      *   };
//      *
//      *   case dsa:
//      *     digitally-signed struct {
//      *     opaque sha_hash[20];
//      *   };
//      * } Signature;
//      * (RFC 4346, section 7.4.3 for TLS 1.1)
//      * (RFC 2246, section 7.4.3 for TLS 1.0 which is the same as SSL 3.0)
//      *
//      * For ECDSA it's SHA1. For EDDSA, it's "intrinsic" (no hashing):
//      * select (SignatureAlgorithm) {
//      *   case ecdsa:
//      *     digitally-signed struct {
//      *       opaque sha_hash[sha_size];
//      *     };
//      *
//      *   case ed25519,ed448:
//      *     digitally-signed struct {
//      *       opaque rawdata[rawdata_size];
//      *     };
//      *   } Signature;
//      * (RFC 8422, section 5.4)
//      *
//      * TODO: GAP1325 - We don't have "intrinsic" primitive in our database,
//      * and we shall consider adding it so that we can properly handle the
//      * EDDSA case mentioned above.
//      */
//     getLowerVersionTLSAuthHash(publicKeyType, isServerAuth) {
//         if (this.tlsVersionCodePoint == '768' ||  // SSL 3.0 code point
//             this.tlsVersionCodePoint == '769' ||  // TLS 1.0 code point
//             this.tlsVersionCodePoint == '770') {  // TLS 1.1 code point

//             let primitives = allTypes['CryptoPrimitive']._enum.idByName
//             let authHashID = isServerAuth ? this.serverAuthHashID : this.clientAuthHashID

//             if (publicKeyType !== undefined) {
//                 switch (publicKeyType) {
//                     case 'EC':
//                     case 'DSA':
//                         authHashID.push(primitives['SHA_1']);
//                         break
//                     case 'RSA':
//                         authHashID.push(primitives['MD5']);
//                         authHashID.push(primitives['SHA_1']);
//                         break
//                     default:
//                         log.d(`Unrecognized public key type: ${publicKeyType}`)
//                         break
//                 }
//             }
//         }
//     }

//     async addCertificate(connection, certificate, certificateType) {
//         if (certificate.alternateNames) {
//             certificate.alternateNames = await writeToString([certificate.alternateNames])
//         }

//         if (connection.connectionProtocolVariants) {
//             let protocolVariantCertEntry = {
//                 connectionCertificateType: certificateType,
//                 certificate: certificate
//             }
//             populateObservedFields(protocolVariantCertEntry, this.observationTime)

//             connection.connectionProtocolVariants[0].connectionProtocolVariantCertificates.push(
//                 protocolVariantCertEntry
//             )
//         }

//         connection.connectionCertificates.push(
//             {
//                 certificate: certificate
//             }
//         )
//     }

//     processParamsTCPRecords(cacheMaps) {
//         /*
//          * paramsRecords is an array of Params_TCP records, as each
//          * TLS session may create more than one Params_TCP records:
//          * One for the client flow and another one for the server flow.
//          */
//         let paramsRecords = cacheMaps.flowIDMap[this.flowID]
//         if (paramsRecords !== undefined) {
//             for (let paramsRecord of paramsRecords) {
//                 /*
//                  * Get the negotiated hash algorithm used for server/client auth,
//                  * when the session is TLS 1.2. I.e., the hash algo the server/client
//                  * used to sign handshake message.
//                  */
//                 if (paramsRecord.record._source.isaraIsClientFlow === true ) {
//                     // Processing a Params_TCP record for the client -> server flow.

//                     /*
//                      * Unlike server flow records, client flow records don't contain TLS
//                      * version info. Nevertheless, the mere presence of a client flow record
//                      * signifies that it is from a TLS 1.2 session, as at this point we do
//                      * not have the need to create client flow records for other TLS versions.
//                      */
//                     let clientAuthSigSchemeCodePoint = paramsRecord.record._source.isaraClientAuthSigSchemeCodePoint
//                     if (clientAuthSigSchemeCodePoint !== undefined) {
//                         let clientHashID = paramsRecord.getAuthHashPrimitive(clientAuthSigSchemeCodePoint);
//                         if (clientHashID !== null && clientHashID !== undefined) {
//                             this.clientAuthHashID.push(clientHashID);
//                         } else {
//                             log.d(`No client auth hash primitive determinable for flow ID '${this.flowID}, Params Record: ${JSON.stringify(paramsRecord)}`)
//                         }
//                     }
//                 } else {
//                     // Processing a Params_TCP record for the server -> client flow.

//                     /*
//                      * If the main record does not contain "isaraTLS13KEXNamedGroupCodePoint",
//                      * then check if there is an accompanying Params_TCP record, which may
//                      * contain the key exchange parameter. However, in this case the session
//                      * would be for TLS 1.2, 1.1, 1.0, or SSL 3.0, instead of TLS 1.3.
//                      */
//                     let kexID = paramsRecord.getKEXPrimitive(this.ephemeral)
//                     if (kexID !== null && kexID !== undefined) {
//                         this.kexID = kexID
//                     } else {
//                         log.d(`No KEX primitive determinable for flow ID '${this.flowID}, Params Record: ${JSON.stringify(paramsRecord)}`)
//                     }

//                     let serverAuthSigSchemeCodePoint = paramsRecord.record._source.isaraServerAuthSigSchemeCodePoint
//                     if (serverAuthSigSchemeCodePoint !== undefined) {
//                         /*
//                          * Only TLS 1.2 session should have this property set.
//                          */
//                         if (this.tlsVersionCodePoint != '771') { // TLS 1.2 code point
//                             /* Log a note, and carry on. */
//                             log.d(`Signature scheme code point should only exist in TLS 1.2 records, but the session being processed is version '${this.tlsVersionCodePoint}`)
//                         }

//                         let serverHashID = paramsRecord.getAuthHashPrimitive(serverAuthSigSchemeCodePoint);
//                         if (serverHashID !== null && serverHashID !== undefined) {
//                             this.serverAuthHashID.push(serverHashID);
//                         } else {
//                             log.d(`No server auth hash primitive determinable for flow ID '${this.flowID}, Params Record: ${JSON.stringify(paramsRecord)}`)
//                         }
//                     }
//                 }
//             }
//         }

//         delete cacheMaps.flowIDMap[this.flowID]
//     }

//     async getConnectionObject(cacheMaps) {
//         /*
//          * Do not ingest TLS main record if it does not contain cipher suite info.
//          */
//         if (this.cipherSuiteCodepoint === undefined) {
//             return null
//         }

//         this.processParamsTCPRecords(cacheMaps)
//         let connection = this.getBaseConnectionObject()

//         if (this.protocol) {
//             connection.connectionProtocolVariants.push(
//                 {
//                     protocolVariant: this.protocolVariant,
//                     connectionProtocolVariantCertificates: []
//                 })
//             populateObservedFields(_.last(connection.connectionProtocolVariants), this.observationTime)
//         }

//         if (this.kexID) {
//             connection.connectionCryptoPrimitives.push({
//                 cryptoPrimitive: this.kexID
//             })
//             populateObservedFields(_.last(connection.connectionCryptoPrimitives), this.observationTime)
//         }

//         this.serverAuthHashID.forEach(elem => {
//             connection.connectionCryptoPrimitives.push({cryptoPrimitive: elem})
//             populateObservedFields(_.last(connection.connectionCryptoPrimitives), this.observationTime)
//         })

//         this.clientAuthHashID.forEach(elem => {
//             connection.connectionCryptoPrimitives.push({cryptoPrimitive: elem})
//             populateObservedFields(_.last(connection.connectionCryptoPrimitives), this.observationTime)
//         })

//         if (this.cipherSuiteID) {
//             connection.connectionCipherSuites.push({
//                 cipherSuite: this.cipherSuiteID
//             })
//             populateObservedFields(_.last(connection.connectionCipherSuites), this.observationTime)
//         }

//         if (this.serverCertificate) {
//             await this.addCertificate(connection, this.serverCertificate, allTypes['ConnectionCertificateType']._enum.idByName['SERVER'])
//         }

//         if (this.clientCertificate) {
//             await this.addCertificate(connection, this.clientCertificate, allTypes['ConnectionCertificateType']._enum.idByName['CLIENT'])
//         }

//         if (connection.serverDeviceAddressPort.deviceAddress.device) {
//             if (this.serverDNSNames) {
//                 connection.serverDeviceAddressPort.deviceAddress.device.friendlyName = this.serverDNSNames[0]
//             } else if (this.serverDHCPName) {
//                 connection.serverDeviceAddressPort.deviceAddress.device.friendlyName = this.serverDHCPName
//             }
//         }

//         // In theory we should never be adding a brand new device here, since those should all have already been matched from the
//         // device query, but just in case...
//         if (connection.clientDeviceAddressPort.device) {
//             if (this.clientDNSNames) {
//                 connection.clientDeviceAddressPort.deviceAddress.device.friendlyName = this.clientDNSNames[0]
//             } else if (this.clientDHCPName) {
//                 connection.clientDeviceAddressPort.deviceAddress.device.friendlyName = this.clientDHCPName
//             }
//         }

//         return connection
//     }
// }

// exports.ISARATLSMainRecord = ISARATLSMainRecord
