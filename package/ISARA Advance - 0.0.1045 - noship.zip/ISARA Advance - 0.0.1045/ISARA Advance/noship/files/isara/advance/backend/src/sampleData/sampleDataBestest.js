/**
 * @file sampleDataBestest.js - 0.0.1045 - ea4595bfd3488684d225574ed7d4c198074d49ba
 * 
 * @copyright Copyright (C) 2016-2023, ISARA Corporation, All Rights Reserved.
 * 
 * @license The code and other content set out herein is not in the public
 * domain, is considered a trade secret and is confidential to ISARA
 * Corporation. Use, reproduction or distribution, in whole or in part, of such
 * code or other content is strictly prohibited except by express written
 * permission of ISARA Corporation. Please contact ISARA Corporation at
 * info@isara.com for more information.
 */

var randomWords = require('random-words')
const { Client } = require('pg')
const {
    Session
} = require('../isaraql/session')
const { initGenerator } = require('./generators/processing')
const { insertNetmasks } = require('./generators/netmask')
const { populateSoftware } = require('./generators/software')
const {
    dumpObjectTimingStats,
    initDbConnection,
    insertObject,
    bulkInsertRecords,
    resetObjectTimingStats
} = require('./dbHelpers')
var lodash = require('lodash')
const {loadEnum} = require("./dbTypeHelpers")
const fetch = (...args) => import('node-fetch').then(({ default: fetch }) => fetch(...args));
const minimist = require('minimist')
process.env.NODE_TLS_REJECT_UNAUTHORIZED = '0';
const advance_config = require('../../sample/advance_preferences.json');
const { insertRecord } = require('../isaraql/fetch')

const { getSampleUserToken, getSampleUser } = require('./utils')
const { importCnxZip } = require('./generators/cnsZipImport')
const { createWidget } = require('./generators/widget')
const { mainJsonImport } = require('./generators/jsonConfigImport')

var log = require('../util/log')(module)
const path = require('path')
const systemPreferences = require('../util/systemPreferences')
const axios = require('axios')
const fs = require('fs')
const FormData = require('form-data')
const { async } = require('node-stream-zip')

var connection = null
let session = new Session()

var data = {
    allConnections: [],
    allDevices: [],
    allDeviceSoftware: {},
    allSoftware: {},
    allSoftwareVersions: {},
    allTags: [],
    notifications: [],
    connectionTags: [],
    connectionTagAssociations: [],
    softwareVersionTags: [],
    softwareVersionTagAssociations: [],
    roles:[],
    protocols:[],
    softwareTypes:[],
    tagTypes:{},
    showCount: { last: {} } // for tracking progress
}

async function main() {
    log.log('Entered main')
    const preferences = await systemPreferences()
    session.ignore = true;
    const user = await getSampleUser(session); // ensure user exists
    data.users = [user]
    const token = await getSampleUserToken();
    log.log('args', process.argv)
    if (process.argv[2] == 'cns') {
        let file = 'developer_built_100k_Connections.zip'
        if (process.argv[3] && process.argv[3].includes(".zip")) {
            file = process.argv[3];
        }
        await importCnxZip(session, token, data.allSoftware, data.allSoftwareVersions, file);
    } else if (process.argv[2] == 'widgets') {
        //add widgets
        createWidget(session);
    } else if (process.argv[2] == 'json') {
        //add via json config
        let jsonFile = null
        if (process.argv[3] && process.argv[3].includes(".json")) {
            jsonFile = process.argv[3];
        } else if (process.argv[3] === 'default') {
            jsonFile = __dirname + '/configs/default.json'
        }
        await mainJsonImport(session, jsonFile, data, user);
    } else if(process.argv[2] == "testDb"){
        //await initGenerator(session, data)
        await initDbConnection(session)
        var results = await session.query(`SELECT id,name,"isNumeric",unit FROM "TagType"`)
    
        console.log("results:", results)
    }
    process.exit(0);
}

main().then(() => {
    log.log('Done!')
}).catch(e => {
    log.e('Sad now. :(', e)
    process.exit(1)
})
