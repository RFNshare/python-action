/**
 * @file fifoQueue.js - 0.0.1045 - ea4595bfd3488684d225574ed7d4c198074d49ba
 * 
 * @copyright Copyright (C) 2016-2023, ISARA Corporation, All Rights Reserved.
 * 
 * @license The code and other content set out herein is not in the public
 * domain, is considered a trade secret and is confidential to ISARA
 * Corporation. Use, reproduction or distribution, in whole or in part, of such
 * code or other content is strictly prohibited except by express written
 * permission of ISARA Corporation. Please contact ISARA Corporation at
 * info@isara.com for more information.
 */

const assert = require('assert')

/**
 * Minimal FirstInFirstOut FIFO Queue
 */
class FIFOQueue {
    /**
     * Will point to the first-in item, or be `undefined`.
     */
    #head

    /**
     * Will point to the end of the queue - where the next addition will be, or be `undefined`.
     */
    #tail

    /**
     * Current length of the queue.
     */
    #length

    /**
     * Simple FIFO Queue
     * @param {[Iterable.<any>]} iterable collection of items to add to the FIFOQueue
     */
    constructor(iterable) {
        this.clear()
        if (iterable) {
            for (let item of iterable) {
                this.enqueue(item)
            }
        }
    }

    /**
     * How many items are in the queue?
     */
    get length() {
        return this.#length
    }

    /**
     * Clear / empty the queue.
     */
    clear() {
        this.#head = this.#tail = undefined
        this.#length = 0
    }

    /**
     * Check if the queue is empty. (Really just checks to see if #length is === 0)
     */
    get empty() {
        return this.#length === 0
    }

    /**
     * Add a value to the queue.
     * @param {Any} item 
     */
    enqueue(item) {
        let newNode = { item, next: undefined }
        if (this.#tail) {
            this.#tail.next = newNode
        }
        if (!this.#head) {
            this.#head = newNode
        }

        this.#tail = newNode
        this.#length++
    }

    /**
     * Remove a value from the start of the queue.
     * @returns {Any|undefined} The value at the start of the queue. Will always return `undefined` if the FIFOQueue was empty.
     */
    dequeue() {
        try {
            return this.#head?.item
        } finally {
            this.#head = this.#head?.next
            if (!this.#head) {
                this.#tail = this.#head
                this.#length = 0
            } else {
                this.#length--
            }
        }
    }
}

/**
 * Basic unit test.
 */
if (require.main === module) {
    let queue = new FIFOQueue([1, 2, 3])
    assert(queue.empty === false)
    assert(queue.empty === false)
    assert(queue.length === 3)
    assert(queue.dequeue() === 1)
    assert(queue.dequeue() === 2)
    assert(queue.length === 1)
    assert(queue.empty === false)
    assert(queue.dequeue() === 3)
    assert(queue.empty === true)
    assert(queue.length === 0)
    assert(queue.dequeue() === undefined)
    assert(queue.length === 0)
    assert(queue.dequeue() === undefined)
    assert(queue.length === 0)
    assert(queue.dequeue() === undefined)
    assert(queue.length === 0)
    queue.enqueue(4)
    queue.enqueue(5)
    assert(queue.length === 2)
    assert(queue.dequeue() === 4)
    assert(queue.length === 1)
    assert(queue.dequeue() === 5)
    assert(queue.length === 0)
}

exports.FIFOQueue = FIFOQueue