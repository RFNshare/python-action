/**
 * @file axiosFactory.js - 0.0.1045 - ea4595bfd3488684d225574ed7d4c198074d49ba
 * 
 * @copyright Copyright (C) 2016-2023, ISARA Corporation, All Rights Reserved.
 * 
 * @license The code and other content set out herein is not in the public
 * domain, is considered a trade secret and is confidential to ISARA
 * Corporation. Use, reproduction or distribution, in whole or in part, of such
 * code or other content is strictly prohibited except by express written
 * permission of ISARA Corporation. Please contact ISARA Corporation at
 * info@isara.com for more information.
 */

const axios = require('axios')
const systemPreferences = require('./systemPreferences')

const log = require('./log')(module)
const { Agent } = require('https')

const DEFAULT_CONFIG = {
    log: {
        request: false,
        requestError: true,
        response: false,
        responseError: true,
        responseAllData: true
    }
}

let axiosLogConfig = JSON.parse(JSON.stringify(DEFAULT_CONFIG))

/**
 * Flag indicating if we should trust all TLS certificates for outbound connections.
 */
let trustAll = false

function createFactory(owner) {
    return {
        create: function () {
            let toReturn = axios.create(...arguments)
            toReturn.interceptors.request.use(
                config => {
                    if (trustAll) {
                        log.w('Enabling trust all for request to', config.baseURL ?? config.url)
                        config.httpsAgent = new Agent({ rejectUnauthorized: false }) // TODO: this would obliterate any previous https agent settings.
                    }
                    if (axiosLogConfig?.log?.request) {
                        log.log(owner, 'AXIOS Request\nConfig:', config)
                    }
                    return config
                },
                error => {
                    if (axiosLogConfig?.log?.requestError) {
                        log.log(owner, 'AXIOS Request\nError:', error)
                    }
                    return Promise.reject(error)
                }
            )
            toReturn.interceptors.response.use(
                response => {
                    if (axiosLogConfig?.log?.response) {
                        log.log(owner, 'AXIOS Response\nResponse:', response)
                    }
                    return response
                },
                error => {
                    if (axiosLogConfig?.log?.responseError) {
                        log.log(owner, 'AXIOS Response\nError:', error)
                    }
                    return Promise.reject(error)
                }
            )
            return toReturn
        }
    }
}

async function init() {
    let preferences = await systemPreferences()
    let source = preferences?.axios?.log
    if (typeof source === 'object') {
        Object.assign(axiosLogConfig.log, source)
        log.log('Using the following axios logging config', axiosLogConfig)
    }
    trustAll = preferences?.axios?.trustAll === true
    if (trustAll) {
        log.w('Trusting ALL TLS certificates for outgoing axios connections')
    }
}

const assert = require('assert')

async function test() {
    await init()
    let failed = false
    for (let i = 0; i < 2; ++i) {
        for (let ta of [true, false]) {
            trustAll = ta
            let axios = createFactory('test')
            let instance = axios.create()
            try {
                await instance.get('http://doesnotexist.isara.com')
                failed = true
            } catch (e) {
                assert(e.code, 'Code should be set')
                assert(e.code === 'ENOTFOUND', 'Code should be host not found')
            }

            assert(!failed)

            try {
                await instance.get('http://httpstat.us/403')
                failed = true
            } catch (e) {
                // good - exception should be thrown by 403 error on website.
            }

            assert(!failed)

            try {
                await instance.get('hppt://www.hotmail.com')
                failed = true
            } catch (e) {
                // good - exception should be thrown by bad protocol in url (hppt)
            }

            await instance.get('https://www.isara.com')

            await instance.get('http://www.cnn.com')

            try {
                await instance.get('https://guardian-qa2.isaracorp.com:442')
                if (!trustAll) {
                    failed = true
                }
            } catch (e) {
                if (trustAll && (e.code ?? '').includes('SELF_SIGNED')) {
                    failed = true
                }
            }

            assert(!failed)
        }
    }
}

if (require.main === module) {
    test().then(() => {
        console.log('\n\nGood\n')
        process.exit(0)
    }).catch(e => {
        console.log(e)
        console.log('\n\nFAILED\n\n')

        process.exit(1)
    })
}

exports.createFactory = createFactory
exports.init = init
exports.create = () => {
    const message = 'Create called directly - call createFactory()'
    log.e(message)
    throw new Error(message)
}
