/**
 * @file walk.js - 0.0.1045 - ea4595bfd3488684d225574ed7d4c198074d49ba
 * 
 * @copyright Copyright (C) 2016-2023, ISARA Corporation, All Rights Reserved.
 * 
 * @license The code and other content set out herein is not in the public
 * domain, is considered a trade secret and is confidential to ISARA
 * Corporation. Use, reproduction or distribution, in whole or in part, of such
 * code or other content is strictly prohibited except by express written
 * permission of ISARA Corporation. Please contact ISARA Corporation at
 * info@isara.com for more information.
 */


function walk(node, transform, arg) {
    switch(node.type) {
        case 'TermExpression':
        case 'NotExpression':
            return transform(
                {
                    type: node.type,
                    term: walk(node.term, transform, arg),
                },
                arg,
            )
        case 'ParenthesesExpression':
            return transform(
                {
                    type: node.type,
                    expression: walk(node.expression, transform, arg),
                },
                arg,
            )

        case 'AndExpression':
        case 'OrExpression':
            return transform(
                {
                    type: node.type,
                    term: walk(node.term, transform, arg),
                    expression: walk(node.expression, transform, arg),
                },
                arg,
            )
        case 'Term':
            return transform(
                {
                    type: node.type,
                    attribute: walk(node.attribute, transform, arg),
                    comparison: walk(node.comparison, transform, arg),
                },
                arg,
            )
        case 'AnonymousAttribute':
            return transform(
                {
                    type: node.type,
                },
                arg,
            )
        case 'NamedAttribute':
        case 'NamedTagAttribute':
            return transform(
                {
                    type: node.type,
                    name: node.name,
                    column: node.column
                },
                arg,
            )
        case 'QualifiedAttribute':
        case 'QualifiedTagAttribute':
            return transform(
                {
                    type: node.type,
                    qualifier: node.qualifier,
                    name: node.name,
                },
                arg,
            )
        case 'ValueComparison':
        case 'BeforeComparison':
        case 'AfterComparison':
            return transform(
                {
                    type: node.type,
                    comparator: walk(node.comparator, transform, arg),
                    literal: walk(node.literal, transform, arg),
                },
                arg,
            )
        case 'Contains':
        case 'ContainsCase':
        case 'Equals':
        case 'EqualsCase':
        case 'LessThan':
        case 'LessThanOrEqual':
        case 'GreaterThan':
        case 'GreaterThanOrEqual':
            return transform(node, arg)
        case 'InsideComparison':
        case 'OutsideComparison':
            return transform(
                {
                    type: node.type,
                    comparator1: walk(node.comparator1, transform, arg),
                    literal1: walk(node.literal1, transform, arg),
                    comparator2: walk(node.comparator2, transform, arg),
                    literal2: walk(node.literal2, transform, arg),
                },
                arg,
            )
        case 'BooleanLiteral':
            return transform(
                {
                    type: node.type,
                    boolean: node.boolean,
                },
                arg,
            )
        case 'IntegerLiteral':
            return transform(
                {
                    type: node.type,
                    integer: node.integer,
                },
                arg,
            )
        case 'FloatLiteral':
            return transform(
                {
                    type: node.type,
                    float: node.float,
                },
                arg,
            )
        case 'StringLiteral':
        case 'UnquotedStringLiteral':
            return transform(
                {
                    type: node.type,
                    string: node.string,
                },
                arg,
            )
        case 'DateLiteral':
            return transform(
                {
                    type: node.type,
                    year: node.year,
                    month: node.month,
                    day: node.day,
                    hour: node.hour,
                    minute: node.minute,
                    second: node.second,
                },
                arg,
            )
        default: {
            let message = `Unknown AST node type: ${node.type}`
            throw message
        }
    }
}

module.exports = {
    walk:        walk,
}
