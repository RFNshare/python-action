/**
 * @file extrahopRecordsRequest.js - 0.0.1045 - ea4595bfd3488684d225574ed7d4c198074d49ba
 * 
 * @copyright Copyright (C) 2016-2023, ISARA Corporation, All Rights Reserved.
 * 
 * @license The code and other content set out herein is not in the public
 * domain, is considered a trade secret and is confidential to ISARA
 * Corporation. Use, reproduction or distribution, in whole or in part, of such
 * code or other content is strictly prohibited except by express written
 * permission of ISARA Corporation. Please contact ISARA Corporation at
 * info@isara.com for more information.
 */

/**
 * Request extrahop recordstore data. This is actually several requests in one,
 * as the API requires one to first initiate a query, and then iterate the returned
 * cursor on success.
 *
 * @module extrahop/requests/ExtrahopDevicesRequest
 */

const { ExtrahopRequest } = require('./extrahopRequest')

class ExtrahopRecordsRequest extends ExtrahopRequest {
    constructor(baseURL, token, queryParameters, parameters) {
        super(baseURL, '/api/v1/records/search', token, 'POST',
            {
                from: queryParameters.start,
                until: queryParameters.end,
                limit: 10000,
                offset: 0,
                sort: [{
                    field: 'timestamp',
                    direction: 'asc'
                }],
                types: ['isara_tls_main', 'isara_tls_params_tcp']
            },
            parameters)

        this.useEXA = queryParameters.useEXA
        if (this.useEXA) {
            this.body.context_ttl = 5 * 60 * 60 * 1000
        }

        this.recordsRetrieved = 0
    }

    async execute() {
        let result = await super.execute()
        if (this.useEXA) {
            if (this.cursor === undefined) {
                if (result.cursor) {
                    this.cursor = result.cursor
                    this.apiPath = `/api/v1/records/cursor?context_ttl=${this.body.context_ttl}`

                    this.body = {
                        cursor: this.cursor
                    }
                }
            }
        } else {
            this.body.offset += this.body.limit
        }

        return result
    }

    async checkComplete(response) {
        // TODO: GAP1624 - depending on how quickly our previously discovered Splunk issue gets resolved,
        // this may need to be adjusted to perform a workaround check, since the latter starts
        // giving responses with 0 records after offset 1000. This would cause an infinite loop
        // here, since our retrieved record count will never hit the total, though it will
        // probably still end since the request is likely to fail when we attempt to ask for
        // an offset exceeding the total.
        this.recordsRetrieved += response.records.length
        if (this.recordsRetrieved == response.total) {
            this.complete = true
        }
    }
}

exports.ExtrahopRecordsRequest = ExtrahopRecordsRequest
