/**
 * @file cryptoPrimitives.js - 0.0.1045 - ea4595bfd3488684d225574ed7d4c198074d49ba
 * 
 * @copyright Copyright (C) 2016-2023, ISARA Corporation, All Rights Reserved.
 * 
 * @license The code and other content set out herein is not in the public
 * domain, is considered a trade secret and is confidential to ISARA
 * Corporation. Use, reproduction or distribution, in whole or in part, of such
 * code or other content is strictly prohibited except by express written
 * permission of ISARA Corporation. Please contact ISARA Corporation at
 * info@isara.com for more information.
 */

/**
 * @module provision/cryptoPrimitives
 */

const cryptoScores = {
    BROKEN: 0,
    WEAK: 1,
    MISUSED: 2,
    NONSTANDARD_QSC: 500,
    UNSPECIFIED_PARAMETERS: 501,
    UNKNOWN_OR_CUSTOM: 502,
    NOT_RECOMMENDED: 503,
    STRONG_CLASSIC_BROKEN_QUANTUM: 1000,
    STRONG_CLASSIC_UNKNOWN_QUANTUM: 1001,
    STRONG_HYBRID: 1002,
    QUANTUM_SAFE_LEVEL1: 1500,
    QUANTUM_SAFE_LEVEL2: 1501,
    QUANTUM_SAFE_LEVEL3: 1502,
    QUANTUM_SAFE_LEVEL4: 1503,
    QUANTUM_SAFE_LEVEL5: 1504
}

const CryptoPrimitivePurposes = {
    SIGNATURE: 'SIGNATURE',
    BULK_ENCRYPTION: 'BULK_ENCRYPTION',
    HASH: 'HASH',
    KEY_EXCHANGE: 'KEY_EXCHANGE',
    MAC: 'MAC',
    MODE_OF_OPERATION: 'MODE_OF_OPERATION'
}

const cryptoPrimitives = {

    // Added oids from http://oidref.com/2.16.840.1.101.3.4.1.42
    // (which got data from https://tools.ietf.org/html/rfc3565.html)
    AES: {
        baseScore: cryptoScores.QUANTUM_SAFE_LEVEL1,
        description: 'AES',
        oid: '2.16.840.1.101.3.4.1',
        hasDefault: true,
        primitives: [
            { name: 'AES_128', description: 'AES-128', score: cryptoScores.QUANTUM_SAFE_LEVEL1 },
            { name: 'AES_192', description: 'AES-192', score: cryptoScores.QUANTUM_SAFE_LEVEL3 },
            { name: 'AES_256', description: 'AES-256', score: cryptoScores.QUANTUM_SAFE_LEVEL5 },
            { name: 'AES_128_GCM', variant: '2.16.840.1.101.3.4.1.6', description: 'AES-128-GCM', score: cryptoScores.QUANTUM_SAFE_LEVEL1 },
            { name: 'AES_192_GCM', variant: '2.16.840.1.101.3.4.1.26', description: 'AES-192-GCM', score: cryptoScores.QUANTUM_SAFE_LEVEL3 },
            { name: 'AES_256_GCM', variant: '2.16.840.1.101.3.4.1.46', description: 'AES-256-GCM', score: cryptoScores.QUANTUM_SAFE_LEVEL5 },
            { name: 'AES_128_CCM', variant: '2.16.840.1.101.3.4.1.7', description: 'AES-128-CCM', score: cryptoScores.QUANTUM_SAFE_LEVEL1 },
            { name: 'AES_192_CCM', variant: '2.16.840.1.101.3.4.1.27', description: 'AES-192-CCM', score: cryptoScores.QUANTUM_SAFE_LEVEL3 },
            { name: 'AES_256_CCM', variant: '2.16.840.1.101.3.4.1.47', description: 'AES-256-CCM', score: cryptoScores.QUANTUM_SAFE_LEVEL5 },
            // No OIDs for CCM_8, as they are not standardized for CMS.
            { name: 'AES_128_CCM_8', description: 'AES-128-CCM_8', score: cryptoScores.QUANTUM_SAFE_LEVEL1 },
            { name: 'AES_256_CCM_8', description: 'AES-256-CCM_8', score: cryptoScores.QUANTUM_SAFE_LEVEL5 },
        ],
        purpose: CryptoPrimitivePurposes.BULK_ENCRYPTION
    },
    ARIA: {
        baseScore: cryptoScores.STRONG_CLASSIC_UNKNOWN_QUANTUM,
        description: 'ARIA',
        hasDefault: true,
        primitives: [
            { name: 'ARIA_128', description: 'ARIA-128' },
            { name: 'ARIA_192', description: 'ARIA-192' },
            { name: 'ARIA_256', description: 'ARIA-256' },
        ],
        purpose: CryptoPrimitivePurposes.BULK_ENCRYPTION
    },
    ANON: {
        baseScore: cryptoScores.BROKEN,
        description: 'anon',
        hasDefault: true,
        purpose: CryptoPrimitivePurposes.SIGNATURE
    },
    BASE64: {
        baseScore: cryptoScores.BROKEN,
        description: 'Base64',
        hasDefault: true,
        purpose: CryptoPrimitivePurposes.BULK_ENCRYPTION
    },
    BIKE2: {
        baseScore: cryptoScores.NONSTANDARD_QSC,
        description: 'BIKE2',
        hasDefault: true,
        primitives: [
            { name: 'BIKE2_1', description: 'BIKE2-1', score: cryptoScores.NONSTANDARD_QSC },
            { name: 'BIKE2_3', description: 'BIKE2-3', score: cryptoScores.NONSTANDARD_QSC },
            { name: 'BIKE2_5', description: 'BIKE2-5', score: cryptoScores.NONSTANDARD_QSC },
        ],
        purpose: CryptoPrimitivePurposes.KEY_EXCHANGE
    },
    // Blake oids from https://tools.ietf.org/html/rfc7693
    // (Could only get oids that were the same for both MAC & HASH not sure if that is correct)
    BLAKE_MAC: {
        baseScore: cryptoScores.NOT_RECOMMENDED,
        description: 'BLAKE MAC',
        oid: '1.3.6.1.4.1.1722.12.2',
        hasDefault: true,
        primitives: [
            { name: 'BLAKE2B_MAC', description: 'BLAKE2b-MAC', variant: '1.3.6.1.4.1.1722.12.2.1', score: cryptoScores.QUANTUM_SAFE_LEVEL5 },
            { name: 'BLAKE2S_MAC', description: 'BLAKE2s-MAC', variant: '1.3.6.1.4.1.1722.12.2.2', score: cryptoScores.QUANTUM_SAFE_LEVEL5 },
            // Not sure about oid for this one
            { name: 'BLAKE3_MAC', description: 'BLAKE3-MAC', score: cryptoScores.NOT_RECOMMENDED }
        ],
        purpose: CryptoPrimitivePurposes.MAC
    },
    BLAKE_DIGEST: {
        baseScore: cryptoScores.UNSPECIFIED_PARAMETERS,
        description: 'BLAKE_DIGEST',
        oid: '1.3.6.1.4.1.1722.12.2',
        hasDefault: true,
        primitives: [
            // Not sure what variant to put if only given the size and not any more variant info
            { name: 'BLAKE_256_DIGEST', description: 'BLAKE-256-HASH', score: cryptoScores.QUANTUM_SAFE_LEVEL2 },
            { name: 'BLAKE_512_DIGEST', description: 'BLAKE-512-HASH', score: cryptoScores.QUANTUM_SAFE_LEVEL5 },
            { name: 'BLAKE_2S_LT_256_DIGEST', description: 'BLAKE2s < 256-HASH', score: cryptoScores.STRONG_CLASSIC_UNKNOWN_QUANTUM },
            { name: 'BLAKE_2S_256_DIGEST', description: 'BLAKE2s 256-HASH', variant: '1.3.6.1.4.1.1722.12.2.2.8', score: cryptoScores.QUANTUM_SAFE_LEVEL2 },
            { name: 'BLAKE_2B_256_DIGEST', description: 'BLAKE2b 256-HASH', variant: '1.3.6.1.4.1.1722.12.2.1.8', score: cryptoScores.QUANTUM_SAFE_LEVEL2 },
            { name: 'BLAKE_2B_384_DIGEST', description: 'BLAKE2b 384-HASH', variant: '1.3.6.1.4.1.1722.12.2.1.12', score: cryptoScores.QUANTUM_SAFE_LEVEL4 },
            { name: 'BLAKE_2B_512_DIGEST', description: 'BLAKE2b 512-HASH', variant: '1.3.6.1.4.1.1722.12.2.1.16', score: cryptoScores.QUANTUM_SAFE_LEVEL5 },
            { name: 'BLAKE_2X_DIGEST', description: 'BLAKE2X-HASH', score: cryptoScores.NOT_RECOMMENDED },
            { name: 'BLAKE_3_DIGEST', description: 'BLAKE3-HASH', score: cryptoScores.NOT_RECOMMENDED },
        ],
        purpose: CryptoPrimitivePurposes.HASH
    },
    BLOWFISH: {
        baseScore: cryptoScores.BROKEN,
        description: 'Blowfish',
        hasDefault: true,
        primitives: [
            { name: 'BLOWFISH_LT_112', description: 'Blowfish < 112' },
            { name: 'BLOWFISH_112_256', description: 'Blowfish 112-256' },
            { name: 'BLOWFISH_GT_256', description: 'Blowfish > 256' },
        ],
        purpose: CryptoPrimitivePurposes.BULK_ENCRYPTION
    },
    CAMELLIA: {
        baseScore: cryptoScores.STRONG_CLASSIC_UNKNOWN_QUANTUM,
        description: 'CAMELLIA',
        hasDefault: true,
        primitives: [
            { name: 'CAMELLIA_128', description: 'CAMELLIA-128' },
            { name: 'CAMELLIA_192', description: 'CAMELLIA-192' },
            { name: 'CAMELLIA_256', description: 'CAMELLIA-256' },
        ],
        purpose: CryptoPrimitivePurposes.BULK_ENCRYPTION
    },
    CAST: {
        baseScore: cryptoScores.BROKEN,
        description: 'CAST',
        primitives: [
            { name: 'CAST5', description: 'CAST5' }
        ],
        purpose: CryptoPrimitivePurposes.BULK_ENCRYPTION
    },
    CBC: {
        baseScore: cryptoScores.MISUSED,
        description: 'CBC',
        hasDefault: true,
        purpose: CryptoPrimitivePurposes.MODE_OF_OPERATION
    },
    CCM: {
        baseScore: cryptoScores.QUANTUM_SAFE_LEVEL5,
        description: 'CCM',
        hasDefault: true,
        purpose: CryptoPrimitivePurposes.MODE_OF_OPERATION
    },
    CFB1: {
        baseScore: cryptoScores.QUANTUM_SAFE_LEVEL5,
        description: 'CFB1',
        hasDefault: true,
        purpose: CryptoPrimitivePurposes.MODE_OF_OPERATION
    },
    CFB8: {
        baseScore: cryptoScores.QUANTUM_SAFE_LEVEL5,
        description: 'CFB8',
        hasDefault: true,
        purpose: CryptoPrimitivePurposes.MODE_OF_OPERATION
    },
    CHACHA: {
        baseScore: cryptoScores.QUANTUM_SAFE_LEVEL5,
        description: 'ChaCha',
        hasDefault: true,
        primitives: [
            { name: 'CHACHA_20', description: 'ChaCha20' },
            { name: 'CHACHA_20_POLY1305', description: 'ChaCha20-Poly1305' },
        ],
        purpose: CryptoPrimitivePurposes.BULK_ENCRYPTION
    },
    CLASSIC_MCELIECE: {
        baseScore: cryptoScores.NONSTANDARD_QSC,
        description: 'Classic McEliece',
        hasDefault: true,
        primitives: [
            { name: 'MCELIECE_348864', description: 'McEliece-348864', score: cryptoScores.NONSTANDARD_QSC },
            { name: 'MCELIECE_460896', description: 'McEliece-460896', score: cryptoScores.NONSTANDARD_QSC },
            { name: 'MCELIECE_6688128', description: 'McEliece-6688128', score: cryptoScores.NONSTANDARD_QSC },
            { name: 'MCELIECE_6960119', description: 'McEliece-6960119', score: cryptoScores.NONSTANDARD_QSC },
            { name: 'MCELIECE_8192128', description: 'McEliece-8192128', score: cryptoScores.NONSTANDARD_QSC }
        ],
        purpose: CryptoPrimitivePurposes.KEY_EXCHANGE
    },
    CTR: {
        baseScore: cryptoScores.QUANTUM_SAFE_LEVEL5,
        description: 'CTR',
        hasDefault: true,
        purpose: CryptoPrimitivePurposes.MODE_OF_OPERATION
    },
    DES: {
        baseScore: cryptoScores.BROKEN,
        description: 'DES',
        hasDefault: true,
        primitives: [
            { name: 'DES_40', description: 'DES-40' },
            { name: 'DES_56', description: 'DES-56' },
        ],
        purpose: CryptoPrimitivePurposes.BULK_ENCRYPTION
    },
    DILITHIUM: {
        baseScore: cryptoScores.NONSTANDARD_QSC,
        description: 'Dilithium',
        hasDefault: true,
        primitives: [
            { name: 'DILITHIUM_2', description: 'Dilithium-2', score: cryptoScores.NONSTANDARD_QSC },
            { name: 'DILITHIUM_3', description: 'Dilithium-3', score: cryptoScores.NONSTANDARD_QSC },
            { name: 'DILITHIUM_5', description: 'Dilithium-5', score: cryptoScores.NONSTANDARD_QSC },
        ],
        purpose: CryptoPrimitivePurposes.SIGNATURE
    },
    DSA: {
        baseScore: cryptoScores.UNSPECIFIED_PARAMETERS,
        description: 'DSA/DSS',
        oid: '1.2.840.10040.4.1',
        hasDefault: true,
        primitives: [
            { name: 'DSA_DSS_toosmall', description: 'DSA/DSS-Too Small', score: cryptoScores.BROKEN },
            { name: 'DSA_DSS_1024', description: 'DSA/DSS-1024', score: cryptoScores.WEAK },
            { name: 'DSA_DSS_2048', description: 'DSA/DSS-2048', score: cryptoScores.NOT_RECOMMENDED },
            { name: 'DSA_DSS_3072', description: 'DSA/DSS-3072', score: cryptoScores.NOT_RECOMMENDED },
            { name: 'DSA_DSS_7680', description: 'DSA/DSS-7680', score: cryptoScores.NOT_RECOMMENDED },
            { name: 'DSA_DSS_15360', description: 'DSA/DSS-15360', score: cryptoScores.STRONG_CLASSIC_BROKEN_QUANTUM },
        ],
        purpose: CryptoPrimitivePurposes.SIGNATURE
    },
    DSS_Export: {
        baseScore: cryptoScores.BROKEN,
        description: 'DSS Export',
        hasDefault: true,
        purpose: CryptoPrimitivePurposes.SIGNATURE
    },
    ECB: {
        baseScore: cryptoScores.WEAK,
        description: 'ECB',
        hasDefault: true,
        purpose: CryptoPrimitivePurposes.MODE_OF_OPERATION
    },
    ECCPWD: {
        baseScore: cryptoScores.UNKNOWN_OR_CUSTOM,
        description: 'ECCPWD',
        hasDefault: true,
        purpose: CryptoPrimitivePurposes.KEY_EXCHANGE
    },
    ECDH: {
        baseScore: cryptoScores.UNSPECIFIED_PARAMETERS,
        description: 'ECDH',
        hasDefault: true,
        primitives: [
            { name: 'ECDH_BRAINPOOL_P160r1', description: 'ECDH Brainpool p160r1', variant: '1.3.36.3.3.2.8.1.1.1', score: cryptoScores.WEAK },
            { name: 'ECDH_BRAINPOOL_P160t1', description: 'ECDH Brainpool p160t1', variant: '1.3.36.3.3.2.8.1.1.2', score: cryptoScores.WEAK },
            { name: 'ECDH_BRAINPOOL_P192r1', description: 'ECDH Brainpool p192r1', variant: '1.3.36.3.3.2.8.1.1.3', score: cryptoScores.WEAK },
            { name: 'ECDH_BRAINPOOL_P192t1', description: 'ECDH Brainpool p192t1', variant: '1.3.36.3.3.2.8.1.1.4', score: cryptoScores.WEAK },
            { name: 'ECDH_BRAINPOOL_P224r1', description: 'ECDH Brainpool p224r1', variant: '1.3.36.3.3.2.8.1.1.5', score: cryptoScores.NOT_RECOMMENDED },
            { name: 'ECDH_BRAINPOOL_P224t1', description: 'ECDH Brainpool p224t1', variant: '1.3.36.3.3.2.8.1.1.6', score: cryptoScores.NOT_RECOMMENDED },
            { name: 'ECDH_BRAINPOOL_P256r1', description: 'ECDH Brainpool p256r1', variant: '1.3.36.3.3.2.8.1.1.7', score: cryptoScores.NOT_RECOMMENDED },
            { name: 'ECDH_BRAINPOOL_P256t1', description: 'ECDH Brainpool p256t1', variant: '1.3.36.3.3.2.8.1.1.8', score: cryptoScores.NOT_RECOMMENDED },
            { name: 'ECDH_BRAINPOOL_P320r1', description: 'ECDH Brainpool p320r1', variant: '1.3.36.3.3.2.8.1.1.9', score: cryptoScores.NOT_RECOMMENDED },
            { name: 'ECDH_BRAINPOOL_P320t1', description: 'ECDH Brainpool p320t1', variant: '1.3.36.3.3.2.8.1.1.10', score: cryptoScores.NOT_RECOMMENDED },
            { name: 'ECDH_BRAINPOOL_P384r1', description: 'ECDH Brainpool p384r1', variant: '1.3.36.3.3.2.8.1.1.11', score: cryptoScores.NOT_RECOMMENDED },
            { name: 'ECDH_BRAINPOOL_P384t1', description: 'ECDH Brainpool p384t1', variant: '1.3.36.3.3.2.8.1.1.12', score: cryptoScores.NOT_RECOMMENDED },
            { name: 'ECDH_BRAINPOOL_P512r1', description: 'ECDH Brainpool p512r1', variant: '1.3.36.3.3.2.8.1.1.13', score: cryptoScores.NOT_RECOMMENDED },
            { name: 'ECDH_BRAINPOOL_P512t1', description: 'ECDH Brainpool p512t1', variant: '1.3.36.3.3.2.8.1.1.14', score: cryptoScores.NOT_RECOMMENDED },
            { name: 'ECDH_SECT163k1', description: 'ECDH sect163k1', variant: '1.3.132.0.1', score: cryptoScores.WEAK },
            { name: 'ECDH_SECT163r1', description: 'ECDH sect163r1', variant: '1.3.132.0.2', score: cryptoScores.WEAK },
            { name: 'ECDH_SECT163r2', description: 'ECDH sect163r2', variant: '1.3.132.0.15', score: cryptoScores.WEAK },
            { name: 'ECDH_SECT193r1', description: 'ECDH sect193r1', variant: '1.3.132.0.24', score: cryptoScores.NOT_RECOMMENDED },
            { name: 'ECDH_SECT193r2', description: 'ECDH sect193r2', variant: '1.3.132.0.25', score: cryptoScores.NOT_RECOMMENDED },
            { name: 'ECDH_SECT233k1', description: 'ECDH sect233k1', variant: '1.3.132.0.26', score: cryptoScores.NOT_RECOMMENDED },
            { name: 'ECDH_SECT233r1', description: 'ECDH sect233r1', variant: '1.3.132.0.27', score: cryptoScores.NOT_RECOMMENDED },
            { name: 'ECDH_SECT239k1', description: 'ECDH sect239k1', variant: '1.3.132.0.3', score: cryptoScores.NOT_RECOMMENDED },
            { name: 'ECDH_SECT283k1', description: 'ECDH sect283k1', variant: '1.3.132.0.16', score: cryptoScores.NOT_RECOMMENDED },
            { name: 'ECDH_SECT283r1', description: 'ECDH sect283r1', variant: '1.3.132.0.17', score: cryptoScores.NOT_RECOMMENDED },
            { name: 'ECDH_SECT409k1', description: 'ECDH sect409k1', variant: '1.3.132.0.36', score: cryptoScores.NOT_RECOMMENDED },
            { name: 'ECDH_SECT409r1', description: 'ECDH sect409r1', variant: '1.3.132.0.37', score: cryptoScores.NOT_RECOMMENDED },
            { name: 'ECDH_SECT571k1', description: 'ECDH sect571k1', variant: '1.3.132.0.38', score: cryptoScores.NOT_RECOMMENDED },
            { name: 'ECDH_SECT571r1', description: 'ECDH sect571r1', variant: '1.3.132.0.39', score: cryptoScores.NOT_RECOMMENDED },
            { name: 'ECDH_SECP256r1', description: 'ECDH secp256r1', variant: '1.2.840.10045.3.1.7', score: cryptoScores.NOT_RECOMMENDED },
            { name: 'ECDH_SECP384r1', description: 'ECDH secp384r1', variant: '1.3.132.0.34', score: cryptoScores.NOT_RECOMMENDED },
            { name: 'ECDH_SECP521r1', description: 'ECDH secp521r1', variant: '1.3.132.0.35', score: cryptoScores.NOT_RECOMMENDED },
            { name: 'ECDH_SECP160k1', description: 'ECDH secp160k1', variant: '1.3.132.0.9', score: cryptoScores.NOT_RECOMMENDED },
            { name: 'ECDH_SECP160r1', description: 'ECDH secp160r1', variant: '1.3.132.0.8', score: cryptoScores.NOT_RECOMMENDED },
            { name: 'ECDH_SECP160r2', description: 'ECDH secp160r2', variant: '1.3.132.0.30', score: cryptoScores.NOT_RECOMMENDED },
            { name: 'ECDH_SECP192k1', description: 'ECDH secp192k1', variant: '1.3.132.0.31', score: cryptoScores.NOT_RECOMMENDED },
            { name: 'ECDH_SECP192r1', description: 'ECDH secp192r1', variant: '1.2.840.10045.3.1.1', score: cryptoScores.NOT_RECOMMENDED },
            { name: 'ECDH_SECP224k1', description: 'ECDH secp224k1', variant: '1.3.132.0.32', score: cryptoScores.NOT_RECOMMENDED },
            { name: 'ECDH_SECP224r1', description: 'ECDH secp224r1', variant: '1.3.132.0.33', score: cryptoScores.NOT_RECOMMENDED },
            { name: 'ECDH_SECP256k1', description: 'ECDH secp256k1', variant: '1.3.132.0.10', score: cryptoScores.NOT_RECOMMENDED },
            // GHOST https://art.tools.ietf.org/id/draft-smyshlyaev-tls12-gost-suites-04.html
            // https://tools.ietf.org/id/draft-deremin-rfc4491-bis-01.html
            { name: 'ECDH_GC256A', description: 'ECDH Gost GC256A', variant: '1.2.643.7.1.2.1.1.1', score: cryptoScores.NOT_RECOMMENDED },
            { name: 'ECDH_GC256B', description: 'ECDH Gost GC256B', variant: '1.2.643.7.1.2.1.1.2', score: cryptoScores.NOT_RECOMMENDED },
            { name: 'ECDH_GC256C', description: 'ECDH Gost GC256C', variant: '1.2.643.7.1.2.1.1.3', score: cryptoScores.NOT_RECOMMENDED },
            { name: 'ECDH_GC256D', description: 'ECDH Gost GC256D', variant: '1.2.643.7.1.2.1.1.4', score: cryptoScores.NOT_RECOMMENDED },
            { name: 'ECDH_GC512A', description: 'ECDH Gost GC512A', variant: '1.2.643.7.1.2.1.2.1', score: cryptoScores.NOT_RECOMMENDED },
            { name: 'ECDH_GC512B', description: 'ECDH Gost GC512B', variant: '1.2.643.7.1.2.1.2.2', score: cryptoScores.NOT_RECOMMENDED },
            { name: 'ECDH_GC512C', description: 'ECDH Gost GC512C', variant: '1.2.643.7.1.2.1.2.3', score: cryptoScores.NOT_RECOMMENDED },
            { name: 'ECDH_Custom', description: 'ECDH Custom', score: cryptoScores.UNKNOWN_OR_CUSTOM },
            // x448 and x25519 oids from https://tools.ietf.org/id/draft-ietf-curdle-pkix-07.html
            { name: 'ECDH_x448', description: 'ECDH-x448', variant: '1.3.101.111', score: cryptoScores.NOT_RECOMMENDED },
            { name: 'ECDH_x25519', description: 'ECDH-x25519', variant: '1.3.101.110', score: cryptoScores.NOT_RECOMMENDED },
            // Chinese SM9 standard
            { name: 'ECDH_CurveSM2', description: 'ECDH Curve SM2', score: cryptoScores.NOT_RECOMMENDED },
        ],
        purpose: CryptoPrimitivePurposes.KEY_EXCHANGE
    },
    ECDHE: {
        baseScore: cryptoScores.UNSPECIFIED_PARAMETERS,
        description: 'ECDHE',
        hasDefault: true,
        primitives: [
            { name: 'ECDHE_BRAINPOOL_P160r1', description: 'ECDHE Brainpool p160r1', variant: '1.3.36.3.3.2.8.1.1.1', score: cryptoScores.WEAK },
            { name: 'ECDHE_BRAINPOOL_P160t1', description: 'ECDHE Brainpool p160t1', variant: '1.3.36.3.3.2.8.1.1.2', score: cryptoScores.WEAK },
            { name: 'ECDHE_BRAINPOOL_P192r1', description: 'ECDHE Brainpool p192r1', variant: '1.3.36.3.3.2.8.1.1.3', score: cryptoScores.WEAK },
            { name: 'ECDHE_BRAINPOOL_P192t1', description: 'ECDHE Brainpool p192t1', variant: '1.3.36.3.3.2.8.1.1.4', score: cryptoScores.WEAK },
            { name: 'ECDHE_BRAINPOOL_P224r1', description: 'ECDHE Brainpool p224r1', variant: '1.3.36.3.3.2.8.1.1.5', score: cryptoScores.NOT_RECOMMENDED },
            { name: 'ECDHE_BRAINPOOL_P224t1', description: 'ECDHE Brainpool p224t1', variant: '1.3.36.3.3.2.8.1.1.6', score: cryptoScores.NOT_RECOMMENDED },
            { name: 'ECDHE_BRAINPOOL_P256r1', description: 'ECDHE Brainpool p256r1', variant: '1.3.36.3.3.2.8.1.1.7', score: cryptoScores.NOT_RECOMMENDED },
            { name: 'ECDHE_BRAINPOOL_P256t1', description: 'ECDHE Brainpool p256t1', variant: '1.3.36.3.3.2.8.1.1.8', score: cryptoScores.NOT_RECOMMENDED },
            { name: 'ECDHE_BRAINPOOL_P320r1', description: 'ECDHE Brainpool p320r1', variant: '1.3.36.3.3.2.8.1.1.9', score: cryptoScores.NOT_RECOMMENDED },
            { name: 'ECDHE_BRAINPOOL_P320t1', description: 'ECDHE Brainpool p320t1', variant: '1.3.36.3.3.2.8.1.1.10', score: cryptoScores.NOT_RECOMMENDED },
            { name: 'ECDHE_BRAINPOOL_P384r1', description: 'ECDHE Brainpool p384r1', variant: '1.3.36.3.3.2.8.1.1.11', score: cryptoScores.NOT_RECOMMENDED },
            { name: 'ECDHE_BRAINPOOL_P384t1', description: 'ECDHE Brainpool p384t1', variant: '1.3.36.3.3.2.8.1.1.12', score: cryptoScores.NOT_RECOMMENDED },
            { name: 'ECDHE_BRAINPOOL_P512r1', description: 'ECDHE Brainpool p512r1', variant: '1.3.36.3.3.2.8.1.1.13', score: cryptoScores.NOT_RECOMMENDED },
            { name: 'ECDHE_BRAINPOOL_P512t1', description: 'ECDHE Brainpool p512t1', variant: '1.3.36.3.3.2.8.1.1.14', score: cryptoScores.NOT_RECOMMENDED },
            // Brainpool curves for TLS 1.3: https://datatracker.ietf.org/doc/html/rfc8734
            // No variant ID (OID) can be found for these Brainpool curves.
            // These do not apply to ECDH, as TLS 1.3 does not support non-ephemeral ECDH key exchanges.
            // Assign score "NOT_RECOMMENDED" as they are not endorsed by IETF.
            { name: 'ECDHE_BRAINPOOL_P256r1_TLS13', description: 'ECDHE Brainpool p256r1-TLS13', score: cryptoScores.NOT_RECOMMENDED },
            { name: 'ECDHE_BRAINPOOL_P384r1_TLS13', description: 'ECDHE Brainpool p384r1-TLS13', score: cryptoScores.NOT_RECOMMENDED },
            { name: 'ECDHE_BRAINPOOL_P512r1_TLS13', description: 'ECDHE Brainpool p512r1-TLS13', score: cryptoScores.NOT_RECOMMENDED },
            // GHOST https://art.tools.ietf.org/id/draft-smyshlyaev-tls12-gost-suites-04.html
            // https://tools.ietf.org/id/draft-deremin-rfc4491-bis-01.html
            { name: 'ECDHE_GC256A', description: 'ECDHE Gost GC256A', variant: '1.2.643.7.1.2.1.1.1', score: cryptoScores.NOT_RECOMMENDED },
            { name: 'ECDHE_GC256B', description: 'ECDHE Gost GC256B', variant: '1.2.643.7.1.2.1.1.2', score: cryptoScores.NOT_RECOMMENDED },
            { name: 'ECDHE_GC256C', description: 'ECDHE Gost GC256C', variant: '1.2.643.7.1.2.1.1.3', score: cryptoScores.NOT_RECOMMENDED },
            { name: 'ECDHE_GC256D', description: 'ECDHE Gost GC256D', variant: '1.2.643.7.1.2.1.1.4', score: cryptoScores.NOT_RECOMMENDED },
            { name: 'ECDHE_GC512A', description: 'ECDHE Gost GC512A', variant: '1.2.643.7.1.2.1.2.1', score: cryptoScores.NOT_RECOMMENDED },
            { name: 'ECDHE_GC512B', description: 'ECDHE Gost GC512B', variant: '1.2.643.7.1.2.1.2.2', score: cryptoScores.NOT_RECOMMENDED },
            { name: 'ECDHE_GC512C', description: 'ECDHE Gost GC512C', variant: '1.2.643.7.1.2.1.2.3', score: cryptoScores.NOT_RECOMMENDED },
            { name: 'ECDHE_Custom', description: 'ECDHE Custom', score: cryptoScores.UNKNOWN_OR_CUSTOM },
            { name: 'ECDHE_SECT163k1', description: 'ECDHE sect163k1', variant: '1.3.132.0.1', score: cryptoScores.WEAK },
            { name: 'ECDHE_SECT163r1', description: 'ECDHE sect163r1', variant: '1.3.132.0.2', score: cryptoScores.WEAK },
            { name: 'ECDHE_SECT163r2', description: 'ECDHE sect163r2', variant: '1.3.132.0.15', score: cryptoScores.WEAK },
            { name: 'ECDHE_SECT193r1', description: 'ECDHE sect193r1', variant: '1.3.132.0.24', score: cryptoScores.NOT_RECOMMENDED },
            { name: 'ECDHE_SECT193r2', description: 'ECDHE sect193r2', variant: '1.3.132.0.25', score: cryptoScores.NOT_RECOMMENDED },
            { name: 'ECDHE_SECT233k1', description: 'ECDHE sect233k1', variant: '1.3.132.0.26', score: cryptoScores.NOT_RECOMMENDED },
            { name: 'ECDHE_SECT233r1', description: 'ECDHE sect233r1', variant: '1.3.132.0.27', score: cryptoScores.NOT_RECOMMENDED },
            { name: 'ECDHE_SECT239k1', description: 'ECDHE sect239k1', variant: '1.3.132.0.3', score: cryptoScores.NOT_RECOMMENDED },
            { name: 'ECDHE_SECT283k1', description: 'ECDHE sect283k1', variant: '1.3.132.0.16', score: cryptoScores.NOT_RECOMMENDED },
            { name: 'ECDHE_SECT283r1', description: 'ECDHE sect283r1', variant: '1.3.132.0.17', score: cryptoScores.NOT_RECOMMENDED },
            { name: 'ECDHE_SECT409k1', description: 'ECDHE sect409k1', variant: '1.3.132.0.36', score: cryptoScores.NOT_RECOMMENDED },
            { name: 'ECDHE_SECT409r1', description: 'ECDHE sect409r1', variant: '1.3.132.0.37', score: cryptoScores.NOT_RECOMMENDED },
            { name: 'ECDHE_SECT571k1', description: 'ECDHE sect571k1', variant: '1.3.132.0.38', score: cryptoScores.NOT_RECOMMENDED },
            { name: 'ECDHE_SECT571r1', description: 'ECDHE sect571r1', variant: '1.3.132.0.39', score: cryptoScores.NOT_RECOMMENDED },
            { name: 'ECDHE_SECP256r1', description: 'ECDHE secp256r1', variant: '1.2.840.10045.3.1.7', score: cryptoScores.STRONG_CLASSIC_BROKEN_QUANTUM },
            { name: 'ECDHE_SECP384r1', description: 'ECDHE secp384r1', variant: '1.3.132.0.34', score: cryptoScores.STRONG_CLASSIC_BROKEN_QUANTUM },
            { name: 'ECDHE_SECP521r1', description: 'ECDHE secp521r1', variant: '1.3.132.0.35', score: cryptoScores.NOT_RECOMMENDED },
            { name: 'ECDHE_SECP160k1', description: 'ECDHE secp160k1', variant: '1.3.132.0.9', score: cryptoScores.NOT_RECOMMENDED },
            { name: 'ECDHE_SECP160r1', description: 'ECDHE secp160r1', variant: '1.3.132.0.8', score: cryptoScores.NOT_RECOMMENDED },
            { name: 'ECDHE_SECP160r2', description: 'ECDHE secp160r2', variant: '1.3.132.0.30', score: cryptoScores.NOT_RECOMMENDED },
            { name: 'ECDHE_SECP192k1', description: 'ECDHE secp192k1', variant: '1.3.132.0.31', score: cryptoScores.NOT_RECOMMENDED },
            { name: 'ECDHE_SECP192r1', description: 'ECDHE secp192r1', variant: '1.2.840.10045.3.1.1', score: cryptoScores.NOT_RECOMMENDED },
            { name: 'ECDHE_SECP224k1', description: 'ECDHE secp224k1', variant: '1.3.132.0.32', score: cryptoScores.NOT_RECOMMENDED },
            { name: 'ECDHE_SECP224r1', description: 'ECDHE secp224r1', variant: '1.3.132.0.33', score: cryptoScores.NOT_RECOMMENDED },
            { name: 'ECDHE_SECP256k1', description: 'ECDHE secp256k1', variant: '1.3.132.0.10', score: cryptoScores.NOT_RECOMMENDED },
            // x448 and x25519 oids from https://tools.ietf.org/id/draft-ietf-curdle-pkix-07.html
            { name: 'ECDHE_x448', description: 'ECDHE-x448', variant: '1.3.101.111', score: cryptoScores.STRONG_CLASSIC_BROKEN_QUANTUM },
            { name: 'ECDHE_x25519', description: 'ECDHE-x25519', variant: '1.3.101.110', score: cryptoScores.STRONG_CLASSIC_BROKEN_QUANTUM },
            // Chinese SM9 standard
            { name: 'ECDHE_CurveSM2', description: 'ECDHE Curve SM2', score: cryptoScores.NOT_RECOMMENDED },
        ],
        purpose: CryptoPrimitivePurposes.KEY_EXCHANGE
    },
    ECDSA: {
        baseScore: cryptoScores.UNSPECIFIED_PARAMETERS,
        description: 'ECDSA',
        oid: '1.2.840.10045.2.1',
        hasDefault: true,
        primitives: [
            { name: 'ECDSA_BRAINPOOL_P160r1', description: 'ECDSA Brainpool p160r1', variant: '1.3.36.3.3.2.8.1.1.1', score: cryptoScores.WEAK },
            { name: 'ECDSA_BRAINPOOL_P160t1', description: 'ECDSA Brainpool p160t1', variant: '1.3.36.3.3.2.8.1.1.2', score: cryptoScores.WEAK },
            { name: 'ECDSA_BRAINPOOL_P192r1', description: 'ECDSA Brainpool p192r1', variant: '1.3.36.3.3.2.8.1.1.3', score: cryptoScores.WEAK },
            { name: 'ECDSA_BRAINPOOL_P192t1', description: 'ECDSA Brainpool p192t1', variant: '1.3.36.3.3.2.8.1.1.4', score: cryptoScores.WEAK },
            { name: 'ECDSA_BRAINPOOL_P224r1', description: 'ECDSA Brainpool p224r1', variant: '1.3.36.3.3.2.8.1.1.5', score: cryptoScores.NOT_RECOMMENDED },
            { name: 'ECDSA_BRAINPOOL_P224t1', description: 'ECDSA Brainpool p224t1', variant: '1.3.36.3.3.2.8.1.1.6', score: cryptoScores.NOT_RECOMMENDED },
            { name: 'ECDSA_BRAINPOOL_P256r1', description: 'ECDSA Brainpool p256r1', variant: '1.3.36.3.3.2.8.1.1.7', score: cryptoScores.NOT_RECOMMENDED },
            { name: 'ECDSA_BRAINPOOL_P256t1', description: 'ECDSA Brainpool p256t1', variant: '1.3.36.3.3.2.8.1.1.8', score: cryptoScores.NOT_RECOMMENDED },
            { name: 'ECDSA_BRAINPOOL_P320r1', description: 'ECDSA Brainpool p320r1', variant: '1.3.36.3.3.2.8.1.1.9', score: cryptoScores.NOT_RECOMMENDED },
            { name: 'ECDSA_BRAINPOOL_P320t1', description: 'ECDSA Brainpool p320t1', variant: '1.3.36.3.3.2.8.1.1.10', score: cryptoScores.NOT_RECOMMENDED },
            { name: 'ECDSA_BRAINPOOL_P384r1', description: 'ECDSA Brainpool p384r1', variant: '1.3.36.3.3.2.8.1.1.11', score: cryptoScores.NOT_RECOMMENDED },
            { name: 'ECDSA_BRAINPOOL_P384t1', description: 'ECDSA Brainpool p384t1', variant: '1.3.36.3.3.2.8.1.1.12', score: cryptoScores.NOT_RECOMMENDED },
            { name: 'ECDSA_BRAINPOOL_P512r1', description: 'ECDSA Brainpool p512r1', variant: '1.3.36.3.3.2.8.1.1.13', score: cryptoScores.NOT_RECOMMENDED },
            { name: 'ECDSA_BRAINPOOL_P512t1', description: 'ECDSA Brainpool p512t1', variant: '1.3.36.3.3.2.8.1.1.14', score: cryptoScores.NOT_RECOMMENDED },
            { name: 'ECDSA_SECT163k1', description: 'ECDSA sect163k1', variant: '1.3.132.0.1', score: cryptoScores.WEAK },
            { name: 'ECDSA_SECT163r1', description: 'ECDSA sect163r1', variant: '1.3.132.0.2', score: cryptoScores.WEAK },
            { name: 'ECDSA_SECT163r2', description: 'ECDSA sect163r2', variant: '1.3.132.0.15', score: cryptoScores.WEAK },
            { name: 'ECDSA_SECT193r1', description: 'ECDSA sect193r1', variant: '1.3.132.0.24', score: cryptoScores.NOT_RECOMMENDED },
            { name: 'ECDSA_SECT193r2', description: 'ECDSA sect193r2', variant: '1.3.132.0.25', score: cryptoScores.NOT_RECOMMENDED },
            { name: 'ECDSA_SECT233k1', description: 'ECDSA sect233k1', variant: '1.3.132.0.26', score: cryptoScores.NOT_RECOMMENDED },
            { name: 'ECDSA_SECT233r1', description: 'ECDSA sect233r1', variant: '1.3.132.0.27', score: cryptoScores.NOT_RECOMMENDED },
            { name: 'ECDSA_SECT239k1', description: 'ECDSA sect239k1', variant: '1.3.132.0.3', score: cryptoScores.NOT_RECOMMENDED },
            { name: 'ECDSA_SECT283k1', description: 'ECDSA sect283k1', variant: '1.3.132.0.16', score: cryptoScores.NOT_RECOMMENDED },
            { name: 'ECDSA_SECT283r1', description: 'ECDSA sect283r1', variant: '1.3.132.0.17', score: cryptoScores.NOT_RECOMMENDED },
            { name: 'ECDSA_SECT409k1', description: 'ECDSA sect409k1', variant: '1.3.132.0.36', score: cryptoScores.NOT_RECOMMENDED },
            { name: 'ECDSA_SECT409r1', description: 'ECDSA sect409r1', variant: '1.3.132.0.37', score: cryptoScores.NOT_RECOMMENDED },
            { name: 'ECDSA_SECT571k1', description: 'ECDSA sect571k1', variant: '1.3.132.0.38', score: cryptoScores.NOT_RECOMMENDED },
            { name: 'ECDSA_SECT571r1', description: 'ECDSA sect571r1', variant: '1.3.132.0.39', score: cryptoScores.NOT_RECOMMENDED },
            { name: 'ECDSA_SECP256r1', description: 'ECDSA secp256r1', variant: '1.2.840.10045.3.1.7', score: cryptoScores.STRONG_CLASSIC_BROKEN_QUANTUM },
            { name: 'ECDSA_SECP384r1', description: 'ECDSA secp384r1', variant: '1.3.132.0.34', score: cryptoScores.STRONG_CLASSIC_BROKEN_QUANTUM },
            { name: 'ECDSA_SECP521r1', description: 'ECDSA secp521r1', variant: '1.3.132.0.35', score: cryptoScores.NOT_RECOMMENDED },
            { name: 'ECDSA_SECP160k1', description: 'ECDSA secp160k1', variant: '1.3.132.0.9', score: cryptoScores.NOT_RECOMMENDED },
            { name: 'ECDSA_SECP160r1', description: 'ECDSA secp160r1', variant: '1.3.132.0.8', score: cryptoScores.NOT_RECOMMENDED },
            { name: 'ECDSA_SECP160r2', description: 'ECDSA secp160r2', variant: '1.3.132.0.30', score: cryptoScores.NOT_RECOMMENDED },
            { name: 'ECDSA_SECP192k1', description: 'ECDSA secp192k1', variant: '1.3.132.0.31', score: cryptoScores.NOT_RECOMMENDED },
            { name: 'ECDSA_SECP192r1', description: 'ECDSA secp192r1', variant: '1.2.840.10045.3.1.1', score: cryptoScores.NOT_RECOMMENDED },
            { name: 'ECDSA_SECP224k1', description: 'ECDSA secp224k1', variant: '1.3.132.0.32', score: cryptoScores.NOT_RECOMMENDED },
            { name: 'ECDSA_SECP224r1', description: 'ECDSA secp224r1', variant: '1.3.132.0.33', score: cryptoScores.NOT_RECOMMENDED },
            { name: 'ECDSA_SECP256k1', description: 'ECDSA secp256k1', variant: '1.3.132.0.10', score: cryptoScores.NOT_RECOMMENDED },
            // GHOST https://art.tools.ietf.org/id/draft-smyshlyaev-tls12-gost-suites-04.html
            // https://tools.ietf.org/id/draft-deremin-rfc4491-bis-01.html
            { name: 'ECDSA_GC256A', description: 'ECDSA Gost GC256A', variant: '1.2.643.7.1.2.1.1.1', score: cryptoScores.NOT_RECOMMENDED },
            { name: 'ECDSA_GC256B', description: 'ECDSA Gost GC256B', variant: '1.2.643.7.1.2.1.1.2', score: cryptoScores.NOT_RECOMMENDED },
            { name: 'ECDSA_GC256C', description: 'ECDSA Gost GC256C', variant: '1.2.643.7.1.2.1.1.3', score: cryptoScores.NOT_RECOMMENDED },
            { name: 'ECDSA_GC256D', description: 'ECDSA Gost GC256D', variant: '1.2.643.7.1.2.1.1.4', score: cryptoScores.NOT_RECOMMENDED },
            { name: 'ECDSA_GC512A', description: 'ECDSA Gost GC512A', variant: '1.2.643.7.1.2.1.2.1', score: cryptoScores.NOT_RECOMMENDED },
            { name: 'ECDSA_GC512B', description: 'ECDSA Gost GC512B', variant: '1.2.643.7.1.2.1.2.2', score: cryptoScores.NOT_RECOMMENDED },
            { name: 'ECDSA_GC512C', description: 'ECDSA Gost GC512C', variant: '1.2.643.7.1.2.1.2.3', score: cryptoScores.NOT_RECOMMENDED },
            { name: 'ECDSA_Custom', description: 'ECDSA Custom', score: cryptoScores.UNKNOWN_OR_CUSTOM },
            // Ed448 and Ed25519 oids from https://datatracker.ietf.org/doc/html/rfc8410
            { name: 'ECDSA_ED448', description: 'ECDSA-ED448', variant: '1.3.101.113', score: cryptoScores.STRONG_CLASSIC_BROKEN_QUANTUM },
            { name: 'ECDSA_ED25519', description: 'ECDSA-ED25519', variant: '1.3.101.112', score: cryptoScores.STRONG_CLASSIC_BROKEN_QUANTUM },
            { name: 'ECDSA_ED', description: 'ECDSA-ED', score: cryptoScores.STRONG_CLASSIC_BROKEN_QUANTUM },
            // Chinese SM9 standard
            { name: 'ECDSA_CurveSM2', description: 'ECDSA Curve SM2', score: cryptoScores.NOT_RECOMMENDED },
        ],
        purpose: CryptoPrimitivePurposes.SIGNATURE
    },
    ECOH: {
        baseScore: cryptoScores.NOT_RECOMMENDED,
        description: 'ECOH',
        hasDefault: true,
        purpose: CryptoPrimitivePurposes.HASH
    },
    ECQV: {
        baseScore: cryptoScores.UNSPECIFIED_PARAMETERS,
        description: 'ECQV',
        hasDefault: true,
        primitives: [
            { name: 'ECQV_160', description: 'ECQV-160', score: cryptoScores.WEAK },
            { name: 'ECQV_192', description: 'ECQV-192', score: cryptoScores.WEAK },
            { name: 'ECQV_224', description: 'ECQV-224', score: cryptoScores.NOT_RECOMMENDED },
            { name: 'ECQV_256', description: 'ECQV-256', score: cryptoScores.NOT_RECOMMENDED },
            { name: 'ECQV_384', description: 'ECQV-384', score: cryptoScores.NOT_RECOMMENDED },
            { name: 'ECQV_521', description: 'ECQV-521', score: cryptoScores.NOT_RECOMMENDED },
        ],
        purpose: CryptoPrimitivePurposes.SIGNATURE
    },
    FALCON: {
        baseScore: cryptoScores.NONSTANDARD_QSC,
        description: 'Falcon',
        hasDefault: true,
        primitives: [
            { name: 'FALCON_512', description: 'Falcon-512', score: cryptoScores.NONSTANDARD_QSC },
            { name: 'FALCON_1024', description: 'Falcon-1024', score: cryptoScores.NONSTANDARD_QSC },
        ],
        purpose: CryptoPrimitivePurposes.SIGNATURE
    },
    FFDH: {
        baseScore: cryptoScores.WEAK,
        description: 'FFDH',
        hasDefault: true,
        primitives: [
            { name: 'FFDH_toosmall', description: 'FFDH-Too Small', score: cryptoScores.BROKEN },
            { name: 'FFDH_512', description: 'FFDH-512', score: cryptoScores.WEAK },
            { name: 'FFDH_768', description: 'FFDH-768', score: cryptoScores.WEAK },
            { name: 'FFDH_1024', description: 'FFDH-1024', score: cryptoScores.WEAK },
            { name: 'FFDH_1536', description: 'FFDH-1536', score: cryptoScores.WEAK },
            { name: 'FFDH_2048', description: 'FFDH-2048', score: cryptoScores.MISUSED },
            { name: 'FFDH_3072', description: 'FFDH-3072', score: cryptoScores.MISUSED },
            { name: 'FFDH_4096', description: 'FFDH-4096', score: cryptoScores.MISUSED },
            { name: 'FFDH_6144', description: 'FFDH-6144', score: cryptoScores.MISUSED },
            { name: 'FFDH_8192', description: 'FFDH-8192', score: cryptoScores.MISUSED }
        ],
        purpose: CryptoPrimitivePurposes.KEY_EXCHANGE
    },
    FFDHE: {
        baseScore: cryptoScores.UNSPECIFIED_PARAMETERS,
        description: 'FFDHE',
        hasDefault: true,
        primitives: [
            { name: 'FFDHE_toosmall', description: 'FFDHE-Too Small', score: cryptoScores.BROKEN },
            { name: 'FFDHE_512', description: 'FFDHE-512', score: cryptoScores.WEAK },
            { name: 'FFDHE_768', description: 'FFDHE-768', score: cryptoScores.WEAK },
            { name: 'FFDHE_1024', description: 'FFDHE-1024', score: cryptoScores.WEAK },
            { name: 'FFDHE_1536', description: 'FFDHE-1536', score: cryptoScores.WEAK },
            { name: 'FFDHE_2048', description: 'FFDHE-2048', score: cryptoScores.STRONG_CLASSIC_BROKEN_QUANTUM },
            { name: 'FFDHE_3072', description: 'FFDHE-3072', score: cryptoScores.STRONG_CLASSIC_BROKEN_QUANTUM },
            { name: 'FFDHE_4096', description: 'FFDHE-4096', score: cryptoScores.NOT_RECOMMENDED },
            { name: 'FFDHE_6144', description: 'FFDHE-6144', score: cryptoScores.NOT_RECOMMENDED },
            { name: 'FFDHE_8192', description: 'FFDHE-8192', score: cryptoScores.NOT_RECOMMENDED }
        ],
        purpose: CryptoPrimitivePurposes.KEY_EXCHANGE
    },
    FORTEZZA: {
        baseScore: cryptoScores.BROKEN,
        description: 'FORTEZZA',
        hasDefault: true,
        purpose: CryptoPrimitivePurposes.BULK_ENCRYPTION
    },
    FORTEZZA_CBC: {
        baseScore: cryptoScores.BROKEN,
        description: 'FORTEZZA-CBC',
        hasDefault: true,
        purpose: CryptoPrimitivePurposes.BULK_ENCRYPTION
    },
    FORTEZZA_RC4: {
        baseScore: cryptoScores.BROKEN,
        description: 'FORTEZZA-RC4',
        hasDefault: true,
        purpose: CryptoPrimitivePurposes.BULK_ENCRYPTION
    },
    FRODODH: {
        baseScore: cryptoScores.NONSTANDARD_QSC,
        description: 'FrodoDH',
        hasDefault: true,
        primitives: [
            { name: 'FRODODH_640', description: 'FrodoDH-640', score: cryptoScores.NONSTANDARD_QSC },
            { name: 'FRODODH_976', description: 'FrodoDH-976', score: cryptoScores.NONSTANDARD_QSC },
            { name: 'FRODODH_1344', description: 'FrodoDH-1344', score: cryptoScores.NONSTANDARD_QSC },
        ],
        purpose: CryptoPrimitivePurposes.KEY_EXCHANGE
    },
    FRODOKEM: {
        baseScore: cryptoScores.NONSTANDARD_QSC,
        description: 'FrodoKEM',
        hasDefault: true,
        primitives: [
            { name: 'FRODOKEM_640', description: 'FrodoKEM-640', score: cryptoScores.NONSTANDARD_QSC },
            { name: 'FRODOKEM_976', description: 'FrodoKEM-976', score: cryptoScores.NONSTANDARD_QSC },
            { name: 'FRODOKEM_1344', description: 'FrodoKEM-1344', score: cryptoScores.NONSTANDARD_QSC },
        ],
        purpose: CryptoPrimitivePurposes.KEY_EXCHANGE
    },
    FSB: {
        baseScore: cryptoScores.NOT_RECOMMENDED,
        description: 'FSB',
        hasDefault: true,
        purpose: CryptoPrimitivePurposes.HASH
    },
    GCM: {
        baseScore: cryptoScores.QUANTUM_SAFE_LEVEL5,
        description: 'GCM',
        hasDefault: true,
        purpose: CryptoPrimitivePurposes.MODE_OF_OPERATION
    },
    // GOST for symmetric encryption
    GOST_ENC: {
        baseScore: cryptoScores.UNSPECIFIED_PARAMETERS,
        description: 'GOST-Encryption',
        hasDefault: true,
        primitives: [
            { name: 'KUZNYECHIK', description: 'KUZNYECHIK (GOST R 34.12-2015)', score: cryptoScores.WEAK },
            { name: 'MAGMA', description: 'MAGMA (GOST28147)', score: cryptoScores.BROKEN }
        ],
        purpose: CryptoPrimitivePurposes.BULK_ENCRYPTION
    },
    GR0STL: {
        baseScore: cryptoScores.NOT_RECOMMENDED,
        description: 'GR0STL',
        hasDefault: true,
        purpose: CryptoPrimitivePurposes.HASH
    },
    HAS: {
        baseScore: cryptoScores.BROKEN,
        description: 'HAS',
        primitives: [
            { name: 'HAS_160', description: 'HAS-160', score: cryptoScores.BROKEN },
        ],
        purpose: CryptoPrimitivePurposes.HASH
    },
    HAVAL: {
        baseScore: cryptoScores.BROKEN,
        description: 'HAVAL',
        hasDefault: true,
        primitives: [
            { name: 'HAVAL_128', description: 'HAVAL-128', score: cryptoScores.BROKEN },
            { name: 'HAVAL_256', description: 'HAVAL-256', score: cryptoScores.BROKEN }
        ],
        purpose: CryptoPrimitivePurposes.HASH

    },
    HMQV: {
        baseScore: cryptoScores.BROKEN,
        description: 'HMQV',
        hasDefault: true,
        purpose: CryptoPrimitivePurposes.KEY_EXCHANGE
    },
    HMAC: {
        baseScore: cryptoScores.UNSPECIFIED_PARAMETERS,
        description: 'HMAC',
        hasDefault: true,
        primitives: [
            { name: 'HMAC_SHA1_LT_160', description: 'HMAC-SHA1-LT-160', score: cryptoScores.MISUSED },
            { name: 'HMAC_SHA1_96', description: 'HMAC-SHA1-96', score: cryptoScores.MISUSED },
            { name: 'HMAC_SHA2_224', description: 'HMAC-SHA2-224', score: cryptoScores.QUANTUM_SAFE_LEVEL1 },
            { name: 'HMAC_SHA2_256', description: 'HMAC-SHA2-256', score: cryptoScores.QUANTUM_SAFE_LEVEL2 },
            { name: 'HMAC_SHA2_384', description: 'HMAC-SHA2-384', score: cryptoScores.QUANTUM_SAFE_LEVEL4 },
            { name: 'HMAC_SHA2_512', description: 'HMAC-SHA2-512', score: cryptoScores.QUANTUM_SAFE_LEVEL5 },
            { name: 'HMAC_MD5_LT_128', description: 'HMAC-MD5-LT-128', score: cryptoScores.MISUSED },
            { name: 'HMAC_MD5_96', description: 'HMAC-MD5-LT-96', score: cryptoScores.MISUSED },
        ],
        purpose: CryptoPrimitivePurposes.MAC
    },
    HQC: {
        baseScore: cryptoScores.UNSPECIFIED_PARAMETERS,
        description: 'HQC',
        hasDefault: true,
        primitives: [
            { name: 'HQC_128', description: 'HQC-128', score: cryptoScores.QUANTUM_SAFE_LEVEL1 },
            { name: 'HQC_192', description: 'HQC-192', score: cryptoScores.QUANTUM_SAFE_LEVEL3 },
            { name: 'HQC_256', description: 'HQC-256', score: cryptoScores.QUANTUM_SAFE_LEVEL5 },
        ],
        purpose: CryptoPrimitivePurposes.KEY_EXCHANGE
    },
    HSS: {
        baseScore: cryptoScores.QUANTUM_SAFE_LEVEL2,
        description: 'HSS',
        hasDefault: true,
        purpose: CryptoPrimitivePurposes.SIGNATURE
    },
    IDEA: {
        baseScore: cryptoScores.BROKEN,
        description: 'IDEA',
        hasDefault: true,
        purpose: CryptoPrimitivePurposes.BULK_ENCRYPTION
    },
    JH: {
        baseScore: cryptoScores.NOT_RECOMMENDED,
        description: 'JH',
        hasDefault: true,
        purpose: CryptoPrimitivePurposes.HASH
    },
    KEA: {
        baseScore: cryptoScores.WEAK,
        description: 'KEA',
        hasDefault: true,
        purpose: CryptoPrimitivePurposes.SIGNATURE
    },
    KMAC: {
        baseScore: cryptoScores.UNSPECIFIED_PARAMETERS,
        description: 'KMAC',
        hasDefault: true,
        primitives: [
            { name: 'KMAC_SHA_3_224', description: 'KMAC-SHA-3-224', score: cryptoScores.QUANTUM_SAFE_LEVEL1 },
            { name: 'KMAC_SHA_3_256', description: 'KMAC-SHA-3-256', score: cryptoScores.QUANTUM_SAFE_LEVEL2 },
            { name: 'KMAC_SHA_3_384', description: 'KMAC-SHA-3-384', score: cryptoScores.QUANTUM_SAFE_LEVEL4 },
            { name: 'KMAC_SHA_3_512', description: 'KMAC-SHA-3-512', score: cryptoScores.QUANTUM_SAFE_LEVEL4 }
        ],
        purpose: CryptoPrimitivePurposes.MAC
    },
    KRB: {
        baseScore: cryptoScores.UNKNOWN_OR_CUSTOM,
        description: 'KRB',
        primitives: [
            { name: 'KRB5_EXPORT', description: 'KRB5-EXPORT', score: cryptoScores.BROKEN },
            { name: 'KRB5', description: 'KRB5', score: cryptoScores.UNKNOWN_OR_CUSTOM }
        ],
        purpose: CryptoPrimitivePurposes.KEY_EXCHANGE
    },
    KYBER: {
        baseScore: cryptoScores.NONSTANDARD_QSC,
        description: 'KYBER',
        hasDefault: true,
        primitives: [
            { name: 'KYBER_512', description: 'KYBER-512', score: cryptoScores.NONSTANDARD_QSC },
            { name: 'KYBER_768', description: 'KYBER-768', score: cryptoScores.NONSTANDARD_QSC },
            { name: 'KYBER_1024', description: 'KYBER-1024', score: cryptoScores.NONSTANDARD_QSC },
        ],
        purpose: CryptoPrimitivePurposes.KEY_EXCHANGE
    },
    LMS: {
        baseScore: cryptoScores.QUANTUM_SAFE_LEVEL2,
        description: 'LMS',
        hasDefault: true,
        purpose: CryptoPrimitivePurposes.SIGNATURE
    },
    LSH: {
        baseScore: cryptoScores.UNSPECIFIED_PARAMETERS,
        description: 'LSH',
        hasDefault: true,
        primitives: [
            { name: 'LSH_256', description: 'LSH-256', score: cryptoScores.QUANTUM_SAFE_LEVEL2 },
            { name: 'LSH_384', description: 'LSH-384', score: cryptoScores.QUANTUM_SAFE_LEVEL4 },
            { name: 'LSH_512', description: 'LSH-512', score: cryptoScores.QUANTUM_SAFE_LEVEL5 },
        ],
        purpose: CryptoPrimitivePurposes.HASH
    },
    MD: {
        baseScore: cryptoScores.BROKEN,
        description: 'MD',
        hasDefault: true,
        primitives: [
            { name: 'MD2', description: 'MD2' },
            { name: 'MD4', description: 'MD4' },
            { name: 'MD5', description: 'MD5' },
            { name: 'MD6', description: 'MD6', score: cryptoScores.NOT_RECOMMENDED },
        ],
        purpose: CryptoPrimitivePurposes.HASH
    },
    MQV: {
        baseScore: cryptoScores.NOT_RECOMMENDED,
        description: 'MQV',
        hasDefault: true,
        purpose: CryptoPrimitivePurposes.KEY_EXCHANGE
    },
    NHDH: {
        baseScore: cryptoScores.NONSTANDARD_QSC,
        description: 'NHDH',
        hasDefault: true,
        purpose: CryptoPrimitivePurposes.KEY_EXCHANGE
    },
    NTRU: {
        baseScore: cryptoScores.NONSTANDARD_QSC,
        description: 'NTRU',
        hasDefault: true,
        primitives: [
            { name: 'NTRU_HPS2048509', description: 'ntruhps2048509', score: cryptoScores.NONSTANDARD_QSC },
            { name: 'NTRU_HPS2048677', description: 'ntruhps2048677', score: cryptoScores.NONSTANDARD_QSC },
            { name: 'NTRU_HPS4096821', description: 'ntruhps409682', score: cryptoScores.NONSTANDARD_QSC },
            { name: 'NTRU_HRSS701', description: 'ntruhrss701', score: cryptoScores.NONSTANDARD_QSC },
        ],
        purpose: CryptoPrimitivePurposes.KEY_EXCHANGE
    },
    NTRU_PRIME: {
        baseScore: cryptoScores.NONSTANDARD_QSC,
        description: 'NTRU Prime',
        hasDefault: true,
        primitives: [
            { name: 'NTRU_PRIME_653', description: 'SNTRUP-653', score: cryptoScores.NONSTANDARD_QSC },
            { name: 'NTRU_PRIME_761', description: 'SNTRUP-761', score: cryptoScores.NONSTANDARD_QSC },
            { name: 'NTRU_PRIME_857', description: 'SNTRUP-857', score: cryptoScores.NONSTANDARD_QSC },
            { name: 'NTRU_PRIME_953', description: 'SNTRUP-953', score: cryptoScores.NONSTANDARD_QSC },
            { name: 'NTRU_PRIME_1013', description: 'SNTRUP-1013', score: cryptoScores.NONSTANDARD_QSC },
            { name: 'NTRU_PRIME_1277', description: 'SNTRUP-1277', score: cryptoScores.NONSTANDARD_QSC },
        ],
        purpose: CryptoPrimitivePurposes.KEY_EXCHANGE
    },
    NULL_KE: {
        baseScore: cryptoScores.BROKEN,
        description: 'NULL-KE',
        hasDefault: true,
        purpose: CryptoPrimitivePurposes.KEY_EXCHANGE
    },
    NULL_SIG: {
        baseScore: cryptoScores.BROKEN,
        description: 'NULL-SIG',
        hasDefault: true,
        purpose: CryptoPrimitivePurposes.SIGNATURE
    },
    NULL_HASH: {
        baseScore: cryptoScores.BROKEN,
        description: 'NULL-HASH',
        hasDefault: true,
        purpose: CryptoPrimitivePurposes.HASH
    },
    NULL_ENC: {
        baseScore: cryptoScores.BROKEN,
        description: 'NULL-ENC',
        hasDefault: true,
        purpose: CryptoPrimitivePurposes.BULK_ENCRYPTION
    },
    NULL_MAC: {
        baseScore: cryptoScores.BROKEN,
        description: 'NULL-MAC',
        hasDefault: true,
        purpose: CryptoPrimitivePurposes.MAC
    },
    OFB: {
        baseScore: cryptoScores.QUANTUM_SAFE_LEVEL5,
        description: 'OFB',
        hasDefault: true,
        purpose: CryptoPrimitivePurposes.MODE_OF_OPERATION
    },
    OCB1: {
        baseScore: cryptoScores.QUANTUM_SAFE_LEVEL5,
        description: 'OCB1',
        hasDefault: true,
        purpose: CryptoPrimitivePurposes.MODE_OF_OPERATION
    },
    OCB2: {
        baseScore: cryptoScores.QUANTUM_SAFE_LEVEL5,
        description: 'OCB2',
        hasDefault: true,
        purpose: CryptoPrimitivePurposes.MODE_OF_OPERATION
    },
    OCB3: {
        baseScore: cryptoScores.QUANTUM_SAFE_LEVEL5,
        description: 'OCB3',
        hasDefault: true,
        purpose: CryptoPrimitivePurposes.MODE_OF_OPERATION
    },
    XTS: {
        baseScore: cryptoScores.QUANTUM_SAFE_LEVEL5,
        description: 'XTS',
        hasDefault: true,
        purpose: CryptoPrimitivePurposes.MODE_OF_OPERATION
    },
    PICNIC: {
        baseScore: cryptoScores.NONSTANDARD_QSC,
        description: 'Picnic',
        hasDefault: true,
        primitives: [
            { name: 'PICNIC3_L1', description: 'PICNIC3-L1', score: cryptoScores.NONSTANDARD_QSC },
            { name: 'PICNIC3_L3', description: 'PICNIC3-L3', score: cryptoScores.NONSTANDARD_QSC },
            { name: 'PICNIC3_L5', description: 'PICNIC3-L5', score: cryptoScores.NONSTANDARD_QSC },
        ],
        purpose: CryptoPrimitivePurposes.SIGNATURE
    },
    Poly1305: {
        baseScore: cryptoScores.QUANTUM_SAFE_LEVEL1,
        description: 'POLY1305',
        hasDefault: true,
        purpose: CryptoPrimitivePurposes.MAC
    },
    PSK_KE: {
        baseScore: cryptoScores.UNKNOWN_OR_CUSTOM,
        description: 'PSK-KE',
        hasDefault: true,
        purpose: CryptoPrimitivePurposes.KEY_EXCHANGE
    },
    PSK_AUTH: {
        baseScore: cryptoScores.UNKNOWN_OR_CUSTOM,
        description: 'PSK-AUTH',
        hasDefault: true,
        purpose: CryptoPrimitivePurposes.SIGNATURE
    },
    RADIO_GATUN: {
        baseScore: cryptoScores.NOT_RECOMMENDED,
        description: 'RadioGatún',
        hasDefault: true,
        purpose: CryptoPrimitivePurposes.HASH
    },
    RC: {
        baseScore: cryptoScores.BROKEN,
        description: 'RC',
        hasDefault: true,
        primitives: [
            { name: 'RC2_40', description: 'RC2-40' },
            { name: 'RC2_56', description: 'RC2-56' },
            { name: 'RC2_128', description: 'RC2-128' },
            { name: 'RC4_40', description: 'RC4-40' },
            { name: 'RC4_56', description: 'RC4-56' },
            { name: 'RC4_64', description: 'RC4-64' },
            { name: 'RC4_128', description: 'RC4-128' },
        ],
        purpose: CryptoPrimitivePurposes.BULK_ENCRYPTION
    },
    RIPEMD: {
        baseScore: cryptoScores.UNSPECIFIED_PARAMETERS,
        description: 'RIPEMD',
        hasDefault: true,
        primitives: [
            { name: 'RIPEMD_128', description: 'RIPEMD-128', score: cryptoScores.BROKEN },
            { name: 'RIPEMD_160', description: 'RIPEMD-160', score: cryptoScores.WEAK },
            { name: 'RIPEMD_320', description: 'RIPEMD-320', score: cryptoScores.NOT_RECOMMENDED },
        ],
        purpose: CryptoPrimitivePurposes.HASH
    },
    RSA_KE: {
        baseScore: cryptoScores.UNSPECIFIED_PARAMETERS,
        description: 'RSA-KE',
        oid: '1.2.840.113549.1.1.1',
        hasDefault: true,
        primitives: [
            { name: 'RSA_KE_toosmall', description: 'RSA-KE-Too Small', score: cryptoScores.BROKEN },
            { name: 'RSA_KE_512', description: 'RSA-KE-512', score: cryptoScores.BROKEN },
            { name: 'RSA_KE_1024', description: 'RSA-KE-1024', score: cryptoScores.WEAK },
            { name: 'RSA_KE_2048', description: 'RSA-KE-2048', score: cryptoScores.NOT_RECOMMENDED },
            { name: 'RSA_KE_3072', description: 'RSA-KE-3072', score: cryptoScores.NOT_RECOMMENDED },
            { name: 'RSA_KE_4096', description: 'RSA-KE-4096', score: cryptoScores.NOT_RECOMMENDED }
        ],
        purpose: CryptoPrimitivePurposes.KEY_EXCHANGE
    },
    RSA_SIG: {
        baseScore: cryptoScores.UNSPECIFIED_PARAMETERS,
        description: 'RSA-Sig',
        oid: '1.2.840.113549.1.1.1',
        hasDefault: true,
        primitives: [
            { name: 'RSA_SIG_toosmall', description: 'RSA-Sig-Too Small', score: cryptoScores.BROKEN },
            { name: 'RSA_SIG_512', description: 'RSA-Sig-512', score: cryptoScores.BROKEN },
            { name: 'RSA_SIG_1024', description: 'RSA-Sig-1024', score: cryptoScores.WEAK },
            { name: 'RSA_SIG_2048', description: 'RSA-Sig-2048', score: cryptoScores.STRONG_CLASSIC_BROKEN_QUANTUM },
            { name: 'RSA_SIG_3072', description: 'RSA-Sig-3072', score: cryptoScores.STRONG_CLASSIC_BROKEN_QUANTUM },
            { name: 'RSA_SIG_4096', description: 'RSA-Sig-4096', score: cryptoScores.STRONG_CLASSIC_BROKEN_QUANTUM },
        ],
        purpose: CryptoPrimitivePurposes.SIGNATURE
    },
    RSA_EXPORT: {
        baseScore: cryptoScores.BROKEN,
        description: 'RSA-EXPORT',
        hasDefault: true,
        purpose: CryptoPrimitivePurposes.KEY_EXCHANGE
    },
    SABER: {
        baseScore: cryptoScores.NONSTANDARD_QSC,
        description: 'SABER',
        hasDefault: true,
        primitives: [
            { name: 'SABER_FIRE', description: 'FireSABER', score: cryptoScores.NONSTANDARD_QSC },
            { name: 'SABER_SABER', description: 'SaberSABER', score: cryptoScores.NONSTANDARD_QSC },
            { name: 'SABER_LIGHT', description: 'LightSABER', score: cryptoScores.NONSTANDARD_QSC }
        ],
        purpose: CryptoPrimitivePurposes.KEY_EXCHANGE
    },
    SEED: {
        baseScore: cryptoScores.STRONG_CLASSIC_UNKNOWN_QUANTUM,
        description: 'SEED',
        hasDefault: true,
        purpose: CryptoPrimitivePurposes.BULK_ENCRYPTION
    },
    SERPENT: {
        baseScore: cryptoScores.NOT_RECOMMENDED,
        description: 'SERPENT',
        hasDefault: true,
        primitives: [
            { name: 'SERPENT_128', description: 'Serpent 128', score: cryptoScores.NOT_RECOMMENDED },
            { name: 'SERPENT_192', description: 'Serpent 192', score: cryptoScores.NOT_RECOMMENDED },
            { name: 'SERPENT_256', description: 'Serpent 256', score: cryptoScores.NOT_RECOMMENDED }
        ],
        purpose: CryptoPrimitivePurposes.BULK_ENCRYPTION
    },
    SHA: {
        baseScore: cryptoScores.UNSPECIFIED_PARAMETERS,
        description: 'SHA',
        hasDefault: true,
        primitives: [
            { name: 'SHA_1', description: 'SHA-1', score: cryptoScores.BROKEN },
            { name: 'SHA_192', description: 'SHA-192', score: cryptoScores.STRONG_CLASSIC_UNKNOWN_QUANTUM },
            { name: 'SHA_224', description: 'SHA-224', score: cryptoScores.QUANTUM_SAFE_LEVEL1 },
            { name: 'SHA_256', description: 'SHA-256', score: cryptoScores.QUANTUM_SAFE_LEVEL2 },
            { name: 'SHA_384', description: 'SHA-384', score: cryptoScores.QUANTUM_SAFE_LEVEL4 },
            { name: 'SHA_512', description: 'SHA-512', score: cryptoScores.QUANTUM_SAFE_LEVEL5 },
            { name: 'SHA_3_224', description: 'SHA-3-224', score: cryptoScores.QUANTUM_SAFE_LEVEL1 },
            { name: 'SHA_3_256', description: 'SHA-3-256', score: cryptoScores.QUANTUM_SAFE_LEVEL2 },
            { name: 'SHA_3_384', description: 'SHA-3-384', score: cryptoScores.QUANTUM_SAFE_LEVEL4 },
            { name: 'SHA_3_512', description: 'SHA-3-512', score: cryptoScores.QUANTUM_SAFE_LEVEL5 },
        ],
        purpose: CryptoPrimitivePurposes.HASH
    },
    SHAKE: {
        baseScore: cryptoScores.UNSPECIFIED_PARAMETERS,
        description: 'SHAKE',
        hasDefault: true,
        primitives: [
            { name: 'SHAKE_128', description: 'SHAKE-128', score: cryptoScores.QUANTUM_SAFE_LEVEL2 },
            { name: 'SHAKE_256', description: 'SHAKE-256', score: cryptoScores.QUANTUM_SAFE_LEVEL5 }
        ],
        purpose: CryptoPrimitivePurposes.HASH
    },
    SIDH: {
        baseScore: cryptoScores.BROKEN,
        description: 'SIDH',
        hasDefault: true,
        primitives: [
            { name: 'SIDH_P434', description: 'SIDH-p434', score: cryptoScores.BROKEN },
            { name: 'SIDH_P503', description: 'SIDH-p503', score: cryptoScores.BROKEN },
            { name: 'SIDH_P610', description: 'SIDH-p610', score: cryptoScores.BROKEN },
            { name: 'SIDH_P751', description: 'SIDH-p751', score: cryptoScores.BROKEN },
        ],
        purpose: CryptoPrimitivePurposes.KEY_EXCHANGE
    },
    SIKE: {
        baseScore: cryptoScores.BROKEN,
        description: 'SIKE',
        hasDefault: true,
        primitives: [
            { name: 'SIKE_P434', description: 'SIKE-p434', score: cryptoScores.BROKEN },
            { name: 'SIKE_P503', description: 'SIKE-p503', score: cryptoScores.BROKEN },
            { name: 'SIKE_P610', description: 'SIKE-p610', score: cryptoScores.BROKEN },
            { name: 'SIKE_P751', description: 'SIKE-p751', score: cryptoScores.BROKEN },
        ],
        purpose: CryptoPrimitivePurposes.KEY_EXCHANGE
    },
    SKEIN: {
        baseScore: cryptoScores.NOT_RECOMMENDED,
        description: 'Skein',
        hasDefault: true,
        purpose: CryptoPrimitivePurposes.HASH
    },
    SKIPJACK: {
        baseScore: cryptoScores.BROKEN,
        description: 'Skipjack',
        hasDefault: true,
        purpose: CryptoPrimitivePurposes.BULK_ENCRYPTION
    },
    SNEFRU: {
        baseScore: cryptoScores.BROKEN,
        description: 'Snefru',
        hasDefault: true,
        primitives: [
            { name: 'SNEFRU_128', description: 'Snefru-128' },
            { name: 'SNEFRU_256', description: 'Snefru-256' },
        ],
        purpose: CryptoPrimitivePurposes.HASH
    },
    SM3: {
        baseScore: cryptoScores.NOT_RECOMMENDED,
        description: 'SM3',
        hasDefault: true,
        purpose: CryptoPrimitivePurposes.HASH
    },
    SM4: {
        baseScore: cryptoScores.NOT_RECOMMENDED,
        description: 'SM4',
        hasDefault: true,
        purpose: CryptoPrimitivePurposes.BULK_ENCRYPTION
    },
    SPECTRAL_HASH: {
        baseScore: cryptoScores.BROKEN,
        description: 'Spectral Hash',
        purpose: CryptoPrimitivePurposes.HASH
    },
    SPHINCS: {
        baseScore: cryptoScores.NONSTANDARD_QSC,
        description: 'SPHINCS',
        hasDefault: true,
        primitives: [
            { name: 'SPHINCS_128S', description: 'SPHINCS-128s', score: cryptoScores.NONSTANDARD_QSC },
            { name: 'SPHINCS_128F', description: 'SPHINCS-128f', score: cryptoScores.NONSTANDARD_QSC },
            { name: 'SPHINCS_192S', description: 'SPHINCS-192s', score: cryptoScores.NONSTANDARD_QSC },
            { name: 'SPHINCS_192F', description: 'SPHINCS-192f', score: cryptoScores.NONSTANDARD_QSC },
            { name: 'SPHINCS_256S', description: 'SPHINCS-256s', score: cryptoScores.NONSTANDARD_QSC },
            { name: 'SPHINCS_256F', description: 'SPHINCS-256f', score: cryptoScores.NONSTANDARD_QSC },
        ],
        purpose: CryptoPrimitivePurposes.SIGNATURE
    },
    SRP: {
        baseScore: cryptoScores.UNKNOWN_OR_CUSTOM,
        description: 'SRP',
        hasDefault: true,
        purpose: CryptoPrimitivePurposes.KEY_EXCHANGE
    },
    STREEBOG: {
        baseScore: cryptoScores.WEAK,
        description: 'Streebog',
        hasDefault: true,
        primitives: [
            { name: 'STREEBOG_256', description: 'Streebog-256' },
            { name: 'STREEBOG_512', description: 'Streebog-512' },
        ],
        purpose: CryptoPrimitivePurposes.HASH
    },
    TDES: {
        baseScore: cryptoScores.BROKEN,
        description: '3DES',
        hasDefault: true,
        purpose: CryptoPrimitivePurposes.BULK_ENCRYPTION
    },
    TIGER: {
        baseScore: cryptoScores.WEAK,
        description: 'TIGER',
        hasDefault: true,
        purpose: CryptoPrimitivePurposes.HASH
    },
    TWOFISH: {
        baseScore: cryptoScores.NOT_RECOMMENDED,
        description: 'Twofish',
        hasDefault: true,
        primitives: [
            { name: 'TWOFISH_128', description: 'Twofish-128' },
            { name: 'TWOFISH_192', description: 'Twofish-192' },
            { name: 'TWOFISH_256', description: 'Twofish-256' },
        ],
        purpose: CryptoPrimitivePurposes.BULK_ENCRYPTION
    },
    UNKNOWN: {
        baseScore: cryptoScores.UNKNOWN_OR_CUSTOM,
        description: 'Unknown',
        hasDefault: true,
        purpose: CryptoPrimitivePurposes.SIGNATURE
    },
    VKO_GOST: {
        baseScore: cryptoScores.WEAK,
        description: 'VKO GOST',
        hasDefault: true,
        primitives: [
            { name: 'VKO_GOST_34_10_2001', description: 'VKO GOST 34.10-2001' },
            { name: 'VKO_GOST_34_10_94', description: 'VKO GOST 34.10-94' },
        ],
        purpose: CryptoPrimitivePurposes.KEY_EXCHANGE
    },
    WHIRLPOOL: {
        baseScore: cryptoScores.QUANTUM_SAFE_LEVEL5,
        description: 'Whirlpool',
        hasDefault: true,
        purpose: CryptoPrimitivePurposes.HASH
    },
    GOSTR341112: {
        baseScore: cryptoScores.WEAK,
        description: 'GOSTR341112',
        hasDefault: true,
        purpose: CryptoPrimitivePurposes.KEY_EXCHANGE
    },
    // GOST for hash
    GOST_HASH: {
        baseScore: cryptoScores.WEAK,
        description: 'GOST-Hash',
        hasDefault: true,
        purpose: CryptoPrimitivePurposes.HASH
    },
    XMSS: {
        baseScore: cryptoScores.QUANTUM_SAFE_LEVEL2,
        description: 'XMSS',
        hasDefault: true,
        purpose: CryptoPrimitivePurposes.SIGNATURE
    },
    XMSSMT: {
        baseScore: cryptoScores.QUANTUM_SAFE_LEVEL2,
        description: 'XMSS-MT',
        hasDefault: true,
        purpose: CryptoPrimitivePurposes.SIGNATURE
    },
    ZUC: {
        baseScore: cryptoScores.NOT_RECOMMENDED,
        description: 'ZUC',
        hasDefault: true,
        primitives: [
            { name: 'ZUC_128', description: 'ZUC-128' },
            { name: 'ZUC_256', description: 'ZUC-256' },
        ],
        purpose: CryptoPrimitivePurposes.BULK_ENCRYPTION
    },
    GPP3_MAC: {
        baseScore: cryptoScores.BROKEN,
        description: '3GPP MAC',
        primitives: [
            { name: 'GPP3_128_EIA3', description: '3GPP 128-EIA3' },
        ],
        purpose: CryptoPrimitivePurposes.MAC
    },
    // 3GPP for symmetric encryption
    GPP3: {
        baseScore: cryptoScores.NOT_RECOMMENDED,
        description: '3GPP',
        primitives: [
            { name: 'GPP3_128_EEA3', description: '3GPP 128-EEA3' },
        ],
        purpose: CryptoPrimitivePurposes.BULK_ENCRYPTION
    },
    PLAIN_TEXT: {
        baseScore: cryptoScores.BROKEN,
        description: 'PLAIN_TEXT',
        hasDefault: true,
        purpose: CryptoPrimitivePurposes.BULK_ENCRYPTION
    },
}

const protocolVariant = {
    TLS: {
        description: 'TLS 1.0',
        codePoint: `x'301'::int`,
        baseScore: cryptoScores.BROKEN,
        primitives: [
            { name: 'TLS Unknown', codePoint: 0x111, score: cryptoScores.UNSPECIFIED_PARAMETERS }, // We use a fake code point for TLS-Unknown, which will not be used by any legit TLS version.
            { name: 'SSL 3', codePoint: 0x300, score: cryptoScores.BROKEN },
            { name: 'TLS 1.0', codePoint: 0x301, score: cryptoScores.BROKEN },
            { name: 'TLS 1.1', codePoint: 0x302, score: cryptoScores.BROKEN },
            { name: 'TLS 1.2', codePoint: 0x303, score: cryptoScores.QUANTUM_SAFE_LEVEL5 },
            { name: 'TLS 1.2 (calculated)', codePoint: 0x103, score: cryptoScores.QUANTUM_SAFE_LEVEL5 }, // We give our "calculated" version a special code point, so that it will not collide with the equivalent ingested version. (But the crypto score should remain the same.)
            { name: 'TLS 1.3', codePoint: 0x304, score: cryptoScores.QUANTUM_SAFE_LEVEL5 },
        ],
    },
    SSH: {
        description: 'SSH 2.0',
        baseScore: cryptoScores.QUANTUM_SAFE_LEVEL5,
    },
    PLAIN_TEXT: {
        description: 'PLAIN_TEXT',
        baseScore: cryptoScores.BROKEN,
    }
}

exports.cryptoPrimitives = cryptoPrimitives
exports.protocolVariant = protocolVariant
