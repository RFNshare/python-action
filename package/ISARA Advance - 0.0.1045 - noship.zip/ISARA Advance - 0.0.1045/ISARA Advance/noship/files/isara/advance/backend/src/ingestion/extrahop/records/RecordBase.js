/**
 * @file RecordBase.js - 0.0.1045 - ea4595bfd3488684d225574ed7d4c198074d49ba
 * 
 * @copyright Copyright (C) 2016-2023, ISARA Corporation, All Rights Reserved.
 * 
 * @license The code and other content set out herein is not in the public
 * domain, is considered a trade secret and is confidential to ISARA
 * Corporation. Use, reproduction or distribution, in whole or in part, of such
 * code or other content is strictly prohibited except by express written
 * permission of ISARA Corporation. Please contact ISARA Corporation at
 * info@isara.com for more information.
 */

// /**
//  * Abstract base class for extrahop records. Attempts to parse lowest common
//  * denominator information from records. Expected to be augmented by
//  * derived classes to parse special purpose data.
//  *
//  * @module extrahop/records/RecordBase
// */

// const { allTypes } = require('../../../isaraql/schemaDiscovery')

// const { extrahopDiscoveryKey, populateObservedFields } = require('../extrahopUtils')

// const { getRoundedObservationTime, populateTags } = require('../../commonIngestion')

// class RecordBase {
//     constructor(data, cacheMaps) {
//         this.cacheMaps = cacheMaps

//         this.clientDiscoveryID = data._source.client.value[0]
//         this.serverDiscoveryID = data._source.server.value[0]

//         // TODO: GAP1620 - this needs to be adapted a bit to deal with flows, where
//         // the client and server are ambiguous (sender / receiver)
//         this.clientAddress = this.parseAddr(data._source.clientAddr, this.clientDiscoveryID)
//         this.serverAddress = this.parseAddr(data._source.serverAddr, this.serverDiscoveryID)
//         this.serverPort = data._source.serverPort

//         this.rawObservationTime = data._source.timestamp
//         this.observationTime = getRoundedObservationTime(data._source.timestamp)
//         let l4Types = allTypes['Layer4Protocol']._enum.idByName

//         // not all record types include the protocol if it's implied.
//         let l4Protocol = l4Types[data._source.proto]
//         if (l4Protocol !== undefined) {
//             this.l4Protocol = l4Protocol
//         } else {
//             this.l4Protocol = l4Types['TCP']
//         }
//     }

//     parseAddr(addrInfo, discoveryID) {
//         let result = {
//             address: addrInfo.value,
//             addressIPVersion: addrInfo.type === "ipaddr4" ? 4 : 6
//         }

//         let found = false
//         let deviceID = this.cacheMaps.discoveryIDMap[discoveryID]
//         if (addrInfo.value in this.cacheMaps.deviceAddressIDMap) {
//             let addressEntries = this.cacheMaps.deviceAddressIDMap[addrInfo.value]
//             if (deviceID !== undefined) {
//                 if (addressEntries[deviceID] !== undefined) {
//                     result = {
//                         id: addressEntries[deviceID].addressID
//                     }

//                     found = true
//                 }
//             }

//         }

//         if (!found) {
//             if (!deviceID) {
//                 // if we had no mapping for this device address, add a device entry, as it is most likely an external host
//                 // (extrahop only keeps device entries for devices on the local network)
//                 result.device = {
//                     deviceType: allTypes['DeviceType']._enum.idByName['UNKNOWN'],
//                     friendlyName: addrInfo.value,
//                     deviceAttributes: [
//                         {
//                             name: extrahopDiscoveryKey,
//                             value: discoveryID
//                         }
//                     ]
//                 }

//             } else {
//                 result.device = {
//                     id: deviceID
//                 }
//             }

//             populateTags(result.device, 'deviceTags', this.cacheMaps.tags)
//         }

//         populateObservedFields(addrInfo, this.observationTime)

//         return result
//     }

//     getBaseConnectionObject() {
//         let cdap = {
//             l4Protocol: this.l4Protocol,
//             // we currently don't care about client ports, but this may change in the future. If so, it is available
//             // from records.
//             port: -1,
//             deviceAddress: this.clientAddress
//         }
//         let sdap = {
//             l4Protocol: this.l4Protocol,
//             port: this.serverPort,
//             deviceAddress: this.serverAddress
//         }
//         populateObservedFields(cdap, this.observationTime)
//         populateObservedFields(sdap, this.observationTime)
//         let connection = {
//             observationTime: this.observationTime.getTime(),
//             clientDeviceAddressPort: cdap,
//             serverDeviceAddressPort: sdap,
//             connectionCertificates: [],
//             connectionCipherSuites: [],
//             connectionCryptoPrimitives: [],
//             connectionProtocolVariants: []
//         }

//         populateTags(connection, 'connectionTags', this.cacheMaps.tags)

//         return connection
//     }
// }

// exports.RecordBase = RecordBase