/**
 * @file calculateCryptoScore.js - 0.0.1045 - ea4595bfd3488684d225574ed7d4c198074d49ba
 * 
 * @copyright Copyright (C) 2016-2023, ISARA Corporation, All Rights Reserved.
 * 
 * @license The code and other content set out herein is not in the public
 * domain, is considered a trade secret and is confidential to ISARA
 * Corporation. Use, reproduction or distribution, in whole or in part, of such
 * code or other content is strictly prohibited except by express written
 * permission of ISARA Corporation. Please contact ISARA Corporation at
 * info@isara.com for more information.
 */

var log = require('../util/log')(module)

const {
    initDbConnection,
} = require('./dbHelpers')

const { updateCryptoScoresForDevice, updateCryptoScoresForConnection } = require('../util/scoreHelpers')

var connection = null

async function main() {

    log.log('Entered main')
    log.log('Calculating crypto scores...')

    connection = await initDbConnection()

    try {

        let promises = []
        let j = 0
        let chunkSize = 1000


        const defineChunkArray = (count) => {

            let toReturn = []
            for (let y = 0; y < Math.ceil(count / chunkSize); y++) {
                toReturn.push(chunkSize)
            }

            return toReturn

        }

        const missingConnectionCount = (await connection.query(`SELECT count("id") FROM "Connection" WHERE "id" IN (select id  from "Connection"  Except Select "connection" from "ConnectionScore" );`)).rows[0].count
        const missingDeviceCount = (await connection.query(`SELECT count("id") FROM "Device" WHERE "id" IN (select id  from "Device"  Except Select "device" from "DeviceScore" );`)).rows[0].count

        let connectionChunk = defineChunkArray(missingConnectionCount)
        let deviceChunk = defineChunkArray(missingDeviceCount)

        try {

            for (let connectionValue = 0; connectionValue < connectionChunk.length; connectionValue++) {

                let limit = connectionChunk[connectionValue]

                const allConnections = (await connection.query(`select id from "Connection" Except Select "connection" from "ConnectionScore" limit ${limit}`)).rows

                for (let connection of allConnections) {
                    promises.push(updateCryptoScoresForConnection(connection.id))
                    if (promises.length >= 10) {
                        await Promise.allSettled(promises)
                        promises = []
                    }

                    showCount('Connection Score', ++j, missingConnectionCount)
                }
            }

            j = 0

            for (let deviceValues = 0; deviceValues < deviceChunk.length; deviceValues++) {

                let limit = deviceChunk[deviceValues]
                const missingDeviceCryptoScore = (await connection.query(`select id from "Device" Except Select "device" from "DeviceScore" limit ${limit}`)).rows

                for (let device of missingDeviceCryptoScore) {
                    promises.push(updateCryptoScoresForDevice(device.id))
                    if (promises.length >= 10) {
                        await Promise.allSettled(promises)
                        promises = []
                    }

                    showCount('Device Score', ++j, missingDeviceCount)
                }

            }

            console.log(`Memory : ${Math.round(process.memoryUsage().heapUsed / 1024 / 1024 * 100) / 100} MB`)
        }
        catch (error) {
            console.error('Error calculating crypto scores', error)
        }
    } finally {
        try {
            await connection.end()
        } catch (error) {
            console.error('Error waiting for connection.end()', error)
        }
    }
}

function showCount(title, number, total) {

    var lastPercentage = showCount.last[title]
    var percentage = Math.round(number / total * 1000) / 10
    if (lastPercentage === undefined || (percentage === 100 && lastPercentage != 100) || (percentage - lastPercentage > 1)) {
        log.log(`${title}: Created ${number} of ${total} (${percentage}%)`)
        showCount.last[title] = percentage
    }
}
showCount.last = {}


main().then(() => {
    log.log('Done!')
}).catch(e => {
    log.e('Sad now. :(', e)
    process.exit(1)
})