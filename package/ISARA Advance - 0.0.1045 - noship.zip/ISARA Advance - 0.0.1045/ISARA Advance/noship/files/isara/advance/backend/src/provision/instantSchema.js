/**
 * @file instantSchema.js - 0.0.1045 - ea4595bfd3488684d225574ed7d4c198074d49ba
 * 
 * @copyright Copyright (C) 2016-2023, ISARA Corporation, All Rights Reserved.
 * 
 * @license The code and other content set out herein is not in the public
 * domain, is considered a trade secret and is confidential to ISARA
 * Corporation. Use, reproduction or distribution, in whole or in part, of such
 * code or other content is strictly prohibited except by express written
 * permission of ISARA Corporation. Please contact ISARA Corporation at
 * info@isara.com for more information.
 */


exports.connectionsSchema = {
    name: 'connections',
    fields: [
        { name: 'id', type: 'string' },
        { name: 'advanceId', type: 'int64', index: false, optional: true },
        { name: 'observedAt', type: 'int64', facet: false },
        { name: 'clientAddress', type: 'string', optional: true },
        { name: 'port', type: 'string', optional: true, facet: false },
        { name: 'serverAddress', type: 'string', optional: true, facet: false },
        { name: 'addressIpVersion', type: 'string', optional: true, facet: false },
        { name: 'protocol', type: 'string[]', facet: true, optional: true, index: true },
        { name: 'keyExchange', type: 'string[]', facet: true, optional: true, index: true },
        { name: 'bulkEncryption', type: 'string[]', facet: true, optional: true, index: true },
        { name: 'modeOfOperation', type: 'string[]', facet: true, optional: true, index: true },
        { name: 'signature', type: 'string[]', facet: true, optional: true, index: true },
        { name: 'hash', type: 'string[]', facet: true, optional: true, index: true },
        { name: 'mac', type: 'string[]', facet: true, optional: true, index: true },
        { name: 'cryptoScore', type: 'string', facet: true },
        { name: 'cryptoScoreCoarse', type: 'string', facet: true },
        { name: 'technology', type: 'string', optional: true, facet: true },  //Still needed?
        { name: 'connectionCount', type: 'string', optional: true, facet: true },
        // { name: 'serverType', type: 'string', optional: true, index: false, facet: false },
        // { name: 'clientType', type: 'string', optional: true, index: false, facet: false },
        { name: 'scryptoScore', type: 'string', optional: true, facet: true },
        { name: 'scryptoScoreCoarse', type: 'string', optional: true, facet: true },
        { name: 'ccryptoScore', type: 'string', optional: true, facet: true },
        { name: 'ccryptoScoreCoarse', type: 'string', optional: true, facet: true },
        { name: 'ciphersuite', type: 'string[]', optional: true, index: true,facet:true },
        { name: 'issuer', type: 'string[]', facet: false, optional: true, index: false },
        { name: 'fingerprint', type: 'string[]', facet: false, optional: true, index: false },
        { name: 'serveros', type: 'string', optional: true, facet: true },
        { name: 'clientos', type: 'string', optional: true, facet: true },
        { name: 'application', type: 'string[]', optional: true, facet: true },
        { name: 'cryptoStrength', type: 'string[]', facet: true, optional: true, index: true },
        { name: 'scryptoStrength', type: 'string[]', facet: true, optional: true, index: true },
        { name: 'ccryptoStrength', type: 'string[]', facet: true, optional: true, index: true },

        //to make cipherSuite facet filtering work as column names are vary between connection and devices
        // { name: 'ciphersuite', type: 'string', facet: true, optional: true },

        { name: 'osType', type: 'string', facet: true, optional: true },
        { name: 'zoneIn', type: 'string', facet: true, optional: true },
        { name: 'zoneOut', type: 'string', facet: true, optional: true },
        { name: 'defaultFacet', type: 'string', facet: true, optional: true },// default facet used for sync the filters
    ]
}


exports.devicesSchema = {
    name: 'devices',
    fields: [
        { name: 'id', type: 'string' },
        { name: 'advanceId', type: 'int64' },
        { name: 'observedAt', type: 'int64', index: false, optional: true },
        { name: 'ipAddress', type: 'string', facet: false },
        { name: 'ipVersion', type: 'string', index: false, optional: true },
        { name: 'protocol', type: 'string[]', facet: true, optional: true, index: true },
        { name: 'keyExchange', type: 'string[]', facet: true, optional: true, index: true },
        { name: 'bulkEncryption', type: 'string[]', facet: true, optional: true, index: true },
        { name: 'modeOfOperation', type: 'string[]', facet: true, optional: true, index: true },
        { name: 'signature', type: 'string[]', facet: true, optional: true, index: true },
        { name: 'hash', type: 'string[]', facet: true, optional: true, index: true },
        { name: 'mac', type: 'string[]', facet: true, optional: true, index: true },
        { name: 'taniumName', type: 'string', optional: true },
        // { name: 'deviceType', type: 'string', facet: true, optional: true },
        { name: 'macAddress', type: 'string', facet: true, optional: true },
        { name: 'osType', type: 'string', facet: true, optional: true },
        { name: 'cryptoScoreCoarse', type: 'string', facet: true },
        { name: 'cryptoScore', type: 'string', facet: true },
        { name: 'issuer', type: 'string[]', facet: true, optional: true, index: true },
        { name: 'application', type: 'string[]', optional: true, facet: true },
        { name: 'ciphersuite', type: 'string[]', facet: true, index: true, optional: true },
        { name: 'listenport', type: 'int64[]', facet: true, optional: true },
        { name: 'cryptoprimitives', type: 'string', facet: false, optional: true },
        { name: 'cryptoStrength', type: 'string[]', facet: true, optional: true, index: true },
        { name: 'serveros', type: 'string', optional: true, facet: true },
        { name: 'clientos', type: 'string', optional: true, facet: true },
        //to make cipherSuite facet filtering work as column names are vary between connection and devices
        // { name: 'cipherSuite', type: 'string', optional: true, facet: true },
        { name: 'zoneIn', type: 'string',  optional: true, facet: true },
        { name: 'zoneOut', type: 'string', optional: true, facet: true },
        { name: 'defaultFacet', type: 'string', facet: true, optional: true }, // default facet used for sync the filters
    ]
}

exports.deviceSoftwareSchema = {
    name: 'deviceSoftware',
    fields: [
        { name: 'id', type: 'string' },
        { name: 'user', type: 'string', optional: true },
        { name: 'device', type: 'string', optional: true, facet: true },
        { name: 'version', type: 'string', optional: true },
        { name: 'DeviceCount', type: 'string', optional: true },
        { name: 'name', type: 'string', optional: true, facet: true },
        //{ name: 'type', type: 'string', optional: true, facet: true },
        { name: 'port', type: 'string', optional: true, facet: true },
        { name: 'osType', type: 'string', facet: true, optional: true },
        { name: 'protocol', type: 'string[]', facet: true, optional: true, index: true },
        { name: 'keyExchange', type: 'string[]', facet: true, optional: true, index: true },
        { name: 'bulkEncryption', type: 'string[]', facet: true, optional: true, index: true },
        { name: 'modeOfOperation', type: 'string[]', facet: true, optional: true, index: true },
        { name: 'signature', type: 'string[]', facet: true, optional: true, index: true },
        { name: 'hash', type: 'string[]', facet: true, optional: true, index: true },
        { name: 'mac', type: 'string[]', facet: true, optional: true, index: true },
        { name: 'observedAt', type: 'int64', facet: true },
        { name: 'connectionCount', type: 'string', optional: true },
    ]
}

exports.instantSearchSchemas = [exports.connectionsSchema, exports.devicesSchema, exports.deviceSoftwareSchema]

/**
 * 
 * @param {*} connection 
 * @returns {JSON}
 */
exports.mapConnectionToSchema = (connection) => {

    return {
        id: connection.id ?connection.id.toString() : '-1',
        advanceId: connection.id,
        serverAddress: connection.serverAddress,
        clientAddress: connection.clientAddress,
        port: connection.port,
        protocol: JSON.parse(connection.protocol),
        cryptoScore: connection.cryptoScore,
        cryptoScoreCoarse: connection.cryptoScoreCoarse,
        bulkEncryption: JSON.parse(connection.bulkEncryption),
        keyExchange: JSON.parse(connection.keyExchange),
        modeOfOperation: JSON.parse(connection.modeOfOperation),
        signature: JSON.parse(connection.signature),
        hash: JSON.parse(connection.hash),
        mac: JSON.parse(connection.mac),
        technology: connection.technology, //needed?
        observedAt: connection.observedAt ? connection.observedAt.getTime() : 0,
        // observedAt:  connection.observedAt.getTime(),  
        connectionCount: connection.connectionCount,
        // serverType: connection.serverType,
        // clientType: connection.clientType,
        scryptoScore: connection.scryptoScore,
        ccryptoScore: connection.ccryptoScore,
        scryptoScoreCoarse: connection.scryptoScoreCoarse,
        ccryptoScoreCoarse: connection.ccryptoScoreCoarse,
        ciphersuite: JSON.parse(connection.cipherSuite),
        serveros: connection.serveros ? connection.serveros : 'u',
        clientos: connection.clientos ? connection.clientos : 'u',
        issuer: JSON.parse(connection.issuer),
        fingerprint: JSON.parse(connection.fingerprint),
        application: connection.application ? JSON.parse(connection.application) : [] ,
        cryptoStrength: JSON.parse(connection.cryptoStrength),
        scryptoStrength: JSON.parse(connection.scryptoStrength),
        ccryptoStrength: JSON.parse(connection.ccryptoStrength),
        zoneIn: connection.zoneIn,
        zoneOut: connection.zoneOut,
        defaultFacet: 'd'
    }
}

/**
 * 
 * @param {*} connection 
 * @returns {JSON}
 */
exports.mapDeviceToSchema = (device) => {
    // const [cryptoStrength] = device.cryptostrength
    return {
        id: device.id.toString(),
        advanceId: device.id,
        observedAt: device.observedAt.getTime(),
        ipAddress: device.ipAddress,
        cryptoScore: device.cryptoScore,
        cryptoScoreCoarse: device.cryptoScoreCoarse,
        ipVersion: device.ipVersion,
        taniumName: device.taniumName,
        // deviceType: device.deviceType,
        macAddress: device.macAddress,
        osType: device.osType ? device.osType : 'u',
        application: device.application ? JSON.parse(device.application) : [],
        protocol: JSON.parse(device.protocol),
        bulkEncryption: device.bulkEncryption ? JSON.parse(device.bulkEncryption) : [],
        keyExchange: device.keyExchange ? JSON.parse(device.keyExchange) : [],
        modeOfOperation: device.modeOfOperation ? JSON.parse(device.modeOfOperation) : [],
        signature: device.signature ? JSON.parse(device.signature) : [],
        hash: device.hash ? JSON.parse(device.hash) : [],
        mac: device.mac ? JSON.parse(device.mac) : [],
        ciphersuite: JSON.parse(device.cipherSuite),
        listenport: device.listenport ? JSON.parse(device.listenport) : [],
        cryptoStrength: JSON.parse(device.cryptoStrength),
        defaultFacet: 'd'
    }
}

/**
 * 
 * @param {*} deviceSw 
 * @returns {JSON}
 */
exports.mapDeviceSoftwareToSchema = (deviceSw) => {
    return {
        id: deviceSw.id.toString(),
        user: deviceSw.user,
        device: deviceSw.device,
        name: deviceSw.name,
        //type: deviceSw.type,
        port: deviceSw.port.toString(),
        taniumName: deviceSw.taniumName,
        deviceType: deviceSw.deviceType,
        macAddress: deviceSw.macAddress,
        osType: deviceSw.osType,
        protocol: JSON.parse(deviceSw.protocol),
        bulkEncryption: deviceSw.bulkEncryption ? JSON.parse(deviceSw.bulkEncryption) : [],
        keyExchange: deviceSw.keyExchange ? JSON.parse(deviceSw.keyExchange) : [],
        modeOfOperation: deviceSw.modeOfOperation ? JSON.parse(deviceSw.modeOfOperation) : [],
        signature: deviceSw.signature ? JSON.parse(deviceSw.signature) : [],
        hash: deviceSw.hash ? JSON.parse(deviceSw.hash) : [],
        mac: deviceSw.mac ? JSON.parse(deviceSw.mac) : [],
        ciphersuite: JSON.parse(deviceSw.cipherSuite),
        observedAt: deviceSw.observedAt.getTime(),
        version: deviceSw.version,
        DeviceCount: deviceSw.DeviceCount.toString(),
        connectionCount: deviceSw.connectionCount ? deviceSw.connectionCount.toString() : ''
    }
}