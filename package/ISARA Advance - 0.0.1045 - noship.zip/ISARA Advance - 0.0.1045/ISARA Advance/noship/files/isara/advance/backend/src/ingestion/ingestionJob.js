/**
 * @file ingestionJob.js - 0.0.1045 - ea4595bfd3488684d225574ed7d4c198074d49ba
 * 
 * @copyright Copyright (C) 2016-2023, ISARA Corporation, All Rights Reserved.
 * 
 * @license The code and other content set out herein is not in the public
 * domain, is considered a trade secret and is confidential to ISARA
 * Corporation. Use, reproduction or distribution, in whole or in part, of such
 * code or other content is strictly prohibited except by express written
 * permission of ISARA Corporation. Please contact ISARA Corporation at
 * info@isara.com for more information.
 */

/**
 * This module is the schedulable Ingestion Job for Data Source Scans.
 * @module ingestion/ingestionJob
 */

const log = require('../util/log')(module)
const { fetchWanted } = require('../isaraql/fetch')
const { createUpdateDelete } = require('../isaraql/cud')
const { allTypes, discoverSchema } = require('../isaraql/schemaDiscovery')
const scheduler = require('../util/scheduler')
const {
    IngestionStatus,
    IngestionAuthError,
    IngestionCommError,
    createPendingScanResults,
    updateScanResults
} = require('./commonIngestion')
const { Session } = require('../isaraql/session')
const { isMainThread } = require('worker_threads')
const { loadNetmasks } = require('./netmaskMatching')

const cns = require('../express/cns')

const SCHEDULED_SCAN_PREFIX = 'ScheduledScan-'

const scanners = {}

/**
 * Initializes the Scanners.
 */
function initializeScanners() {
    // Scanners should adhere to this interface, and throw strings if fatal errors occur.
    // {
    //    name: string
    //    test: async function(dataSource)
    //    scan: async function(dataSourceScan, scanResults, onFulfilled, onRejected, onFinally)
    // }
    let scannerModules = [
        './csv/csvIngestionScanner',
        './extrahop/extrahopScanner',
        './tanium/taniumScanner',
        './cns/cnsScanner',
        './netscout/netscoutIngestionScanner'
    ]

    for (let scannerModule of scannerModules) {
        log.d(`Processing Scanner module '${scannerModule}'...`)
        try {
            let module = require(scannerModule)
            if (!module.name || !module.scan || !module.test) {
                throw new Error(`Module '${scannerModule}' does not implement the required scanner interface.`)
            }
            scanners[module.name] = module
        } catch (e) {
            log.e(`Could not import scanner module '${scannerModule}':\n${e.message}\n${e.stack}`)
        }
    }
}

/**
 * Retrieves a Data Source from the Database.
 * @param {BigInt} id The ID of the Data Source to retrieve.
 * @returns An object representing the Data Source.
 */
async function findDataSource(id) {
    let wanted = {
        friendlyName: true,
        configuration: true,
        softwareVersion: {
            name: true,
            version: true,
            software: {
                name: true,
                softwareVendor: true,
            },
        },
    }

    let wpcs = { DataSource: { where: { equals: { column: 'id', value: id } } } }
    let dataSources = await fetchWanted('DataSource', wanted, wpcs, undefined, true)
    if (dataSources.length === 0) {
        throw `No Data Source found with ID ${id}`
    }

    return dataSources[0]
}

/**
 * Retrieves a Data Source Scan from the Database.
 * @param {BigInt} id The ID of the Data Source Scan to retrieve.
 * @returns An object representing the Data Source Scan.
 */
async function findScan(id) {
    let wanted = {
        id: true,
        friendlyName: true,
        configuration: true,
        metadata: true,
        scanCount: true,
        lastStatus: {
            name: true
        },
        addedBy: {
            id: true
        },
        dataSourceScanTags: {
            tag: {
                id
            }
        },
        dataSource: {
            id: true,
            friendlyName: true,
            configuration: true,
            status: {
                name: true,
            },
            softwareVersion: {
                name: true,
                version: true,
                software: {
                    name: true,
                    softwareVendor: true
                }
            }
        }
    }

    let wpcs = { DataSourceScan: { where: { equals: { column: 'id', value: id } } } }
    let scans = await fetchWanted('DataSourceScan', wanted, wpcs, undefined, true)
    if (scans.length === 0) {
        throw `No Data Source Scan found with ID ${id}`
    }

    return scans[0]
}

async function updateScan(scan) {
    let tables = {
        DataSourceScan: true
    }
    let config = {
        allowDelete: false,
        allowInsert: false,
        allowUpdate: true,
        deletableTables: {},
        modifiableTables: tables,
        checkExistingTables: tables
    }

    let updateScan = {
        id: scan.id,
        metadata: scan.metadata,
        lastStatus: scan.lastStatus,
        scanCount: scan.scanCount + 1
    }

    await createUpdateDelete('DataSourceScan', [updateScan], config)
}

const LENGTH_OF_ERROR_IN_DATABASE = 200

/**
 * Sets a Data Source status and error message as specified.
 * @param {BigInt} dataSourceId The Data Source ID.
 * @param {String} status The status.
 * @param {*} errorMessage The error message.
 */
async function setDataSourceResults(dataSourceId, error) {
    /**
     * @type String
     */
    let errorMessage = null
    let statusName = 'ENABLED'

    if (error) {
        if (error instanceof IngestionAuthError || error instanceof IngestionCommError) {
            statusName = error.status
            errorMessage = error.message
        } else {
            statusName = 'COMM_FAILED'
            errorMessage = error.message || error.toString()
        }
        if (errorMessage.length > LENGTH_OF_ERROR_IN_DATABASE) {
            errorMessage = errorMessage.substring(0, LENGTH_OF_ERROR_IN_DATABASE)
        }
    }

    let dataSource = {
        id: dataSourceId,
        status: allTypes['DataSourceStatus']._enum.idByName[statusName],
        errorMessage: errorMessage || null
    }
    let tables = {
        DataSource: true
    }
    let config = {
        allowDelete: false,
        allowInsert: false,
        allowUpdate: true,
        deletableTables: {},
        modifiableTables: tables,
        checkExistingTables: tables
    }
    await createUpdateDelete('DataSource', [dataSource], config)
}

/**
 * Verifies that a specified Data Source can connect and authenticate with the target system.
 * @param {BigInt} dataSourceId The Data Source ID.
 */
async function runDataSourceTest(dataSourceId) {
    let dataSource = await findDataSource(dataSourceId)

    try {
        // Lookup Scanner
        let scanner = scanners[dataSource.softwareVersion.software.name]
        if (!scanner) {
            throw `No Scanner available for Software: ${dataSource.softwareVersion.software.name}`
        }

        // Invoke Scanner
        log.log(`Running ${scanner.name} Authentication Test '${dataSource.friendlyName}'`)
        await scanner.test(dataSource)

        // Update Data Source Results Column(s) -- Success
        await setDataSourceResults(dataSourceId)
        log.log(`Authentication Test '${dataSource.friendlyName}' complete`)
        return true
    } catch (e) {
        // TODO: GAP1606 - handle more specific status types, e.g. auth vs comms
        // Update Data Source Results Column(s) -- Failure
        await setDataSourceResults(dataSourceId, e)
        log.log(`Authentication Test '${dataSource.friendlyName}' failed`)
        return false
    }
}

/**
 * The entry-point for running Data Source Scans asynchronously.
 * @param {BigInt} scanId The Data Source Scan ID.
 * @returns {BigInt} The Scan Results ID of the scan that is running.
 */
async function runDataSourceScan(scanId, scheduleId = null) {
    let session = new Session()
    if(scheduleId) {
        await session.query(`UPDATE "DataSourceScanSchedule" SET "start" = NOW(), "end" = NULL 
            WHERE "id" = ${scheduleId}
        `)
    }
    let scan = await findScan(scanId)
    let friendlyName = `${scan.dataSource.friendlyName} - ${scan.friendlyName}`

    if (scan.lastStatus && scan.lastStatus.name === 'IN_PROGRESS') {
        throw `Data Source Scan '${friendlyName}' is already In Progress.`
    }

    await session.query(`UPDATE "DataSource" SET "start" = NOW(), "end" = NULL 
        WHERE "id" = ${scan.dataSource.id}
    `)

    // Create Results Entry -- Pending
    let scanResults = await createPendingScanResults(scan)

    const { runInWorker } = require('../util/worker')
    const errorHandler = async (error) => {
        log.e('Handling fatal worker error')
        await updateScanResults(scanResults, IngestionStatus.FAILED, error)
        log.log(`Scan '${friendlyName}' error occurred`, error)
        scan.lastStatus = scanResults.status
        await updateScan(scan)
    }

    await runInWorker({ requireName: __filename, functionName: 'runDataSourceScanWorker', args: { scan, friendlyName, scanResults, scheduleId }, errorHandler})

    return scanResults.id
}

async function runDataSourceScanWorker({ scan, friendlyName, scanResults, scheduleId }) {
    let session = new Session()
    if (isMainThread) {
        throw new Error('This function should not be called in the main thread')
    }

    // Schema needs to be (re)discovered for this worker thread.
    await discoverSchema()
    await loadNetmasks()

    initializeScanners()

    scan.lastStatus = allTypes['DataSourceScanResultStatus']._enum.idByName[IngestionStatus.IN_PROGRESS]
    await updateScan(scan)

    try {
        // Block Scan if DataSource.Status is not ENABLED
        if (scan.dataSource.status.name !== 'ENABLED') {
            throw `Skipping Data Source Scan '${friendlyName}' with state '${scan.dataSource.status.name}'`
        }

        // Lookup Scanner
        let scanner = scanners[scan.dataSource.softwareVersion.software.name]
        if (!scanner) {
            throw `No Scanner available for Software: ${scan.dataSource.softwareVersion.software.name}`
        }

        // Invoke Scanner
        log.log(`Running ${scanner.name} Scan '${friendlyName}'`)
        await scanner.scan(
            scan,
            scanResults,
            // onFulfilled
            async (status, summary, errorMessage) => {
                if (summary) {
                    scanResults.summary = summary
                }
                if (errorMessage) {
                    scanResults.errorMessage = errorMessage
                }
                await updateScanResults(scanResults, status)
                log.log(`Scan '${friendlyName}' completed with status ${status}`)
            },
            // onRejected
            async (e) => {
                await updateScanResults(scanResults, IngestionStatus.FAILED, e)
                log.log(`Scan '${friendlyName}' error occurred`)
            },
            // onFinally
            async () => {
                // mirror result status onto scan object
                scan.lastStatus = scanResults.status
                await updateScan(scan)
            }
        )
    } catch (e) {
        await updateScanResults(scanResults, IngestionStatus.FAILED, e)
        log.log(`Scan '${friendlyName}' error occurred`, e)
        scan.lastStatus = scanResults.status
        await updateScan(scan)
    } finally {
        await session.query(`UPDATE "DataSource" SET "end" = NOW() 
            WHERE "id" = ${scan.dataSource.id}
        `)
        if(scheduleId) {
            await session.query(`UPDATE "DataSourceScanSchedule" SET "end" = NOW() 
                WHERE "id" = ${scheduleId}
            `)
        }

    }

    return scanResults.id
}

const SCAN_SCHEDULE_WANTED = {
    id: true,
    cronish: true,
    scheduleActive: true,
    timezone: true,
    dataSourceScan: {
        id: true
    }
}

function sanitizeCron(cronish) {
    let cronColumns = cronish.split(' ')
    if (cronColumns[2] === 'L') {
        // Schedule 3 times for "Last Day of Month"
        return [
            `${cronColumns[0]} ${cronColumns[1]} 30 Apr,Jun,Sep,Nov ${cronColumns[4]} `,
            `${cronColumns[0]} ${cronColumns[1]} 31 Jan,Mar,May,Jul,Aug,Oct,Dec ${cronColumns[4]} `,
            `${cronColumns[0]} ${cronColumns[1]} 28 Feb ${cronColumns[4]} `,
        ]
    }
    return [cronish]
}

/**
 * Schedules a Scan Schedule.
 * @param {object} scanSchedule The Scan Schedule to schedule.
 * @param {Session} session The database session to use.
 * @returns true if successfully scheduled; otherwise, false.
 */
async function scheduleScan(scanSchedule, session) {
    if (!scanSchedule.id) {
        log.e(`Cannot schedule scan without ID`)
        return false
    }

    if (scanSchedule.scheduleActive === undefined || scanSchedule.cronish === undefined ||
        scanSchedule.dataSourceScan === undefined || scanSchedule.dataSourceScan.id === undefined ||
        scanSchedule.timezone === undefined) {
        if (!session) {
            session = new Session()
        }
        let wpcs = { DataSourceScanSchedule: { where: { equals: { column: 'id', value: scanSchedule.id } } } }
        let scanSchedules = await fetchWanted('DataSourceScanSchedule', SCAN_SCHEDULE_WANTED, wpcs, session)
        if (scanSchedules.length) {
            scanSchedule = scanSchedules[0]
        }
    }

    let error = false
    if (scanSchedule.scheduleActive && scanSchedule.cronish) {
        for (let cron of sanitizeCron(scanSchedule.cronish)) {
            error = !(await scheduler.scheduleJob(
                `${SCHEDULED_SCAN_PREFIX}${scanSchedule.id}`,
                cron,
                scanSchedule.timezone,
                async function () {
                    try {
                        await runDataSourceScan(scanSchedule.dataSourceScan.id, scanSchedule.id)
                    } catch (e) {
                        let message = e.message || e
                        log.e(`Exception running Scan: ${message}`)
                    }
                }
            )) || error
        }
    }

    return !error
}

/**
 * Unschedules a Scan Schedule.
 * @param {object} scanSchedule The Scan Schedule to unschedule.
 * @returns true if successfully unscheduled; otherwise, false.
 */
async function unscheduleScan(scanSchedule) {
    if (!scanSchedule.id) {
        log.e(`Cannot unschedule scan without ID`)
        return false
    }

    return await scheduler.cancelJob(`${SCHEDULED_SCAN_PREFIX}${scanSchedule.id}`)
}

async function cleanupStaleScans(session) {
    await session.query(`
        UPDATE "DataSourceScan" SET "lastStatus" = ?
        WHERE id in (select id from "DataSourceScan" where "lastStatus" = ?)`,
    [
        allTypes['DataSourceScanResultStatus']._enum.idByName[IngestionStatus.FAILED],
        allTypes['DataSourceScanResultStatus']._enum.idByName[IngestionStatus.IN_PROGRESS],
    ]
    )
    let errorMessage = 'Service terminated while Ingestion in progress.'
    await session.query(`
        UPDATE "DataSourceScanResult" SET "status" = ?, "errorMessage" = '${errorMessage}', "summary" = '${errorMessage}'
        WHERE id in (select id from "DataSourceScanResult" where "status" = ?)`,
    [
        allTypes['DataSourceScanResultStatus']._enum.idByName[IngestionStatus.FAILED],
        allTypes['DataSourceScanResultStatus']._enum.idByName[IngestionStatus.IN_PROGRESS],
    ])
}

/**
 * Initializes the Ingestion Jobs in the scheduler. Intended to be used on system startup.
 */
async function initializeIngestionJobs() {
    initializeScanners()

    let session = new Session()
    await cleanupStaleScans(session)

    let wpcs = { DataSourceScanSchedule: {} }
    let scanSchedules = await fetchWanted('DataSourceScanSchedule', SCAN_SCHEDULE_WANTED, wpcs, session)

    // Schedule Scans
    for (let scanSchedule of scanSchedules) {
        await scheduleScan(scanSchedule, session)
    }

    // Start other background tasks
    await cns.startBackgroundTasks()
}

exports.scheduleScan = scheduleScan
exports.unscheduleScan = unscheduleScan
exports.runDataSourceTest = runDataSourceTest
exports.runDataSourceScan = runDataSourceScan
exports.runDataSourceScanWorker = runDataSourceScanWorker
exports.initializeIngestionJobs = initializeIngestionJobs
