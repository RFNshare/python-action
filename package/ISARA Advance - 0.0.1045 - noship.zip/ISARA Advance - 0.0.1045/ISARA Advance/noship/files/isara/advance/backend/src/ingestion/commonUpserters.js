/**
 * @file commonUpserters.js - 0.0.1045 - ea4595bfd3488684d225574ed7d4c198074d49ba
 * 
 * @copyright Copyright (C) 2016-2023, ISARA Corporation, All Rights Reserved.
 * 
 * @license The code and other content set out herein is not in the public
 * domain, is considered a trade secret and is confidential to ISARA
 * Corporation. Use, reproduction or distribution, in whole or in part, of such
 * code or other content is strictly prohibited except by express written
 * permission of ISARA Corporation. Please contact ISARA Corporation at
 * info@isara.com for more information.
 */

const { BatchManager } = require('./batchManager')
const log = require('../util/log')(module)
const { sleep } = require('../util/sleep')
log.debug = true

const MAX_COMMIT_QUEUE_SIZE = 5

class CommitBlocker {
    #promise
    #resolve
    #reject
    #commitPromise

    constructor() {
        this.#promise = new Promise((resolve, reject) => {
            this.#resolve = resolve
            this.#reject = reject
        })
    }

    unblock() {
        this.#resolve('unblocked')
    }

    abort() {
        this.#reject(new Error('Commit has been dropped'))
    }

    get promise() {
        return this.#promise
    }

    set commitPromise(comPromise) {
        this.#commitPromise = comPromise
    }
}

class CommonUpserters {
    #timer
    #allowParallelCommits

    /**
     * @type Array.<CommitBlocker>
     */
    #queuedCommits = []

    /**
     * @param {Session} session
     * @param {[Object]} options
     * @param {[ChattyTimer]} options.timer An optional timer to track commit durations.
     * @param {[boolean]} options.allowParallelCommits Flag indicating if parallel commits are permitted (defaults to true)
     */
    constructor(session, { timer, allowParallelCommits } = {}) {
        if (!session) {
            throw new Error('Session is mandatory for CommonUpserters')
        }
        this.#timer = timer
        this.#allowParallelCommits = allowParallelCommits ?? true
        this.batchManagers = []
        this.connectionUpserter = new BatchManager(
            session,
            'Connection',
            [
                'serverAddress',
                'port',
                'clientAddress',
                'l4Protocol',
                'friendlyName',
                'connectionCount',
                'observedAt',
                'zoneIn',
                'zoneOut',
            ],
            [
                'serverAddress',
                'port',
                'clientAddress',
                'l4Protocol',
            ],
            {
                'connectionCount': n => `"Connection"."connectionCount" + ${n}`,
                'observedAt': n => n,
                'friendlyName': n => n,
                'zoneIn': n => n,
                'zoneOut': n => n,
            },
            (a, b) => {
                return {
                    serverAddress: b.serverAddress,
                    port: b.port,
                    clientAddress: b.clientAddress,
                    l4Protocol: b.l4Protocol,
                    connectionCount: a.connectionCount + b.connectionCount,
                    observedAt: a.observedAt > b.observedAt ? a.observedAt : b.observedAt,
                    friendlyName: b.friendlyName,
                    zoneIn: b.zoneIn,
                    zoneOut: b.zoneOut,
                }
            }
        )

        this.deviceUpserter = new BatchManager(
            session,
            'Device',
            [
                'observedAt',
                'ipAddress',
                'ipVersion',
                'macAddress',
            ],
            [
                'ipAddress'
            ],
            {
                'observedAt': n => n,
            },
            (a, b) => {
                return {
                    observedAt: a.observedAt > b.observedAt ? a.observedAt : b.observedAt,
                    ipAddress: b.ipAddress,
                    ipVersion: b.ipVersion,
                    macAddress: b.macAddress,
                }
            }
        )

        this.cryptoUpserter = new BatchManager(
            session,
            'ConnectionCryptoPrimitive',
            [
                'serverAddress',
                'port',
                'clientAddress',
                'l4Protocol',
                'cryptoPrimitive',
                'cryptoPrimitiveParameter',
                'observedAt',
            ],
            [
                'serverAddress',
                'port',
                'clientAddress',
                'l4Protocol',
                'cryptoPrimitive',
            ],
            {
                'observedAt': n => n,
            },
            (a, b) => {
                return {
                    serverAddress: b.serverAddress,
                    port: b.port,
                    clientAddress: b.clientAddress,
                    l4Protocol: b.l4Protocol,
                    cryptoPrimitive: b.cryptoPrimitive,
                    cryptoPrimitiveParameter: a.cryptoPrimitiveParameter ? a.cryptoPrimitiveParameter : b.cryptoPrimitiveParameter,
                    observedAt: a.observedAt > b.observedAt ? a.observedAt : b.observedAt,
                }
            }
        )

        this.cipherSuiteUpserter = new BatchManager(
            session,
            'ConnectionCipherSuite',
            [
                'serverAddress',
                'port',
                'clientAddress',
                'l4Protocol',
                'cipherSuite',
                'observedAt',
            ],
            [
                'serverAddress',
                'port',
                'clientAddress',
                'l4Protocol',
                'cipherSuite',
            ],
            {
                'observedAt': n => n,
            },
            (a, b) => {
                return {
                    serverAddress: b.serverAddress,
                    port: b.port,
                    clientAddress: b.clientAddress,
                    l4Protocol: b.l4Protocol,
                    cipherSuite: b.cipherSuite,
                    observedAt: a.observedAt > b.observedAt ? a.observedAt : b.observedAt,
                }
            }
        )

        this.protocolVariantUpserter = new BatchManager(
            session,
            'ConnectionProtocolVariant',
            [
                'serverAddress',
                'port',
                'clientAddress',
                'l4Protocol',
                'protocolVariant',
                'observedAt',
            ],
            [
                'serverAddress',
                'port',
                'clientAddress',
                'l4Protocol',
                'protocolVariant',
            ],
            {
                'observedAt': n => n,
            },
            (a, b) => {
                return {
                    serverAddress: b.serverAddress,
                    port: b.port,
                    clientAddress: b.clientAddress,
                    l4Protocol: b.l4Protocol,
                    protocolVariant: b.protocolVariant,
                    observedAt: a.observedAt > b.observedAt ? a.observedAt : b.observedAt,
                }
            }
        )

        this.deviceCertificateUpserter = new BatchManager(
            session,
            'DeviceCertificate',
            [
                'serverAddress',
                'port',
                'clientAddress',
                'l4Protocol',
                'fingerprint',
                'observedAt',
                'notAfter',
                'notBefore',
                'issuer',
                'subject',
            ],
            [
                'serverAddress',
                'port',
                'clientAddress',
                'l4Protocol',
                'fingerprint',
                'issuer',
                'subject'
            ],
            {
                'observedAt': n => n,
            },
            (a, b) => {
                let toReturn = { ...b }
                toReturn.observedAt = a.observedAt > b.observedAt ? a.observedAt : b.observedAt
                return toReturn
            }
        )

        this.certificateUpserter = new BatchManager(
            session,
            'Certificate',
            [
                'fingerprint',
                'certificateType',
                'certificateContent',
                'subject',
                'issuer',
                'issuerCertificate',
                'internalIssuer',
                'notBefore',
                'notAfter',
                'publicKeyType',
                'publicKeyParameter',
                'publicKeyCryptoPrimitive',
                'publicKeyCryptoPrimitiveParameter',
                'issuerSigAndHash',
                'serial',
                'alternateNames',
                'manuallyAdded',
                'observedAt',
            ],
            [
                'fingerprint',
            ],
            {
                'observedAt': n => n
            },
            (a, b) => {
                let toReturn = { ...b }
                toReturn.observedAt = a.observedAt > b.observedAt ? a.observedAt : b.observedAt
                return toReturn
            }
        )

        this.upserters = [this.cipherSuiteUpserter, this.connectionUpserter, this.cryptoUpserter, this.deviceUpserter, this.protocolVariantUpserter, this.deviceCertificateUpserter, this.certificateUpserter]
    }

    queuedCommit() {
        // Parallel commits must be on to allow all upserters to 'clear' their state.
        this.#allowParallelCommits = true

        let commitBlocker = new CommitBlocker()
        let commitPromise = this.commit(commitBlocker.promise)
        let aborted = false
        commitBlocker.commitPromise = commitPromise
        commitPromise.then(() => {
            log.log('A commit finished')
        }).catch(error => {
            log.e('Error from commit promise', error)
            if (aborted) {
                log.e('I was aborted')
            }
        }).finally(() => {
            log.log('Finally - going to remove this item from the queue')
            let where = this.#queuedCommits.indexOf(commitBlocker)
            if (where !== -1) {
                this.#queuedCommits.splice(where, 1)
            }
            if (!aborted && this.#queuedCommits.length > 0) {
                this.#queuedCommits[0].unblock()
            }
        })

        this.#queuedCommits.push(commitBlocker)

        if (this.#queuedCommits.length > MAX_COMMIT_QUEUE_SIZE) {
            aborted = true
            commitBlocker.abort()
        } else if (this.#queuedCommits.length === 1) {
            commitBlocker.unblock()
        } else {
            // do nothing some other commit ending will start this commit.
        }
    }

    async commit(blocker) {
        this.#timer?.start()
        let neverPushed = []
        let promises = []
        let totalCommitted = 0
        for (let which of this.upserters) {
            if (!which.everPushed) {
                neverPushed.push(which.tableName)
            }
            let commitPromise = which.commit(blocker)
            if (this.#allowParallelCommits) {
                promises.push(commitPromise)
            } else {
                totalCommitted += await commitPromise
            }
        }
        if (neverPushed.length) {
            // Temporarily disable this warning until Solana cert tables update is implemented.
            // log.d(`Never pushed records in this run to: ${neverPushed.join(', ')}`)
        }
        if (this.#allowParallelCommits) {
            (await Promise.all(promises)).forEach(count => totalCommitted += count)
        }
        this.#timer?.stop(totalCommitted)
        await sleep(10000)
        return totalCommitted
    }

    needsCommit() {
        return this.upserters.some(bm => bm.needsCommit())
    }
}

exports.CommonUpserters = CommonUpserters
