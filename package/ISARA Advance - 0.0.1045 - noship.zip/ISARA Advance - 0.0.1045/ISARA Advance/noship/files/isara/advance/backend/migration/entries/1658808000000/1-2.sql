--
-- @file 1-2.sql - 0.0.1045 - ea4595bfd3488684d225574ed7d4c198074d49ba
-- 
-- @copyright Copyright (C) 2016-2023, ISARA Corporation, All Rights Reserved.
-- 
-- @license The code and other content set out herein is not in the public
-- domain, is considered a trade secret and is confidential to ISARA
-- Corporation. Use, reproduction or distribution, in whole or in part, of such
-- code or other content is strictly prohibited except by express written
-- permission of ISARA Corporation. Please contact ISARA Corporation at
-- info@isara.com for more information.
--

    /* 
    * 
    *    DATA - FORWARDS 
    *    MIGRATION 1 to 2
    *    ORIGIN GIT HASH:bfb8c1ca8944d88b169866fb5471cd67a1cf0bf8
    *
    *    CREATED ON 2022-07-26T04:17:00.000Z
    *
    *
    *   NOTE: THIS IS A STARTING POINT FOR MIGRATIONS - release/0.82.1
    *   DEST GIT HASH IS ALSO bfb8c1ca8944d88b169866fb5471cd67a1cf0bf8
    *
    */

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

INSERT INTO "advance"."CertificateType" ("name") VALUES ('X509');
INSERT INTO "advance"."CertificateType" ("name") VALUES ('CATALYST');

INSERT INTO "advance"."ConnectionCertificateType" ("name") VALUES ('CLIENT');
INSERT INTO "advance"."ConnectionCertificateType" ("name") VALUES ('SERVER');

INSERT INTO "advance"."ConnectionRatingScale" ("name") VALUES ('HIGH');
INSERT INTO "advance"."ConnectionRatingScale" ("name") VALUES ('MEDIUM');
INSERT INTO "advance"."ConnectionRatingScale" ("name") VALUES ('LOW');

INSERT INTO "advance"."CryptoPostureTemplate" ("name", "description", "system") VALUES
    ('ISARA', 'ISARA default cryptographic posture template.', true);

INSERT INTO "advance"."CryptoScoreCoarse" ("id", "name", "friendlyName", "baseScore") VALUES
    (-1, 'PENDING', 'Pending', -1),
    (0, 'UNACCEPTABLE', 'Unacceptable', 0),
    (1, 'CAUTION', 'Caution', 500),
    (2, 'STRONG_CLASSIC', 'Strong', 1000),
    (3, 'STRONG_QSC', 'Quantum Safe', 1500);

INSERT INTO "advance"."CryptoScore" ("name", "friendlyName", "shortName", "score", "isDefault", "cryptoScoreCoarse", "cryptoPostureTemplate")
    select 'PENDING', 'Pending', 'Pending', -1, false, (SELECT id FROM "advance"."CryptoScoreCoarse" where name = 'PENDING'), (SELECT id FROM "advance"."CryptoPostureTemplate" WHERE name = 'ISARA') union
    select 'BROKEN', 'Broken', 'Broken', 0, false, (SELECT id from "advance"."CryptoScoreCoarse" where name = 'UNACCEPTABLE'), (SELECT id FROM "advance"."CryptoPostureTemplate" WHERE name = 'ISARA') union
    select 'WEAK', 'Weak', 'Weak', 1, false, (SELECT id from "advance"."CryptoScoreCoarse" where name = 'UNACCEPTABLE'), (SELECT id FROM "advance"."CryptoPostureTemplate" WHERE name = 'ISARA') union
    select 'MISUSED', 'Misused', 'Misused', 2, false, (SELECT id from "advance"."CryptoScoreCoarse" where name = 'UNACCEPTABLE'), (SELECT id FROM "advance"."CryptoPostureTemplate" WHERE name = 'ISARA') union
    select 'NONSTANDARD_QSC', 'Nonstandard QSC', 'Nonstandard QSC', 500, false, (SELECT id from "advance"."CryptoScoreCoarse" where name = 'CAUTION'), (SELECT id FROM "advance"."CryptoPostureTemplate" WHERE name = 'ISARA') union
    select 'UNSPECIFIED_PARAMETERS', 'Unspecified Parameters', 'Unspecified Parameters', 501, false, (SELECT id from "advance"."CryptoScoreCoarse" where name = 'CAUTION'), (SELECT id FROM "advance"."CryptoPostureTemplate" WHERE name = 'ISARA') union
    select 'UNKNOWN_OR_CUSTOM', 'Unknown or Custom', 'Unknown or Custom', 502, true, (SELECT id from "advance"."CryptoScoreCoarse" where name = 'CAUTION'), (SELECT id FROM "advance"."CryptoPostureTemplate" WHERE name = 'ISARA') union
    select 'NOT_RECOMMENDED', 'Not Recommended', 'Not Recommended', 503, false, (SELECT id from "advance"."CryptoScoreCoarse" where name = 'CAUTION'), (SELECT id FROM "advance"."CryptoPostureTemplate" WHERE name = 'ISARA') union
    select 'STRONG_CLASSIC_BROKEN_QUANTUM', 'Strong - Quantum Broken', 'Quantum Broken', 1000, false, (SELECT id from "advance"."CryptoScoreCoarse" where name = 'STRONG_CLASSIC'), (SELECT id FROM "advance"."CryptoPostureTemplate" WHERE name = 'ISARA') union
    select 'STRONG_CLASSIC_WEAK_UNKNOWN_QUANTUM', 'Strong - Quantum Unknown', 'Quantum Unknown', 1001, false, (SELECT id from "advance"."CryptoScoreCoarse" where name = 'STRONG_CLASSIC'), (SELECT id FROM "advance"."CryptoPostureTemplate" WHERE name = 'ISARA') union
    select 'STRONG_HYBRID', 'Pre-standard Hybrid', 'Pre-standard Hybrid', 1002, false, (SELECT id from "advance"."CryptoScoreCoarse" where name = 'STRONG_CLASSIC'), (SELECT id FROM "advance"."CryptoPostureTemplate" WHERE name = 'ISARA') union
    select 'QUANTUM_SAFE_LEVEL1', 'QS - Security Level 1', 'Security Level 1', 1500, false, (SELECT id from "advance"."CryptoScoreCoarse" where name = 'STRONG_QSC'), (SELECT id FROM "advance"."CryptoPostureTemplate" WHERE name = 'ISARA') union
    select 'QUANTUM_SAFE_LEVEL2', 'QS - Security Level 2', 'Security Level 2', 1501, false, (SELECT id from "advance"."CryptoScoreCoarse" where name = 'STRONG_QSC'), (SELECT id FROM "advance"."CryptoPostureTemplate" WHERE name = 'ISARA') union
    select 'QUANTUM_SAFE_LEVEL3', 'QS - Security Level 3', 'Security Level 3', 1502, false, (SELECT id from "advance"."CryptoScoreCoarse" where name = 'STRONG_QSC'), (SELECT id FROM "advance"."CryptoPostureTemplate" WHERE name = 'ISARA') union
    select 'QUANTUM_SAFE_LEVEL4', 'QS - Security Level 4', 'Security Level 4', 1503, false, (SELECT id from "advance"."CryptoScoreCoarse" where name = 'STRONG_QSC'), (SELECT id FROM "advance"."CryptoPostureTemplate" WHERE name = 'ISARA') union
    select 'QUANTUM_SAFE_LEVEL5', 'QS - Security Level 5', 'Security Level 5', 1504, false, (SELECT id from "advance"."CryptoScoreCoarse" where name = 'STRONG_QSC'), (SELECT id FROM "advance"."CryptoPostureTemplate" WHERE name = 'ISARA');

INSERT INTO "advance"."DataSourceStatus" ("name") VALUES ('AUTH_FAILED');
INSERT INTO "advance"."DataSourceStatus" ("name") VALUES ('COMM_FAILED');
INSERT INTO "advance"."DataSourceStatus" ("name") VALUES ('ENABLED');

INSERT INTO "advance"."DataSourceScanResultStatus" ("name") VALUES ('FAILED');
INSERT INTO "advance"."DataSourceScanResultStatus" ("name") VALUES ('IN_PROGRESS');
INSERT INTO "advance"."DataSourceScanResultStatus" ("name") VALUES ('PARTIAL_SUCCESS');
INSERT INTO "advance"."DataSourceScanResultStatus" ("name") VALUES ('SUCCESS');

INSERT INTO "advance"."SearchIndexExportSchedule" ("scheduleActive", "timezone", "cronish") VALUES (true, 'America/Toronto', '*/15 * * * *');

INSERT INTO "advance"."DeviceType" ("name") VALUES ('UNKNOWN');
INSERT INTO "advance"."DeviceType" ("name") VALUES ('OTHER');
INSERT INTO "advance"."DeviceType" ("name") VALUES ('DATABASE');
INSERT INTO "advance"."DeviceType" ("name") VALUES ('DHCP_SERVER');
INSERT INTO "advance"."DeviceType" ("name") VALUES ('DNS_SERVER');
INSERT INTO "advance"."DeviceType" ("name") VALUES ('DOMAIN_CONTROLLER');
INSERT INTO "advance"."DeviceType" ("name") VALUES ('FILE_SERVER');
INSERT INTO "advance"."DeviceType" ("name") VALUES ('FIREWALL');
INSERT INTO "advance"."DeviceType" ("name") VALUES ('GATEWAY');
INSERT INTO "advance"."DeviceType" ("name") VALUES ('IP_CAMERA');
INSERT INTO "advance"."DeviceType" ("name") VALUES ('LOAD_BALANCER');
INSERT INTO "advance"."DeviceType" ("name") VALUES ('MEDICAL_DEVICE');
INSERT INTO "advance"."DeviceType" ("name") VALUES ('MOBILE_DEVICE');
INSERT INTO "advance"."DeviceType" ("name") VALUES ('NAT_GATEWAY');
INSERT INTO "advance"."DeviceType" ("name") VALUES ('PC');
INSERT INTO "advance"."DeviceType" ("name") VALUES ('PRINTER');
INSERT INTO "advance"."DeviceType" ("name") VALUES ('VOIP_PHONE');
INSERT INTO "advance"."DeviceType" ("name") VALUES ('VPN_CLIENT');
INSERT INTO "advance"."DeviceType" ("name") VALUES ('VPN_GATEWAY');
INSERT INTO "advance"."DeviceType" ("name") VALUES ('VULNERABILITY_SCANNER');
INSERT INTO "advance"."DeviceType" ("name") VALUES ('WEB_PROXY_SERVER');
INSERT INTO "advance"."DeviceType" ("name") VALUES ('WEB_SERVER');
INSERT INTO "advance"."DeviceType" ("name") VALUES ('WIFI_AP');

INSERT INTO "advance"."CryptoPrimitivePurpose" ("name") VALUES ('SIGNATURE');
INSERT INTO "advance"."CryptoPrimitivePurpose" ("name") VALUES ('BULK_ENCRYPTION');
INSERT INTO "advance"."CryptoPrimitivePurpose" ("name") VALUES ('HASH');
INSERT INTO "advance"."CryptoPrimitivePurpose" ("name") VALUES ('KEY_EXCHANGE');
INSERT INTO "advance"."CryptoPrimitivePurpose" ("name") VALUES ('MAC');
INSERT INTO "advance"."CryptoPrimitivePurpose" ("name") VALUES ('MODE_OF_OPERATION');

INSERT INTO "advance"."Layer4Protocol" ("name") VALUES ('TCP');
INSERT INTO "advance"."Layer4Protocol" ("name") VALUES ('UDP');
INSERT INTO "advance"."Layer4Protocol" ("name") VALUES ('SCTP');
INSERT INTO "advance"."Layer4Protocol" ("name") VALUES ('UNKNOWN');

INSERT INTO "advance"."NotificationType" ("name") VALUES ('ALERT');
INSERT INTO "advance"."NotificationType" ("name") VALUES ('NOTIFICATION');

INSERT INTO "advance"."Protocol" ("name") VALUES ('TLS');
INSERT INTO "advance"."Protocol" ("name") VALUES ('SSH');
INSERT INTO "advance"."Protocol" ("name") VALUES ('PLAIN_TEXT');
INSERT INTO "advance"."Protocol" ("name") VALUES ('UNKNOWN');

-- CipherSuite depends on Protocol values, so it must come after.
INSERT INTO "advance"."CipherSuite" VALUES (DEFAULT, (SELECT id FROM "advance"."Protocol" WHERE name='TLS'),
    'SSL_FORTEZZA_KEA_WITH_NULL_SHA', x'001C'::int);
INSERT INTO "advance"."CipherSuite" VALUES (DEFAULT, (SELECT id FROM "advance"."Protocol" WHERE name='TLS'),
    'SSL_FORTEZZA_KEA_WITH_FORTEZZA_CBC_SHA', x'001D'::int);
INSERT INTO "advance"."CipherSuite" VALUES (DEFAULT, (SELECT id FROM "advance"."Protocol" WHERE name='TLS'),
    'TLS_NULL_WITH_NULL_NULL', x'0000'::int);
INSERT INTO "advance"."CipherSuite" VALUES (DEFAULT, (SELECT id FROM "advance"."Protocol" WHERE name='TLS'),
    'TLS_RSA_WITH_NULL_MD5', x'0001'::int);
INSERT INTO "advance"."CipherSuite" VALUES (DEFAULT, (SELECT id FROM "advance"."Protocol" WHERE name='TLS'),
    'TLS_RSA_WITH_NULL_SHA', x'0002'::int);
INSERT INTO "advance"."CipherSuite" VALUES (DEFAULT, (SELECT id FROM "advance"."Protocol" WHERE name='TLS'),
    'TLS_RSA_EXPORT_WITH_RC4_40_MD5', x'0003'::int);
INSERT INTO "advance"."CipherSuite" VALUES (DEFAULT, (SELECT id FROM "advance"."Protocol" WHERE name='TLS'),
    'TLS_RSA_WITH_RC4_128_MD5', x'0004'::int);
INSERT INTO "advance"."CipherSuite" VALUES (DEFAULT, (SELECT id FROM "advance"."Protocol" WHERE name='TLS'),
    'TLS_RSA_WITH_RC4_128_SHA', x'0005'::int);
INSERT INTO "advance"."CipherSuite" VALUES (DEFAULT, (SELECT id FROM "advance"."Protocol" WHERE name='TLS'),
    'TLS_RSA_EXPORT_WITH_RC2_CBC_40_MD5', x'0006'::int);
INSERT INTO "advance"."CipherSuite" VALUES (DEFAULT, (SELECT id FROM "advance"."Protocol" WHERE name='TLS'),
    'TLS_RSA_WITH_IDEA_CBC_SHA', x'0007'::int);
INSERT INTO "advance"."CipherSuite" VALUES (DEFAULT, (SELECT id FROM "advance"."Protocol" WHERE name='TLS'),
    'TLS_RSA_EXPORT_WITH_DES40_CBC_SHA', x'0008'::int);
INSERT INTO "advance"."CipherSuite" VALUES (DEFAULT, (SELECT id FROM "advance"."Protocol" WHERE name='TLS'),
    'TLS_RSA_WITH_DES_CBC_SHA', x'0009'::int);
INSERT INTO "advance"."CipherSuite" VALUES (DEFAULT, (SELECT id FROM "advance"."Protocol" WHERE name='TLS'),
    'TLS_RSA_WITH_3DES_EDE_CBC_SHA', x'000A'::int);
INSERT INTO "advance"."CipherSuite" VALUES (DEFAULT, (SELECT id FROM "advance"."Protocol" WHERE name='TLS'),
    'TLS_DH_DSS_EXPORT_WITH_DES40_CBC_SHA', x'000B'::int);
INSERT INTO "advance"."CipherSuite" VALUES (DEFAULT, (SELECT id FROM "advance"."Protocol" WHERE name='TLS'),
    'TLS_DH_DSS_WITH_DES_CBC_SHA', x'000C'::int);
INSERT INTO "advance"."CipherSuite" VALUES (DEFAULT, (SELECT id FROM "advance"."Protocol" WHERE name='TLS'),
    'TLS_DH_DSS_WITH_3DES_EDE_CBC_SHA', x'000D'::int);
INSERT INTO "advance"."CipherSuite" VALUES (DEFAULT, (SELECT id FROM "advance"."Protocol" WHERE name='TLS'),
    'TLS_DH_RSA_EXPORT_WITH_DES40_CBC_SHA', x'000E'::int);
INSERT INTO "advance"."CipherSuite" VALUES (DEFAULT, (SELECT id FROM "advance"."Protocol" WHERE name='TLS'),
    'TLS_DH_RSA_WITH_DES_CBC_SHA', x'000F'::int);
INSERT INTO "advance"."CipherSuite" VALUES (DEFAULT, (SELECT id FROM "advance"."Protocol" WHERE name='TLS'),
    'TLS_DH_RSA_WITH_3DES_EDE_CBC_SHA', x'0010'::int);
INSERT INTO "advance"."CipherSuite" VALUES (DEFAULT, (SELECT id FROM "advance"."Protocol" WHERE name='TLS'),
    'TLS_DHE_DSS_EXPORT_WITH_DES40_CBC_SHA', x'0011'::int);
INSERT INTO "advance"."CipherSuite" VALUES (DEFAULT, (SELECT id FROM "advance"."Protocol" WHERE name='TLS'),
    'TLS_DHE_DSS_WITH_DES_CBC_SHA', x'0012'::int);
INSERT INTO "advance"."CipherSuite" VALUES (DEFAULT, (SELECT id FROM "advance"."Protocol" WHERE name='TLS'),
    'TLS_DHE_DSS_WITH_3DES_EDE_CBC_SHA', x'0013'::int);
INSERT INTO "advance"."CipherSuite" VALUES (DEFAULT, (SELECT id FROM "advance"."Protocol" WHERE name='TLS'),
    'TLS_DHE_RSA_EXPORT_WITH_DES40_CBC_SHA', x'0014'::int);
INSERT INTO "advance"."CipherSuite" VALUES (DEFAULT, (SELECT id FROM "advance"."Protocol" WHERE name='TLS'),
    'TLS_DHE_RSA_WITH_DES_CBC_SHA', x'0015'::int);
INSERT INTO "advance"."CipherSuite" VALUES (DEFAULT, (SELECT id FROM "advance"."Protocol" WHERE name='TLS'),
    'TLS_DHE_RSA_WITH_3DES_EDE_CBC_SHA', x'0016'::int);
INSERT INTO "advance"."CipherSuite" VALUES (DEFAULT, (SELECT id FROM "advance"."Protocol" WHERE name='TLS'),
    'TLS_DH_anon_EXPORT_WITH_RC4_40_MD5', x'0017'::int);
INSERT INTO "advance"."CipherSuite" VALUES (DEFAULT, (SELECT id FROM "advance"."Protocol" WHERE name='TLS'),
    'TLS_DH_anon_WITH_RC4_128_MD5', x'0018'::int);
INSERT INTO "advance"."CipherSuite" VALUES (DEFAULT, (SELECT id FROM "advance"."Protocol" WHERE name='TLS'),
    'TLS_DH_anon_EXPORT_WITH_DES40_CBC_SHA', x'0019'::int);
INSERT INTO "advance"."CipherSuite" VALUES (DEFAULT, (SELECT id FROM "advance"."Protocol" WHERE name='TLS'),
    'TLS_DH_anon_WITH_DES_CBC_SHA', x'001A'::int);
INSERT INTO "advance"."CipherSuite" VALUES (DEFAULT, (SELECT id FROM "advance"."Protocol" WHERE name='TLS'),
    'TLS_DH_anon_WITH_3DES_EDE_CBC_SHA', x'001B'::int);
INSERT INTO "advance"."CipherSuite" VALUES (DEFAULT, (SELECT id FROM "advance"."Protocol" WHERE name='TLS'),
    'TLS_KRB5_WITH_DES_CBC_SHA', x'001E'::int);
INSERT INTO "advance"."CipherSuite" VALUES (DEFAULT, (SELECT id FROM "advance"."Protocol" WHERE name='TLS'),
    'TLS_KRB5_WITH_3DES_EDE_CBC_SHA', x'001F'::int);
INSERT INTO "advance"."CipherSuite" VALUES (DEFAULT, (SELECT id FROM "advance"."Protocol" WHERE name='TLS'),
    'TLS_KRB5_WITH_RC4_128_SHA', x'0020'::int);
INSERT INTO "advance"."CipherSuite" VALUES (DEFAULT, (SELECT id FROM "advance"."Protocol" WHERE name='TLS'),
    'TLS_KRB5_WITH_IDEA_CBC_SHA', x'0021'::int);
INSERT INTO "advance"."CipherSuite" VALUES (DEFAULT, (SELECT id FROM "advance"."Protocol" WHERE name='TLS'),
    'TLS_KRB5_WITH_DES_CBC_MD5', x'0022'::int);
INSERT INTO "advance"."CipherSuite" VALUES (DEFAULT, (SELECT id FROM "advance"."Protocol" WHERE name='TLS'),
    'TLS_KRB5_WITH_3DES_EDE_CBC_MD5', x'0023'::int);
INSERT INTO "advance"."CipherSuite" VALUES (DEFAULT, (SELECT id FROM "advance"."Protocol" WHERE name='TLS'),
    'TLS_KRB5_WITH_RC4_128_MD5', x'0024'::int);
INSERT INTO "advance"."CipherSuite" VALUES (DEFAULT, (SELECT id FROM "advance"."Protocol" WHERE name='TLS'),
    'TLS_KRB5_WITH_IDEA_CBC_MD5', x'0025'::int);
INSERT INTO "advance"."CipherSuite" VALUES (DEFAULT, (SELECT id FROM "advance"."Protocol" WHERE name='TLS'),
    'TLS_KRB5_EXPORT_WITH_DES_CBC_40_SHA', x'0026'::int);
INSERT INTO "advance"."CipherSuite" VALUES (DEFAULT, (SELECT id FROM "advance"."Protocol" WHERE name='TLS'),
    'TLS_KRB5_EXPORT_WITH_RC2_CBC_40_SHA', x'0027'::int);
INSERT INTO "advance"."CipherSuite" VALUES (DEFAULT, (SELECT id FROM "advance"."Protocol" WHERE name='TLS'),
    'TLS_KRB5_EXPORT_WITH_RC4_40_SHA', x'0028'::int);
INSERT INTO "advance"."CipherSuite" VALUES (DEFAULT, (SELECT id FROM "advance"."Protocol" WHERE name='TLS'),
    'TLS_KRB5_EXPORT_WITH_DES_CBC_40_MD5', x'0029'::int);
INSERT INTO "advance"."CipherSuite" VALUES (DEFAULT, (SELECT id FROM "advance"."Protocol" WHERE name='TLS'),
    'TLS_KRB5_EXPORT_WITH_RC2_CBC_40_MD5', x'002A'::int);
INSERT INTO "advance"."CipherSuite" VALUES (DEFAULT, (SELECT id FROM "advance"."Protocol" WHERE name='TLS'),
    'TLS_KRB5_EXPORT_WITH_RC4_40_MD5', x'002B'::int);
INSERT INTO "advance"."CipherSuite" VALUES (DEFAULT, (SELECT id FROM "advance"."Protocol" WHERE name='TLS'),
    'TLS_PSK_WITH_NULL_SHA', x'002C'::int);
INSERT INTO "advance"."CipherSuite" VALUES (DEFAULT, (SELECT id FROM "advance"."Protocol" WHERE name='TLS'),
    'TLS_DHE_PSK_WITH_NULL_SHA', x'002D'::int);
INSERT INTO "advance"."CipherSuite" VALUES (DEFAULT, (SELECT id FROM "advance"."Protocol" WHERE name='TLS'),
    'TLS_RSA_PSK_WITH_NULL_SHA', x'002E'::int);
INSERT INTO "advance"."CipherSuite" VALUES (DEFAULT, (SELECT id FROM "advance"."Protocol" WHERE name='TLS'),
    'TLS_RSA_WITH_AES_128_CBC_SHA', x'002F'::int);
INSERT INTO "advance"."CipherSuite" VALUES (DEFAULT, (SELECT id FROM "advance"."Protocol" WHERE name='TLS'),
    'TLS_DH_DSS_WITH_AES_128_CBC_SHA', x'0030'::int);
INSERT INTO "advance"."CipherSuite" VALUES (DEFAULT, (SELECT id FROM "advance"."Protocol" WHERE name='TLS'),
    'TLS_DH_RSA_WITH_AES_128_CBC_SHA', x'0031'::int);
INSERT INTO "advance"."CipherSuite" VALUES (DEFAULT, (SELECT id FROM "advance"."Protocol" WHERE name='TLS'),
    'TLS_DHE_DSS_WITH_AES_128_CBC_SHA', x'0032'::int);
INSERT INTO "advance"."CipherSuite" VALUES (DEFAULT, (SELECT id FROM "advance"."Protocol" WHERE name='TLS'),
    'TLS_DHE_RSA_WITH_AES_128_CBC_SHA', x'0033'::int);
INSERT INTO "advance"."CipherSuite" VALUES (DEFAULT, (SELECT id FROM "advance"."Protocol" WHERE name='TLS'),
    'TLS_DH_anon_WITH_AES_128_CBC_SHA', x'0034'::int);
INSERT INTO "advance"."CipherSuite" VALUES (DEFAULT, (SELECT id FROM "advance"."Protocol" WHERE name='TLS'),
    'TLS_RSA_WITH_AES_256_CBC_SHA', x'0035'::int);
INSERT INTO "advance"."CipherSuite" VALUES (DEFAULT, (SELECT id FROM "advance"."Protocol" WHERE name='TLS'),
    'TLS_DH_DSS_WITH_AES_256_CBC_SHA', x'0036'::int);
INSERT INTO "advance"."CipherSuite" VALUES (DEFAULT, (SELECT id FROM "advance"."Protocol" WHERE name='TLS'),
    'TLS_DH_RSA_WITH_AES_256_CBC_SHA', x'0037'::int);
INSERT INTO "advance"."CipherSuite" VALUES (DEFAULT, (SELECT id FROM "advance"."Protocol" WHERE name='TLS'),
    'TLS_DHE_DSS_WITH_AES_256_CBC_SHA', x'0038'::int);
INSERT INTO "advance"."CipherSuite" VALUES (DEFAULT, (SELECT id FROM "advance"."Protocol" WHERE name='TLS'),
    'TLS_DHE_RSA_WITH_AES_256_CBC_SHA', x'0039'::int);
INSERT INTO "advance"."CipherSuite" VALUES (DEFAULT, (SELECT id FROM "advance"."Protocol" WHERE name='TLS'),
    'TLS_DH_anon_WITH_AES_256_CBC_SHA', x'003A'::int);
INSERT INTO "advance"."CipherSuite" VALUES (DEFAULT, (SELECT id FROM "advance"."Protocol" WHERE name='TLS'),
    'TLS_RSA_WITH_NULL_SHA256', x'003B'::int);
INSERT INTO "advance"."CipherSuite" VALUES (DEFAULT, (SELECT id FROM "advance"."Protocol" WHERE name='TLS'),
    'TLS_RSA_WITH_AES_128_CBC_SHA256', x'003C'::int);
INSERT INTO "advance"."CipherSuite" VALUES (DEFAULT, (SELECT id FROM "advance"."Protocol" WHERE name='TLS'),
    'TLS_RSA_WITH_AES_256_CBC_SHA256', x'003D'::int);
INSERT INTO "advance"."CipherSuite" VALUES (DEFAULT, (SELECT id FROM "advance"."Protocol" WHERE name='TLS'),
    'TLS_DH_DSS_WITH_AES_128_CBC_SHA256', x'003E'::int);
INSERT INTO "advance"."CipherSuite" VALUES (DEFAULT, (SELECT id FROM "advance"."Protocol" WHERE name='TLS'),
    'TLS_DH_RSA_WITH_AES_128_CBC_SHA256', x'003F'::int);
INSERT INTO "advance"."CipherSuite" VALUES (DEFAULT, (SELECT id FROM "advance"."Protocol" WHERE name='TLS'),
    'TLS_DHE_DSS_WITH_AES_128_CBC_SHA256', x'0040'::int);
INSERT INTO "advance"."CipherSuite" VALUES (DEFAULT, (SELECT id FROM "advance"."Protocol" WHERE name='TLS'),
    'TLS_RSA_WITH_CAMELLIA_128_CBC_SHA', x'0041'::int);
INSERT INTO "advance"."CipherSuite" VALUES (DEFAULT, (SELECT id FROM "advance"."Protocol" WHERE name='TLS'),
    'TLS_DH_DSS_WITH_CAMELLIA_128_CBC_SHA', x'0042'::int);
INSERT INTO "advance"."CipherSuite" VALUES (DEFAULT, (SELECT id FROM "advance"."Protocol" WHERE name='TLS'),
    'TLS_DH_RSA_WITH_CAMELLIA_128_CBC_SHA', x'0043'::int);
INSERT INTO "advance"."CipherSuite" VALUES (DEFAULT, (SELECT id FROM "advance"."Protocol" WHERE name='TLS'),
    'TLS_DHE_DSS_WITH_CAMELLIA_128_CBC_SHA', x'0044'::int);
INSERT INTO "advance"."CipherSuite" VALUES (DEFAULT, (SELECT id FROM "advance"."Protocol" WHERE name='TLS'),
    'TLS_DHE_RSA_WITH_CAMELLIA_128_CBC_SHA', x'0045'::int);
INSERT INTO "advance"."CipherSuite" VALUES (DEFAULT, (SELECT id FROM "advance"."Protocol" WHERE name='TLS'),
    'TLS_DH_anon_WITH_CAMELLIA_128_CBC_SHA', x'0046'::int);
INSERT INTO "advance"."CipherSuite" VALUES (DEFAULT, (SELECT id FROM "advance"."Protocol" WHERE name='TLS'),
    'TLS_DHE_RSA_WITH_AES_128_CBC_SHA256', x'0067'::int);
INSERT INTO "advance"."CipherSuite" VALUES (DEFAULT, (SELECT id FROM "advance"."Protocol" WHERE name='TLS'),
    'TLS_DH_DSS_WITH_AES_256_CBC_SHA256', x'0068'::int);
INSERT INTO "advance"."CipherSuite" VALUES (DEFAULT, (SELECT id FROM "advance"."Protocol" WHERE name='TLS'),
    'TLS_DH_RSA_WITH_AES_256_CBC_SHA256', x'0069'::int);
INSERT INTO "advance"."CipherSuite" VALUES (DEFAULT, (SELECT id FROM "advance"."Protocol" WHERE name='TLS'),
    'TLS_DHE_DSS_WITH_AES_256_CBC_SHA256', x'006A'::int);
INSERT INTO "advance"."CipherSuite" VALUES (DEFAULT, (SELECT id FROM "advance"."Protocol" WHERE name='TLS'),
    'TLS_DHE_RSA_WITH_AES_256_CBC_SHA256', x'006B'::int);
INSERT INTO "advance"."CipherSuite" VALUES (DEFAULT, (SELECT id FROM "advance"."Protocol" WHERE name='TLS'),
    'TLS_DH_anon_WITH_AES_128_CBC_SHA256', x'006C'::int);
INSERT INTO "advance"."CipherSuite" VALUES (DEFAULT, (SELECT id FROM "advance"."Protocol" WHERE name='TLS'),
    'TLS_DH_anon_WITH_AES_256_CBC_SHA256', x'006D'::int);
INSERT INTO "advance"."CipherSuite" VALUES (DEFAULT, (SELECT id FROM "advance"."Protocol" WHERE name='TLS'),
    'TLS_RSA_WITH_CAMELLIA_256_CBC_SHA', x'0084'::int);
INSERT INTO "advance"."CipherSuite" VALUES (DEFAULT, (SELECT id FROM "advance"."Protocol" WHERE name='TLS'),
    'TLS_DH_DSS_WITH_CAMELLIA_256_CBC_SHA', x'0085'::int);
INSERT INTO "advance"."CipherSuite" VALUES (DEFAULT, (SELECT id FROM "advance"."Protocol" WHERE name='TLS'),
    'TLS_DH_RSA_WITH_CAMELLIA_256_CBC_SHA', x'0086'::int);
INSERT INTO "advance"."CipherSuite" VALUES (DEFAULT, (SELECT id FROM "advance"."Protocol" WHERE name='TLS'),
    'TLS_DHE_DSS_WITH_CAMELLIA_256_CBC_SHA', x'0087'::int);
INSERT INTO "advance"."CipherSuite" VALUES (DEFAULT, (SELECT id FROM "advance"."Protocol" WHERE name='TLS'),
    'TLS_DHE_RSA_WITH_CAMELLIA_256_CBC_SHA', x'0088'::int);
INSERT INTO "advance"."CipherSuite" VALUES (DEFAULT, (SELECT id FROM "advance"."Protocol" WHERE name='TLS'),
    'TLS_DH_anon_WITH_CAMELLIA_256_CBC_SHA', x'0089'::int);
INSERT INTO "advance"."CipherSuite" VALUES (DEFAULT, (SELECT id FROM "advance"."Protocol" WHERE name='TLS'),
    'TLS_PSK_WITH_RC4_128_SHA', x'008A'::int);
INSERT INTO "advance"."CipherSuite" VALUES (DEFAULT, (SELECT id FROM "advance"."Protocol" WHERE name='TLS'),
    'TLS_PSK_WITH_3DES_EDE_CBC_SHA', x'008B'::int);
INSERT INTO "advance"."CipherSuite" VALUES (DEFAULT, (SELECT id FROM "advance"."Protocol" WHERE name='TLS'),
    'TLS_PSK_WITH_AES_128_CBC_SHA', x'008C'::int);
INSERT INTO "advance"."CipherSuite" VALUES (DEFAULT, (SELECT id FROM "advance"."Protocol" WHERE name='TLS'),
    'TLS_PSK_WITH_AES_256_CBC_SHA', x'008D'::int);
INSERT INTO "advance"."CipherSuite" VALUES (DEFAULT, (SELECT id FROM "advance"."Protocol" WHERE name='TLS'),
    'TLS_DHE_PSK_WITH_RC4_128_SHA', x'008E'::int);
INSERT INTO "advance"."CipherSuite" VALUES (DEFAULT, (SELECT id FROM "advance"."Protocol" WHERE name='TLS'),
    'TLS_DHE_PSK_WITH_3DES_EDE_CBC_SHA', x'008F'::int);
INSERT INTO "advance"."CipherSuite" VALUES (DEFAULT, (SELECT id FROM "advance"."Protocol" WHERE name='TLS'),
    'TLS_DHE_PSK_WITH_AES_128_CBC_SHA', x'0090'::int);
INSERT INTO "advance"."CipherSuite" VALUES (DEFAULT, (SELECT id FROM "advance"."Protocol" WHERE name='TLS'),
    'TLS_DHE_PSK_WITH_AES_256_CBC_SHA', x'0091'::int);
INSERT INTO "advance"."CipherSuite" VALUES (DEFAULT, (SELECT id FROM "advance"."Protocol" WHERE name='TLS'),
    'TLS_RSA_PSK_WITH_RC4_128_SHA', x'0092'::int);
INSERT INTO "advance"."CipherSuite" VALUES (DEFAULT, (SELECT id FROM "advance"."Protocol" WHERE name='TLS'),
    'TLS_RSA_PSK_WITH_3DES_EDE_CBC_SHA', x'0093'::int);
INSERT INTO "advance"."CipherSuite" VALUES (DEFAULT, (SELECT id FROM "advance"."Protocol" WHERE name='TLS'),
    'TLS_RSA_PSK_WITH_AES_128_CBC_SHA', x'0094'::int);
INSERT INTO "advance"."CipherSuite" VALUES (DEFAULT, (SELECT id FROM "advance"."Protocol" WHERE name='TLS'),
    'TLS_RSA_PSK_WITH_AES_256_CBC_SHA', x'0095'::int);
INSERT INTO "advance"."CipherSuite" VALUES (DEFAULT, (SELECT id FROM "advance"."Protocol" WHERE name='TLS'),
    'TLS_RSA_WITH_SEED_CBC_SHA', x'0096'::int);
INSERT INTO "advance"."CipherSuite" VALUES (DEFAULT, (SELECT id FROM "advance"."Protocol" WHERE name='TLS'),
    'TLS_DH_DSS_WITH_SEED_CBC_SHA', x'0097'::int);
INSERT INTO "advance"."CipherSuite" VALUES (DEFAULT, (SELECT id FROM "advance"."Protocol" WHERE name='TLS'),
    'TLS_DH_RSA_WITH_SEED_CBC_SHA', x'0098'::int);
INSERT INTO "advance"."CipherSuite" VALUES (DEFAULT, (SELECT id FROM "advance"."Protocol" WHERE name='TLS'),
    'TLS_DHE_DSS_WITH_SEED_CBC_SHA', x'0099'::int);
INSERT INTO "advance"."CipherSuite" VALUES (DEFAULT, (SELECT id FROM "advance"."Protocol" WHERE name='TLS'),
    'TLS_DHE_RSA_WITH_SEED_CBC_SHA', x'009A'::int);
INSERT INTO "advance"."CipherSuite" VALUES (DEFAULT, (SELECT id FROM "advance"."Protocol" WHERE name='TLS'),
    'TLS_DH_anon_WITH_SEED_CBC_SHA', x'009B'::int);
INSERT INTO "advance"."CipherSuite" VALUES (DEFAULT, (SELECT id FROM "advance"."Protocol" WHERE name='TLS'),
    'TLS_RSA_WITH_AES_128_GCM_SHA256', x'009C'::int);
INSERT INTO "advance"."CipherSuite" VALUES (DEFAULT, (SELECT id FROM "advance"."Protocol" WHERE name='TLS'),
    'TLS_RSA_WITH_AES_256_GCM_SHA384', x'009D'::int);
INSERT INTO "advance"."CipherSuite" VALUES (DEFAULT, (SELECT id FROM "advance"."Protocol" WHERE name='TLS'),
    'TLS_DHE_RSA_WITH_AES_128_GCM_SHA256', x'009E'::int);
INSERT INTO "advance"."CipherSuite" VALUES (DEFAULT, (SELECT id FROM "advance"."Protocol" WHERE name='TLS'),
    'TLS_DHE_RSA_WITH_AES_256_GCM_SHA384', x'009F'::int);
INSERT INTO "advance"."CipherSuite" VALUES (DEFAULT, (SELECT id FROM "advance"."Protocol" WHERE name='TLS'),
    'TLS_DH_RSA_WITH_AES_128_GCM_SHA256', x'00A0'::int);
INSERT INTO "advance"."CipherSuite" VALUES (DEFAULT, (SELECT id FROM "advance"."Protocol" WHERE name='TLS'),
    'TLS_DH_RSA_WITH_AES_256_GCM_SHA384', x'00A1'::int);
INSERT INTO "advance"."CipherSuite" VALUES (DEFAULT, (SELECT id FROM "advance"."Protocol" WHERE name='TLS'),
    'TLS_DHE_DSS_WITH_AES_128_GCM_SHA256', x'00A2'::int);
INSERT INTO "advance"."CipherSuite" VALUES (DEFAULT, (SELECT id FROM "advance"."Protocol" WHERE name='TLS'),
    'TLS_DHE_DSS_WITH_AES_256_GCM_SHA384', x'00A3'::int);
INSERT INTO "advance"."CipherSuite" VALUES (DEFAULT, (SELECT id FROM "advance"."Protocol" WHERE name='TLS'),
    'TLS_DH_DSS_WITH_AES_128_GCM_SHA256', x'00A4'::int);
INSERT INTO "advance"."CipherSuite" VALUES (DEFAULT, (SELECT id FROM "advance"."Protocol" WHERE name='TLS'),
    'TLS_DH_DSS_WITH_AES_256_GCM_SHA384', x'00A5'::int);
INSERT INTO "advance"."CipherSuite" VALUES (DEFAULT, (SELECT id FROM "advance"."Protocol" WHERE name='TLS'),
    'TLS_DH_anon_WITH_AES_128_GCM_SHA256', x'00A6'::int);
INSERT INTO "advance"."CipherSuite" VALUES (DEFAULT, (SELECT id FROM "advance"."Protocol" WHERE name='TLS'),
    'TLS_DH_anon_WITH_AES_256_GCM_SHA384', x'00A7'::int);
INSERT INTO "advance"."CipherSuite" VALUES (DEFAULT, (SELECT id FROM "advance"."Protocol" WHERE name='TLS'),
    'TLS_PSK_WITH_AES_128_GCM_SHA256', x'00A8'::int);
INSERT INTO "advance"."CipherSuite" VALUES (DEFAULT, (SELECT id FROM "advance"."Protocol" WHERE name='TLS'),
    'TLS_PSK_WITH_AES_256_GCM_SHA384', x'00A9'::int);
INSERT INTO "advance"."CipherSuite" VALUES (DEFAULT, (SELECT id FROM "advance"."Protocol" WHERE name='TLS'),
    'TLS_DHE_PSK_WITH_AES_128_GCM_SHA256', x'00AA'::int);
INSERT INTO "advance"."CipherSuite" VALUES (DEFAULT, (SELECT id FROM "advance"."Protocol" WHERE name='TLS'),
    'TLS_DHE_PSK_WITH_AES_256_GCM_SHA384', x'00AB'::int);
INSERT INTO "advance"."CipherSuite" VALUES (DEFAULT, (SELECT id FROM "advance"."Protocol" WHERE name='TLS'),
    'TLS_RSA_PSK_WITH_AES_128_GCM_SHA256', x'00AC'::int);
INSERT INTO "advance"."CipherSuite" VALUES (DEFAULT, (SELECT id FROM "advance"."Protocol" WHERE name='TLS'),
    'TLS_RSA_PSK_WITH_AES_256_GCM_SHA384', x'00AD'::int);
INSERT INTO "advance"."CipherSuite" VALUES (DEFAULT, (SELECT id FROM "advance"."Protocol" WHERE name='TLS'),
    'TLS_PSK_WITH_AES_128_CBC_SHA256', x'00AE'::int);
INSERT INTO "advance"."CipherSuite" VALUES (DEFAULT, (SELECT id FROM "advance"."Protocol" WHERE name='TLS'),
    'TLS_PSK_WITH_AES_256_CBC_SHA384', x'00AF'::int);
INSERT INTO "advance"."CipherSuite" VALUES (DEFAULT, (SELECT id FROM "advance"."Protocol" WHERE name='TLS'),
    'TLS_PSK_WITH_NULL_SHA256', x'00B0'::int);
INSERT INTO "advance"."CipherSuite" VALUES (DEFAULT, (SELECT id FROM "advance"."Protocol" WHERE name='TLS'),
    'TLS_PSK_WITH_NULL_SHA384', x'00B1'::int);
INSERT INTO "advance"."CipherSuite" VALUES (DEFAULT, (SELECT id FROM "advance"."Protocol" WHERE name='TLS'),
    'TLS_DHE_PSK_WITH_AES_128_CBC_SHA256', x'00B2'::int);
INSERT INTO "advance"."CipherSuite" VALUES (DEFAULT, (SELECT id FROM "advance"."Protocol" WHERE name='TLS'),
    'TLS_DHE_PSK_WITH_AES_256_CBC_SHA384', x'00B3'::int);
INSERT INTO "advance"."CipherSuite" VALUES (DEFAULT, (SELECT id FROM "advance"."Protocol" WHERE name='TLS'),
    'TLS_DHE_PSK_WITH_NULL_SHA256', x'00B4'::int);
INSERT INTO "advance"."CipherSuite" VALUES (DEFAULT, (SELECT id FROM "advance"."Protocol" WHERE name='TLS'),
    'TLS_DHE_PSK_WITH_NULL_SHA384', x'00B5'::int);
INSERT INTO "advance"."CipherSuite" VALUES (DEFAULT, (SELECT id FROM "advance"."Protocol" WHERE name='TLS'),
    'TLS_RSA_PSK_WITH_AES_128_CBC_SHA256', x'00B6'::int);
INSERT INTO "advance"."CipherSuite" VALUES (DEFAULT, (SELECT id FROM "advance"."Protocol" WHERE name='TLS'),
    'TLS_RSA_PSK_WITH_AES_256_CBC_SHA384', x'00B7'::int);
INSERT INTO "advance"."CipherSuite" VALUES (DEFAULT, (SELECT id FROM "advance"."Protocol" WHERE name='TLS'),
    'TLS_RSA_PSK_WITH_NULL_SHA256', x'00B8'::int);
INSERT INTO "advance"."CipherSuite" VALUES (DEFAULT, (SELECT id FROM "advance"."Protocol" WHERE name='TLS'),
    'TLS_RSA_PSK_WITH_NULL_SHA384', x'00B9'::int);
INSERT INTO "advance"."CipherSuite" VALUES (DEFAULT, (SELECT id FROM "advance"."Protocol" WHERE name='TLS'),
    'TLS_RSA_WITH_CAMELLIA_128_CBC_SHA256', x'00BA'::int);
INSERT INTO "advance"."CipherSuite" VALUES (DEFAULT, (SELECT id FROM "advance"."Protocol" WHERE name='TLS'),
    'TLS_DH_DSS_WITH_CAMELLIA_128_CBC_SHA256', x'00BB'::int);
INSERT INTO "advance"."CipherSuite" VALUES (DEFAULT, (SELECT id FROM "advance"."Protocol" WHERE name='TLS'),
    'TLS_DH_RSA_WITH_CAMELLIA_128_CBC_SHA256', x'00BC'::int);
INSERT INTO "advance"."CipherSuite" VALUES (DEFAULT, (SELECT id FROM "advance"."Protocol" WHERE name='TLS'),
    'TLS_DHE_DSS_WITH_CAMELLIA_128_CBC_SHA256', x'00BD'::int);
INSERT INTO "advance"."CipherSuite" VALUES (DEFAULT, (SELECT id FROM "advance"."Protocol" WHERE name='TLS'),
    'TLS_DHE_RSA_WITH_CAMELLIA_128_CBC_SHA256', x'00BE'::int);
INSERT INTO "advance"."CipherSuite" VALUES (DEFAULT, (SELECT id FROM "advance"."Protocol" WHERE name='TLS'),
    'TLS_DH_anon_WITH_CAMELLIA_128_CBC_SHA256', x'00BF'::int);
INSERT INTO "advance"."CipherSuite" VALUES (DEFAULT, (SELECT id FROM "advance"."Protocol" WHERE name='TLS'),
    'TLS_RSA_WITH_CAMELLIA_256_CBC_SHA256', x'00C0'::int);
INSERT INTO "advance"."CipherSuite" VALUES (DEFAULT, (SELECT id FROM "advance"."Protocol" WHERE name='TLS'),
    'TLS_DH_DSS_WITH_CAMELLIA_256_CBC_SHA256', x'00C1'::int);
INSERT INTO "advance"."CipherSuite" VALUES (DEFAULT, (SELECT id FROM "advance"."Protocol" WHERE name='TLS'),
    'TLS_DH_RSA_WITH_CAMELLIA_256_CBC_SHA256', x'00C2'::int);
INSERT INTO "advance"."CipherSuite" VALUES (DEFAULT, (SELECT id FROM "advance"."Protocol" WHERE name='TLS'),
    'TLS_DHE_DSS_WITH_CAMELLIA_256_CBC_SHA256', x'00C3'::int);
INSERT INTO "advance"."CipherSuite" VALUES (DEFAULT, (SELECT id FROM "advance"."Protocol" WHERE name='TLS'),
    'TLS_DHE_RSA_WITH_CAMELLIA_256_CBC_SHA256', x'00C4'::int);
INSERT INTO "advance"."CipherSuite" VALUES (DEFAULT, (SELECT id FROM "advance"."Protocol" WHERE name='TLS'),
    'TLS_DH_anon_WITH_CAMELLIA_256_CBC_SHA256', x'00C5'::int);
INSERT INTO "advance"."CipherSuite" VALUES (DEFAULT, (SELECT id FROM "advance"."Protocol" WHERE name='TLS'),
    'TLS_SM4_GCM_SM3', x'00C6'::int);
INSERT INTO "advance"."CipherSuite" VALUES (DEFAULT, (SELECT id FROM "advance"."Protocol" WHERE name='TLS'),
    'TLS_SM4_CCM_SM3', x'00C7'::int);
INSERT INTO "advance"."CipherSuite" VALUES (DEFAULT, (SELECT id FROM "advance"."Protocol" WHERE name='TLS'),
    'TLS_EMPTY_RENEGOTIATION_INFO_SCSV', x'00FF'::int);
INSERT INTO "advance"."CipherSuite" VALUES (DEFAULT, (SELECT id FROM "advance"."Protocol" WHERE name='TLS'),
    'TLS_AES_128_GCM_SHA256', x'1301'::int);
INSERT INTO "advance"."CipherSuite" VALUES (DEFAULT, (SELECT id FROM "advance"."Protocol" WHERE name='TLS'),
    'TLS_AES_256_GCM_SHA384', x'1302'::int);
INSERT INTO "advance"."CipherSuite" VALUES (DEFAULT, (SELECT id FROM "advance"."Protocol" WHERE name='TLS'),
    'TLS_CHACHA20_POLY1305_SHA256', x'1303'::int);
INSERT INTO "advance"."CipherSuite" VALUES (DEFAULT, (SELECT id FROM "advance"."Protocol" WHERE name='TLS'),
    'TLS_AES_128_CCM_SHA256', x'1304'::int);
INSERT INTO "advance"."CipherSuite" VALUES (DEFAULT, (SELECT id FROM "advance"."Protocol" WHERE name='TLS'),
    'TLS_AES_128_CCM_8_SHA256', x'1305'::int);
INSERT INTO "advance"."CipherSuite" VALUES (DEFAULT, (SELECT id FROM "advance"."Protocol" WHERE name='TLS'),
    'TLS_FALLBACK_SCSV', x'5600'::int);
INSERT INTO "advance"."CipherSuite" VALUES (DEFAULT, (SELECT id FROM "advance"."Protocol" WHERE name='TLS'),
    'TLS_ECDH_ECDSA_WITH_NULL_SHA', x'C001'::int);
INSERT INTO "advance"."CipherSuite" VALUES (DEFAULT, (SELECT id FROM "advance"."Protocol" WHERE name='TLS'),
    'TLS_ECDH_ECDSA_WITH_RC4_128_SHA', x'C002'::int);
INSERT INTO "advance"."CipherSuite" VALUES (DEFAULT, (SELECT id FROM "advance"."Protocol" WHERE name='TLS'),
    'TLS_ECDH_ECDSA_WITH_3DES_EDE_CBC_SHA', x'C003'::int);
INSERT INTO "advance"."CipherSuite" VALUES (DEFAULT, (SELECT id FROM "advance"."Protocol" WHERE name='TLS'),
    'TLS_ECDH_ECDSA_WITH_AES_128_CBC_SHA', x'C004'::int);
INSERT INTO "advance"."CipherSuite" VALUES (DEFAULT, (SELECT id FROM "advance"."Protocol" WHERE name='TLS'),
    'TLS_ECDH_ECDSA_WITH_AES_256_CBC_SHA', x'C005'::int);
INSERT INTO "advance"."CipherSuite" VALUES (DEFAULT, (SELECT id FROM "advance"."Protocol" WHERE name='TLS'),
    'TLS_ECDHE_ECDSA_WITH_NULL_SHA', x'C006'::int);
INSERT INTO "advance"."CipherSuite" VALUES (DEFAULT, (SELECT id FROM "advance"."Protocol" WHERE name='TLS'),
    'TLS_ECDHE_ECDSA_WITH_RC4_128_SHA', x'C007'::int);
INSERT INTO "advance"."CipherSuite" VALUES (DEFAULT, (SELECT id FROM "advance"."Protocol" WHERE name='TLS'),
    'TLS_ECDHE_ECDSA_WITH_3DES_EDE_CBC_SHA', x'C008'::int);
INSERT INTO "advance"."CipherSuite" VALUES (DEFAULT, (SELECT id FROM "advance"."Protocol" WHERE name='TLS'),
    'TLS_ECDHE_ECDSA_WITH_AES_128_CBC_SHA', x'C009'::int);
INSERT INTO "advance"."CipherSuite" VALUES (DEFAULT, (SELECT id FROM "advance"."Protocol" WHERE name='TLS'),
    'TLS_ECDHE_ECDSA_WITH_AES_256_CBC_SHA', x'C00A'::int);
INSERT INTO "advance"."CipherSuite" VALUES (DEFAULT, (SELECT id FROM "advance"."Protocol" WHERE name='TLS'),
    'TLS_ECDH_RSA_WITH_NULL_SHA', x'C00B'::int);
INSERT INTO "advance"."CipherSuite" VALUES (DEFAULT, (SELECT id FROM "advance"."Protocol" WHERE name='TLS'),
    'TLS_ECDH_RSA_WITH_RC4_128_SHA', x'C00C'::int);
INSERT INTO "advance"."CipherSuite" VALUES (DEFAULT, (SELECT id FROM "advance"."Protocol" WHERE name='TLS'),
    'TLS_ECDH_RSA_WITH_3DES_EDE_CBC_SHA', x'C00D'::int);
INSERT INTO "advance"."CipherSuite" VALUES (DEFAULT, (SELECT id FROM "advance"."Protocol" WHERE name='TLS'),
    'TLS_ECDH_RSA_WITH_AES_128_CBC_SHA', x'C00E'::int);
INSERT INTO "advance"."CipherSuite" VALUES (DEFAULT, (SELECT id FROM "advance"."Protocol" WHERE name='TLS'),
    'TLS_ECDH_RSA_WITH_AES_256_CBC_SHA', x'C00F'::int);
INSERT INTO "advance"."CipherSuite" VALUES (DEFAULT, (SELECT id FROM "advance"."Protocol" WHERE name='TLS'),
    'TLS_ECDHE_RSA_WITH_NULL_SHA', x'C010'::int);
INSERT INTO "advance"."CipherSuite" VALUES (DEFAULT, (SELECT id FROM "advance"."Protocol" WHERE name='TLS'),
    'TLS_ECDHE_RSA_WITH_RC4_128_SHA', x'C011'::int);
INSERT INTO "advance"."CipherSuite" VALUES (DEFAULT, (SELECT id FROM "advance"."Protocol" WHERE name='TLS'),
    'TLS_ECDHE_RSA_WITH_3DES_EDE_CBC_SHA', x'C012'::int);
INSERT INTO "advance"."CipherSuite" VALUES (DEFAULT, (SELECT id FROM "advance"."Protocol" WHERE name='TLS'),
    'TLS_ECDHE_RSA_WITH_AES_128_CBC_SHA', x'C013'::int);
INSERT INTO "advance"."CipherSuite" VALUES (DEFAULT, (SELECT id FROM "advance"."Protocol" WHERE name='TLS'),
    'TLS_ECDHE_RSA_WITH_AES_256_CBC_SHA', x'C014'::int);
INSERT INTO "advance"."CipherSuite" VALUES (DEFAULT, (SELECT id FROM "advance"."Protocol" WHERE name='TLS'),
    'TLS_ECDH_anon_WITH_NULL_SHA', x'C015'::int);
INSERT INTO "advance"."CipherSuite" VALUES (DEFAULT, (SELECT id FROM "advance"."Protocol" WHERE name='TLS'),
    'TLS_ECDH_anon_WITH_RC4_128_SHA', x'C016'::int);
INSERT INTO "advance"."CipherSuite" VALUES (DEFAULT, (SELECT id FROM "advance"."Protocol" WHERE name='TLS'),
    'TLS_ECDH_anon_WITH_3DES_EDE_CBC_SHA', x'C017'::int);
INSERT INTO "advance"."CipherSuite" VALUES (DEFAULT, (SELECT id FROM "advance"."Protocol" WHERE name='TLS'),
    'TLS_ECDH_anon_WITH_AES_128_CBC_SHA', x'C018'::int);
INSERT INTO "advance"."CipherSuite" VALUES (DEFAULT, (SELECT id FROM "advance"."Protocol" WHERE name='TLS'),
    'TLS_ECDH_anon_WITH_AES_256_CBC_SHA', x'C019'::int);
INSERT INTO "advance"."CipherSuite" VALUES (DEFAULT, (SELECT id FROM "advance"."Protocol" WHERE name='TLS'),
    'TLS_SRP_SHA_WITH_3DES_EDE_CBC_SHA', x'C01A'::int);
INSERT INTO "advance"."CipherSuite" VALUES (DEFAULT, (SELECT id FROM "advance"."Protocol" WHERE name='TLS'),
    'TLS_SRP_SHA_RSA_WITH_3DES_EDE_CBC_SHA', x'C01B'::int);
INSERT INTO "advance"."CipherSuite" VALUES (DEFAULT, (SELECT id FROM "advance"."Protocol" WHERE name='TLS'),
    'TLS_SRP_SHA_DSS_WITH_3DES_EDE_CBC_SHA', x'C01C'::int);
INSERT INTO "advance"."CipherSuite" VALUES (DEFAULT, (SELECT id FROM "advance"."Protocol" WHERE name='TLS'),
    'TLS_SRP_SHA_WITH_AES_128_CBC_SHA', x'C01D'::int);
INSERT INTO "advance"."CipherSuite" VALUES (DEFAULT, (SELECT id FROM "advance"."Protocol" WHERE name='TLS'),
    'TLS_SRP_SHA_RSA_WITH_AES_128_CBC_SHA', x'C01E'::int);
INSERT INTO "advance"."CipherSuite" VALUES (DEFAULT, (SELECT id FROM "advance"."Protocol" WHERE name='TLS'),
    'TLS_SRP_SHA_DSS_WITH_AES_128_CBC_SHA', x'C01F'::int);
INSERT INTO "advance"."CipherSuite" VALUES (DEFAULT, (SELECT id FROM "advance"."Protocol" WHERE name='TLS'),
    'TLS_SRP_SHA_WITH_AES_256_CBC_SHA', x'C020'::int);
INSERT INTO "advance"."CipherSuite" VALUES (DEFAULT, (SELECT id FROM "advance"."Protocol" WHERE name='TLS'),
    'TLS_SRP_SHA_RSA_WITH_AES_256_CBC_SHA', x'C021'::int);
INSERT INTO "advance"."CipherSuite" VALUES (DEFAULT, (SELECT id FROM "advance"."Protocol" WHERE name='TLS'),
    'TLS_SRP_SHA_DSS_WITH_AES_256_CBC_SHA', x'C022'::int);
INSERT INTO "advance"."CipherSuite" VALUES (DEFAULT, (SELECT id FROM "advance"."Protocol" WHERE name='TLS'),
    'TLS_ECDHE_ECDSA_WITH_AES_128_CBC_SHA256', x'C023'::int);
INSERT INTO "advance"."CipherSuite" VALUES (DEFAULT, (SELECT id FROM "advance"."Protocol" WHERE name='TLS'),
    'TLS_ECDHE_ECDSA_WITH_AES_256_CBC_SHA384', x'C024'::int);
INSERT INTO "advance"."CipherSuite" VALUES (DEFAULT, (SELECT id FROM "advance"."Protocol" WHERE name='TLS'),
    'TLS_ECDH_ECDSA_WITH_AES_128_CBC_SHA256', x'C025'::int);
INSERT INTO "advance"."CipherSuite" VALUES (DEFAULT, (SELECT id FROM "advance"."Protocol" WHERE name='TLS'),
    'TLS_ECDH_ECDSA_WITH_AES_256_CBC_SHA384', x'C026'::int);
INSERT INTO "advance"."CipherSuite" VALUES (DEFAULT, (SELECT id FROM "advance"."Protocol" WHERE name='TLS'),
    'TLS_ECDHE_RSA_WITH_AES_128_CBC_SHA256', x'C027'::int);
INSERT INTO "advance"."CipherSuite" VALUES (DEFAULT, (SELECT id FROM "advance"."Protocol" WHERE name='TLS'),
    'TLS_ECDHE_RSA_WITH_AES_256_CBC_SHA384', x'C028'::int);
INSERT INTO "advance"."CipherSuite" VALUES (DEFAULT, (SELECT id FROM "advance"."Protocol" WHERE name='TLS'),
    'TLS_ECDH_RSA_WITH_AES_128_CBC_SHA256', x'C029'::int);
INSERT INTO "advance"."CipherSuite" VALUES (DEFAULT, (SELECT id FROM "advance"."Protocol" WHERE name='TLS'),
    'TLS_ECDH_RSA_WITH_AES_256_CBC_SHA384', x'C02A'::int);
INSERT INTO "advance"."CipherSuite" VALUES (DEFAULT, (SELECT id FROM "advance"."Protocol" WHERE name='TLS'),
    'TLS_ECDHE_ECDSA_WITH_AES_128_GCM_SHA256', x'C02B'::int);
INSERT INTO "advance"."CipherSuite" VALUES (DEFAULT, (SELECT id FROM "advance"."Protocol" WHERE name='TLS'),
    'TLS_ECDHE_ECDSA_WITH_AES_256_GCM_SHA384', x'C02C'::int);
INSERT INTO "advance"."CipherSuite" VALUES (DEFAULT, (SELECT id FROM "advance"."Protocol" WHERE name='TLS'),
    'TLS_ECDH_ECDSA_WITH_AES_128_GCM_SHA256', x'C02D'::int);
INSERT INTO "advance"."CipherSuite" VALUES (DEFAULT, (SELECT id FROM "advance"."Protocol" WHERE name='TLS'),
    'TLS_ECDH_ECDSA_WITH_AES_256_GCM_SHA384', x'C02E'::int);
INSERT INTO "advance"."CipherSuite" VALUES (DEFAULT, (SELECT id FROM "advance"."Protocol" WHERE name='TLS'),
    'TLS_ECDHE_RSA_WITH_AES_128_GCM_SHA256', x'C02F'::int);
INSERT INTO "advance"."CipherSuite" VALUES (DEFAULT, (SELECT id FROM "advance"."Protocol" WHERE name='TLS'),
    'TLS_ECDHE_RSA_WITH_AES_256_GCM_SHA384', x'C030'::int);
INSERT INTO "advance"."CipherSuite" VALUES (DEFAULT, (SELECT id FROM "advance"."Protocol" WHERE name='TLS'),
    'TLS_ECDH_RSA_WITH_AES_128_GCM_SHA256', x'C031'::int);
INSERT INTO "advance"."CipherSuite" VALUES (DEFAULT, (SELECT id FROM "advance"."Protocol" WHERE name='TLS'),
    'TLS_ECDH_RSA_WITH_AES_256_GCM_SHA384', x'C032'::int);
INSERT INTO "advance"."CipherSuite" VALUES (DEFAULT, (SELECT id FROM "advance"."Protocol" WHERE name='TLS'),
    'TLS_ECDHE_PSK_WITH_RC4_128_SHA', x'C033'::int);
INSERT INTO "advance"."CipherSuite" VALUES (DEFAULT, (SELECT id FROM "advance"."Protocol" WHERE name='TLS'),
    'TLS_ECDHE_PSK_WITH_3DES_EDE_CBC_SHA', x'C034'::int);
INSERT INTO "advance"."CipherSuite" VALUES (DEFAULT, (SELECT id FROM "advance"."Protocol" WHERE name='TLS'),
    'TLS_ECDHE_PSK_WITH_AES_128_CBC_SHA', x'C035'::int);
INSERT INTO "advance"."CipherSuite" VALUES (DEFAULT, (SELECT id FROM "advance"."Protocol" WHERE name='TLS'),
    'TLS_ECDHE_PSK_WITH_AES_256_CBC_SHA', x'C036'::int);
INSERT INTO "advance"."CipherSuite" VALUES (DEFAULT, (SELECT id FROM "advance"."Protocol" WHERE name='TLS'),
    'TLS_ECDHE_PSK_WITH_AES_128_CBC_SHA256', x'C037'::int);
INSERT INTO "advance"."CipherSuite" VALUES (DEFAULT, (SELECT id FROM "advance"."Protocol" WHERE name='TLS'),
    'TLS_ECDHE_PSK_WITH_AES_256_CBC_SHA384', x'C038'::int);
INSERT INTO "advance"."CipherSuite" VALUES (DEFAULT, (SELECT id FROM "advance"."Protocol" WHERE name='TLS'),
    'TLS_ECDHE_PSK_WITH_NULL_SHA', x'C039'::int);
INSERT INTO "advance"."CipherSuite" VALUES (DEFAULT, (SELECT id FROM "advance"."Protocol" WHERE name='TLS'),
    'TLS_ECDHE_PSK_WITH_NULL_SHA256', x'C03A'::int);
INSERT INTO "advance"."CipherSuite" VALUES (DEFAULT, (SELECT id FROM "advance"."Protocol" WHERE name='TLS'),
    'TLS_ECDHE_PSK_WITH_NULL_SHA384', x'C03B'::int);
INSERT INTO "advance"."CipherSuite" VALUES (DEFAULT, (SELECT id FROM "advance"."Protocol" WHERE name='TLS'),
    'TLS_RSA_WITH_ARIA_128_CBC_SHA256', x'C03C'::int);
INSERT INTO "advance"."CipherSuite" VALUES (DEFAULT, (SELECT id FROM "advance"."Protocol" WHERE name='TLS'),
    'TLS_RSA_WITH_ARIA_256_CBC_SHA384', x'C03D'::int);
INSERT INTO "advance"."CipherSuite" VALUES (DEFAULT, (SELECT id FROM "advance"."Protocol" WHERE name='TLS'),
    'TLS_DH_DSS_WITH_ARIA_128_CBC_SHA256', x'C03E'::int);
INSERT INTO "advance"."CipherSuite" VALUES (DEFAULT, (SELECT id FROM "advance"."Protocol" WHERE name='TLS'),
    'TLS_DH_DSS_WITH_ARIA_256_CBC_SHA384', x'C03F'::int);
INSERT INTO "advance"."CipherSuite" VALUES (DEFAULT, (SELECT id FROM "advance"."Protocol" WHERE name='TLS'),
    'TLS_DH_RSA_WITH_ARIA_128_CBC_SHA256', x'C040'::int);
INSERT INTO "advance"."CipherSuite" VALUES (DEFAULT, (SELECT id FROM "advance"."Protocol" WHERE name='TLS'),
    'TLS_DH_RSA_WITH_ARIA_256_CBC_SHA384', x'C041'::int);
INSERT INTO "advance"."CipherSuite" VALUES (DEFAULT, (SELECT id FROM "advance"."Protocol" WHERE name='TLS'),
    'TLS_DHE_DSS_WITH_ARIA_128_CBC_SHA256', x'C042'::int);
INSERT INTO "advance"."CipherSuite" VALUES (DEFAULT, (SELECT id FROM "advance"."Protocol" WHERE name='TLS'),
    'TLS_DHE_DSS_WITH_ARIA_256_CBC_SHA384', x'C043'::int);
INSERT INTO "advance"."CipherSuite" VALUES (DEFAULT, (SELECT id FROM "advance"."Protocol" WHERE name='TLS'),
    'TLS_DHE_RSA_WITH_ARIA_128_CBC_SHA256', x'C044'::int);
INSERT INTO "advance"."CipherSuite" VALUES (DEFAULT, (SELECT id FROM "advance"."Protocol" WHERE name='TLS'),
    'TLS_DHE_RSA_WITH_ARIA_256_CBC_SHA384', x'C045'::int);
INSERT INTO "advance"."CipherSuite" VALUES (DEFAULT, (SELECT id FROM "advance"."Protocol" WHERE name='TLS'),
    'TLS_DH_anon_WITH_ARIA_128_CBC_SHA256', x'C046'::int);
INSERT INTO "advance"."CipherSuite" VALUES (DEFAULT, (SELECT id FROM "advance"."Protocol" WHERE name='TLS'),
    'TLS_DH_anon_WITH_ARIA_256_CBC_SHA384', x'C047'::int);
INSERT INTO "advance"."CipherSuite" VALUES (DEFAULT, (SELECT id FROM "advance"."Protocol" WHERE name='TLS'),
    'TLS_ECDHE_ECDSA_WITH_ARIA_128_CBC_SHA256', x'C048'::int);
INSERT INTO "advance"."CipherSuite" VALUES (DEFAULT, (SELECT id FROM "advance"."Protocol" WHERE name='TLS'),
    'TLS_ECDHE_ECDSA_WITH_ARIA_256_CBC_SHA384', x'C049'::int);
INSERT INTO "advance"."CipherSuite" VALUES (DEFAULT, (SELECT id FROM "advance"."Protocol" WHERE name='TLS'),
    'TLS_ECDH_ECDSA_WITH_ARIA_128_CBC_SHA256', x'C04A'::int);
INSERT INTO "advance"."CipherSuite" VALUES (DEFAULT, (SELECT id FROM "advance"."Protocol" WHERE name='TLS'),
    'TLS_ECDH_ECDSA_WITH_ARIA_256_CBC_SHA384', x'C04B'::int);
INSERT INTO "advance"."CipherSuite" VALUES (DEFAULT, (SELECT id FROM "advance"."Protocol" WHERE name='TLS'),
    'TLS_ECDHE_RSA_WITH_ARIA_128_CBC_SHA256', x'C04C'::int);
INSERT INTO "advance"."CipherSuite" VALUES (DEFAULT, (SELECT id FROM "advance"."Protocol" WHERE name='TLS'),
    'TLS_ECDHE_RSA_WITH_ARIA_256_CBC_SHA384', x'C04D'::int);
INSERT INTO "advance"."CipherSuite" VALUES (DEFAULT, (SELECT id FROM "advance"."Protocol" WHERE name='TLS'),
    'TLS_ECDH_RSA_WITH_ARIA_128_CBC_SHA256', x'C04E'::int);
INSERT INTO "advance"."CipherSuite" VALUES (DEFAULT, (SELECT id FROM "advance"."Protocol" WHERE name='TLS'),
    'TLS_ECDH_RSA_WITH_ARIA_256_CBC_SHA384', x'C04F'::int);
INSERT INTO "advance"."CipherSuite" VALUES (DEFAULT, (SELECT id FROM "advance"."Protocol" WHERE name='TLS'),
    'TLS_RSA_WITH_ARIA_128_GCM_SHA256', x'C050'::int);
INSERT INTO "advance"."CipherSuite" VALUES (DEFAULT, (SELECT id FROM "advance"."Protocol" WHERE name='TLS'),
    'TLS_RSA_WITH_ARIA_256_GCM_SHA384', x'C051'::int);
INSERT INTO "advance"."CipherSuite" VALUES (DEFAULT, (SELECT id FROM "advance"."Protocol" WHERE name='TLS'),
    'TLS_DHE_RSA_WITH_ARIA_128_GCM_SHA256', x'C052'::int);
INSERT INTO "advance"."CipherSuite" VALUES (DEFAULT, (SELECT id FROM "advance"."Protocol" WHERE name='TLS'),
    'TLS_DHE_RSA_WITH_ARIA_256_GCM_SHA384', x'C053'::int);
INSERT INTO "advance"."CipherSuite" VALUES (DEFAULT, (SELECT id FROM "advance"."Protocol" WHERE name='TLS'),
    'TLS_DH_RSA_WITH_ARIA_128_GCM_SHA256', x'C054'::int);
INSERT INTO "advance"."CipherSuite" VALUES (DEFAULT, (SELECT id FROM "advance"."Protocol" WHERE name='TLS'),
    'TLS_DH_RSA_WITH_ARIA_256_GCM_SHA384', x'C055'::int);
INSERT INTO "advance"."CipherSuite" VALUES (DEFAULT, (SELECT id FROM "advance"."Protocol" WHERE name='TLS'),
    'TLS_DHE_DSS_WITH_ARIA_128_GCM_SHA256', x'C056'::int);
INSERT INTO "advance"."CipherSuite" VALUES (DEFAULT, (SELECT id FROM "advance"."Protocol" WHERE name='TLS'),
    'TLS_DHE_DSS_WITH_ARIA_256_GCM_SHA384', x'C057'::int);
INSERT INTO "advance"."CipherSuite" VALUES (DEFAULT, (SELECT id FROM "advance"."Protocol" WHERE name='TLS'),
    'TLS_DH_DSS_WITH_ARIA_128_GCM_SHA256', x'C058'::int);
INSERT INTO "advance"."CipherSuite" VALUES (DEFAULT, (SELECT id FROM "advance"."Protocol" WHERE name='TLS'),
    'TLS_DH_DSS_WITH_ARIA_256_GCM_SHA384', x'C059'::int);
INSERT INTO "advance"."CipherSuite" VALUES (DEFAULT, (SELECT id FROM "advance"."Protocol" WHERE name='TLS'),
    'TLS_DH_anon_WITH_ARIA_128_GCM_SHA256', x'C05A'::int);
INSERT INTO "advance"."CipherSuite" VALUES (DEFAULT, (SELECT id FROM "advance"."Protocol" WHERE name='TLS'),
    'TLS_DH_anon_WITH_ARIA_256_GCM_SHA384', x'C05B'::int);
INSERT INTO "advance"."CipherSuite" VALUES (DEFAULT, (SELECT id FROM "advance"."Protocol" WHERE name='TLS'),
    'TLS_ECDHE_ECDSA_WITH_ARIA_128_GCM_SHA256', x'C05C'::int);
INSERT INTO "advance"."CipherSuite" VALUES (DEFAULT, (SELECT id FROM "advance"."Protocol" WHERE name='TLS'),
    'TLS_ECDHE_ECDSA_WITH_ARIA_256_GCM_SHA384', x'C05D'::int);
INSERT INTO "advance"."CipherSuite" VALUES (DEFAULT, (SELECT id FROM "advance"."Protocol" WHERE name='TLS'),
    'TLS_ECDH_ECDSA_WITH_ARIA_128_GCM_SHA256', x'C05E'::int);
INSERT INTO "advance"."CipherSuite" VALUES (DEFAULT, (SELECT id FROM "advance"."Protocol" WHERE name='TLS'),
    'TLS_ECDH_ECDSA_WITH_ARIA_256_GCM_SHA384', x'C05F'::int);
INSERT INTO "advance"."CipherSuite" VALUES (DEFAULT, (SELECT id FROM "advance"."Protocol" WHERE name='TLS'),
    'TLS_ECDHE_RSA_WITH_ARIA_128_GCM_SHA256', x'C060'::int);
INSERT INTO "advance"."CipherSuite" VALUES (DEFAULT, (SELECT id FROM "advance"."Protocol" WHERE name='TLS'),
    'TLS_ECDHE_RSA_WITH_ARIA_256_GCM_SHA384', x'C061'::int);
INSERT INTO "advance"."CipherSuite" VALUES (DEFAULT, (SELECT id FROM "advance"."Protocol" WHERE name='TLS'),
    'TLS_ECDH_RSA_WITH_ARIA_128_GCM_SHA256', x'C062'::int);
INSERT INTO "advance"."CipherSuite" VALUES (DEFAULT, (SELECT id FROM "advance"."Protocol" WHERE name='TLS'),
    'TLS_ECDH_RSA_WITH_ARIA_256_GCM_SHA384', x'C063'::int);
INSERT INTO "advance"."CipherSuite" VALUES (DEFAULT, (SELECT id FROM "advance"."Protocol" WHERE name='TLS'),
    'TLS_PSK_WITH_ARIA_128_CBC_SHA256', x'C064'::int);
INSERT INTO "advance"."CipherSuite" VALUES (DEFAULT, (SELECT id FROM "advance"."Protocol" WHERE name='TLS'),
    'TLS_PSK_WITH_ARIA_256_CBC_SHA384', x'C065'::int);
INSERT INTO "advance"."CipherSuite" VALUES (DEFAULT, (SELECT id FROM "advance"."Protocol" WHERE name='TLS'),
    'TLS_DHE_PSK_WITH_ARIA_128_CBC_SHA256', x'C066'::int);
INSERT INTO "advance"."CipherSuite" VALUES (DEFAULT, (SELECT id FROM "advance"."Protocol" WHERE name='TLS'),
    'TLS_DHE_PSK_WITH_ARIA_256_CBC_SHA384', x'C067'::int);
INSERT INTO "advance"."CipherSuite" VALUES (DEFAULT, (SELECT id FROM "advance"."Protocol" WHERE name='TLS'),
    'TLS_RSA_PSK_WITH_ARIA_128_CBC_SHA256', x'C068'::int);
INSERT INTO "advance"."CipherSuite" VALUES (DEFAULT, (SELECT id FROM "advance"."Protocol" WHERE name='TLS'),
    'TLS_RSA_PSK_WITH_ARIA_256_CBC_SHA384', x'C069'::int);
INSERT INTO "advance"."CipherSuite" VALUES (DEFAULT, (SELECT id FROM "advance"."Protocol" WHERE name='TLS'),
    'TLS_PSK_WITH_ARIA_128_GCM_SHA256', x'C06A'::int);
INSERT INTO "advance"."CipherSuite" VALUES (DEFAULT, (SELECT id FROM "advance"."Protocol" WHERE name='TLS'),
    'TLS_PSK_WITH_ARIA_256_GCM_SHA384', x'C06B'::int);
INSERT INTO "advance"."CipherSuite" VALUES (DEFAULT, (SELECT id FROM "advance"."Protocol" WHERE name='TLS'),
    'TLS_DHE_PSK_WITH_ARIA_128_GCM_SHA256', x'C06C'::int);
INSERT INTO "advance"."CipherSuite" VALUES (DEFAULT, (SELECT id FROM "advance"."Protocol" WHERE name='TLS'),
    'TLS_DHE_PSK_WITH_ARIA_256_GCM_SHA384', x'C06D'::int);
INSERT INTO "advance"."CipherSuite" VALUES (DEFAULT, (SELECT id FROM "advance"."Protocol" WHERE name='TLS'),
    'TLS_RSA_PSK_WITH_ARIA_128_GCM_SHA256', x'C06E'::int);
INSERT INTO "advance"."CipherSuite" VALUES (DEFAULT, (SELECT id FROM "advance"."Protocol" WHERE name='TLS'),
    'TLS_RSA_PSK_WITH_ARIA_256_GCM_SHA384', x'C06F'::int);
INSERT INTO "advance"."CipherSuite" VALUES (DEFAULT, (SELECT id FROM "advance"."Protocol" WHERE name='TLS'),
    'TLS_ECDHE_PSK_WITH_ARIA_128_CBC_SHA256', x'C070'::int);
INSERT INTO "advance"."CipherSuite" VALUES (DEFAULT, (SELECT id FROM "advance"."Protocol" WHERE name='TLS'),
    'TLS_ECDHE_PSK_WITH_ARIA_256_CBC_SHA384', x'C071'::int);
INSERT INTO "advance"."CipherSuite" VALUES (DEFAULT, (SELECT id FROM "advance"."Protocol" WHERE name='TLS'),
    'TLS_ECDHE_ECDSA_WITH_CAMELLIA_128_CBC_SHA256', x'C072'::int);
INSERT INTO "advance"."CipherSuite" VALUES (DEFAULT, (SELECT id FROM "advance"."Protocol" WHERE name='TLS'),
    'TLS_ECDHE_ECDSA_WITH_CAMELLIA_256_CBC_SHA384', x'C073'::int);
INSERT INTO "advance"."CipherSuite" VALUES (DEFAULT, (SELECT id FROM "advance"."Protocol" WHERE name='TLS'),
    'TLS_ECDH_ECDSA_WITH_CAMELLIA_128_CBC_SHA256', x'C074'::int);
INSERT INTO "advance"."CipherSuite" VALUES (DEFAULT, (SELECT id FROM "advance"."Protocol" WHERE name='TLS'),
    'TLS_ECDH_ECDSA_WITH_CAMELLIA_256_CBC_SHA384', x'C075'::int);
INSERT INTO "advance"."CipherSuite" VALUES (DEFAULT, (SELECT id FROM "advance"."Protocol" WHERE name='TLS'),
    'TLS_ECDHE_RSA_WITH_CAMELLIA_128_CBC_SHA256', x'C076'::int);
INSERT INTO "advance"."CipherSuite" VALUES (DEFAULT, (SELECT id FROM "advance"."Protocol" WHERE name='TLS'),
    'TLS_ECDHE_RSA_WITH_CAMELLIA_256_CBC_SHA384', x'C077'::int);
INSERT INTO "advance"."CipherSuite" VALUES (DEFAULT, (SELECT id FROM "advance"."Protocol" WHERE name='TLS'),
    'TLS_ECDH_RSA_WITH_CAMELLIA_128_CBC_SHA256', x'C078'::int);
INSERT INTO "advance"."CipherSuite" VALUES (DEFAULT, (SELECT id FROM "advance"."Protocol" WHERE name='TLS'),
    'TLS_ECDH_RSA_WITH_CAMELLIA_256_CBC_SHA384', x'C079'::int);
INSERT INTO "advance"."CipherSuite" VALUES (DEFAULT, (SELECT id FROM "advance"."Protocol" WHERE name='TLS'),
    'TLS_RSA_WITH_CAMELLIA_128_GCM_SHA256', x'C07A'::int);
INSERT INTO "advance"."CipherSuite" VALUES (DEFAULT, (SELECT id FROM "advance"."Protocol" WHERE name='TLS'),
    'TLS_RSA_WITH_CAMELLIA_256_GCM_SHA384', x'C07B'::int);
INSERT INTO "advance"."CipherSuite" VALUES (DEFAULT, (SELECT id FROM "advance"."Protocol" WHERE name='TLS'),
    'TLS_DHE_RSA_WITH_CAMELLIA_128_GCM_SHA256', x'C07C'::int);
INSERT INTO "advance"."CipherSuite" VALUES (DEFAULT, (SELECT id FROM "advance"."Protocol" WHERE name='TLS'),
    'TLS_DHE_RSA_WITH_CAMELLIA_256_GCM_SHA384', x'C07D'::int);
INSERT INTO "advance"."CipherSuite" VALUES (DEFAULT, (SELECT id FROM "advance"."Protocol" WHERE name='TLS'),
    'TLS_DH_RSA_WITH_CAMELLIA_128_GCM_SHA256', x'C07E'::int);
INSERT INTO "advance"."CipherSuite" VALUES (DEFAULT, (SELECT id FROM "advance"."Protocol" WHERE name='TLS'),
    'TLS_DH_RSA_WITH_CAMELLIA_256_GCM_SHA384', x'C07F'::int);
INSERT INTO "advance"."CipherSuite" VALUES (DEFAULT, (SELECT id FROM "advance"."Protocol" WHERE name='TLS'),
    'TLS_DHE_DSS_WITH_CAMELLIA_128_GCM_SHA256', x'C080'::int);
INSERT INTO "advance"."CipherSuite" VALUES (DEFAULT, (SELECT id FROM "advance"."Protocol" WHERE name='TLS'),
    'TLS_DHE_DSS_WITH_CAMELLIA_256_GCM_SHA384', x'C081'::int);
INSERT INTO "advance"."CipherSuite" VALUES (DEFAULT, (SELECT id FROM "advance"."Protocol" WHERE name='TLS'),
    'TLS_DH_DSS_WITH_CAMELLIA_128_GCM_SHA256', x'C082'::int);
INSERT INTO "advance"."CipherSuite" VALUES (DEFAULT, (SELECT id FROM "advance"."Protocol" WHERE name='TLS'),
    'TLS_DH_DSS_WITH_CAMELLIA_256_GCM_SHA384', x'C083'::int);
INSERT INTO "advance"."CipherSuite" VALUES (DEFAULT, (SELECT id FROM "advance"."Protocol" WHERE name='TLS'),
    'TLS_DH_anon_WITH_CAMELLIA_128_GCM_SHA256', x'C084'::int);
INSERT INTO "advance"."CipherSuite" VALUES (DEFAULT, (SELECT id FROM "advance"."Protocol" WHERE name='TLS'),
    'TLS_DH_anon_WITH_CAMELLIA_256_GCM_SHA384', x'C085'::int);
INSERT INTO "advance"."CipherSuite" VALUES (DEFAULT, (SELECT id FROM "advance"."Protocol" WHERE name='TLS'),
    'TLS_ECDHE_ECDSA_WITH_CAMELLIA_128_GCM_SHA256', x'C086'::int);
INSERT INTO "advance"."CipherSuite" VALUES (DEFAULT, (SELECT id FROM "advance"."Protocol" WHERE name='TLS'),
    'TLS_ECDHE_ECDSA_WITH_CAMELLIA_256_GCM_SHA384', x'C087'::int);
INSERT INTO "advance"."CipherSuite" VALUES (DEFAULT, (SELECT id FROM "advance"."Protocol" WHERE name='TLS'),
    'TLS_ECDH_ECDSA_WITH_CAMELLIA_128_GCM_SHA256', x'C088'::int);
INSERT INTO "advance"."CipherSuite" VALUES (DEFAULT, (SELECT id FROM "advance"."Protocol" WHERE name='TLS'),
    'TLS_ECDH_ECDSA_WITH_CAMELLIA_256_GCM_SHA384', x'C089'::int);
INSERT INTO "advance"."CipherSuite" VALUES (DEFAULT, (SELECT id FROM "advance"."Protocol" WHERE name='TLS'),
    'TLS_ECDHE_RSA_WITH_CAMELLIA_128_GCM_SHA256', x'C08A'::int);
INSERT INTO "advance"."CipherSuite" VALUES (DEFAULT, (SELECT id FROM "advance"."Protocol" WHERE name='TLS'),
    'TLS_ECDHE_RSA_WITH_CAMELLIA_256_GCM_SHA384', x'C08B'::int);
INSERT INTO "advance"."CipherSuite" VALUES (DEFAULT, (SELECT id FROM "advance"."Protocol" WHERE name='TLS'),
    'TLS_ECDH_RSA_WITH_CAMELLIA_128_GCM_SHA256', x'C08C'::int);
INSERT INTO "advance"."CipherSuite" VALUES (DEFAULT, (SELECT id FROM "advance"."Protocol" WHERE name='TLS'),
    'TLS_ECDH_RSA_WITH_CAMELLIA_256_GCM_SHA384', x'C08D'::int);
INSERT INTO "advance"."CipherSuite" VALUES (DEFAULT, (SELECT id FROM "advance"."Protocol" WHERE name='TLS'),
    'TLS_PSK_WITH_CAMELLIA_128_GCM_SHA256', x'C08E'::int);
INSERT INTO "advance"."CipherSuite" VALUES (DEFAULT, (SELECT id FROM "advance"."Protocol" WHERE name='TLS'),
    'TLS_PSK_WITH_CAMELLIA_256_GCM_SHA384', x'C08F'::int);
INSERT INTO "advance"."CipherSuite" VALUES (DEFAULT, (SELECT id FROM "advance"."Protocol" WHERE name='TLS'),
    'TLS_DHE_PSK_WITH_CAMELLIA_128_GCM_SHA256', x'C090'::int);
INSERT INTO "advance"."CipherSuite" VALUES (DEFAULT, (SELECT id FROM "advance"."Protocol" WHERE name='TLS'),
    'TLS_DHE_PSK_WITH_CAMELLIA_256_GCM_SHA384', x'C091'::int);
INSERT INTO "advance"."CipherSuite" VALUES (DEFAULT, (SELECT id FROM "advance"."Protocol" WHERE name='TLS'),
    'TLS_RSA_PSK_WITH_CAMELLIA_128_GCM_SHA256', x'C092'::int);
INSERT INTO "advance"."CipherSuite" VALUES (DEFAULT, (SELECT id FROM "advance"."Protocol" WHERE name='TLS'),
    'TLS_RSA_PSK_WITH_CAMELLIA_256_GCM_SHA384', x'C093'::int);
INSERT INTO "advance"."CipherSuite" VALUES (DEFAULT, (SELECT id FROM "advance"."Protocol" WHERE name='TLS'),
    'TLS_PSK_WITH_CAMELLIA_128_CBC_SHA256', x'C094'::int);
INSERT INTO "advance"."CipherSuite" VALUES (DEFAULT, (SELECT id FROM "advance"."Protocol" WHERE name='TLS'),
    'TLS_PSK_WITH_CAMELLIA_256_CBC_SHA384', x'C095'::int);
INSERT INTO "advance"."CipherSuite" VALUES (DEFAULT, (SELECT id FROM "advance"."Protocol" WHERE name='TLS'),
    'TLS_DHE_PSK_WITH_CAMELLIA_128_CBC_SHA256', x'C096'::int);
INSERT INTO "advance"."CipherSuite" VALUES (DEFAULT, (SELECT id FROM "advance"."Protocol" WHERE name='TLS'),
    'TLS_DHE_PSK_WITH_CAMELLIA_256_CBC_SHA384', x'C097'::int);
INSERT INTO "advance"."CipherSuite" VALUES (DEFAULT, (SELECT id FROM "advance"."Protocol" WHERE name='TLS'),
    'TLS_RSA_PSK_WITH_CAMELLIA_128_CBC_SHA256', x'C098'::int);
INSERT INTO "advance"."CipherSuite" VALUES (DEFAULT, (SELECT id FROM "advance"."Protocol" WHERE name='TLS'),
    'TLS_RSA_PSK_WITH_CAMELLIA_256_CBC_SHA384', x'C099'::int);
INSERT INTO "advance"."CipherSuite" VALUES (DEFAULT, (SELECT id FROM "advance"."Protocol" WHERE name='TLS'),
    'TLS_ECDHE_PSK_WITH_CAMELLIA_128_CBC_SHA256', x'C09A'::int);
INSERT INTO "advance"."CipherSuite" VALUES (DEFAULT, (SELECT id FROM "advance"."Protocol" WHERE name='TLS'),
    'TLS_ECDHE_PSK_WITH_CAMELLIA_256_CBC_SHA384', x'C09B'::int);
INSERT INTO "advance"."CipherSuite" VALUES (DEFAULT, (SELECT id FROM "advance"."Protocol" WHERE name='TLS'),
    'TLS_RSA_WITH_AES_128_CCM', x'C09C'::int);
INSERT INTO "advance"."CipherSuite" VALUES (DEFAULT, (SELECT id FROM "advance"."Protocol" WHERE name='TLS'),
    'TLS_RSA_WITH_AES_256_CCM', x'C09D'::int);
INSERT INTO "advance"."CipherSuite" VALUES (DEFAULT, (SELECT id FROM "advance"."Protocol" WHERE name='TLS'),
    'TLS_DHE_RSA_WITH_AES_128_CCM', x'C09E'::int);
INSERT INTO "advance"."CipherSuite" VALUES (DEFAULT, (SELECT id FROM "advance"."Protocol" WHERE name='TLS'),
    'TLS_DHE_RSA_WITH_AES_256_CCM', x'C09F'::int);
INSERT INTO "advance"."CipherSuite" VALUES (DEFAULT, (SELECT id FROM "advance"."Protocol" WHERE name='TLS'),
    'TLS_RSA_WITH_AES_128_CCM_8', x'C0A0'::int);
INSERT INTO "advance"."CipherSuite" VALUES (DEFAULT, (SELECT id FROM "advance"."Protocol" WHERE name='TLS'),
    'TLS_RSA_WITH_AES_256_CCM_8', x'C0A1'::int);
INSERT INTO "advance"."CipherSuite" VALUES (DEFAULT, (SELECT id FROM "advance"."Protocol" WHERE name='TLS'),
    'TLS_DHE_RSA_WITH_AES_128_CCM_8', x'C0A2'::int);
INSERT INTO "advance"."CipherSuite" VALUES (DEFAULT, (SELECT id FROM "advance"."Protocol" WHERE name='TLS'),
    'TLS_DHE_RSA_WITH_AES_256_CCM_8', x'C0A3'::int);
INSERT INTO "advance"."CipherSuite" VALUES (DEFAULT, (SELECT id FROM "advance"."Protocol" WHERE name='TLS'),
    'TLS_PSK_WITH_AES_128_CCM', x'C0A4'::int);
INSERT INTO "advance"."CipherSuite" VALUES (DEFAULT, (SELECT id FROM "advance"."Protocol" WHERE name='TLS'),
    'TLS_PSK_WITH_AES_256_CCM', x'C0A5'::int);
INSERT INTO "advance"."CipherSuite" VALUES (DEFAULT, (SELECT id FROM "advance"."Protocol" WHERE name='TLS'),
    'TLS_DHE_PSK_WITH_AES_128_CCM', x'C0A6'::int);
INSERT INTO "advance"."CipherSuite" VALUES (DEFAULT, (SELECT id FROM "advance"."Protocol" WHERE name='TLS'),
    'TLS_DHE_PSK_WITH_AES_256_CCM', x'C0A7'::int);
INSERT INTO "advance"."CipherSuite" VALUES (DEFAULT, (SELECT id FROM "advance"."Protocol" WHERE name='TLS'),
    'TLS_PSK_WITH_AES_128_CCM_8', x'C0A8'::int);
INSERT INTO "advance"."CipherSuite" VALUES (DEFAULT, (SELECT id FROM "advance"."Protocol" WHERE name='TLS'),
    'TLS_PSK_WITH_AES_256_CCM_8', x'C0A9'::int);
INSERT INTO "advance"."CipherSuite" VALUES (DEFAULT, (SELECT id FROM "advance"."Protocol" WHERE name='TLS'),
    'TLS_DHE_PSK_WITH_AES_128_CCM_8', x'C0AA'::int);
INSERT INTO "advance"."CipherSuite" VALUES (DEFAULT, (SELECT id FROM "advance"."Protocol" WHERE name='TLS'),
    'TLS_DHE_PSK_WITH_AES_256_CCM_8', x'C0AB'::int);
INSERT INTO "advance"."CipherSuite" VALUES (DEFAULT, (SELECT id FROM "advance"."Protocol" WHERE name='TLS'),
    'TLS_ECDHE_ECDSA_WITH_AES_128_CCM', x'C0AC'::int);
INSERT INTO "advance"."CipherSuite" VALUES (DEFAULT, (SELECT id FROM "advance"."Protocol" WHERE name='TLS'),
    'TLS_ECDHE_ECDSA_WITH_AES_256_CCM', x'C0AD'::int);
INSERT INTO "advance"."CipherSuite" VALUES (DEFAULT, (SELECT id FROM "advance"."Protocol" WHERE name='TLS'),
    'TLS_ECDHE_ECDSA_WITH_AES_128_CCM_8', x'C0AE'::int);
INSERT INTO "advance"."CipherSuite" VALUES (DEFAULT, (SELECT id FROM "advance"."Protocol" WHERE name='TLS'),
    'TLS_ECDHE_ECDSA_WITH_AES_256_CCM_8', x'C0AF'::int);
INSERT INTO "advance"."CipherSuite" VALUES (DEFAULT, (SELECT id FROM "advance"."Protocol" WHERE name='TLS'),
    'TLS_ECCPWD_WITH_AES_128_GCM_SHA256', x'C0B0'::int);
INSERT INTO "advance"."CipherSuite" VALUES (DEFAULT, (SELECT id FROM "advance"."Protocol" WHERE name='TLS'),
    'TLS_ECCPWD_WITH_AES_256_GCM_SHA384', x'C0B1'::int);
INSERT INTO "advance"."CipherSuite" VALUES (DEFAULT, (SELECT id FROM "advance"."Protocol" WHERE name='TLS'),
    'TLS_ECCPWD_WITH_AES_128_CCM_SHA256', x'C0B2'::int);
INSERT INTO "advance"."CipherSuite" VALUES (DEFAULT, (SELECT id FROM "advance"."Protocol" WHERE name='TLS'),
    'TLS_ECCPWD_WITH_AES_256_CCM_SHA384', x'C0B3'::int);
INSERT INTO "advance"."CipherSuite" VALUES (DEFAULT, (SELECT id FROM "advance"."Protocol" WHERE name='TLS'),
    'TLS_SHA256_SHA256', x'C0B4'::int);
INSERT INTO "advance"."CipherSuite" VALUES (DEFAULT, (SELECT id FROM "advance"."Protocol" WHERE name='TLS'),
    'TLS_SHA384_SHA384', x'C0B5'::int);
INSERT INTO "advance"."CipherSuite" VALUES (DEFAULT, (SELECT id FROM "advance"."Protocol" WHERE name='TLS'),
    'TLS_GOSTR341112_256_WITH_KUZNYECHIK_CTR_OMAC', x'C100'::int);
INSERT INTO "advance"."CipherSuite" VALUES (DEFAULT, (SELECT id FROM "advance"."Protocol" WHERE name='TLS'),
    'TLS_GOSTR341112_256_WITH_MAGMA_CTR_OMAC', x'C101'::int);
INSERT INTO "advance"."CipherSuite" VALUES (DEFAULT, (SELECT id FROM "advance"."Protocol" WHERE name='TLS'),
    'TLS_GOSTR341112_256_WITH_28147_CNT_IMIT', x'C102'::int);
INSERT INTO "advance"."CipherSuite" VALUES (DEFAULT, (SELECT id FROM "advance"."Protocol" WHERE name='TLS'),
    'TLS_GOSTR341112_256_WITH_KUZNYECHIK_MGM_L', x'C103'::int);
INSERT INTO "advance"."CipherSuite" VALUES (DEFAULT, (SELECT id FROM "advance"."Protocol" WHERE name='TLS'),
    'TLS_GOSTR341112_256_WITH_MAGMA_MGM_L', x'C104'::int);
INSERT INTO "advance"."CipherSuite" VALUES (DEFAULT, (SELECT id FROM "advance"."Protocol" WHERE name='TLS'),
    'TLS_GOSTR341112_256_WITH_KUZNYECHIK_MGM_S', x'C105'::int);
INSERT INTO "advance"."CipherSuite" VALUES (DEFAULT, (SELECT id FROM "advance"."Protocol" WHERE name='TLS'),
    'TLS_GOSTR341112_256_WITH_MAGMA_MGM_S', x'C106'::int);
INSERT INTO "advance"."CipherSuite" VALUES (DEFAULT, (SELECT id FROM "advance"."Protocol" WHERE name='TLS'),
    'TLS_ECDHE_RSA_WITH_CHACHA20_POLY1305_SHA256', x'CCA8'::int);
INSERT INTO "advance"."CipherSuite" VALUES (DEFAULT, (SELECT id FROM "advance"."Protocol" WHERE name='TLS'),
    'TLS_ECDHE_ECDSA_WITH_CHACHA20_POLY1305_SHA256', x'CCA9'::int);
INSERT INTO "advance"."CipherSuite" VALUES (DEFAULT, (SELECT id FROM "advance"."Protocol" WHERE name='TLS'),
    'TLS_DHE_RSA_WITH_CHACHA20_POLY1305_SHA256', x'CCAA'::int);
INSERT INTO "advance"."CipherSuite" VALUES (DEFAULT, (SELECT id FROM "advance"."Protocol" WHERE name='TLS'),
    'TLS_PSK_WITH_CHACHA20_POLY1305_SHA256', x'CCAB'::int);
INSERT INTO "advance"."CipherSuite" VALUES (DEFAULT, (SELECT id FROM "advance"."Protocol" WHERE name='TLS'),
    'TLS_ECDHE_PSK_WITH_CHACHA20_POLY1305_SHA256', x'CCAC'::int);
INSERT INTO "advance"."CipherSuite" VALUES (DEFAULT, (SELECT id FROM "advance"."Protocol" WHERE name='TLS'),
    'TLS_DHE_PSK_WITH_CHACHA20_POLY1305_SHA256', x'CCAD'::int);
INSERT INTO "advance"."CipherSuite" VALUES (DEFAULT, (SELECT id FROM "advance"."Protocol" WHERE name='TLS'),
    'TLS_RSA_PSK_WITH_CHACHA20_POLY1305_SHA256', x'CCAE'::int);
INSERT INTO "advance"."CipherSuite" VALUES (DEFAULT, (SELECT id FROM "advance"."Protocol" WHERE name='TLS'),
    'TLS_ECDHE_PSK_WITH_AES_128_GCM_SHA256', x'D001'::int);
INSERT INTO "advance"."CipherSuite" VALUES (DEFAULT, (SELECT id FROM "advance"."Protocol" WHERE name='TLS'),
    'TLS_ECDHE_PSK_WITH_AES_256_GCM_SHA384', x'D002'::int);
INSERT INTO "advance"."CipherSuite" VALUES (DEFAULT, (SELECT id FROM "advance"."Protocol" WHERE name='TLS'),
    'TLS_ECDHE_PSK_WITH_AES_128_CCM_8_SHA256', x'D003'::int);
INSERT INTO "advance"."CipherSuite" VALUES (DEFAULT, (SELECT id FROM "advance"."Protocol" WHERE name='TLS'),
    'TLS_ECDHE_PSK_WITH_AES_128_CCM_SHA256', x'D005'::int);
INSERT INTO "advance"."CipherSuite" VALUES (DEFAULT, (SELECT id FROM "advance"."Protocol" WHERE name='TLS'),
    'TLS_ECDHE_SIDH_RSA_WITH_AES_256_GCM_SHA384', x'FF10'::int);
INSERT INTO "advance"."CipherSuite" VALUES (DEFAULT, (SELECT id FROM "advance"."Protocol" WHERE name='TLS'),
    'TLS_ECDHE_SIDH_ECDSA_WITH_AES_256_GCM_SHA384', x'FF11'::int);
INSERT INTO "advance"."CipherSuite" VALUES (DEFAULT, (SELECT id FROM "advance"."Protocol" WHERE name='TLS'),
    'TLS_ECDHE_NHDH_SIDH_RSA_WITH_AES_256_GCM_SHA384', x'FF12'::int);
INSERT INTO "advance"."CipherSuite" VALUES (DEFAULT, (SELECT id FROM "advance"."Protocol" WHERE name='TLS'),
    'TLS_ECDHE_NHDH_SIDH_ECDSA_WITH_AES_256_GCM_SHA384', x'FF13'::int);
INSERT INTO "advance"."CipherSuite" VALUES (DEFAULT, (SELECT id FROM "advance"."Protocol" WHERE name='TLS'),
    'TLS_ECDHE_NHDH_DILM_WITH_AES_256_GCM_SHA384', x'FF14'::int);
INSERT INTO "advance"."CipherSuite" VALUES (DEFAULT, (SELECT id FROM "advance"."Protocol" WHERE name='TLS'),
    'TLS_ECDHE_SIDH_DILM_WITH_AES_256_GCM_SHA384', x'FF15'::int);
INSERT INTO "advance"."CipherSuite" VALUES (DEFAULT, (SELECT id FROM "advance"."Protocol" WHERE name='TLS'),
    'TLS_ECDHE_NHDH_SIDH_DILM_WITH_AES_256_GCM_SHA384', x'FF16'::int);
INSERT INTO "advance"."CipherSuite" VALUES (DEFAULT, (SELECT id FROM "advance"."Protocol" WHERE name='TLS'),
    'TLS_ECDHE_SIKE_ECDSA_WITH_AES_256_GCM_SHA384', x'FF17'::int);
INSERT INTO "advance"."CipherSuite" VALUES (DEFAULT, (SELECT id FROM "advance"."Protocol" WHERE name='TLS'),
    'TLS_ECDHE_KYBER_ECDSA_WITH_AES_256_GCM_SHA384', x'FF18'::int);
INSERT INTO "advance"."CipherSuite" VALUES (DEFAULT, (SELECT id FROM "advance"."Protocol" WHERE name='TLS'),
    'TLS_ECDHE_SIKE_RSA_WITH_AES_256_GCM_SHA384', x'FF19'::int);
INSERT INTO "advance"."CipherSuite" VALUES (DEFAULT, (SELECT id FROM "advance"."Protocol" WHERE name='TLS'),
    'TLS_ECDHE_KYBER_RSA_WITH_AES_256_GCM_SHA384', x'FF1A'::int);
INSERT INTO "advance"."CipherSuite" VALUES (DEFAULT, (SELECT id FROM "advance"."Protocol" WHERE name='TLS'),
    'TLS_ECDHE_SIKE_DILM_WITH_AES_256_GCM_SHA384', x'FF1B'::int);
INSERT INTO "advance"."CipherSuite" VALUES (DEFAULT, (SELECT id FROM "advance"."Protocol" WHERE name='TLS'),
    'TLS_ECDHE_KYBER_DILM_WITH_AES_256_GCM_SHA384', x'FF1C'::int);
INSERT INTO "advance"."CipherSuite" VALUES (DEFAULT, (SELECT id FROM "advance"."Protocol" WHERE name='TLS'),
    'TLS_ECDHE_KYBER_SIKE_DILM_WITH_AES_256_GCM_SHA384', x'FF1D'::int);
INSERT INTO "advance"."CipherSuite" VALUES (DEFAULT, (SELECT id FROM "advance"."Protocol" WHERE name='TLS'),
    'TLS_ECDHE_KYBER_SIKE_ECDSA_WITH_AES_256_GCM_SHA384', x'FF1E'::int);
INSERT INTO "advance"."CipherSuite" VALUES (DEFAULT, (SELECT id FROM "advance"."Protocol" WHERE name='TLS'),
    'TLS_ECDHE_KYBER_SIKE_RSA_WITH_AES_256_GCM_SHA384', x'FF1F'::int);
INSERT INTO "advance"."CipherSuite" VALUES (DEFAULT, (SELECT id FROM "advance"."Protocol" WHERE name='TLS'),
    'TLS_KYBER_DILM_WITH_AES_256_GCM_SHA384', x'FF20'::int);
INSERT INTO "advance"."CipherSuite" VALUES (DEFAULT, (SELECT id FROM "advance"."Protocol" WHERE name='TLS'),
    'TLS_KYBER_ECDSA_WITH_AES_256_GCM_SHA384', x'FF21'::int);
INSERT INTO "advance"."CipherSuite" VALUES (DEFAULT, (SELECT id FROM "advance"."Protocol" WHERE name='TLS'),
    'TLS_KYBER_RSA_WITH_AES_256_GCM_SHA384', x'FF22'::int);
INSERT INTO "advance"."CipherSuite" VALUES (DEFAULT, (SELECT id FROM "advance"."Protocol" WHERE name='TLS'),
    'TLS_SIKE_DILM_WITH_AES_256_GCM_SHA384', x'FF23'::int);
INSERT INTO "advance"."CipherSuite" VALUES (DEFAULT, (SELECT id FROM "advance"."Protocol" WHERE name='TLS'),
    'TLS_SIKE_ECDSA_WITH_AES_256_GCM_SHA384', x'FF24'::int);
INSERT INTO "advance"."CipherSuite" VALUES (DEFAULT, (SELECT id FROM "advance"."Protocol" WHERE name='TLS'),
    'TLS_SIKE_RSA_WITH_AES_256_GCM_SHA384', x'FF25'::int);
INSERT INTO "advance"."CipherSuite" VALUES (DEFAULT, (SELECT id FROM "advance"."Protocol" WHERE name='TLS'),
    'TLS_ECDHE_SABER_ECDSA_WITH_AES_256_GCM_SHA384', x'FF26'::int);
INSERT INTO "advance"."CipherSuite" VALUES (DEFAULT, (SELECT id FROM "advance"."Protocol" WHERE name='TLS'),
    'TLS_ECDHE_SABER_RSA_WITH_AES_256_GCM_SHA384', x'FF27'::int);
INSERT INTO "advance"."CipherSuite" VALUES (DEFAULT, (SELECT id FROM "advance"."Protocol" WHERE name='TLS'),
    'TLS_ECDHE_SABER_DILM_WITH_AES_256_GCM_SHA384', x'FF28'::int);
INSERT INTO "advance"."CipherSuite" VALUES (DEFAULT, (SELECT id FROM "advance"."Protocol" WHERE name='TLS'),
    'TLS_ECDHE_SABER_SIKE_DILM_WITH_AES_256_GCM_SHA384', x'FF29'::int);
INSERT INTO "advance"."CipherSuite" VALUES (DEFAULT, (SELECT id FROM "advance"."Protocol" WHERE name='TLS'),
    'TLS_ECDHE_SABER_SIKE_ECDSA_WITH_AES_256_GCM_SHA384', x'FF2A'::int);
INSERT INTO "advance"."CipherSuite" VALUES (DEFAULT, (SELECT id FROM "advance"."Protocol" WHERE name='TLS'),
    'TLS_ECDHE_SABER_SIKE_RSA_WITH_AES_256_GCM_SHA384', x'FF2B'::int);
INSERT INTO "advance"."CipherSuite" VALUES (DEFAULT, (SELECT id FROM "advance"."Protocol" WHERE name='TLS'),
    'TLS_SABER_DILM_WITH_AES_256_GCM_SHA384', x'FF2C'::int);
INSERT INTO "advance"."CipherSuite" VALUES (DEFAULT, (SELECT id FROM "advance"."Protocol" WHERE name='TLS'),
    'TLS_SABER_ECDSA_WITH_AES_256_GCM_SHA384', x'FF2D'::int);
INSERT INTO "advance"."CipherSuite" VALUES (DEFAULT, (SELECT id FROM "advance"."Protocol" WHERE name='TLS'),
    'TLS_SABER_RSA_WITH_AES_256_GCM_SHA384', x'FF2E'::int);
INSERT INTO "advance"."CipherSuite" VALUES (DEFAULT, (SELECT id FROM "advance"."Protocol" WHERE name='PLAIN_TEXT'), 'PLAIN_TEXT');

INSERT INTO "advance"."Role" ("name") VALUES ('USER');
INSERT INTO "advance"."Role" ("name") VALUES ('ADMIN');

INSERT INTO "advance"."SoftwareType" ("name") VALUES ('OS');
INSERT INTO "advance"."SoftwareType" ("name") VALUES ('SERVER');
INSERT INTO "advance"."SoftwareType" ("name") VALUES ('APP');
INSERT INTO "advance"."SoftwareType" ("name") VALUES ('DATA');
INSERT INTO "advance"."SoftwareType" ("name") VALUES ('WEB_SERVER');
INSERT INTO "advance"."SoftwareType" ("name") VALUES ('DATABASE');
INSERT INTO "advance"."SoftwareType" ("name") VALUES ('ARCHIVE');
INSERT INTO "advance"."SoftwareType" ("name") VALUES ('FINANCIAL');
INSERT INTO "advance"."SoftwareType" ("name") VALUES ('BROWSER');
INSERT INTO "advance"."SoftwareType" ("name") VALUES ('CMS');
INSERT INTO "advance"."SoftwareType" ("name") VALUES ('CRYPTOGRAPHIC');
INSERT INTO "advance"."SoftwareType" ("name") VALUES ('OTHER');
INSERT INTO "advance"."SoftwareType" ("name") VALUES ('UNKNOWN');

--INSERT INTO "advance"."Software" ("name", "softwareVendor", "softwareType") VALUES ('CSV', 'ISARA',
--    (SELECT id FROM "advance"."SoftwareType" WHERE "name" = 'DATA' LIMIT 1));
INSERT INTO "advance"."Software" ("name", "softwareVendor", "softwareType") VALUES ('Tanium', 'Tanium',
    (SELECT id FROM "advance"."SoftwareType" WHERE "name" = 'DATA' LIMIT 1));
INSERT INTO "advance"."Software" ("name", "softwareVendor", "softwareType") VALUES ('Discover(x)', 'Extrahop Networks',
   (SELECT id FROM "advance"."SoftwareType" WHERE "name" = 'DATA' LIMIT 1));
INSERT INTO "advance"."Software" ("name", "softwareVendor", "softwareType") VALUES ('ISARA Cryptographic Network Sensor', 'ISARA',
    (SELECT id FROM "advance"."SoftwareType" WHERE "name" = 'DATA' LIMIT 1));
INSERT INTO "advance"."Software" ("name", "softwareVendor", "softwareType") VALUES ('NETSCOUT CSV', 'ISARA',
    (SELECT id FROM "advance"."SoftwareType" WHERE "name" = 'DATA' LIMIT 1));

--INSERT INTO "advance"."SoftwareVersion" ("name", "version", "sortableVersion", "software") VALUES ('CSV Upload', '1.0', 1,
--    (SELECT id FROM "advance"."Software" WHERE "name" = 'CSV' LIMIT 1));
INSERT INTO "advance"."SoftwareVersion" ("name", "version", "sortableVersion", "software") VALUES ('Tanium 7', '7', 7,
    (SELECT id FROM "advance"."Software" WHERE "name" = 'Tanium' LIMIT 1));
INSERT INTO "advance"."SoftwareVersion" ("name", "version", "sortableVersion", "software") VALUES ('Discover(x) 8', '8', 8,
   (SELECT id FROM "advance"."Software" WHERE "name" = 'Discover(x)' LIMIT 1));
INSERT INTO "advance"."SoftwareVersion" ("name", "version", "sortableVersion", "software") VALUES ('ISARA Cryptographic Network Sensor', '1.0', 1,
    (SELECT id FROM "advance"."Software" WHERE "name" = 'ISARA Cryptographic Network Sensor' LIMIT 1));
INSERT INTO "advance"."SoftwareVersion" ("name", "version", "sortableVersion", "software") VALUES ('NETSCOUT CSV', '1.0', 1,
    (SELECT id FROM "advance"."Software" WHERE "name" = 'NETSCOUT CSV' LIMIT 1));

INSERT INTO "advance"."TagType" VALUES (DEFAULT, 'CUSTOM', 'custom', false, NULL);
INSERT INTO "advance"."TagType" VALUES (DEFAULT, 'EXCEPTION', 'exception', false, NULL);
INSERT INTO "advance"."TagType" VALUES (DEFAULT, 'ZONE', 'zone', false, NULL);
INSERT INTO "advance"."TagType" VALUES (DEFAULT, 'PRIORITY', 'priority', false, NULL);
INSERT INTO "advance"."TagType" VALUES (DEFAULT, 'DEVICE_PURPOSE', 'devicepurpose', false, NULL);
INSERT INTO "advance"."TagType" VALUES (DEFAULT, 'CPU_FAMILY', 'cpufamily', false, NULL);
INSERT INTO "advance"."TagType" VALUES (DEFAULT, 'HOSTNAME', 'host', false, NULL);
INSERT INTO "advance"."TagType" VALUES (DEFAULT, 'DOMAIN', 'domain', false, NULL);
INSERT INTO "advance"."TagType" VALUES (DEFAULT, 'COORDINATE', 'coord', false, NULL);
INSERT INTO "advance"."TagType" VALUES (DEFAULT, 'NORMAL_ADDRESS', 'address', false, NULL);
INSERT INTO "advance"."TagType" VALUES (DEFAULT, 'SERVER_ROOM_NUMBER', 'serverroom', false, NULL);
INSERT INTO "advance"."TagType" VALUES (DEFAULT, 'RACK_ADDRESS', 'rackaddress', false, NULL);
INSERT INTO "advance"."TagType" VALUES (DEFAULT, 'MACHINE_SERIAL_NUMBER', 'machineserial', false, NULL);
INSERT INTO "advance"."TagType" VALUES (DEFAULT, 'CORPORATE_ASSET_TAG_TRACKING_NUMBER', 'corptag', false, NULL);
INSERT INTO "advance"."TagType" VALUES (DEFAULT, 'RAM_SIZE', 'ramsize', true, 'B');
INSERT INTO "advance"."TagType" VALUES (DEFAULT, 'CPU_SPEED', 'cpuspeed', true, 'Hz');

INSERT INTO "advance"."Software" VALUES (DEFAULT, 'Windows', 'Microsoft', (SELECT id FROM "advance"."SoftwareType" WHERE "name" = 'OS' LIMIT 1), DEFAULT, DEFAULT);
INSERT INTO "advance"."Software" VALUES (DEFAULT, 'macOS', 'Apple', (SELECT id FROM "advance"."SoftwareType" WHERE "name" = 'OS' LIMIT 1), DEFAULT, DEFAULT);
INSERT INTO "advance"."Software" VALUES (DEFAULT, 'Linux', '-', (SELECT id FROM "advance"."SoftwareType" WHERE "name" = 'OS' LIMIT 1), DEFAULT, DEFAULT);

INSERT INTO "advance"."SystemProperty" (key, value) 
SELECT 'databaseVersion', '1.0'
WHERE NOT EXISTS (
SELECT key FROM "advance"."SystemProperty" where key = 'databaseVersion'
);
INSERT INTO "advance"."SystemProperty" VALUES (DEFAULT, 'cptGlobalDefault', '1');

INSERT INTO "advance"."StreamToken" VALUES (DEFAULT, 'l5udS552h+CwzhFYJtjHENWas3uKN575zNsp0lLm2zs=', 'Default Token - Should be replaced with generated', '2022-12-31 23:59:59+00');
INSERT INTO "advance"."StreamToken" VALUES (DEFAULT, 'l5udS562e+CwzhFYJtjHENWas3uKN575zNsp0lLm2zs=', 'Default Token - Should be replaced with generated', '2022-07-01 00:00:00+00');
