/**
 * @file userPreferencesQL.js - 0.0.1045 - ea4595bfd3488684d225574ed7d4c198074d49ba
 * 
 * @copyright Copyright (C) 2016-2023, ISARA Corporation, All Rights Reserved.
 * 
 * @license The code and other content set out herein is not in the public
 * domain, is considered a trade secret and is confidential to ISARA
 * Corporation. Use, reproduction or distribution, in whole or in part, of such
 * code or other content is strictly prohibited except by express written
 * permission of ISARA Corporation. Please contact ISARA Corporation at
 * info@isara.com for more information.
 */

/**
 * This module contains queries to manage user preferences.
 * @module graphql/userPreferencesQL
 */

var {
    fetchNoTree, store, deleteRecords
} = require('../isaraql/fetch')

var {
    roles
} = require('./commonQL')

function defaultValueReturner() {
    return ''
}

function defaultValidator(value) {
    return {
        value: value,
        valid: true
    }
}

function getInfoForKey(keyName) {
    if (Object.keys(exports.wellKnownKeys).includes(keyName)) {
        return exports.wellKnownKeys[keyName]
    }

    return {
        default: defaultValueReturner,
        validator: defaultValidator
    }
}

function isValidJSON(value) {
    let valid = true

    try {
        JSON.parse(value)
    } catch (e) {
        valid = false
    }

    return valid && {
        value,
        valid,
        parsedValue: JSON.parse(value)
    }
}

exports.isValidJSON = isValidJSON

async function userPreferenceQuery(fields, request) {
    var and = []
    and.push({ equals: { column: 'user', value: request.user.uid } })

    if (!fields.keyName) {
        throw 'Required key parameter missing.'
    }

    and.push({ equals: { column: 'keyName', value: fields.keyName } })

    var tableName = 'UserPreference'
    var records = await fetchNoTree(tableName, { [tableName]: { where: { and } } })

    let keyInfo = getInfoForKey(fields.keyName)
    let value = await keyInfo.default()
    if (records.length != 0) {
        let result = await keyInfo.validator(records[0].value)
        if (result.valid) {
            value = result.value
        } else {
            // TODO: GAP1601 - log? throw exception?
        }
    }

    return value
}

async function setUserPreferenceMutation(fields, request) {
    var key = { user: request.user.uid, keyName: fields.keyName }
    var keyInfo = getInfoForKey(fields.keyName)
    if (!await keyInfo.validator(fields.value)) {
        throw `Malformed value: '${fields.value}'`
    }

    var update = { value: fields.value }
    await store('UserPreference', key, update)
    return fields.value
}


/**
 * Resolver function to handle deleting user preference key.
 *
 * @param {*} fields The GraphQL fields structure specify the key to delete.
 * @param {*} request HTTP request headers object.
 * @param {*} graphQLState The GraphQL structure dictating the desired field selections for the deleted user preference.
 * @returns {Promise<any>} The updated record structure for the user.
 * @throws An exception is thrown if an error occurs while updating.
 */
async function deleteUserPreferenceMutation(fields, request) {
    if (!fields.keyName) {
        throw 'Required key parameter missing.'
    }

    var key = { user: request.user.uid, keyName: fields.keyName }
    var rows = await deleteRecords('UserPreference', key)

    return rows > 0
}

/**
 *
 * Registers a key in the well known keys table.
 *
 * @param {string} keyName The short string used to identify the key. Reserved keys are expected to start with '_'.
 * @param {string} description A descriptive string of what purpose the key in question serves.
 * @param {function} [defaultFunction] A function that supplies a default value for the key in question. If omitted, defaults
 * to an empty string.
 * @param {function} [validatorFunction] A function that validates the argument on both update and query to ensure it
 * conforms to the desired syntax/type. If omitted, values are passed through unmodified. Expected return is an object with fields
 * 'valid' (boolean), and 'value' containing the parsed/typed value on success.
 *
 * @throws {string} If a key is registered twice, or the key is not formatted as expected for reserved keys, an error is thrown.
 */
exports.registerKey = function (keyName, description, defaultFunction, validatorFunction) {
    if (!keyName.startsWith('_')) {
        throw `Key '${keyName}' missing required _ prefix`
    }

    if (exports.wellKnownKeys.keyName) {
        throw `Key '${keyName}' already exists`
    }

    if (!defaultFunction) {
        defaultFunction = defaultValueReturner
    }

    if (!validatorFunction) {
        validatorFunction = defaultValidator
    }

    exports.wellKnownKeys[keyName] = {
        description: description,
        default: defaultFunction,
        validator: validatorFunction
    }
}

/**
 *
 * Standard pref keys that we in some way support. Each key is mapped to an object containing fields:
 * - description: A short description of the key's purpose.
 * - defaultFunction: An optional function that supplies a default value for the key if none is stored in the DB.
 * - validatorFunction: An optional function that ensures field values conform to a required format or type.
 */

exports.wellKnownKeys = {
    DeviceUIColumnGroups: {
        description: "User's preference for device column groups.",
        default: defaultValueReturner,
        validator: isValidJSON
    },
    ConnectionUIColumnGroups: {
        description: "User's preference for connection column groups.",
        default: defaultValueReturner,
        validator: isValidJSON
    },
    SoftwareUIColumnGroups: {
        description: "User's preference for software column groups.",
        default: defaultValueReturner,
        validator: isValidJSON
    },
}


exports.graphQL = {
    queries: `
        userPreference(keyName: String!) : String
    `,
    mutations: `
        setUserPreference(keyName: String!, value: String) : String
        deleteUserPreference(keyName: String!) : Boolean
    `,
    root: {
        userPreference: userPreferenceQuery,
        setUserPreference: setUserPreferenceMutation,
        deleteUserPreference: deleteUserPreferenceMutation
    },
    restrictions: {
        userPreference: [roles.AUTHENTICATED],
        setUserPreference: [roles.AUTHENTICATED],
        deleteUserPreference: [roles.AUTHENTICATED]
    }
}
