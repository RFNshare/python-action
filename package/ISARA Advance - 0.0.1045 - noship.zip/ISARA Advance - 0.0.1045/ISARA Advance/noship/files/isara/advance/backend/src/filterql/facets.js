/**
 * @file facets.js - 0.0.1045 - ea4595bfd3488684d225574ed7d4c198074d49ba
 * 
 * @copyright Copyright (C) 2016-2023, ISARA Corporation, All Rights Reserved.
 * 
 * @license The code and other content set out herein is not in the public
 * domain, is considered a trade secret and is confidential to ISARA
 * Corporation. Use, reproduction or distribution, in whole or in part, of such
 * code or other content is strictly prohibited except by express written
 * permission of ISARA Corporation. Please contact ISARA Corporation at
 * info@isara.com for more information.
 */

var schemaDiscovery = require('../isaraql/schemaDiscovery')

var log = require('../util/log')(module)

const {
    filterCategoryTypes,
    postureCategories
} = require('../graphql/categoryConstants')

const chrono = require('chrono-node')
const { getCptForRequest } = require('../util/cptHelpers')

/**
* A filter expression applies to a specific facet of the network map,
* and comprise relational expressions on the facet's network
* model attributes.
*/
exports.facets = {
    attributesByName: {},
    attributes: [
        {
            name: 'conname',
            type: 'string',
            description: 'Connection name',
            table: 'Connection',
            column: 'friendlyName',
            isTag: false,
            pathExclusions: {
                User: true,
                Tag: true,
                Certificate: true,
                CipherSuite: true,
                CryptoPostureTemplate: true,
            },
            originSpecificExclusions: {
                Device: {
                    DeviceSoftwareConnection: true
                },
                SoftwareVersion: {
                    DeviceSoftwareConnection: true,
                    DeviceSoftwareVersionLibrary: true
                }
            }
        },
        {
            name: 'clientname',
            type: 'string',
            description: 'Client name',
            table: 'Tag',
            tagType: 'HOSTNAME',
            isTag: true,
            pathExclusions: {
                User: true,
                Certificate: true,
                CipherSuite: true,
                DeviceAddressPort: 'serverDeviceAddressPort',
            },
        },
        {
            name: 'servername',
            type: 'string',
            description: 'Server name',
            table: 'Tag',
            tagType: 'HOSTNAME',
            isTag: true,
            pathExclusions: {
                User: true,
                Certificate: true,
                CipherSuite: true,
                DeviceAddressPort: 'clientDeviceAddressPort',
            },
        },
        {
            name: 'isclient',
            type: 'boolean',
            description: 'Is client',
            table: 'Device',
            column: 'outgoingConnectionCount',
            isTag: false,
            pathExclusions: {
                User: true,
                Tag: true,
                Certificate: true,
                CipherSuite: true,
                Connection: 'serverDeviceAddressPort',
                CryptoPostureTemplate: true,
                DeviceSoftwareVersionLibrary: true,
            },
            originSpecificExclusions: {
                Connection: {
                    DeviceAddressMACAddress: true,
                    DeviceSoftware: true,
                },
            },
            converter: buildBooleanConverter({ 'true': 0, 'false': 0 }),
            operatorConverter: buildOperatorConverter({ 'true': 'gt', 'false': 'equals' })
        },
        {
            name: 'isserver',
            type: 'boolean',
            description: 'Is server',
            table: 'Device',
            column: 'incomingConnectionCount',
            isTag: false,
            pathExclusions: {
                User: true,
                Tag: true,
                Certificate: true,
                CipherSuite: true,
                Connection: 'clientDeviceAddressPort',
                CryptoPostureTemplate: true,
                DeviceSoftwareConnection: true,
                DeviceSoftwareVersionLibrary: true,
            },
            originSpecificExclusions: {
                Connection: {
                    DeviceAddressMACAddress: true,
                    DeviceSoftware: true,
                },
            },
            converter: buildBooleanConverter({ 'true': 0, 'false': 0 }),
            operatorConverter: buildOperatorConverter({ 'true': 'gt', 'false': 'equals' })
        },
        {
            name: 'serverport',
            type: 'integer',
            description: 'Server port',
            table: 'DeviceAddressPort',
            column: 'port',
            isTag: false,
            pathExclusions: {
                User: true,
                Tag: true,
                Certificate: true,
                CipherSuite: true,
                CryptoPostureTemplate: true,
                DeviceAddressPort: 'clientDeviceAddressPort',
                DeviceSoftwareConnection: true,
                DeviceSoftwareVersionLibrary: true,
            },
        },
        {
            name: 'clienthost',
            type: 'string',
            description: 'Client host name',
            table: 'Tag',
            tagType: 'HOSTNAME',
            isTag: true,
            pathExclusions: {
                User: true,
                Certificate: true,
                CipherSuite: true,
            },
            originSpecificExclusions: {
                Connection: {
                    DeviceAddressPort: 'serverDeviceAddressPort',
                    DeviceSoftwareConnection: true,
                }
            }
        },
        {
            name: 'serverhost',
            type: 'string',
            description: 'Server host name',
            table: 'Tag',
            tagType: 'HOSTNAME',
            isTag: true,
            pathExclusions: {
                User: true,
                Certificate: true,
                CipherSuite: true,
            },
            originSpecificExclusions: {
                Connection: {
                    DeviceAddressPort: 'clientDeviceAddressPort',
                    DeviceSoftwareConnection: true,
                }
            }
        },
        {
            name: 'clientpriority',
            type: 'string',
            description: 'Client priority',
            table: 'Tag',
            tagType: 'PRIORITY',
            isTag: true,
            pathExclusions: {
                User: true,
                Certificate: true,
                CipherSuite: true,
            },
            originSpecificExclusions: {
                Connection: {
                    DeviceAddressPort: 'serverDeviceAddressPort',
                    DeviceSoftwareConnection: true,
                }
            }
        },
        {
            name: 'serverpriority',
            type: 'string',
            description: 'Server priority',
            table: 'Tag',
            tagType: 'PRIORITY',
            isTag: true,
            pathExclusions: {
                User: true,
                Certificate: true,
                CipherSuite: true,
            },
            originSpecificExclusions: {
                Connection: {
                    DeviceAddressPort: 'clientDeviceAddressPort',
                    DeviceSoftwareConnection: true,
                }
            }
        },
        {
            name: 'clientpurpose',
            type: 'string',
            description: 'Client purpose',
            table: 'Tag',
            tagType: 'DEVICE_PURPOSE',
            isTag: true,
            pathExclusions: {
                User: true,
                Certificate: true,
                CipherSuite: true,
            },
            originSpecificExclusions: {
                Connection: {
                    DeviceAddressPort: 'serverDeviceAddressPort',
                    DeviceSoftwareConnection: true,
                }
            }
        },
        {
            name: 'serverpurpose',
            type: 'string',
            description: 'Server purpose',
            table: 'Tag',
            tagType: 'DEVICE_PURPOSE',
            isTag: true,
            pathExclusions: {
                User: true,
                Certificate: true,
                CipherSuite: true,
            },
            originSpecificExclusions: {
                Connection: {
                    DeviceAddressPort: 'clientDeviceAddressPort',
                    DeviceSoftwareConnection: true,
                }
            }
        },
        {
            name: 'clientdevicetype',
            type: 'enum',
            description: 'Client device type',
            table: 'Device',
            column: 'deviceType',
            isTag: false,
            converter: buildEnumConverter('DeviceType'),
            pathExclusions: {
                User: true,
                Tag: true,
                Certificate: true,
                CipherSuite: true,
                CryptoPostureTemplate: true,
                DeviceSoftwareVersionLibrary: true,
            },
            originSpecificExclusions: {
                SoftwareVersion: {
                    DeviceSoftwareConnection: true
                },
                Connection: {
                    DeviceAddressPort: 'serverDeviceAddressPort',
                    DeviceSoftwareConnection: true,
                }
            },
        },
        {
            name: 'serverdevicetype',
            type: 'enum',
            description: 'Server device type',
            table: 'Device',
            column: 'deviceType',
            isTag: false,
            converter: buildEnumConverter('DeviceType'),
            pathExclusions: {
                User: true,
                Tag: true,
                Certificate: true,
                CipherSuite: true,
                CryptoPostureTemplate: true,
                DeviceSoftwareVersionLibrary: true,
            },
            originSpecificExclusions: {
                SoftwareVersion: {
                    DeviceSoftwareConnection: true
                },
                Connection: {
                    DeviceAddressPort: 'clientDeviceAddressPort',
                    DeviceSoftwareConnection: true,
                }
            },
        },
        {
            name: 'clientzone',
            type: 'string',
            description: 'Client zone',
            table: 'Tag',
            tagType: 'ZONE',
            isTag: true,
            pathExclusions: {
                User: true,
                Certificate: true,
                CipherSuite: true,
            },
            originSpecificExclusions: {
                Connection: {
                    DeviceAddressPort: 'serverDeviceAddressPort',
                    DeviceSoftwareConnection: true,
                }
            }
        },
        {
            name: 'serverzone',
            type: 'string',
            description: 'Server zone',
            table: 'Tag',
            tagType: 'ZONE',
            isTag: true,
            pathExclusions: {
                User: true,
                Certificate: true,
                CipherSuite: true,
            },
            originSpecificExclusions: {
                Connection: {
                    DeviceAddressPort: 'clientDeviceAddressPort',
                    DeviceSoftwareConnection: true,
                }
            }
        },
        {
            name: 'clientos',
            type: 'string',
            description: 'Client operating system',
            table: 'Software',
            column: 'name',
            isTag: false,
            matchCondition: ` "softwareType" = (SELECT id FROM "SoftwareType" WHERE name = 'OS') `,
            pathExclusions: {
                User: true,
                DeviceSoftwareVersionLibrary: true
            },
            originSpecificExclusions: {
                Connection: {
                    DeviceAddressPort: 'serverDeviceAddressPort',
                    DeviceSoftwareConnection: true,
                }
            }
        },
        {
            name: 'serveros',
            type: 'string',
            description: 'Server operating system',
            table: 'Software',
            column: 'name',
            isTag: false,
            matchCondition: ` "softwareType" = (SELECT id FROM "SoftwareType" WHERE name = 'OS') `,
            pathExclusions: {
                User: true,
                DeviceSoftwareVersionLibrary: true
            },
            originSpecificExclusions: {
                Connection: {
                    DeviceAddressPort: 'clientDeviceAddressPort',
                    DeviceSoftwareConnection: true,
                }
            }
        },
        {
            name: 'sensitivity',
            type: 'enum',
            description: 'Connection sensitivity',
            table: 'Connection',
            column: 'sensitivity',
            isTag: false,
            // TODO: GAP506 - temporarily disabled for demo.
            /*
                        filterCategory: {
                            category: filterCategoryTypes.CONNECTION,
                            group: "Type",
                            appliesTo: [postureCategories.CONNECTION]
                        },
                        */
            pathExclusions: {
                User: true,
                Tag: true,
                Certificate: true,
                CipherSuite: true,
                CryptoPostureTemplate: true,
                DeviceSoftwareVersionLibrary: true,
            },
            converter: buildEnumConverter('ConnectionRatingScale')
        },
        {
            name: 'conncount',
            type: 'integer',
            description: 'Number of incoming and outgoing connections',
            table: 'Device',
            column: ['incomingConnectionCount', 'outgoingConnectionCount'],
            isTag: false,
            pathExclusions: {
                User: true,
                Tag: true,
                Certificate: true,
                CipherSuite: true,
                CryptoPostureTemplate: true,
                DeviceSoftwareConnection: true,
            },
            originSpecificExclusions: {
                Connection: {
                    DeviceAddressMACAddress: true,
                    DeviceSoftware: true,
                },
                SoftwareVersion: {
                    DeviceSoftwareVersionLibrary: true,
                },
            },
            customClause: () => (` "Device"."incomingConnectionCount" + "Device"."outgoingConnectionCount" `)
        },
        {
            name: 'incoming',
            type: 'integer',
            description: 'Number of incoming connections',
            table: 'Device',
            column: 'incomingConnectionCount',
            isTag: false,
            pathExclusions: {
                User: true,
                Tag: true,
                Certificate: true,
                CipherSuite: true,
                CryptoPostureTemplate: true,
                DeviceSoftwareConnection: true,
            },
            originSpecificExclusions: {
                Connection: {
                    DeviceAddressMACAddress: true,
                    DeviceSoftware: true,
                },
                SoftwareVersion: {
                    DeviceSoftwareVersionLibrary: true,
                },
            },
        },
        {
            name: 'outgoing',
            type: 'integer',
            description: 'Number of outgoing connections',
            table: 'Device',
            column: 'outgoingConnectionCount',
            isTag: false,
            pathExclusions: {
                User: true,
                Tag: true,
                Certificate: true,
                CipherSuite: true,
                CryptoPostureTemplate: true,
                DeviceSoftwareConnection: true,
            },
            originSpecificExclusions: {
                Connection: {
                    DeviceAddressMACAddress: true,
                    DeviceSoftware: true,
                },
                SoftwareVersion: {
                    DeviceSoftwareVersionLibrary: true,
                },
            },
        },
        {
            name: 'deviceid',
            type: 'integer',
            description: 'Device ID',
            table: 'Device',
            column: 'id',
            isTag: false,
            pathExclusions: {
                Certificate: true,
                CipherSuite: true,
                CryptoPostureTemplate: true,
                DeviceSoftwareConnection: true,
                Tag: true,
                User: true,
            },
            originSpecificExclusions: {
                Connection: {
                    DeviceAddressMACAddress: true,
                },
                SoftwareVersion: {
                    DeviceSoftwareVersionLibrary: true,
                },
            },
        },
        {
            name: 'bytes',
            type: 'integer',
            description: 'Number of bytes transferred on a connection',
            table: 'Connection',
            column: 'bytesTransferred',
            isTag: false,
            pathExclusions: {
                Certificate: true,
                CipherSuite: true,
                CryptoPostureTemplate: true,
                DeviceSoftwareVersionLibrary: true,
                Tag: true,
                User: true,
            },
            originSpecificExclusions: {
                Device: {
                    DeviceSoftware: true,
                },
            },
        },
        {
            name: 'devicecryptoscore',
            type: 'integer',
            description: 'Device Crypto Strength',
            table: 'CryptoScore',
            column: 'score',
            isTag: false,
            filterCategory: {
                category: [filterCategoryTypes.DEVICECRYPTO],
                group: 'Strength',
                additionalFlatCacheMapping: {
                    column: 'cryptoPostureTemplate',
                    table: 'CryptoPostureTemplate',
                    linkedValue: getCptForRequest
                },
            },
            pathExclusions: {
                Certificate: true,
                CipherSuite: true,
                ConnectionScore: true,
                DeviceMACAddress: true,
                DeviceSoftwareConnection: true,
                DeviceSoftwareVersionLibrary: true,
                ProtocolVariant: true,
                SoftwareVersion: true,
                Tag: true,
                User: true,
                CryptoPostureTemplate: true
            },
            extraMatching: cptDeviceExtraMatching
        },
        {
            name: 'devicecryptocategory',
            type: 'enum',
            description: 'Device crypto category',
            table: 'CryptoScoreCoarse',
            column: 'id',
            isTag: false,
            converter: buildEnumConverter('CryptoScoreCoarse'),
            pathExclusions: {
                User: true,
                Tag: true,
                Certificate: true,
                CipherSuite: true,
            },
            pathInclusions: {
                Device: true,
                CryptoScore: true,
                CryptoScoreCoarse: true
            },
            originSpecificExclusions: {
                SoftwareVersion: {
                    DeviceSoftwareConnection: true,
                    DeviceSoftwareVersionLibrary: true
                },
            },
        },
        {
            name: 'devicetype',
            type: 'enum',
            description: 'Device type',
            table: 'Device',
            column: 'deviceType',
            isTag: false,
            converter: buildEnumConverter('DeviceType'),
            filterCategory: {
                category: filterCategoryTypes.DEVICE,
                group: 'Type',
                appliesTo: [postureCategories.DEVICE, postureCategories.SOFTWARE]
            },
            pathExclusions: {
                User: true,
                Tag: true,
                Certificate: true,
                CipherSuite: true,
                CryptoPostureTemplate: true,
                DeviceSoftwareVersionLibrary: true,
            },
            originSpecificExclusions: {
                SoftwareVersion: {
                    DeviceSoftwareConnection: true
                },
            },
        },
        {
            name: 'devicename',
            type: 'string',
            description: 'Device name',
            table: 'Device',
            column: 'friendlyName',
            isTag: false,
            pathExclusions: {
                User: true,
                Tag: true,
                Certificate: true,
                CipherSuite: true,
                CryptoPostureTemplate: true,
                DeviceSoftwareConnection: true
            },
            originSpecificExclusions: {
                Connection: {
                    DeviceAddressMACAddress: true
                },
                SoftwareVersion: {
                    DeviceSoftwareVersionLibrary: true
                },
            },
        },
        {
            name: 'macaddress',
            type: 'string',
            description: 'Device MAC address',
            table: 'DeviceMACAddress',
            column: 'mac',
            isTag: false,
            pathExclusions: {
                User: true,
                DeviceSoftwareVersionLibrary: true,
            },
        },
        {
            name: 'port',
            type: 'integer',
            description: 'Device port',
            table: 'DeviceAddressPort',
            column: 'port',
            isTag: false,
            maxLength: {
                'Device': 3,
                'Connection': 3,
                'SoftwareVersion': 5
            },
            pathExclusions: {
                Tag: true,
                User: true,
                DeviceSoftwareConnection: true
            },
        },
        {
            name: 'lastonline',
            type: 'datetime|string',
            description: 'Last time a device was online',
            table: 'Device',
            column: 'lastTimeOnline',
            isTag: false,
            pathExclusions: {
                User: true,
                Tag: true,
                Certificate: true,
                CipherSuite: true,
                CryptoPostureTemplate: true,
                DeviceSoftwareVersionLibrary: true,
            },
            originSpecificExclusions: {
                SoftwareVersion: {
                    DeviceSoftwareConnection: true
                },
            },
            converter: dateTimeConverter,
            operatorConverter: buildOperatorConverterByOperator({ 'like': 'rangelte' }),
        },
        {
            name: 'addedby',
            type: 'string',
            description: 'Added by username',
            table: 'User',
            column: 'userName',
            isTag: false,
            maxLength: 2,
            pathExclusions: {
                DataSource: true,
            },
        },
        {
            name: 'deviceaddeddate',
            type: 'datetime|string',
            description: 'The date/time a device was added',
            table: 'Device',
            column: 'addedDate',
            isTag: false,
            pathExclusions: {
                Certificate: true,
                CipherSuite: true,
                CryptoPostureTemplate: true,
                DeviceSoftwareConnection: true,
                Tag: true,
                User: true,
            },
            originSpecificExclusions: {
                Connection: {
                    DeviceAddressMACAddress: true,
                },
                SoftwareVersion: {
                    DeviceSoftwareVersionLibrary: true,
                },
            },
            converter: dateTimeConverter,
            operatorConverter: buildOperatorConverterByOperator({ 'like': 'rangelte' }),
        },
        {
            name: 'conaddeddate',
            type: 'datetime|string',
            description: 'The date/time a connection was added',
            table: 'Connection',
            column: 'addedAt',
            isTag: false,
            pathExclusions: {
                User: true,
                Tag: true,
                Certificate: true,
                CipherSuite: true,
                CryptoPostureTemplate: true,
                DeviceSoftwareConnection: true,
                DeviceSoftwareVersionLibrary: true
            },
            converter: dateTimeConverter,
            operatorConverter: buildOperatorConverterByOperator({ 'like': 'rangelte' }),
        },
        {
            name: 'conimportance',
            type: 'enum',
            description: 'Connection importance',
            table: 'Connection',
            column: 'importance',
            isTag: false,
            converter: buildEnumConverter('ConnectionRatingScale'),
            pathExclusions: {
                User: true,
                Tag: true,
                Certificate: true,
                CipherSuite: true,
                CryptoPostureTemplate: true,
            },
            originSpecificExclusions: {
                Device: {
                    DeviceSoftware: true
                },
                SoftwareVersion: {
                    Device: true
                },
            }
        },
        {
            name: 'peer',
            type: 'string',
            description: 'Peers with matching IP address',
            table: 'DeviceAddress',
            column: 'address',
            isTag: false,
            maxLength: {
                'Device': 3,
                'SoftwareVersion': 4,
                'Connection': 3,
            },
            pathExclusions: {
                User: true,
                Tag: true,
                Certificate: true,
                DeviceSoftwareVersionLibrary: true
            }
        },
        {
            name: 'peerport',
            type: 'integer',
            description: 'Peers with matching ports',
            table: 'DeviceAddressPort',
            column: 'port',
            isTag: false,
            maxLength: {
                'Device': 3,
                'Connection': 3,
                'SoftwareVersion': 5
            },
            originSpecificExclusions: {
                SoftwareVersion: {
                    DeviceSoftwareVersionLibrary: true
                }
            },
            pathExclusions: {
                User: true,
                Tag: true,
                DeviceSoftwareConnection: true
            },
        },
        {
            name: 'concryptoscore',
            type: 'integer',
            description: 'Connection Crypto Strength',
            table: 'CryptoScore',
            column: 'score',
            isTag: false,
            filterCategory: {
                category: [filterCategoryTypes.CONNECTIONCRYPTO],
                group: 'Strength',
                additionalFlatCacheMapping: {
                    column: 'cryptoPostureTemplate',
                    table: 'CryptoPostureTemplate',
                    linkedValue: getCptForRequest
                },
            },
            pathExclusions: {
                Certificate: true,
                CipherSuite: true,
                DeviceScore: true,
                ProtocolVariant: true,
                SoftwareVersion: true,
                Tag: true,
                User: true,
                CryptoPostureTemplate: true
            },
            extraMatching: cptConnectionExtraMatching
        },
        {
            name: 'concryptocategory',
            type: 'enum',
            description: 'Connection crypto category',
            table: 'CryptoScoreCoarse',
            column: 'id',
            isTag: false,
            converter: buildEnumConverter('CryptoScoreCoarse'),
            pathExclusions: {
                User: true,
                Tag: true,
                Certificate: true,
                CipherSuite: true
            },
            pathInclusions: {
                CryptoScore: true,
                CryptoScoreCoarse: true
            },
        },
        {
            name: 'protocol',
            type: 'enum',
            description: 'Protocol',
            table: 'Protocol',
            column: 'id',
            isTag: false,
            converter: buildEnumConverter('Protocol'),
            pathExclusions: {
                User: true,
                Tag: true,
                Certificate: true,
                CipherSuite: true
            },
        },
        {
            name: 'protocolvariant',
            type: 'string',
            description: 'Protocol variant',
            table: 'ProtocolVariant',
            column: 'name',
            isTag: false,
            filterCategory: {
                category: filterCategoryTypes.CRYPTO,
                group: 'Protocol'
            },
            pathExclusions: {
                User: true,
                Tag: true,
                Certificate: true,
                CipherSuite: true
            },
            originSpecificExclusions: {
                Device: {
                    DeviceSoftware: true
                }
            }
        },
        {
            name: 'ciphersuite',
            type: 'string',
            description: 'Cipher suite',
            table: 'CipherSuite',
            column: 'name',
            isTag: false,
            pathExclusions: {
                User: true,
                CryptoPrimitive: true,
                Protocol: true,
                ProtocolVariant: true,
            },
            originSpecificExclusions: {
                Device: {
                    DeviceSoftwareConnection: true
                }
            }
        },
        {
            name: 'cryptoprim',
            type: 'enum',
            description: 'Cryptographic primitive',
            table: 'CryptoPrimitive',
            column: 'id',
            isTag: false,
            converter: buildEnumConverter('CryptoPrimitive'),
            filterCategory: {
                category: filterCategoryTypes.CRYPTO,
                group: 'Primitives'
            },
            pathInclusions: {
                ConnectionProtocolVariant: true
            },
            pathExclusions: {
                User: true,
                Tag: true,
                DeviceSoftwareConnection: true
            },
            orderedExclusions: [
                'ConnectionCryptoPrimitive',
                'DeviceSoftware',
                'DeviceCertificate',
            ],
            originSpecificExclusions: {
                Device: {
                    CryptoScore: true
                },
                Connection: {
                    CryptoScore: true
                },
                SoftwareVersion: {
                    DeviceCertificate: true,
                    DeviceAddress: true,
                    Connection: true,
                },
            }
        },
        {
            name: 'certalgo',
            type: 'enum',
            description: 'Certificate algorithms',
            table: 'CryptoPrimitive',
            column: 'id',
            isTag: false,
            converter: buildEnumConverter('CryptoPrimitive'),
            pathInclusions: {
                CertificateCryptoPrimitive: true
            },
            pathExclusions: {
                User: true,
                Tag: true,
                ConnectionCryptoPrimitive: true,
                CipherSuite: true,
                ConfigurationFile: true,
                Agent: true,
            },
            originSpecificExclusions: {
                Device: {
                    CryptoScore: true,
                    DeviceSoftwareConnection: true,
                },
                Connection: {
                    CryptoScore: true,
                    DeviceSoftwareConnection: true,
                },
                SoftwareVersion: {
                    DeviceAddress: true,
                    DeviceCertificate: true,
                },
            }
        },
        {
            name: 'certtype',
            type: 'enum',
            description: 'Certificate type',
            table: 'Certificate',
            column: 'certificateType',
            isTag: false,
            converter: buildEnumConverter('CertificateType'),
            pathExclusions: {
                User: true,
                ConnectionProtocolVariant: true,
                CipherSuite: true,
                CryptoPrimitive: true,
                DeviceSoftwareConnection: true,
                DeviceSoftwareVersionLibrary: true
            },
            originSpecificExclusions: {
                SoftwareVersion: {
                    Connection: true,
                    Agent: true,
                },
                Connection: {
                    Device: true,
                    DeviceSoftware: true,
                },
            },
        },
        {
            name: 'cert',
            type: 'string',
            description: 'Certificate',
            table: 'Certificate',
            column: 'subject',
            isTag: false,
            pathExclusions: {
                User: true,
                ConfigurationFileCertificate: true,
                ConnectionProtocolVariant: true,
                DeviceSoftwareConnection: true,
                CipherSuite: true,
                CryptoPrimitive: true,
                Tag: true,
            },
            originSpecificExclusions: {
                SoftwareVersion: {
                    DeviceSoftwareVersionLibrary: true,
                    Agent: true,
                },
            },
        },
        {
            name: 'certissuer',
            type: 'string',
            description: 'Cert Issuer',
            table: 'CertificationAuthority',
            column: 'name',
            isTag: false,
            pathExclusions: {
                User: true,
                ConfigurationFile: true,
            },
            originSpecificExclusions: {
                SoftwareVersion: {
                    Connection: true,
                    Agent: true,
                },
            },
        },
        {
            name: 'abnormal',
            type: 'boolean',
            description: 'Has abnormal key sizes',
            table: 'CertificateCryptoPrimitive',
            column: 'keyLength',
            isTag: false,
            pathExclusions: {
                User: true,
                ConfigurationFileCertificate: true,
                ConnectionProtocolVariant: true,
                DeviceSoftwareConnection: true,
                CipherSuite: true,
                CryptoPrimitive: true,
                Tag: true,
            },
            originSpecificExclusions: {
                SoftwareVersion: {
                    DeviceSoftwareVersionLibrary: true,
                    Agent: true,
                },
            },
            converter: buildBooleanConverter({ 'true': null, 'false': null }),
            operatorConverter: buildOperatorConverter({ 'true': 'isnotnull', 'false': 'isnull' })
        },
        {
            name: 'softwareid',
            type: 'integer',
            description: 'Software ID',
            table: 'SoftwareVersion',
            column: 'id',
            isTag: false,
            pathExclusions: {
                Tag: true,
                User: true,
                DeviceSoftwareVersionLibrary: true,
            },
        },
        {
            name: 'connid',
            type: 'integer',
            description: 'Connection ID',
            table: 'Connection',
            column: 'id',
            isTag: false,
            pathExclusions: {
                User: true,
                Tag: true,
                Certificate: true,
                CipherSuite: true,
                CryptoPostureTemplate: true,
                DeviceSoftwareVersionLibrary: true,
            },
        },
        {
            name: 'software',
            type: 'string',
            description: 'Software name',
            table: 'Software',
            column: 'name',
            isTag: false,
            pathExclusions: {
                User: true,
            },
        },
        {
            name: 'softwaretype',
            type: 'enum',
            description: 'Software Type',
            table: 'Software',
            column: 'softwareType',
            isTag: false,
            pathExclusions: {
                User: true
            },
            converter: buildEnumConverter('SoftwareType')
        },
        {
            name: 'softwarevendor',
            type: 'string',
            description: 'Software vendor',
            table: 'Software',
            column: 'softwareVendor',
            isTag: false,
            pathExclusions: {
                DeviceSoftwareVersionLibrary: true,
                User: true,
            },
        },
        {
            name: 'softwareversion',
            type: 'string',
            description: 'Software version',
            table: 'SoftwareVersion',
            column: 'version',
            isTag: false,
            pathExclusions: {
                User: true,
                Tag: true,
            },
        },
        {
            name: 'binaryhash',
            type: 'string',
            description: 'Software Hash',
            table: 'SoftwareVersion',
            column: 'binaryHash',
            isTag: false,
            pathExclusions: {
                User: true,
                Tag: true,
            },
        },
        {
            name: 'softwareversionname',
            type: 'string',
            description: 'Software version name',
            table: 'SoftwareVersion',
            column: 'name',
            isTag: false,
            pathExclusions: {
                DeviceSoftwareVersionLibrary: true,
                Tag: true,
                User: true,
            },
        }, {
            name: 'softwareversionid',
            type: 'integer',
            description: 'Software version id',
            table: 'SoftwareVersion',
            column: 'id',
            isTag: false,
            pathExclusions: {
                DeviceSoftwareVersionLibrary: true,
                Tag: true,
                User: true,
            },
        },
        {
            name: 'softwareaddeddate',
            type: 'datetime|string',
            description: 'The date/time a software was added',
            table: 'Software',
            column: 'addedAt',
            isTag: false,
            pathExclusions: {
                User: true,
            },
            converter: dateTimeConverter,
            operatorConverter: buildOperatorConverterByOperator({ 'like': 'rangelte' }),
        },
        {
            name: 'os',
            type: 'string',
            description: 'Operating system',
            table: 'Software',
            column: 'name',
            isTag: false,
            matchCondition: ` "softwareType" = (SELECT id FROM "SoftwareType" WHERE name = 'OS') `,
            extraMatching: buildOSExtraMatching,
            prependQuery: buildOSprependQuery,
            filterCategory: {
                category: filterCategoryTypes.TECHNOLOGY,
                group: 'Operating Systems'
            },
            pathExclusions: {
                User: true,
                DeviceSoftwareVersionLibrary: true
            },
        },
        {
            name: 'softwarepath',
            type: 'string',
            description: 'Software path',
            table: 'DeviceSoftware',
            column: 'path',
            isTag: false,
            pathExclusions: {
                User: true,
                Tag: true,
                Agent: true,
                ConfigurationFile: true,
                DeviceAddress: true,
                DeviceScore: true,
                DeviceCertificate: true,
                ConnectionCertificate: true,
                DeviceSoftwareVersionLibrary: true
            }
        },

        {
            name: 'coord',
            type: 'string',
            description: 'Geographic coordinates',
            table: 'Tag',
            tagType: 'COORDINATE',
            isTag: true,
        },
        {
            name: 'corptag',
            type: 'string',
            description: 'Corporate tag',
            table: 'Tag',
            tagType: 'CORPORATE_ASSET_TAG_TRACKING_NUMBER',
            isTag: true
        },
        {
            name: 'cpufamily',
            type: 'string',
            description: 'CPU family',
            table: 'Tag',
            tagType: 'CPU_FAMILY',
            isTag: true
        },
        {
            name: 'cpuspeed',
            type: 'integer',
            description: 'CPU speed',
            table: 'Tag',
            tagType: 'CPU_SPEED',
            isTag: true
        },
        {
            name: 'tag',
            type: 'string',
            description: 'Tag',
            table: 'Tag',
            tagType: 'CUSTOM',
            isTag: true,
            maxLength: 3
        },
        {
            name: 'devicepurpose',
            type: 'string',
            description: 'Device purpose',
            table: 'Tag',
            tagType: 'DEVICE_PURPOSE',
            isTag: true
        },
        {
            name: 'domain',
            type: 'string',
            description: 'Domain',
            table: 'Tag',
            tagType: 'DOMAIN',
            isTag: true
        },
        {
            name: 'exception',
            type: 'string',
            description: 'Exception',
            table: 'Tag',
            tagType: 'EXCEPTION',
            isTag: true
        },
        {
            name: 'host',
            type: 'string',
            description: 'Host name',
            table: 'Tag',
            tagType: 'HOSTNAME',
            isTag: true
        },
        {
            name: 'machineserial',
            type: 'string',
            description: 'Machine serial number',
            table: 'Tag',
            tagType: 'MACHINE_SERIAL_NUMBER',
            isTag: true
        },
        {
            name: 'address',
            type: 'string',
            description: 'Normal address',
            table: 'Tag',
            tagType: 'NORMAL_ADDRESS',
            isTag: true
        },
        {
            name: 'priority',
            type: 'string',
            description: 'Priority',
            table: 'Tag',
            tagType: 'PRIORITY',
            isTag: true
        },
        {
            name: 'rackaddress',
            type: 'string',
            description: 'Rack address',
            table: 'Tag',
            tagType: 'RACK_ADDRESS',
            isTag: true
        },
        {
            name: 'ramsize',
            type: 'integer',
            description: 'RAM size',
            table: 'Tag',
            tagType: 'RAM_SIZE',
            isTag: true
        },
        {
            name: 'serverroom',
            type: 'string',
            description: 'Server room number',
            table: 'Tag',
            tagType: 'SERVER_ROOM_NUMBER',
            isTag: true
        },
        {
            name: 'zone',
            type: 'string',
            description: 'Zone',
            table: 'Tag',
            tagType: 'ZONE',
            isTag: true
        }
        // End: Generated Device Tag Facets
    ]
}

// function ipAddressExtraMatching(value, clause) {
//     /* We have to do some special work for ipv4 vs ipv6. */
//     if (value.includes('.')) {
//         return `(${clause}) AND ("DeviceAddress"."addressIPVersion" = 4)`
//     } else if (value.includes(':')) {
//         return `(${clause}) AND ("DeviceAddress"."addressIPVersion" = 6)`
//     }
//     /* Ambiguous search terms will result in two search patterns. */
//     return `((${clause}) AND "DeviceAddress"."addressIPVersion" = 4) OR ((${clause}) AND "DeviceAddress"."addressIPVersion" = 6)`
// }

function buildOSExtraMatching(value, clause) {
    if (value.includes('Unknown')) {
        clause = ''
    }
    return clause
}

function buildOSprependQuery(value, prependQuery, table) {
    if (value.includes('Unknown')) {
        prependQuery = `select distinct "${table}".id from "${table}" WHERE id NOT IN`
    }
    return prependQuery
}

async function cptDeviceExtraMatching(value, clause) {
    return `(${clause}) AND ("DeviceScore"."cryptoPostureTemplate" = ${await getCptForRequest()})`
}

async function cptConnectionExtraMatching(value, clause) {
    return `(${clause}) AND ("ConnectionScore"."cryptoPostureTemplate" = ${await getCptForRequest()})`
}

/**
 * Hold sorted lists of enum names for tables. These are produced to allow consistent results when search by enums with ":" syntax.
 */
var sortedEnumNames = {}

/**
 * When hunting for enum conversions, we want to try begins with, ends with, then contains.
 */
const buildEnumConverterPatterns = ['^X', 'X$', 'X']

/**
 * Create an enum converter that will attempt to convert a string to an enum value from the given table.
 *
 * @param {string} enumTable The table to produce the enum for.
 * @return {function} The returned function attempts to convert its input to the int matching an enum.
 */
function buildEnumConverter(enumTable) {
    let func = function (value, operator) {
        var e = schemaDiscovery.allTypes[enumTable]
        if (value.includes('%')) {
            value = value.replace(/%/g, '')
        }
        if (operator === 'equals') {
            let regexp = new RegExp(`^${value}$`, 'i')
            let entries = Object.entries(e._enum.idByName)
            const attemptOne = entries.find(k => regexp.test(k[0]))
            if (attemptOne !== undefined) {
                return attemptOne[1]
            }
            const asInt = +value
            if (e._enum.nameByID[asInt]) {
                return asInt
            }
            throw new Error(`No exact match for ${value} in ${enumTable}`)

        }
        if (!(enumTable in sortedEnumNames)) {
            sortedEnumNames[enumTable] = Object.keys(e._enum.idByName).sort()
        }
        const matches = []
        const matchNames = []
        for (let pattern of buildEnumConverterPatterns) {
            var exp = new RegExp(pattern.replace('X', value), 'i')
            for (var name of sortedEnumNames[enumTable]) {
                if (exp.test(name)) {
                    matches.push(e._enum.idByName[name])
                    matchNames.push(name)
                }
            }
            if (matches.length !== 0) {
                // Return array if multiple.
                return matches
            }
        }
        throw `No conversion to ${enumTable} for ${value}`
    }
    func.enumType = enumTable
    return func
}

function dateTimeConverter(value, operator) {
    try {
        let parsedValue = chrono.parse(value)
        if (parsedValue.length > 0) {
            if (operator === 'like') {
                var start = new Date(0)
                var end = new Date(0)
                var kvals = parsedValue[0].start.knownValues
                var startParams = []
                var endParams = []
                if (kvals.millisecond) {
                    startParams.push(kvals.year, kvals.month - 1, kvals.day, kvals.hour, kvals.minute, kvals.second, kvals.millisecond)
                } else if (kvals.second) {
                    startParams.push(kvals.year, kvals.month - 1, kvals.day, kvals.hour, kvals.minute, kvals.second)
                } else if (kvals.minute) {
                    startParams.push(kvals.year, kvals.month - 1, kvals.day, kvals.hour, kvals.minute)
                    endParams.push(kvals.year, kvals.month - 1, kvals.day, kvals.hour, kvals.minute + 1)
                } else if (kvals.hour) {
                    startParams.push(kvals.year, kvals.month - 1, kvals.day, kvals.hour)
                    endParams.push(kvals.year, kvals.month - 1, kvals.day, kvals.hour + 1)
                } else {
                    startParams.push(kvals.year, kvals.month - 1, kvals.day)
                    endParams.push(kvals.year, kvals.month - 1, kvals.day + 1)
                }
                start = new Date(Date.UTC(...startParams))
                if (endParams.length > 0) {
                    end = new Date(Date.UTC(...endParams))
                } else {
                    return start
                }
                return [start, end]
            } else {
                return parsedValue[0].date()
            }
        }
        else {
            throw new Error(`Datetime input couldn't be parsed`)
        }
    } catch (e) {
        throw `Unable to understand datetime input: ${value}`
    }
}

function buildBooleanConverter(options) {
    return function (value) {
        if (value.includes('%')) {
            value = value.replace(/%/g, '')
        }

        return value === 'true' ? options.true : options.false
    }
}

function buildOperatorConverter(options) {
    return function (value) {
        if (value.includes('%')) {
            value = value.replace(/%/g, '')
        }
        return options[value]
    }
}

function buildOperatorConverterByOperator(options) {
    return function (partValue, operator, value) {
        if (operator.includes('%')) {
            operator = operator.replace(/%/g, '')
        }
        if (Array.isArray(value) && options[operator]) {
            return options[operator]
        } else {
            return operator
        }
    }
}



/**
 * The tag paths need to be shorter for Device, but longer for Connection. This lookup
 * stores those lengths.
 */
var maxTagPathLengthByTable = {
    'Device': 3,
    'Connection': 7,
    'SoftwareVersion': 5
}

/**
 * Add paths (SQL chunks) to the attributes.
 * @param {string} baseTable The table to start from.
 *
 * @returns Nothing.
 */
async function addPathsToAttributes(origins) {
    for (let origin of origins) {
        for (let attribute of exports.facets.attributes) {
            if (!attribute.table || attribute.table === '') {
                log.e('Attribute missing table', attribute)
                continue
            }

            let targetTable = attribute.table
            let targetType = schemaDiscovery.allTypes[targetTable]

            if (!(targetTable in schemaDiscovery.allTypes)) {
                log.e('Attribute claims unknown table', attribute)
                continue
            }

            let tableMatches = []
            if (attribute.matchCondition !== undefined) {
                tableMatches.push(attribute.matchCondition)
            }

            let maxLength = typeof attribute.maxLength === 'object' ? attribute.maxLength[origin] : attribute.maxLength
            let exclusionList = { ...attribute.pathExclusions }
            let columnValid = Array.isArray(attribute.column) ? attribute.column.every(column => column in targetType) : (attribute.column in targetType)
            if (attribute.isTag) {
                if (attribute.tagType !== 'CUSTOM') {
                    exclusionList.SoftwareVersionTag = true
                    exclusionList.DataSource = true
                    exclusionList.ConnectionTag = true
                    exclusionList.DeviceSoftwareConnection = true
                    exclusionList.DeviceSoftwareVersionLibrary = true
                }
                let tagTypeID = schemaDiscovery.allTypes['TagType']._enum.idByName[attribute.tagType]
                if (tagTypeID === undefined) {
                    throw `Tag type not found: ${JSON.stringify(attribute)}`
                }
                tableMatches.push(` "Tag"."tagType" = ${tagTypeID} `)
                if (!(origin in maxTagPathLengthByTable)) {
                    throw `Have not considered how to handle tag paths from ${origin}`
                }
                if (!maxLength) {
                    maxLength = maxTagPathLengthByTable[origin]
                }
                exclusionList['User'] = true
            } else if (!columnValid) {
                log.e('Columns not right in attribute (missing from table)', attribute)
                continue
            }

            let tableMatch = tableMatches.join(' AND ')

            if (!attribute.paths) {
                attribute.paths = {}
            }

            if (attribute.originSpecificExclusions && attribute.originSpecificExclusions[origin]) {
                for (let [key, value] of Object.entries(attribute.originSpecificExclusions[origin])) {
                    exclusionList[key] = value
                }
            }

            let pathParams = {
                from: origin,
                to: targetTable,
                finalTableExtraCondition: tableMatch,
                excludes: exclusionList,
                includes: attribute.pathInclusions,
                maxLength
            }

            let pathSet = new Set()
            let paths = schemaDiscovery.paths(pathParams)
            let pathsFound = false
            if (paths !== null) {
                pathsFound = true
                paths.forEach(path => pathSet.add(path))
            }

            if (attribute.orderedExclusions) {
                for (let exclusion of attribute.orderedExclusions) {
                    exclusionList[exclusion] = true
                    paths = schemaDiscovery.paths(pathParams)
                    if (paths !== null) {
                        pathsFound = true
                        paths.forEach(path => pathSet.add(path))
                    }
                }
            }

            if (pathsFound && pathSet.size === 0) {
                throw new Error(`Derived facet with 0 paths ${attribute.name}`)
            }

            if (pathSet.size !== 0) {
                attribute.paths[origin] = Array.from(pathSet)
            } else {
                attribute.paths[origin] = null
            }
        }
    }
}

/**
 * Discover the paths between database tables to satisfy query generation.
 */
exports.discoverPaths = async function discoverPaths() {
    if (exports.discoverPaths.done) {
        return
    }
    exports.discoverPaths.done = true
    exports.facets.attributes.forEach(attribute => {
        if (attribute.isTag) {
            attribute.column = 'value'
        }
        if (attribute.name in exports.facets.attributesByName) {
            throw `Duplicate attribute name ${attribute.name}`
        }
        exports.facets.attributesByName[attribute.name] = attribute
    })
    await addPathsToAttributes(['Device', 'Connection', 'SoftwareVersion'])
    if (log.debug) {
        log.d('Generated facet paths', (JSON.stringify(exports.facets.attributes, null, 2)))
    }
}
exports.discoverPaths.done = false
