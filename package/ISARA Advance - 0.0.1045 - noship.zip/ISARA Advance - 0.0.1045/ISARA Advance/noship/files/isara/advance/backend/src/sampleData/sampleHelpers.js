/**
 * @file sampleHelpers.js - 0.0.1045 - ea4595bfd3488684d225574ed7d4c198074d49ba
 * 
 * @copyright Copyright (C) 2016-2023, ISARA Corporation, All Rights Reserved.
 * 
 * @license The code and other content set out herein is not in the public
 * domain, is considered a trade secret and is confidential to ISARA
 * Corporation. Use, reproduction or distribution, in whole or in part, of such
 * code or other content is strictly prohibited except by express written
 * permission of ISARA Corporation. Please contact ISARA Corporation at
 * info@isara.com for more information.
 */

var crypto = require('crypto')
var randomWords = require('random-words')

var {
    certificateTypes,
    deviceTypes,
    layer4Protocols
} = require('./dbTypes')

function certificateType() {
    var types = Object.keys(certificateTypes)
    var which = Math.floor(Math.random() * types.length)
    return certificateTypes[types[which]]
}

function deviceType() {
    var types = Object.keys(deviceTypes)
    var which = Math.floor(Math.random() * types.length)
    return deviceTypes[types[which]]
}

function l4Protocol() {
    let types = Object.keys(layer4Protocols)
    let which = Math.floor(Math.random() * types.length)
    return layer4Protocols[types[which]]
}

function generateHostName() {
    // random hostname
    let machineName = randomWords(1)[0]
    let machineSuffix = `${randomBelow(99, 1)}`.padStart(3, '0')
    let domainName = randomWords(1)[0]
    let topLevel = pickOne(['com', 'net', 'org'])
    return `${machineName}${machineSuffix}.${domainName}.${topLevel}`
}

function intToPaddedHex(value, digits) {
    if (value < 0 || isNaN(value)) {
        throw 'value must be a non-negative number.'
    }

    var hexStr = value.toString(16)
    if (hexStr.length > digits) {
        throw 'value length exceeds specified digits.'
    }

    return hexStr.padStart(digits, '0')
}

function ipAddress() {
    if (ipAddress.existing === undefined) {
        ipAddress.existing = new Set()
    }

    if (pickOne([true, false])) {
        return ipv4Address()
    } else {
        return ipv6Address()
    }
}

function ipv4Address() {
    let notDone = true
    while (notDone) {
        do {
            var a = Math.floor(Math.random() * 200) + 10
        } while (a == 127)

        let result = `${a}`
        for (var i = 0; i < 3; ++i) {
            var next = Math.floor(Math.random() * 254) + 1
            result += `.${next}`
        }

        if (!ipAddress.existing.has(result)) {
            ipAddress.existing.add(result)
            notDone = false
            return result
        }
    }
}

function ipv6Address() {
    let notDone = true
    while (notDone) {
        do {
            var a = Math.floor(Math.random() * 65535)
        } while ((a == 0) || (a == 1) || (a == 65152 /* FE80 */) || (a == 65280 /* FF00 */))
        a = a.toString(16)
        let result = `${a}`

        for (var i = 0; i < 7; ++i) {
            if ((i < 6) && pickOne([true, false])) {
                result += `:0`
            } else {
                var next = Math.floor(Math.random() * 65534) + 1
                next = next.toString(16)
                result += `:${next}`
            }
        }

        if (!ipAddress.existing.has(result)) {
            ipAddress.existing.add(result)
            notDone = false
            return result
        }
    }
}

function macAddress() {
    let octets = []
    for (let i = 0; i < 6; ++i) {
        octets.push(intToPaddedHex(randomBelow(256), 2))
    }
    return octets.join(':')
}

function pickOne(values) {
    if (values.length === undefined) {
        var keys = Object.keys(values)
        var which = randomBelow(keys.length)
        return values[keys[which]]
    } else {
        return values[randomBelow(values.length)]
    }
}

/**
 * Splice a random item out of the given array.
 * @param {Array.<any>} values Array of objects to remove from.
 * @throws if `values` is not an array, or is empty.
 * @return {any} A member of the array.
 */
function pickOneAndRemove(values) {
    if (Array.isArray(values)) {
        if (values.length===0) {
            throw new Error('Array is already empty')
        }
        return values.splice(randomBelow(values.length),1)[0]
    } else {
        throw new Error('Pick one and remove does not work for dictionaries. (yet)')
    }
}

function port(unusablePorts) {
    if (unusablePorts.length > 20) {
        throw 'Oddly long set of unusable ports'
    }
    var candidatePorts = [443, 80, 8443, 8080, 22, 23]
    candidatePorts = candidatePorts.filter(a => !unusablePorts.includes(a))

    if (candidatePorts.length == 0) {
        for (var attempts = 0; attempts < 20; ++attempts) {
            var toReturn = Math.floor(Math.random() * 65535) + 1
            if (!(unusablePorts.includes(toReturn))) {
                return toReturn
            }
        }
        throw 'Too many attempts to find unique number'
    }

    if (Math.random() > 0.98) {
        for (attempts = 0; attempts < 20; ++attempts) {
            toReturn = Math.floor(Math.random() * 8000) + 1
            if (!(unusablePorts.includes(toReturn))) {
                return toReturn
            }
        }
        throw 'Too many attempts to find unique number'
    } else {
        return pickOne(candidatePorts)
    }
}

function randomBelow(
    max /* exclusive */,
    min = 0 /* inclusive */,
    dontInclude = null
) {
    min = Math.ceil(min)
    max = Math.floor(max)
    let randomNum = Math.floor(Math.random() * (max - min)) + min
    while ( dontInclude && dontInclude.includes(randomNum) ) {
        randomNum = Math.floor(Math.random() * (max - min)) + min
    }
    return randomNum
}

function randomCompany() {
    let first = pickOne(['Large', 'Big', 'Super', 'Software', 'Mega', 'Double', 'Triple', 'Jones', 'Random'])
    let second = pickOne(['Inc.', 'Company', 'Corp.', 'Incorporated', 'co.', '& co.', '& Sons'])
    return `${first} ${second}`
}

function randomDate(after) {
    const msInAYear = 1000 * 60 * 60 * 24 * 365.25
    var toReturn = new Date()
    var now = Date.now()
    var when = now
    if (after) {
        when = after + Math.random() * (now - after)
    } else {
        when -= Math.random() * msInAYear * 2
    }
    toReturn.setTime(when)
    return toReturn
}

function randomName(prefix = 'name', extend = 4, dash = '-') {
    const suffix = crypto.randomBytes(Math.ceil(extend / 2))
        .toString('hex').substring(0, extend)
    return `${prefix}${dash}${suffix}`
}

function randomPastDate(randomOffset, fixedOffset) {
    if (fixedOffset === undefined) {
        fixedOffset = 0
    }
    let fixedOffsetMs = fixedOffset * 3600000
    let randomOffsetMs = randomOffset * 3600000
    let randomDate = new Date(new Date() - fixedOffsetMs - randomBelow(randomOffsetMs))
    return randomDate
}

exports.certificateType = certificateType
exports.deviceType = deviceType
exports.generateHostName = generateHostName
exports.ipAddress = ipAddress
exports.l4Protocol = l4Protocol
exports.macAddress = macAddress
exports.pickOne = pickOne
exports.pickOneAndRemove = pickOneAndRemove
exports.port = port
exports.randomBelow = randomBelow
exports.randomCompany = randomCompany
exports.randomDate = randomDate
exports.randomName = randomName
exports.randomPastDate = randomPastDate
