/**
 * @file ASTNode.js - 0.0.1045 - ea4595bfd3488684d225574ed7d4c198074d49ba
 * 
 * @copyright Copyright (C) 2016-2023, ISARA Corporation, All Rights Reserved.
 * 
 * @license The code and other content set out herein is not in the public
 * domain, is considered a trade secret and is confidential to ISARA
 * Corporation. Use, reproduction or distribution, in whole or in part, of such
 * code or other content is strictly prohibited except by express written
 * permission of ISARA Corporation. Please contact ISARA Corporation at
 * info@isara.com for more information.
 */

/**
 * This module contains class definitions for the filter language
 * Abstract Syntax Tree nodes.
 * @module filterql/ASTNode
 */

function isLiteralCompatible(literal, type) {
    let types = type.split('|')
    let matched = false
    for (let subType of types) {
        switch (subType) {
            case 'boolean':
                matched = literal instanceof BooleanLiteral
                break
            case 'integer':
            case 'float':
                matched = literal instanceof IntegerLiteral ||
                        literal instanceof FloatLiteral
                break
            case 'enum':
            case 'string':
                matched = literal instanceof StringLiteral
                break
            case 'datetime':
                matched = literal instanceof DateLiteral
                break
            default:
                throw `Not implemented: ${type}`
        }

        if (matched) {
            break
        }
    }

    return matched
}

/**
  * @class ASTNode is the base class for constructing nodes in the
  *        Abstract Syntax Tree (AST)
  */
class ASTNode {
    constructor() {}

    generate() {
        return JSON.stringify(this)
    }

    generateQueryStruct(/*arg*/) {
        throw `Not implemented`
    }
}

class Expression extends ASTNode {
    constructor() {
        super()
    }
}

class TermExpression extends Expression {
    constructor(term) {
        super()
        this.term = term
    }

    generate() {
        return this.term.generate()
    }

    generateQueryStruct(arg) {
        return this.term.generateQueryStruct(arg)
    }
}

class NotExpression extends TermExpression {
    generate() {
        return `NOT ${this.term.generate()}`
    }

    generateQueryStruct(arg) {
        return { not: this.term.generateQueryStruct(arg)}
    }
}

class UnaryExpression extends Expression {
    constructor(expression) {
        super()
        this.expression = expression
    }

    generateQueryStruct(arg) {
        return this.expression.generateQueryStruct(arg)
    }
}

class ParenthesesExpression extends UnaryExpression {
    generate() {
        return `(${this.expression.generate()})`
    }
}

class BinaryExpression extends Expression {
    constructor(term, expression) {
        super()
        this.term = term
        this.expression = expression
    }
}

class AndExpression extends BinaryExpression {
    generate() {
        return `${this.term.generate()} AND ${this.expression.generate()}`
    }

    generateQueryStruct(arg) {
        return { and: [this.term.generateQueryStruct(arg),
            this.expression.generateQueryStruct(arg)] }
    }
}

class OrExpression extends BinaryExpression {
    generate() {
        return `${this.term.generate()} OR ${this.expression.generate()}`
    }

    generateQueryStruct(arg) {
        return { or: [this.term.generateQueryStruct(arg),
            this.expression.generateQueryStruct(arg)] }
    }
}

class Term extends ASTNode {
    constructor(attribute, comparison) {
        super()
        this.attribute = attribute
        this.comparison = comparison
    }
    generate() {
        return `${this.attribute.generate()}${this.comparison.generate()}`
    }

    generateQueryStruct(arg) {
        if (this.attribute instanceof NamedAttribute) {
            if (arg === undefined || arg.attributes === undefined) {
                throw `Invalid argument for NamedAttribute`
            }
            const attribute = arg.attributes.find(
                ({ name }) => name === this.attribute.name
            )
            if (attribute) {
                let isCompatible = false

                if(this.attribute.name === 'ip' || this.attribute.name === 'peer') {
                    //It accepts IP numbers AND characters
                    isCompatible = true
                } else if (this.comparison instanceof ValueComparison ||
                    this.comparison instanceof OneWayComparison) {
                    isCompatible = isLiteralCompatible(this.comparison.literal, attribute.type)
                } else if (this.comparison instanceof TwoWayComparison) {
                    isCompatible = isLiteralCompatible(this.comparison.literal1, attribute.type) &&
                                   isLiteralCompatible(this.comparison.literal2, attribute.type)
                } else {
                    throw `Unknown comparison type`
                }

                if (!isCompatible) {
                    throw `NamedAttribute type incompatible with ${attribute.type}`
                }
                return this.comparison.generateQueryStruct({column:`${attribute.name}`})
            } else {
                throw `NamedAttribute ${this.attribute.name} not found in facets list`
            }
        } else {
            throw `Not implemented for AnonymousAttribute`
        }
    }
}

class Attribute extends ASTNode { }

class AnonymousAttribute extends Attribute {
    generate() {
        return ''
    }
}

class NamedAttribute extends Attribute {
    constructor(name) {
        super()
        this.name = name
    }
    generate() {
        return this.name
    }
}

class QualifiedAttribute extends NamedAttribute {
    constructor(qualifier, name) {
        super(name)
        this.qualifier = qualifier
    }
    generate() {
        return `${this.qualifier}.${this.name}`
    }
}

class NamedTagAttribute extends NamedAttribute {
    generate() {
        return `#${this.name}`
    }
}

class QualifiedTagAttribute extends QualifiedAttribute {
    generate() {
        return `#${this.qualifier}`
    }
}

class Comparison extends ASTNode { }

class Comparator extends ASTNode { }

class ValueComparison extends Comparison {
    constructor(comparator, literal) {
        super()
        this.comparator = comparator
        this.literal = literal
    }

    generate() {
        return `${this.comparator.generate()}${this.literal.generate()}`
    }

    generateQueryStruct(arg) {
        if (arg === undefined || arg.column === undefined) {
            throw `Value comparison received invalid argument`
        }
        // Generate query object
        return this.comparator.generateQueryStruct({literal:this.literal,
            column:arg.column})
    }
}

class ValueComparator extends Comparator { }

class Contains extends ValueComparator {
    generate() {
        return ':'
    }

    generateQueryStruct(arg) {
        if (arg === undefined || arg.literal === undefined
                              || arg.column === undefined) {
            throw `Contains received invalid argument`
        }

        return  {
            like: {
                column: arg.column,
                value: `%${arg.literal.generate()}%`
            }
        }
    }
}

class ContainsCase extends Contains {
    generate() {
        return '::'
    }
}

class Equals extends ValueComparator {
    generate() {
        return '='
    }

    generateQueryStruct(arg) {
        if (arg === undefined || arg.literal === undefined
                              || arg.column === undefined) {
            throw `Equals received invalid argument`
        }
        return  {
            equals: {
                column: arg.column,
                value: `${arg.literal.generate()}`
            }
        }
    }
}

class EqualsCase extends Equals {
    generate() {
        return '=='
    }
}

class OneWayComparison extends Comparison {
    constructor(comparator, literal) {
        super()
        this.comparator = comparator
        this.literal = literal
    }
    generate() {
        return `${this.comparator.generate()}${this.literal.generate()}`
    }

    generateQueryStruct(arg) {
        if (arg === undefined) {
            throw `OneWayComparison received invalid argument`
        }
        // Generate query object
        return this.comparator.generateQueryStruct({literal:this.literal,
            column:arg.column})
    }
}

class BeforeComparison extends OneWayComparison { }
class AfterComparison extends OneWayComparison { }

class TwoWayComparison extends Comparison {
    constructor(comparator1, literal1, comparator2, literal2) {
        super()
        this.comparator1 = comparator1
        this.literal1 = literal1
        this.comparator2 = comparator2
        this.literal2 = literal2
    }
    generate() {
        return `${this.comparator1.generate()}${this.literal1.generate()}`
            + `${this.comparator2.generate()}${this.literal2.generate()}`
    }

    generateQueryStruct(arg) {
        if (arg === undefined) {
            throw `TwoWayComparison received invalid argument`
        }
        // Generate query object
        return { and: [this.comparator1.generateQueryStruct({literal:this.literal1,
            column:arg.column}),
        this.comparator2.generateQueryStruct({literal:this.literal2,
            column:arg.column})]
        }
    }
}

class InsideComparison extends TwoWayComparison { }
class OutsideComparison extends TwoWayComparison { }

class OneWayComparator extends Comparator {
    generateQueryStruct(arg) {
        if (arg === undefined || arg.literal === undefined
                              || arg.column === undefined) {
            throw `OneWayComparator received invalid argument`
        }
        return { column: arg.column, value: `${arg.literal.generate()}` }
    }
}
class LessThan extends OneWayComparator {
    generate() {
        return '<'
    }

    generateQueryStruct(arg) {
        return { lt : super.generateQueryStruct(arg) }
    }
}
class LessThanOrEqual extends OneWayComparator {
    generate() {
        return '<='
    }

    generateQueryStruct(arg) {
        return { lte : super.generateQueryStruct(arg) }
    }
}
class GreaterThan extends OneWayComparator {
    generate() {
        return '>'
    }

    generateQueryStruct(arg) {
        return { gt : super.generateQueryStruct(arg) }
    }
}
class GreaterThanOrEqual extends OneWayComparator {
    generate() {
        return '>='
    }

    generateQueryStruct(arg) {
        return { gte : super.generateQueryStruct(arg) }
    }
}

class Literal extends ASTNode { }

class BooleanLiteral extends Literal {
    constructor(isTrue) {
        super()
        this.isTrue = isTrue
    }
    generate() {
        return `${this.isTrue}`
    }
}

class IntegerLiteral extends Literal {
    constructor(value) {
        super()
        this.value = value
    }
    generate() {
        return `${this.value}`
    }
}

class FloatLiteral extends Literal {
    constructor(value) {
        super()
        this.value = value
    }
    generate() {
        return `${this.value}`
    }
}

class StringLiteral extends Literal {
    constructor(string, isQuoted=false) {
        super()
        this.string = string
        this.isQuoted = isQuoted
    }
    generate() {
        return `${this.string}`
    }
}

class DateLiteral extends Literal {
    constructor(year, month, day, hour, minute, second) {
        super()
        this.year = year
        this.month = month
        this.day = day
        this.hour = hour
        this.minute = minute
        this.second = second
    }
    generate() {
        return `${this.year}`
        + `-${this.month.toString().padStart(2, '0')}`
        + `-${this.day.toString().padStart(2, '0')}`
        + `T${this.hour.toString().padStart(2, '0')}`
        + `:${this.minute.toString().padStart(2, '0')}`
        + `:${this.second.toString().padStart(2, '0')}`
    }
}

module.exports = {
    TermExpression:	TermExpression,
    NotExpression: NotExpression,
    ParenthesesExpression: ParenthesesExpression,
    AndExpression: AndExpression,
    OrExpression: OrExpression,
    Term: Term,
    AnonymousAttribute: AnonymousAttribute,
    NamedAttribute: NamedAttribute,
    QualifiedAttribute: QualifiedAttribute,
    NamedTagAttribute: NamedTagAttribute,
    QualifiedTagAttribute: QualifiedTagAttribute,
    ValueComparison: ValueComparison,
    Contains: Contains,
    ContainsCase: ContainsCase,
    Equals: Equals,
    EqualsCase: EqualsCase,
    BeforeComparison: BeforeComparison,
    AfterComparison: AfterComparison,
    InsideComparison: InsideComparison,
    OutsideComparison: OutsideComparison,
    LessThan: LessThan,
    LessThanOrEqual: LessThanOrEqual,
    GreaterThan: GreaterThan,
    GreaterThanOrEqual: GreaterThanOrEqual,
    BooleanLiteral: BooleanLiteral,
    IntegerLiteral: IntegerLiteral,
    FloatLiteral: FloatLiteral,
    StringLiteral: StringLiteral,
    DateLiteral: DateLiteral,
}
