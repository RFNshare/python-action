/**
 * @file cud.js - 0.0.1045 - ea4595bfd3488684d225574ed7d4c198074d49ba
 * 
 * @copyright Copyright (C) 2016-2023, ISARA Corporation, All Rights Reserved.
 * 
 * @license The code and other content set out herein is not in the public
 * domain, is considered a trade secret and is confidential to ISARA
 * Corporation. Use, reproduction or distribution, in whole or in part, of such
 * code or other content is strictly prohibited except by express written
 * permission of ISARA Corporation. Please contact ISARA Corporation at
 * info@isara.com for more information.
 */

/**
* Code intended to Create Update or Delete records in the database.
* @module isaraql/cud
*/

const { Session } = require('./session')
const { insertRecord, updateRecord, SQLUpdateOp, upsertRecord, OPERATION_INSERT, generatePlaceholders } = require('./fetch')
const { allTypes, FK_INBOUND, FK_OUTBOUND } = require('./schemaDiscovery')
const log = require('../util/log')(module)
const {partition} = require('lodash')

const CUD_OP_INSERT = 'coInsert'
const CUD_OP_UPDATE = 'coUpdate'
const CUD_OP_DELETE = 'coDelete'
const CUD_OP_ALL = 'coAll' // insert update - primarily intended for use with _CHILDREN.
const CUD_OP_PRE = 'coPre'
const CUD_OP_PRE_CHILDREN = 'coPreChild'
const CUD_OP_POST = 'coPost'
const CUD_OP_POST_CHILDREN = 'coPostChild'

exports.CUD_OP_INSERT = CUD_OP_INSERT
exports.CUD_OP_UPDATE = CUD_OP_UPDATE
exports.CUD_OP_DELETE = CUD_OP_DELETE
exports.CUD_OP_PRE = CUD_OP_PRE
exports.CUD_OP_PRE_CHILDREN = CUD_OP_PRE_CHILDREN
exports.CUD_OP_POST = CUD_OP_POST
exports.CUD_OP_POST_CHILDREN = CUD_OP_POST_CHILDREN

/**
 * @typedef CUDHook Data showing pre or post write object information.
 * @property {string} table The relevant table
 * @property {string} operation Operation, one of CUD_OP_INSERT, CUD_OP_UPDATE or CUD_UP_DELETE.
 * @property {string} when When this event is happening, one of CUD_OP_PRE or CUD_OP_POST.
 * @property {object} record The (minimal in memory) record being operated on.
 * @property {Session} session The database session.
 */

/**
 * Holds the CUD event hooks.
 */
const hooks = {}

async function registerHook(table, operation, when, hook) {
    if (!table || !operation || !when || !hook) {
        throw new Error('Missing required parameter')
    }
    hooks[table] || (hooks[table] = {})
    hooks[table][operation] || (hooks[table][operation] = {})
    hooks[table][operation][when] || (hooks[table][operation][when] = [])
    hooks[table][operation][when].push(hook)
}
/**
 * Register a hook for CUD operations.
 * @param {string} table
 * @param {string} operation
 * @param {string} when
 * @param {function} hook An async function that will be called with `CUDHook` data.
 */
exports.registerHook = registerHook

async function callHooks(table, operation, when, record, session) {
    if (hooks[table] && hooks[table][operation] && hooks[table][operation][when]) {
        var params = { table, operation, when, record, session }
        for (var hook of hooks[table][operation][when]) {
            await hook(params)
        }
    }
}

/**
 * Register a hook for CUD operations pre and post tree-traversal. Note that these hooks are op-independent.
 * @param {string} table
 * @param {string} when
 * @param {function} hook An async function that will be called with `CUDHook` data.
 */
exports.registerTreeHook = function (table, when, hook) {
    if (!table || !when || !hook) {
        throw new Error('Missing required parameter')
    }

    if (when !== CUD_OP_PRE_CHILDREN && when !== CUD_OP_POST_CHILDREN) {
        throw new Error(`Invalid 'when' passed in for tree hook.`)
    }

    registerHook(table, CUD_OP_ALL, when, hook)
}


async function findExisting(table, record, session) {
    var tableType = allTypes[table]
    var params = []
    var conditions = []
    var query = `select id from "${table}" where `
    let needsUpdate = false
    for (var field in record) {
        if (!(field in tableType)) {
            throw `Could not find ${field} in ${table}`
        }
        if (record[field] instanceof SQLUpdateOp) {
            needsUpdate = true
            continue
        }
        if (record[field] === null) {
            conditions.push(` "${field}" is null `)
        } else {
            conditions.push(` "${field}" = ? `)
            params.push(record[field])
        }
    }
    if (params.length === 0) {
        return []
    }

    query += conditions.join(' and ')
    // if we will be modifying this row, we need to acquire a row-level lock.
    if (needsUpdate) {
        query += ' FOR UPDATE'
    }

    let result = await session.query(query, params)
    if (result.rowCount == 1 && needsUpdate) {
        record.NEEDS_UPDATE = true
    }

    return result
}

/**
 * Create, Update and Delete database records based on graph input.
 * @param {string} topLevelTable
 * @param {object[]} values
 * @param {object} [config] A dictionary controlling behaviour.
 * @param {object} [config.modifiableTables] A dictionary of tables that may be written to. If not provided, no tables will be writeable. You may as well just not call this function.
 * @param {object} [config.deletableTables] A dictionary of tables that may be deleted. If not provided, no tables will be deletable.
 * @param {object} [config.checkExistingTables] A dictionary of tables that should have values reused, not attempted to re-insert.
 * @param {boolean} [config.allowInsert] Flag indicating that creation is allowed. Defaults to `false`.
 * @param {boolean} [config.allowUpdate] Flag indicating that updates are allowed. Defaults to `false`.
 * @param {boolean} [config.allowDelete] Flag indicating that deletions are allowed. Defaults to `false`.
 * @param {boolean} {config.populateIDs} Flag indicating whether to decorate the inputs with IDs resulting from recursive inserts or updates. Defaults to `false`.
 * @param {Session} [config.session] A database session to minimise connection overhead.
 */
exports.createUpdateDelete = async function (topLevelTable, values, config) {
    if (!config) {
        config = {}
    }

    if (values === undefined || values.length === 0) {
        return []
    }

    var modifiableTables = config.modifiableTables ? config.modifiableTables : {}
    var deletableTables = config.deletableTables ? config.deletableTables : {}
    var checkExistingTables = config.checkExistingTables ? config.checkExistingTables : {}
    var allowInsert = config.allowInsert === true
    var allowUpdate = config.allowUpdate === true
    var allowDelete = config.allowDelete === true
    var populateIDs = config.populateIDs === true
    var session = config.session

    var survivingIDs = []

    if (!session) {
        session = new Session()
    }

    await session.asTransaction(iterateValues)

    return survivingIDs

    async function iterateValues() {
        for (let value of values) {
            var result = await cudRecurse(topLevelTable, value)
            var ids = result.map(({record}) => record.id)
            if (ids !== null && ids.length !== 0) {
                survivingIDs.push(...ids)
            }
            if (result.length > 0) {
                let resultValue = result[0].value
                for (let field in resultValue) {
                    value[field] = resultValue[field]
                }
            }
        }
    }

    async function cascadeDelete(table, ids) {
        if (!Array.isArray(ids)) {
            ids = [ids]
        }
        if (!allowDelete) {
            throw `Not allowed to delete`
        }
        if (!(table in deletableTables)) {
            throw `Not allowed to delete from ${table}`
        }
        if (ids === undefined || ids === null || ids.length === 0) {
            throw `ID required to delete from ${table}`
        }

        var tableType = allTypes[table]

        // Delete records with incoming links
        for (var relationshipName in tableType._meta) {
            var relationship = tableType._meta[relationshipName]
            if (typeof relationship === 'object' && relationship.dir === FK_INBOUND) {
                let select = `select id from "${relationship.table}" where "${relationship.column}" in (${generatePlaceholders(ids)})`
                let children = (await session.query(select, ids)).rows
                for (var child of children) {
                    await cascadeDelete(relationship.table, child.id)
                }
            }
        }


        var deleteQuery = `delete from "${table}" where id in (${generatePlaceholders(ids)})`

        var rootOp = {}
        rootOp[topLevelTable] = CUD_OP_DELETE

        for (let id of ids) {
            var record = { id, rootOp }
            await callHooks(table, CUD_OP_DELETE, CUD_OP_PRE, record, session)
        }
        await session.query(deleteQuery, ids)
        for (let id of ids) {
            record = { id, rootOp }
            await callHooks(table, CUD_OP_DELETE, CUD_OP_POST, record, session)
        }
    }

    /**
     * @typedef CudRecurseAncestor
     * @property {string} table Name of the table for this ancestor.
     * @property {object.<string,any>} record Record contents for this ancestor.
     */

    /**
     * Create, update and delete recursively.
     * @param {string} table The current table to work on.
     * @param {object} value The record as known from GraphQL.
     * @param {CudRecurseAncestor[]} ancestors The records created / referenced prior to this one. May be needed for complex / multi directional relationships.
     *                               The oldest ancestor will be LAST in this array.
     */
    async function cudRecurse(table, values, ancestors) {
        let tableType = allTypes[table]
        if (tableType === undefined) {
            throw `${table} is not known as a table`
        }

        if (!ancestors) {
            ancestors = []
        }

        // if (values === null || values === undefined) {
        //     debugger
        // }

        if (!Array.isArray(values)) {
            values = [values]
        }

        let batchDelete = values.filter(v => v.DELETE === true).map(v => v.id)
        if (batchDelete.length > 0) {
            await cascadeDelete(table, batchDelete)
            return []
        }
        // make sure no DELETE properties exist, as we'll otherwise attempt to treat this as a named field of the object, which will fail.
        values = values.map(({DELETE, ...rest}) => {
            if (DELETE) {
                log.d(`make sure no DELETE properties exist`)
            }
            return rest
        })

        const recordValueMap = []
        for(const value of values) {
            const record = {}
            for (const field in value) {
                if (field === 'id') {
                    continue
                }
                if (!(field in tableType)) {
                    throw `Could not find ${field} in ${table}`
                }

                if (field in tableType._meta) {
                    const relationship = tableType._meta[field]
                    // Outbound join
                    if (relationship.dir === FK_OUTBOUND) {
                        const fieldValue = value[field]
                        if (fieldValue === null || typeof (fieldValue) === 'bigint' || fieldValue instanceof SQLUpdateOp) {
                            record[field] = fieldValue
                        } else {
                            const peerTable = relationship.table
                            const peerTableType = allTypes[peerTable]
                            if (peerTableType._meta._isEnum) {
                                record[field] = peerTableType._enum.idByName[fieldValue]
                                if (record[field] === null || record[field] === undefined) {
                                    throw `Unknown enum value ${fieldValue} in ${peerTable}`
                                }
                            } else {
                                const result = await cudRecurse(peerTable, fieldValue, ancestors)
                                if (result.length > 0) {
                                    if (result[0].record?.id !== undefined) {
                                        record[field] = result[0].record.id
                                    }
                                }
                            }
                        }
                    }
                } else {
                    // Basic field, no recurse action
                    record[field] = value[field]
                }
            }
            recordValueMap.push({record, value})
        }


        for (let {record, value} of recordValueMap) {
            let keys = Object.keys(record)

            if (keys.length !== 0) {
                if ('id' in value && value.id !== undefined) {
                    // We have an ID, we know it's an update
                    if (!allowUpdate || !(table in modifiableTables)) {
                        throw `Not permitted to update ${table}`
                    }
                    // The hook may need to see the ID of the current record.
                    record.id = value.id
                    await callHooks(table, CUD_OP_UPDATE, CUD_OP_PRE, record, session)
                    delete record.id
                    let updated = await updateRecord(table, { id: value.id }, record, session)
                    if (!updated) {
                        throw `Could not update ${table}`
                    }
                    record.id = value.id
                    await callHooks(table, CUD_OP_UPDATE, CUD_OP_POST, record, session)
                } else {
                    // PGSQL upsert does not work with multiple unique constraints, but this is a small number of tables
                    let uniqueConstraints = allTypes[table]._meta['_uniqueConstraints']
                    // Fallback on old-style uniqueness check
                    if (uniqueConstraints.length !== 1 && checkExistingTables[table]) {
                        uniqueConstraints = []
                        let existing = await findExisting(table, record, session)
                        if (existing.rowCount === 0) {
                            if (!allowInsert || !(table in modifiableTables)) {
                                throw `Could not find existing match for ${table}`
                            } else {
                                // ok - will attempt to add below.
                            }
                        } else if (existing.rowCount == 1) {
                            record.id = existing.rows[0].id
                            if (populateIDs) {
                                value.id = record.id
                            }
                            if (record.NEEDS_UPDATE) {
                                delete record.NEEDS_UPDATE
                                await callHooks(table, CUD_OP_UPDATE, CUD_OP_PRE, record, session)
                                let updated = await updateRecord(table, { id: record.id }, record, session)
                                if (!updated) {
                                    throw `Could not update ${table}`
                                }
                                await callHooks(table, CUD_OP_UPDATE, CUD_OP_POST, record, session)
                            }
                        } else {
                            throw `Not enough parameters to determine a unique entry for ${table}`
                        }
                    }
                    if (!('id' in record)) {
                        await callHooks(table, CUD_OP_INSERT, CUD_OP_PRE, record, session)

                        for (const field in tableType._meta) {
                            if (field[0] === '_') {
                                continue
                            }
                            const relationship = tableType._meta[field]
                            if (relationship.dir === FK_OUTBOUND && !relationship.isNullable && (record[field] === null || record[field] === undefined)) {
                                let set = false
                                for (const ancestor of ancestors) {
                                    if (ancestor.table === relationship.table) {
                                        record[field] = ancestor.record[relationship.column]
                                        set = true
                                        break
                                    }
                                }
                                if (!set) {
                                    log.e('Expecting to fail with null. Hooks and ancestor checks did not satisfy:', table, relationship)
                                }
                            }
                        }

                        if (uniqueConstraints.length !== 1 && !checkExistingTables[table]) {
                            let insertResult = await insertRecord(table, record, session)
                            if (insertResult.affectedRows != 1) {
                                throw `Did not insert single expected record into ${table} (${insertResult.affectedRows})`
                            }
                            record.id = insertResult.id
                            if (populateIDs) {
                                value.id = record.id
                            }
                            await callHooks(table, CUD_OP_INSERT, CUD_OP_POST, record, session)
                        } else {
                            let upsertResult = await upsertRecord(table, record, uniqueConstraints, session)
                            if (upsertResult.affectedRows != 1) {
                                throw `Did not upsert single expected record in ${table} (${upsertResult.affectedRows})`
                            }
                            record.id = upsertResult.id
                            if (populateIDs) {
                                value.id = record.id
                            }

                            for (let upsertRow of upsertResult.rows) {
                                if (upsertRow.operation === OPERATION_INSERT) {
                                    await callHooks(table, CUD_OP_INSERT, CUD_OP_POST, record, session)
                                } else {
                                    await callHooks(table, CUD_OP_UPDATE, CUD_OP_POST, record, session)
                                }
                            }
                        }
                    }
                }
            }

            if (!('id' in record)) {
                record.id = value.id
            }

            await callHooks(table, CUD_OP_ALL, CUD_OP_PRE_CHILDREN, record, session)
            for (let field in value) {
                if (field in tableType._meta) {
                    let relationship = tableType._meta[field]
                    // Inbound relation is basically an array
                    if (relationship.dir === FK_INBOUND) {
                        let children = []
                        for (let child of value[field]) {
                            child[relationship.column] = record.id
                            if ('id' in child) {
                                let expectedChild = { id: child.id, [relationship.column]: record.id }
                                let existing = await findExisting(relationship.table, expectedChild, session)
                                if (existing.length === 0) {
                                    log.w('Ignoring attempt to manipulate relationship that does not exist', relationship.table, JSON.stringify(expectedChild))
                                    continue
                                }
                            }
                            children.push(child)
                        }

                        // Batch delete
                        const [deletes, writes] = partition(children, v => v.DELETE === true)
                        await cudRecurse(relationship.table, deletes, [{ table, record }, ...ancestors])

                        // Determine the other end of the relation
                        const nestedRelation = allTypes[relationship.table]
                        let uniqueConstraints = allTypes[relationship.table]._meta['_uniqueConstraints']
                        let otherRecords = []
                        for(let other in nestedRelation._meta) {
                            if (other[0] === '_') {
                                continue
                            }
                            let otherTable = nestedRelation._meta[other].table
                            let otherDir = nestedRelation._meta[other].dir
                            let otherMeta = allTypes[otherTable]._meta

                            if (otherMeta._isEnum) {
                                for(let x = 0; x < writes.length; x++) {
                                    if (writes[x][other] !== undefined && typeof (writes[x][other]) !== 'bigint') {
                                        writes[x][other] = allTypes[otherTable]._enum.idByName[writes[x][other]]
                                    }
                                }
                                continue
                            }

                            if (otherTable !== table && otherDir === FK_OUTBOUND && other !== 'addedBy') {
                                // Found the other side
                                let otherChildren = writes.map((write) => {
                                    if (typeof (write[other]) === 'bigint') {
                                        return {id: write[other]}
                                    } else {
                                        return write[other]
                                    }
                                })


                                let otherResult = await cudRecurse(otherTable, otherChildren, [{ table, record }, ...ancestors])
                                otherRecords[other] = otherResult.map(result => result.record)

                            } else if (otherTable !== table) {
                                // Check we haven't already
                                if (record[field] === undefined) {
                                    let recurseResult = await cudRecurse(relationship.table, value[field], [{ table, record }, ...ancestors])
                                    record[field] = recurseResult.map(({record}) => record)
                                    value[field] = recurseResult.map(({value}) => value)
                                }
                            }
                        }

                        let relationMeta = allTypes[relationship.table]._meta
                        let ignoreFields = []
                        for (let relationField in relationMeta) {
                            if (relationField[0] === '_') {
                                continue
                            }
                            if (relationMeta[relationField].dir === FK_INBOUND) {
                                ignoreFields.push(relationField)
                            }
                        }

                        let otherLinks = []
                        for (let i = 0; i < writes.length; i++) {
                            let write = {...writes[i]}

                            let otherKeys = Object.keys(otherRecords)
                            for (let key of otherKeys) {
                                write[key] = otherRecords[key][i].id
                            }
                            for (let ignoreField of ignoreFields) {
                                delete write[ignoreField]
                            }
                            otherLinks.push(write)
                        }

                        if (otherLinks.length === 0 || record[field] !== undefined) {
                            continue
                        }

                        let upsertResult = await upsertRecord(relationship.table, otherLinks, uniqueConstraints, session)
                        let upsertRecords = []
                        for (let upsertRow of upsertResult.rows) {
                            let {operation, ...rest} = upsertRow
                            log.d(`operation is ${operation}`)
                            upsertRecords.push(rest)
                            if (upsertRow.operation === OPERATION_INSERT) {
                                await callHooks(relationship.table, CUD_OP_INSERT, CUD_OP_POST, {id: upsertRow.id}, session)
                            } else {
                                await callHooks(relationship.table, CUD_OP_UPDATE, CUD_OP_POST, {id: upsertRow.id}, session)
                            }
                        }
                        record[field] = otherLinks
                        if (populateIDs) {
                            let valueUpdate = []
                            for (let i = 0; i < upsertRecords.length; i++) {
                                let written = {...upsertRecords[i]}
                                let otherKeys = Object.keys(otherRecords)
                                for (let key of otherKeys) {
                                    written[key] = otherRecords[key][i].id
                                }
                                valueUpdate.push(written)
                            }
                            value[field] = valueUpdate
                        }
                    }

                }
            }
            await callHooks(table, CUD_OP_ALL, CUD_OP_POST_CHILDREN, record, session)
        }
        values = recordValueMap.map(result => result.value)
        return recordValueMap
    }
}
