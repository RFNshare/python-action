/**
 * @file netmask.js - 0.0.1045 - ea4595bfd3488684d225574ed7d4c198074d49ba
 * 
 * @copyright Copyright (C) 2016-2023, ISARA Corporation, All Rights Reserved.
 * 
 * @license The code and other content set out herein is not in the public
 * domain, is considered a trade secret and is confidential to ISARA
 * Corporation. Use, reproduction or distribution, in whole or in part, of such
 * code or other content is strictly prohibited except by express written
 * permission of ISARA Corporation. Please contact ISARA Corporation at
 * info@isara.com for more information.
 */



const {
    Netmask,
} = require('../dbObjects')
const {
    dumpObjectTimingStats,
    initDbConnection,
    insertObject,
    bulkInsertRecords,
    resetObjectTimingStats
} = require('../dbHelpers')

var log = require('../../util/log')(module)
exports.insertNetmasks = async function (session, config, data) {
    let netmaskArray = []
    const emptyNetmasks = config.numEmpty || 20
    for (var i = 0; i < emptyNetmasks; ++i) {
        let netmask = new Netmask()
        netmaskArray.push(netmask.nameValues)
    }
    config.named && config.named.map((row) => {
        //let netmask = new Netmask(row)
        netmaskArray.push(row)
    })
    const result = await bulkInsertRecords('Netmask', netmaskArray, session)
    if (!data.netmasks) data.netmasks = []
    log.log(result)
    data.netmasks = [...data.netmasks, ...result.rows]
}


