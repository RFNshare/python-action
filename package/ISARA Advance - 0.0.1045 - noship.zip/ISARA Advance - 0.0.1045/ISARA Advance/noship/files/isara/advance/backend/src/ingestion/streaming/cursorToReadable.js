/**
 * @file cursorToReadable.js - 0.0.1045 - ea4595bfd3488684d225574ed7d4c198074d49ba
 * 
 * @copyright Copyright (C) 2016-2023, ISARA Corporation, All Rights Reserved.
 * 
 * @license The code and other content set out herein is not in the public
 * domain, is considered a trade secret and is confidential to ISARA
 * Corporation. Use, reproduction or distribution, in whole or in part, of such
 * code or other content is strictly prohibited except by express written
 * permission of ISARA Corporation. Please contact ISARA Corporation at
 * info@isara.com for more information.
 */

const Cursor = require('pg-cursor')
const { Readable } = require('stream')

const log = require('../../util/log')(module)

const FAILED_ROWS_TO_LOG = Infinity
const FAILED_ROWS_TO_ALLOW = 0

/**
 * Class that wraps Cursor reads into a Readable.
 */
class CursorToReadable extends Readable {
    /**
     * This records the number of rows that did not correctly translate from the cursor to the readable.
     */
    #failedRowCount = 0

    /**
     * This records the number of remaining failed rows to log before going silent.
     */
    #failedRowsToLog = FAILED_ROWS_TO_LOG

    /**
     * This records the number of remaining failures before throwing an exception (ie: not continuing)
     */
    #failedRowsToAllow = FAILED_ROWS_TO_ALLOW

    /**
     * This records the total number of records that have been read by this cursor.
     * @type {Number}
     */
    #totalRead = 0

    /**
     * This is the postgres cursor the data is reading from.
     * @type {Cursor}
     */
    #cursor = null

    /**
     * This is the maximum number of rows that the cursor should be allowed to traverse, before the stream is closed.
     * (The cursor will be left operational)
     * @type {Number}
     */
    #maxRows

    /**
     * This is the number of rows that should be read from the cursor at a time. This number will directly impact
     * memory usage - arrays this big will come back from the cursor.
     * @type {Number}
     */
    #chunkSize

    /**
     * This is the regular (NON async) function that will convert the cursor/database object to the data to stream.
     */
    #converter = null

    /**
     * This will hold an array of up to #chunkSize records for streaming.
     */
    #buffer

    /**
     * This is the offset of the next valid record to read from #buffer.
     */
    #bufferOffset

    /**
     * Records if the cursor has finished; ie: the query stopped returning rows.
     */
    #cursorFinished = false

    /**
     * Records if any data has been streamed yet.
     */
    #any = false

    /**
     * CursorToReadable
     * @param {Object} params 
     * @property {Cursor} params.cursor The postgres cursor to stream from
     * @property {function} params.converter The function to convert the postgres data to typesense data
     * @property {[Number]} params.maxRows The maximum number of rows to stream before done. (Cursor is not closed)
     * @property {[Number]} params.chunkSize The maximum number of records to read at at time.
     */
    constructor({cursor, converter, maxRows = 100000, chunkSize = 1000}) {
        super()
        if (cursor?.constructor !== Cursor) {
            throw new Error('Expected cursor')
        }
        if (typeof converter !== 'function') {
            throw new Error('Expected converter function')
        }

        this.#cursor = cursor
        this.#maxRows = maxRows
        this.#chunkSize = chunkSize
        this.#converter = converter
        this.#buffer = []
        this.#bufferOffset = -1 // initial
    }

    _read(/*max*/) {
        // eslint-disable-next-line no-constant-condition
        while(true) {
            // Check if need to read again.
            if (this.#bufferOffset == -1 || (this.#bufferOffset >= this.#buffer.length)) {
                if (this.#totalRead > this.#maxRows) {
                    // Finish the stream.
                    this.push(null)
                    return
                }
                const toRead = Math.min(this.#maxRows - this.#totalRead, this.#chunkSize)
                if (toRead <= 0) {
                    // Finish the stream.
                    this.push(null)
                    return
                }
                this.#cursor.read(toRead, (err,rows) => {
                    if (err) {
                        log.e('Error reading from cursor',err)
                        this.emit('error',err)
                        return
                    }

                    if (rows.length === 0) {
                        this.#cursorFinished = true
                        this.push(null)
                        return
                    }

                    this.#totalRead += rows.length

                    this.#buffer = rows
                    this.#bufferOffset = 0
                    this._read()
                })
                return
            }

            let toPush = this.#buffer[this.#bufferOffset]
            const toLog = toPush
            this.#bufferOffset++

            try {
                if (this.#converter) {
                    toPush = this.#converter(toPush, null, null)
                }
                if (typeof toPush !== 'string') {
                    toPush = JSON.stringify(toPush)
                }
                this.push(`${this.#any ? '\n' : ''}${toPush}`)
                this.#any = true
                return
            } catch (conversionError) {
                this.#failedRowCount++
                if (this.#failedRowsToLog > 0) {
                    this.#failedRowsToLog++
                    log.e('Failed to convert row',conversionError,toLog)
                }
                if (this.#failedRowsToAllow > 0) {
                    this.#failedRowsToAllow--
                } else {
                    this.emit('error', conversionError)
                    return
                }
            }
        }
    }

    /**
     * Check if the cursor finished. ie: if the query stopped returning rows.
     * @returns {Boolean}
     */
    get cursorFinished() { 
        return this.#cursorFinished
    }

    /**
     * Report the number of rows that failed to convert.
     */
    get failedRowCount() {
        return this.#failedRowCount
    }

    /**
     * Report the number of records that have been read from the cursor by this stream so far. (Not the total that have been read from the cursor over all time)
     * @returns {Number}
     */
    get cusorRead() {
        return this.#totalRead
    }
}

exports.CursorToReadable = CursorToReadable
