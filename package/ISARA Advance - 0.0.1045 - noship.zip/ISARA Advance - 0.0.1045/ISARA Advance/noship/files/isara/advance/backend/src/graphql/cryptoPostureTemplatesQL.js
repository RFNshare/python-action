/**
 * @file cryptoPostureTemplatesQL.js - 0.0.1045 - ea4595bfd3488684d225574ed7d4c198074d49ba
 * 
 * @copyright Copyright (C) 2016-2023, ISARA Corporation, All Rights Reserved.
 * 
 * @license The code and other content set out herein is not in the public
 * domain, is considered a trade secret and is confidential to ISARA
 * Corporation. Use, reproduction or distribution, in whole or in part, of such
 * code or other content is strictly prohibited except by express written
 * permission of ISARA Corporation. Please contact ISARA Corporation at
 * info@isara.com for more information.
 */

/**
 * This module contains crypto posture template (CPT) focused queries.
 * @module graphql/cryptoPostureTemplatesQL
 */

var { filterQuery } = require('./filterQL')
const { Session } = require('../isaraql/session')
const { getSort, roles, populateAddedBy } = require('./commonQL')
const {
    createUpdateDelete,
    registerHook,
    CUD_OP_INSERT,
    CUD_OP_PRE,
} = require('../isaraql/cud')
const {
    getCptSystemDefault,
    setCptSystemDefault,
} = require('../util/cptHelpers')
const { updateCryptoScoresForTemplate } = require('../util/scoreHelpers')

const log = require('../util/log')(module)

/**
 * This dictionary will hold the SQL fragments needed by `fetch.js` to build a table spanning sort query.
 */
const sortDictionary = {}

async function cptGlobalDefaultId() {
    return (await getCptSystemDefault()).value
}

async function isSystemCPT(id, session) {
    let result = await session.query('SELECT system FROM "advance"."CryptoPostureTemplate" WHERE "id" = (?)', [id])
    return result.rows[0]?.system
}

exports.isSystemCPT = isSystemCPT

async function cptQuery(fields, request, graphQLState) {
    return cptFilterQuery(fields, request, graphQLState, [fields.id])
}

/**
 * Main query to see CPTs.
 * @param {Object} fields Fields from GraphQL Query
 * @param {Object} request GraphQL request
 * @param {Object} graphQLState GraphQL State
 * @param {number[]} [ids] Set of IDs to run query for (instead of filter)
 */

async function cptFilterQuery (fields, request, graphQLState, ids) {
    if (!('paging' in fields)) {
        fields.paging = { offset: 0n, limit: 5n }
    }

    var wpcs = { CryptoPostureTemplate: { paging: fields.paging } }
    if (ids && ids.length !== 0) {
        wpcs.CryptoPostureTemplate.where = { in: { column: 'id', value: ids } }
    }
    if ('sorting' in fields) {
        wpcs.CryptoPostureTemplate.sort = await getSort(
            sortDictionary,
            fields.sorting
        )
    }

    if ('scoreSorting' in fields) {
        wpcs.CryptoScore = {}
        wpcs.CryptoScore.sort =  await getSort(
            sortDictionary,
            fields.scoreSorting
        )
    }

    return filterQuery(
        'CryptoPostureTemplate',
        'cryptoPostureTemplates',
        fields.filter,
        graphQLState,
        wpcs,
        fields.asOf,
        null,
        makeMetaAndSummaries
    )
}

exports.getCptFilterQuery = async function(fields, request, graphQLState, ids) {
    return await cptFilterQuery (fields, request, graphQLState, ids)
}

async function makeMetaAndSummaries(graphQLResult, wanted/*, session*/) {
    if (wanted.meta) {
        graphQLResult.meta = []
        var globalDefault = await getCptSystemDefault()
        if (!globalDefault || !globalDefault.key) {
            throw 'No global default template configured'
        }
        graphQLResult.meta.push({
            key: globalDefault.key,
            value: globalDefault.value,
            name: globalDefault.key,
        })
    }
}

/**
 * Mutation to kick off a score recalculation
 * @param {*} fields
 * @param {*} request
 * @param {*} graphQLState
 */
async function cptRecalculateScores(fields/*, request, graphQLState*/) {
    const cptId = fields.cryptoPostureTemplateId
    const session = new Session()

    // Kick-off asynchronously
    updateCryptoScoresForTemplate(session, cptId)

    return cptId
}

/**
 * Mutation for updating the Global Default CPT
 * @param {Object} fields
 * @param {Object} request
 * @param {Object} graphQLState
 */
async function cptGlobalDefaultMutation(fields/*, request, graphQLState*/) {
    const cptId = fields.cryptoPostureTemplateId
    return await setCptSystemDefault(cptId)
}

/**
 * This function will be called before a new Template is inserted.
 * @param {CUDHook} params
 */
async function preInsertCpt(params) {
    populateAddedBy(params)
}

/**
 * Mutation for creating/updating/deleting CPTs and their attributes.
 * @param {Object} fields
 * @param {Object} request
 * @param {Object} graphQLState
 */
async function cptMutation(fields, request, graphQLState) {
    var cryptoPostureTemplates = fields.cryptoPostureTemplates
    var parentTemplateId = fields.parentTemplateId
    var config = {
        allowDelete: true,
        allowInsert: true,
        allowUpdate: true,
        modifiableTables: {
            CryptoPostureTemplate: true,
            CryptoScore: !!parentTemplateId,
        },
        deletableTables: {
            CryptoPostureTemplate: true,
            CryptoScore: true,
            CryptoPrimitiveScore: true,
            ProtocolVariantScore: true,
            DeviceScore: true,
            ConnectionScore: true
        },
    }

    var ids = []
    const session = new Session()

    let requiredFields = ['name', 'description']

    for(let cryptoPostureTemplate of cryptoPostureTemplates) {
        const {id, DELETE} = cryptoPostureTemplate

        let isSystem = await isSystemCPT(id, session)

        if(isSystem){
            throw 'ISARA CPT may not be modified'
        }

        if (!DELETE && (requiredFields.some((field => !cryptoPostureTemplate[field]?.trim())))) {
            throw `Unable to process CPT with missing required fields: ${requiredFields.filter(field => cryptoPostureTemplate[field]?.trim() === '' || cryptoPostureTemplate[field] === undefined).join(', ')}`
        }
    }

    if (parentTemplateId) {
        await session.asTransaction(async function () {
            // Clone
            ids = await createUpdateDelete(
                'CryptoPostureTemplate',
                [cryptoPostureTemplates[0]],
                config
            )
            if (ids.length < 1) {
                log.e('Failed to create new CPT')
                throw 'Failed to create new CPT'
            }
            // Select all scores from parent
            const newCptId = ids[0]
            var scoresToClone = (
                await session.query(
                    `select
                cs."id",
                cs."name",
                cs."friendlyName",
                cs."shortName",
                cs.score,
                cs."cryptoScoreCoarse",
                cs."isDefault",
                string_agg(distinct csp."cryptoPrimitive"::text, ',') as linkedPrimitives,
                string_agg(distinct pvs."protocolVariant"::text, ',') as linkedProtocols
            from "CryptoScore" cs
            left join "CryptoPrimitiveScore" csp on csp."cryptoScore" = cs.id
            left join "ProtocolVariantScore" pvs on pvs."cryptoScore" = cs.id
            where cs."cryptoPostureTemplate" = ?
            group by cs.id
            order by cs.id`,
                    [parentTemplateId]
                )
            ).rows

            for (let i = 0; i < scoresToClone.length; i++) {
                const {
                    name,
                    friendlyName,
                    shortName,
                    score,
                    cryptoScoreCoarse,
                    isDefault,
                    linkedprimitives,
                    linkedprotocols,
                } = scoresToClone[i]
                // Insert the new score
                const scoreId = (
                    await createUpdateDelete(
                        'CryptoScore',
                        [
                            {
                                name,
                                friendlyName,
                                shortName,
                                score,
                                isDefault,
                                cryptoScoreCoarse,
                                cryptoPostureTemplate: newCptId,
                            },
                        ],
                        config
                    )
                )[0]

                // Insert Linked Primitives
                if (linkedprimitives) {
                    const primitivesArray = linkedprimitives.split(',')
                    for (let k = 0; k < primitivesArray.length; k++) {
                        await session.query('INSERT INTO "CryptoPrimitiveScore" ("cryptoScore", "cryptoPrimitive") values (?,?)', [scoreId, Number(primitivesArray[k])])
                    }
                }

                // Insert Linked Protocols
                if (linkedprotocols) {
                    const protocolsArray = linkedprotocols.split(',')
                    for (let k = 0; k < protocolsArray.length; k++) {
                        await session.query('INSERT INTO "ProtocolVariantScore" ("cryptoScore", "protocolVariant") values (?,?)', [scoreId, Number(protocolsArray[k])])
                    }
                }
            }
        })
        return cptFilterQuery(fields, request, graphQLState, ids)
    } else {
    // Update
    // Remove any "new" templates, which would be parentless
        var updates = cryptoPostureTemplates.filter((cpt) => !!cpt.id)
        ids = await createUpdateDelete('CryptoPostureTemplate', updates, config)
        return cptFilterQuery(fields, request, graphQLState, ids)
    }
}

/**
 * Builds the sorting dictionary showing `fetch` how to sort for named parameters.
 */
function buildSortDictionary() {
    // All the simple sorts that use a field which exists ON the Template table.
    sortDictionary['ADDED_DATE'] = `"addedDate" %DIR%`
    sortDictionary['NAME'] = `NULLIF("name", '') %DIR% %NULLS%`
    sortDictionary['SYSTEM'] = `"system" %DIR%`
    sortDictionary['SCORE'] = `"score" %DIR%`
}

function initialise() {
    registerHook('CryptoPostureTemplate', CUD_OP_INSERT, CUD_OP_PRE, preInsertCpt)

    buildSortDictionary()
}

exports.graphQL = {
    types: `
        enum SortableCryptoPostureTemplateFields {
            ADDED_DATE
            NAME
            SYSTEM
        }

        enum SortableCptCryptoScoreFields {
            SCORE
        }

        type FilteredCryptoPostureTemplates {
            paging: Paging!
            cryptoPostureTemplates: [CryptoPostureTemplate!]!
            meta: [MetaTag!]!
        }

        input CryptoPostureTemplateSortingInput {
            field: SortableCryptoPostureTemplateFields!,
            direction: SortDirection!,
        }

        input CptCryptoScoreSortingInput {
          field: SortableCptCryptoScoreFields!,
            direction: SortDirection!,
        }
    `,
    queries: `
        cryptoPostureTemplateGlobalDefault: BigInt

        cryptoPostureTemplateById(
            id: BigInt!
            paging: PagingInput
            scoreSorting: CptCryptoScoreSortingInput
        ): FilteredCryptoPostureTemplates!

        filteredCryptoPostureTemplates(
            filter: String
            paging: PagingInput
            sorting: CryptoPostureTemplateSortingInput
            scoreSorting: CptCryptoScoreSortingInput
        ) : FilteredCryptoPostureTemplates!
    `,
    mutations: `
        cryptoPostureTemplateUpdate(
            parentTemplateId: BigInt
            cryptoPostureTemplates: [CryptoPostureTemplateInput]!
        ): FilteredCryptoPostureTemplates

        cryptoPostureGlobalDefaultUpdate(
            cryptoPostureTemplateId: BigInt!
        ): BigInt

        recalculateScores(
          cryptoPostureTemplateId: BigInt
        ): BigInt
    `,
    root: {
        cryptoPostureTemplateGlobalDefault: cptGlobalDefaultId,
        cryptoPostureTemplateById: cptQuery,
        filteredCryptoPostureTemplates: cptFilterQuery,
        cryptoPostureTemplateUpdate: cptMutation,
        cryptoPostureGlobalDefaultUpdate: cptGlobalDefaultMutation,
        recalculateScores: cptRecalculateScores
    },
    restrictions: {
        cryptoPostureTemplateGlobalDefault: [roles.AUTHENTICATED],
        cryptoPostureTemplateById: [roles.AUTHENTICATED],
        filteredCryptoPostureTemplates: [roles.AUTHENTICATED],
        cryptoPostureTemplateUpdate: [roles.AUTHENTICATED],
        cryptoPostureGlobalDefaultUpdate: [roles.ADMIN],
        recalculateScores: [roles.ADMIN],
    },
    initialise,
}
