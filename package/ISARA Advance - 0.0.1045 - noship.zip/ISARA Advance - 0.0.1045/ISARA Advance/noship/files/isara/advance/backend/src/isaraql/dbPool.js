/**
 * @file dbPool.js - 0.0.1045 - ea4595bfd3488684d225574ed7d4c198074d49ba
 * 
 * @copyright Copyright (C) 2016-2023, ISARA Corporation, All Rights Reserved.
 * 
 * @license The code and other content set out herein is not in the public
 * domain, is considered a trade secret and is confidential to ISARA
 * Corporation. Use, reproduction or distribution, in whole or in part, of such
 * code or other content is strictly prohibited except by express written
 * permission of ISARA Corporation. Please contact ISARA Corporation at
 * info@isara.com for more information.
 */

/**
 * A module that exposes a function to connect to the DB
 * @module isaraql/dbPool
 **/

const { Pool } = require('pg')
var LazySingleton = require('../util/lazySingleton')
const systemPreferences = require('../util/systemPreferences')
const log = require('../util/log')(module)
const { loadCACertificates } = require('../util/certificates')

/**
 * Create a connection pool.
 * @private
 * @return The connection pool.
 */
async function createPool() {
    const toUse = await exports.getDatabaseConfiguration()
    const copyToLog = JSON.parse(JSON.stringify(toUse))
    delete copyToLog.password
    delete copyToLog?.ssl?.ca?.data
    log.log('Using database configuration', JSON.stringify(copyToLog))

    var toReturn = await new Pool(toUse)
    toReturn.on('error', (e) => {
        log.e('Error in DB pool', e)
        pool.purge()
    })
    delete toUse.password
    toReturn.configuration = toUse
    return toReturn
}

/**
 * When initialised, will contain the DB pool.
 * @private
 * @type LazySingleton
 */
var pool = new LazySingleton(createPool)

/**
 * Get the DB pool.
 * @return The pool.
 * @throws An error if the connection could not be made.
 */
exports.getPool = async function () {
    return await pool.get()
}

/**
 * Get the preferred database configuration. It may be from either system preferences, environment variables or defaults.
 * @returns The database configuration, from either system preferences, environment variables or defaults.
 */
exports.getDatabaseConfiguration = async (applicationName) => {
    const preferences = await systemPreferences()
    let toUse = preferences?.db?.coreDB
    if (!toUse) {
        let caCerts = await loadCACertificates()
        toUse = {
            host: process.env.DATABASE_HOST ?? '127.0.0.1',
            user: process.env.DATABASE_USER ?? 'postgres',
            password: process.env.DATABASE_PASSWORD ?? 'password',
            port: parseInt(process.env.DATABASE_PORT ?? 5432),
            idleTimeoutMillis: parseInt(process.env.DATABASE_IDLE_TIMEOUT ?? 300000),
            max: 100,
            database: process.env.DATABASE_NAME ?? 'advance',
            ssl: {
                ca: caCerts,
            },
        }
    } else {
        toUse = JSON.parse(JSON.stringify(toUse))
    }

    if (!toUse.application_name) {
        toUse.application_name = applicationName ?? 'ISARA Advance'
    }
    return toUse
}
