/**
 * @file provisionDB.js - 0.0.1045 - ea4595bfd3488684d225574ed7d4c198074d49ba
 * 
 * @copyright Copyright (C) 2016-2023, ISARA Corporation, All Rights Reserved.
 * 
 * @license The code and other content set out herein is not in the public
 * domain, is considered a trade secret and is confidential to ISARA
 * Corporation. Use, reproduction or distribution, in whole or in part, of such
 * code or other content is strictly prohibited except by express written
 * permission of ISARA Corporation. Please contact ISARA Corporation at
 * info@isara.com for more information.
 */

const fs = require('fs')
const log = require('../util/log')(module)

const { Client } = require('pg')
const dbPool = require('../isaraql/dbPool')

const {
    Session
} = require('../isaraql/session')
const { getPool } = require('../isaraql/dbPool')
const { protocolVariant, cryptoPrimitives } = require('./cryptoPrimitives')
const { parseCipherSuite } = require('../util/cipherSuiteUtils')

const PRODUCTION_LOG_FILE_NAME = '/var/log/isara/advance.provision.log'

let isaraCPTID = -1

/**
 * Utility function for populating CipherSuiteCryptoPrimitive with links between each CipherSuite
 * and the crypto primitives included in it.
 */
async function populateCipherSuiteCryptoPrimitive(session) {
    try {
        session = session || await getPool()
        var cipherSuiteList = await session.query(`SELECT id,name FROM advance."CipherSuite"`)

        for (var cipherSuiteResult of cipherSuiteList.rows) {
            var cipherSuiteInfo = parseCipherSuite(cipherSuiteResult.name)

            if ('PLAIN_TEXT' !== cipherSuiteInfo.protocol) {
                var allPrimitives = cipherSuiteInfo.kemPrimitives.concat(cipherSuiteInfo.sigPrimitives)
                    .concat(cipherSuiteInfo.encPrimitives)
                    .concat(cipherSuiteInfo.modeOfOperation)
                    .concat(cipherSuiteInfo.hashPrimitives)

                for (var primitive of allPrimitives) {
                    await session.query(
                        `INSERT INTO advance."CipherSuiteCryptoPrimitive" ("cipherSuite", "cryptoPrimitive")
                        VALUES ($1,(SELECT id FROM advance."CryptoPrimitive" WHERE name= $2))`, [cipherSuiteResult.id, primitive])
                }
            }
        }
    } catch (e) {
        throw `Unable to populate CipherSuiteCryptoPrimitive: ${JSON.stringify(e)}`
        
    }
    /** Add ciphersuiteScore table population **/
    
    await session.query(`INSERT INTO "advance"."CipherSuiteScore" ("cipherSuite", "cryptoScore") select cs.name, min(cscore.score)
    from "advance"."CipherSuite" as cs, "advance"."CipherSuiteCryptoPrimitive" as cscp,
"advance"."CryptoPrimitiveScore" as cpscore,
"advance"."CryptoScore" as cscore
where 
cs.id=cscp."cipherSuite" and
cscp."cryptoPrimitive" = cpscore."cryptoPrimitive" and
cpscore."cryptoScore" = cscore.id 
group by 1 `)
}

async function main() {
    log.logFile = PRODUCTION_LOG_FILE_NAME

    const argv = require('minimist')(process.argv.slice(2))

    const forceDestruction = argv.force ?? false

    let dbConfig = await dbPool.getDatabaseConfiguration()

    // for provisioning the database itself, we need to connect to the default postgres database, otherwise we won't be able to drop
    // or reprovision our own.
    let dbName = dbConfig.database
    dbConfig.database = 'postgres'

    let client = await new Client(dbConfig)

    let schema = fs.readFileSync(__dirname + '/DataModel.sql').toString()
    let defaultData = fs.readFileSync(__dirname + '/DefaultData.sql').toString()

    await client.connect()

    let databaseExistsResult = await client.query(`SELECT * FROM pg_database WHERE datname = $1`, [dbName])
    if (databaseExistsResult.rowCount !== 0) {
        log.log(`Database ${dbName} already exists`)
        if (!forceDestruction) {
            throw new Error(`Refusing to provision existing database. Use --force to DESTROY existing database`)
        }
        log.log('Provisioning existing database')
    }

    await client.query(`DROP DATABASE IF EXISTS "${dbName}"`)
    await client.query(`CREATE DATABASE "${dbName}" WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE = 'en_US.utf-8'`)
    client.end()

    let session = new Session()
    await session.asTransaction(async () => {
        log.log('Creating schema...')
        await session.query(schema)
        await session.query(`ALTER DATABASE "${dbName}" SET search_path TO advance,public`)

        // TODO: 1981 - Cleanup/Redesign Database Timetravel Capabilities
        // await session.query('CREATE SCHEMA "history"')
        // create log procedure
        // await session.query(logProcedure)
        // await session.query('CREATE SCHEMA "timetravel"')

        // special schema for flat cache tables and other non-versioned items.
        // await session.query('CREATE SCHEMA "flatcache"')

        // let result = await session.query("select relname AS table FROM pg_catalog.pg_class c WHERE c.relkind IN ('r','p','s') AND c.relnamespace = (select oid FROM pg_catalog.pg_namespace WHERE nspname='advance')")
        // for (let row of result.rows) {
        //     let table = row.table
        //     log.log(`Provisioning table ${table}...`)
        //     await session.query(`CREATE TABLE history."${table}" (LIKE advance."${table}", _validrange tstzrange)`)
        //     await session.query(`ALTER TABLE history."${table}" ADD CONSTRAINT "${table}_exclusion" EXCLUDE USING gist `
        //         + `(id WITH =, _validrange with &&)`)
        //     await session.query(`
        //         CREATE TRIGGER "${table}_history"
        //         AFTER INSERT OR UPDATE OR DELETE
        //         ON advance."${table}" FOR EACH ROW
        //         EXECUTE PROCEDURE history.logtable()
        //     `)
        //     let columns = (await session.query("select column_name, coalesce(col_description(concat('\"', table_schema, '\".\"', table_name, '\"')::regClass,"
        //         + " ordinal_position), '') as comment from information_schema.columns where table_name = ? AND table_schema='advance'", [table]))
        //     await session.query(`
        //         CREATE VIEW timetravel."${table}" AS
        //         SELECT "${columns.rows.map(x => x.column_name).join('", "')}"
        //         FROM history."${table}"
        //         WHERE _validrange @>
        //             current_setting('history.timestamp'::text)::timestamptz
        //     `)
        //     for (let column of columns.rows) {
        //         let index = column.comment.match(/@provision\.index\.?(?<type>[a-zA-Z]+)?/)
        //         if (index !== null) {
        //             let type = index.groups.type ?? 'btree'

        //             if (!supportedIndexTypes.includes(type)) {
        //                 throw `Unsupported index type ${index.type} on ${table}.${column.column_name}`
        //             }

        //             log.log(`Adding ${type} index on '${column.column_name}...`)
        //             await session.query(`CREATE INDEX ON advance."${table}" USING ${type}("${column.column_name}")`)
        //             await session.query(`CREATE INDEX ON history."${table}" USING ${type}("${column.column_name}")`)
        //         }
        //     }
        // }

        log.log('Loading default data...')
        await session.query(defaultData)

        let result = await session.query('SELECT id FROM "advance"."CryptoPostureTemplate" WHERE name=?', ['ISARA'])
        isaraCPTID = result.rows[0].id
        await populateCryptoPrimitives(session)
        await populateProtocolVariant(session)
        log.log('Adding cipher suite primitives...')
        await populateCipherSuiteCryptoPrimitive(session)
    })

    let pool = await getPool()
    await pool.end()
}

async function populateProtocolVariant(session) {
    for (let variant of Object.keys(protocolVariant)) {
        log.log(`Adding variant: ${variant}...`)
        let primitiveDetails = protocolVariant[variant]
        let baseScore = primitiveDetails.baseScore

        let protocolResult = await session.query('SELECT id FROM "advance"."Protocol" WHERE "name"=?', [variant])
        let protocol = protocolResult.rows[0].id
        if (!primitiveDetails.primitives) {
            let result = await session.query(
                `INSERT INTO advance."ProtocolVariant" (name, "codePoint", "protocol")`
                + ` VALUES (?,?,?) RETURNING id`,
                [primitiveDetails.description, primitiveDetails.codePoint, protocol])
            await session.query(`INSERT INTO advance."ProtocolVariantScore" ("protocolVariant", "cryptoScore")`
                + ` VALUES (?, (SELECT id FROM advance."CryptoScore" where score=? AND "cryptoPostureTemplate"=?))`,
            [result.rows[0].id, baseScore, isaraCPTID])
        }


        if ('primitives' in primitiveDetails) {
            log.log(`\tAdding ${primitiveDetails.primitives.length} variants...`)
            for (let primitive of primitiveDetails.primitives) {
                let result = await session.query(`INSERT INTO advance."ProtocolVariant" (name, "codePoint", "protocol")`
                    + ` VALUES (?,?,?) RETURNING id`,
                [primitive.name, primitive.codePoint, protocol])
                await session.query(`INSERT INTO advance."ProtocolVariantScore" ("protocolVariant", "cryptoScore")`
                    + ` VALUES (?, (SELECT id FROM advance."CryptoScore" where score=? AND "cryptoPostureTemplate"=?))`,
                [result.rows[0].id, primitive.score, isaraCPTID])
            }
        }
    }
}

/**
 * Builds up the CryptoAlgorithm and CryptoPrimitive tables. Due to the complexity and interlinked nature, of the data,
 * these are not done via DefaultData.
 *
 * @param {*} session The transactional database session to use for population. Assumes that the schema has already been populated.
 */
async function populateCryptoPrimitives(session) {
    for (let algorithm of Object.keys(cryptoPrimitives)) {
        log.log(`Adding algorithm: ${algorithm}...`)
        let result = await session.query('INSERT INTO advance."CryptoAlgorithm" (name) VALUES (?) RETURNING id', [algorithm])
        let algorithmID = result.rows[0].id
        let algorithmDetails = cryptoPrimitives[algorithm]
        // add "unknown" baseline primitive for algorithm.
        let baseScore = algorithmDetails.baseScore
        let oid
        let purposeResult = await session.query('SELECT id FROM "advance"."CryptoPrimitivePurpose" WHERE "name"=?', [algorithmDetails.purpose])
        let purposeId = purposeResult.rows[0].id
        if ('oid' in algorithmDetails) {
            oid = algorithmDetails.oid
        }
        if (algorithmDetails.hasDefault === true || !algorithmDetails.primitives) {
            result = await session.query(
                `INSERT INTO advance."CryptoPrimitive" (name, "friendlyName", "cryptoAlgorithm", "oid", "isDefault", "purpose")`
                + ` VALUES (?,?,?,?,?,?) RETURNING id`,
                [algorithm, algorithmDetails.description, algorithmID, oid, true, purposeId])
            await session.query(`INSERT INTO advance."CryptoPrimitiveScore" ("cryptoPrimitive", "cryptoScore") VALUES (?, `
                + `(SELECT id FROM advance."CryptoScore" where score=? AND "cryptoPostureTemplate"=?))`, [result.rows[0].id, baseScore, isaraCPTID])
            await session.query(
                `INSERT INTO advance."CryptoPrimitiveDefault" ("cryptoPrimitive", "defaultPrimitive", "purpose")`
                + ` VALUES (?,?,?) RETURNING id`,
                [result.rows[0].id, result.rows[0].id, purposeId])    
        }
        if ('primitives' in algorithmDetails) {
            log.log(`\tAdding ${algorithmDetails.primitives.length} variants...`)
            for (let primitive of algorithmDetails.primitives) {
                let score = baseScore
                let variant
                if ('variant' in primitive) {
                    variant = primitive.variant
                }
                if ('score' in primitive) {
                    score = primitive['score']
                }
                result = await session.query('INSERT INTO advance."CryptoPrimitive" (name, "friendlyName", "cryptoAlgorithm",'
                    + '"oid", "variant","purpose") VALUES (?,?,?,?,?,?) RETURNING id', [primitive.name, primitive.description, algorithmID, oid,
                    variant, purposeId])
                await session.query(`INSERT INTO advance."CryptoPrimitiveScore" ("cryptoPrimitive", "cryptoScore") VALUES (?, `
                    + `(SELECT id FROM advance."CryptoScore" where score=? AND "cryptoPostureTemplate"=?))`, [result.rows[0].id, score, isaraCPTID])
            }
        }
    }
}

main().then(() => {
    require('child_process').exec('npm run migrator:setup')
    log.log('Success')
}).catch(e => {
    log.e('Fatal exception:', e)
    process.exit(1)
})
