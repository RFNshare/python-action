/**
 * @file jsonConfigImport.js - 0.0.1045 - ea4595bfd3488684d225574ed7d4c198074d49ba
 * 
 * @copyright Copyright (C) 2016-2023, ISARA Corporation, All Rights Reserved.
 * 
 * @license The code and other content set out herein is not in the public
 * domain, is considered a trade secret and is confidential to ISARA
 * Corporation. Use, reproduction or distribution, in whole or in part, of such
 * code or other content is strictly prohibited except by express written
 * permission of ISARA Corporation. Please contact ISARA Corporation at
 * info@isara.com for more information.
 */


const fs = require('fs')
var log = require('../../util/log')(module)
const { initGenerator } = require('./processing')
const { insertNetmasks } = require('./netmask')
const { populateSoftware } = require('./software')
const {
    dumpObjectTimingStats,
    initDbConnection,
    insertObject,
    bulkInsertRecords,
    resetObjectTimingStats
} = require('../dbHelpers')

const { generateAndInsertSoftwareVersionTags,
    generateAndInsertConnectionTags
} = require("./tag")
const { insertNotifications,
    insertNotificationActions
} = require("./notification")
const { clamp } = require('../utils')
const { createWidgetFromConfig, createReportsFromConfig } = require('./widget')
const { generateDevice } = require('./device')
const { generateConnections } = require('./connection')
const {
    discoverSchema
} = require('../../isaraql/schemaDiscovery')

const loadJsonFile = async (file) => {
    const str = fs.readFileSync(file) + ''
    let json;
    try {
        json = JSON.parse(str)
    } catch (e) {
        log.log(e)
    }
    return json;
}
const mainJsonImport = async (session, file, data, user) => {
    log.log("mainJsonImport", file)
    const config = await loadJsonFile(file)
    await discoverSchema()
    await initGenerator(session, data)
    await initDbConnection(session)
    log.log("config.SoftwareVersionTags", config)
    /// basic stuff
    try {
        await generateAndInsertSoftwareVersionTags(session, config.SoftwareVersionTags, data)
    } catch (e) { }
    log.log('Adding connection tags...')
    try {
        await generateAndInsertConnectionTags(session, config.ConnectionTags, data)
    } catch (e) { }
    log.log('Adding notifications...')
    try {
        await insertNotifications(session, data)
    } catch (e) { }
    try {
        await insertNotificationActions(session, data.notifications, data.users)
    } catch (e) { }
    log.log('Adding network masks...')
    try {
        await insertNetmasks(session, config.Netmasks, data)
    } catch (e) { }
    log.log('Adding software...')
    if (!data.sampleSoftware) {
        data.sampleSoftware = {
            'OS': ['Windows', 'macOS', 'Linux'],
            'SERVER': ['Apache', 'Nginx', 'Mongoose'],
            'APP': ['AngryBirds', 'Outlook', 'Sublime Text'],
            'WEB_SERVER': ['Tomcat', 'Apache'],
            'DATABASE': ['MongoDB', 'SQLite', 'Oracle', 'Redis', 'MariaDB', 'Couchbase'],
            'ARCHIVE': ['Winzip', 'WinRAR', '7-Zip', 'Zip Archiver'],
            'FINANCIAL': ['QuickBooks', 'Xero', 'FreshBooks', 'Sage', 'Zoho Books'],
            'BROWSER': ['Firefox', 'Chrome', 'Internet Explorer', 'Safari', 'Brave'],
            'CMS': ['WordPress', 'Drupal', 'Joomla', 'SharePoint', 'Magneto'],
            'CRYPTOGRAPHIC': ['LastPass', 'BitLocker', 'VeraCrypt', 'FileVault', 'DiskCryptor'],
            'OTHER': ['REAPER', 'Random', 'Other']
        }
    }
    try {
        await populateSoftware(session, data)
    } catch (e) { }
    try {
        await createWidgetFromConfig(session, user, config)
    } catch (e) { }
    try {
        await createReportsFromConfig(session, user, config)
    } catch (e) { }
    //pick how many
    const numDevices = clamp(Math.random() * 1000, config.Devices.min, config.Devices.max)
    const numServers = clamp(Math.random() * 1000, config.Servers.min, config.Servers.max)
    const numDConnections = clamp(Math.random() * 1000, config.Connections.min, config.Connections.max)

    log.log(`Decided on ${numDevices} devices, of which ${numServers} are servers, and ${numDConnections} connections...`)

    // generate bunch of devices
    data.overallDevices = []
    do {
        data.overallDevices.push(generateDevice());
    } while (data.overallDevices.length < numDevices)
    try {
        await bulkInsertRecords('Device', data.overallDevices, session)
    } catch (e) { }
    log.log('Created Devices...')

    // pick some to be servers
    data.overallServers = []
    do {
        let index = Math.floor(Math.random() * data.overallDevices.length)
        if (data.overallServers.indexOf(index) == (-1)) {
            data.overallServers.push(index);
        }
    } while (data.overallServers.length < numServers)

    log.log('picked out servers...')

    // generate connections based on these devices and config
    try {
        await generateConnections(session, config, data, numDConnections)
    } catch (e) { }
    log.log('done')
    process.exit()
}

exports.mainJsonImport = mainJsonImport;