/**
 * @file ISARATLSParamsTCPRecord.js - 0.0.1045 - ea4595bfd3488684d225574ed7d4c198074d49ba
 * 
 * @copyright Copyright (C) 2016-2023, ISARA Corporation, All Rights Reserved.
 * 
 * @license The code and other content set out herein is not in the public
 * domain, is considered a trade secret and is confidential to ISARA
 * Corporation. Use, reproduction or distribution, in whole or in part, of such
 * code or other content is strictly prohibited except by express written
 * permission of ISARA Corporation. Please contact ISARA Corporation at
 * info@isara.com for more information.
 */

// /**
//  * Handling for ISARA custom ExtraHop records containing TLS parameters parsed
//  * from TCP dataflow. Used in order to gather key exchange parameters and
//  * negotiated hash algorithms for entity authentication for TLS 1.2 and below.
//  *
//  * @module extrahop/records/ISARATLSParamsTCPRecord
// */

// const { writeToString } = require('@fast-csv/format')

// const { RecordBase } = require('./RecordBase')
// const { allTypes } = require('../../../isaraql/schemaDiscovery')
// const { populateObservedFields } = require('../extrahopUtils')

// class ISARATLSParamsTCPRecord extends RecordBase {
//     constructor(record, cacheMaps) {
//         super(record, cacheMaps)

//         this.record = record
//         delete this.cacheMaps

//         if (cacheMaps.flowIDMap[record._source.isaraFlowID] === undefined) {
//             cacheMaps.flowIDMap[record._source.isaraFlowID] = []
//         }
//         cacheMaps.flowIDMap[record._source.isaraFlowID].push(this)
//     }

//     getKEXPrimitive(ephemeral) {
//         let record = this.record

//         let algorithm = record._source.isaraKEXAlgorithm
//         let parameter = record._source.isaraTLSKEXParameter

//         let primitiveID
//         switch (algorithm) {
//             case 'ECDH': {
//                 let prefix = ephemeral ? 'ECDHE' : 'ECDH'
//                 primitiveID = this.getECDHPrimitive(prefix, parameter)
//                 break
//             }

//             case 'FFDH': {
//                 let prefix = ephemeral ? 'FFDHE' : 'FFDH'
//                 primitiveID = this.getFFDHPrimitive(prefix, parameter)
//                 break
//             }
//         }

//         return primitiveID
//     }

//     // All IANA defined TLS supported groups:
//     // https://www.iana.org/assignments/tls-parameters/tls-parameters.xhtml#tls-parameters-8
//     getECDHPrimitive(prefix, curveParameter) {
//         let cryptoPrimitives = allTypes['CryptoPrimitive']._enum.idByName
//         switch (curveParameter) {
//             case 1: // sect163k1
//                 return cryptoPrimitives[`${prefix}_SECT163k1`]
//             case 2: // sect163r1
//                 return cryptoPrimitives[`${prefix}_SECT163r1`]
//             case 3: // sect163r2
//                 return cryptoPrimitives[`${prefix}_SECT163r2`]
//             case 4: // sect193r1
//                 return cryptoPrimitives[`${prefix}_SECT193r1`]
//             case 5: // sect193r2
//                 return cryptoPrimitives[`${prefix}_SECT193r2`]
//             case 6: // sect233k1
//                 return cryptoPrimitives[`${prefix}_SECT233k1`]
//             case 7: // sect233r1
//                 return cryptoPrimitives[`${prefix}_SECT233r1`]
//             case 8: // sect239k1
//                 return cryptoPrimitives[`${prefix}_SECT239k1`]
//             case 9: // sect283k1
//                 return cryptoPrimitives[`${prefix}_SECT283k1`]
//             case 10: // sect283r1
//                 return cryptoPrimitives[`${prefix}_SECT283r1`]
//             case 11: // sect409k1
//                 return cryptoPrimitives[`${prefix}_SECT409k1`]
//             case 12: // sect409r1
//                 return cryptoPrimitives[`${prefix}_SECT409r1`]
//             case 13: // sect571k1
//                 return cryptoPrimitives[`${prefix}_SECT571k1`]
//             case 14: // sect571r1
//                 return cryptoPrimitives[`${prefix}_SECT571r1`]
//             case 15: // secp160k1
//                 return cryptoPrimitives[`${prefix}_SECP160k1`]
//             case 16: // secp160r1
//                 return cryptoPrimitives[`${prefix}_SECP160r1`]
//             case 17: // secp160r2
//                 return cryptoPrimitives[`${prefix}_SECP160r2`]
//             case 18: // secp192k1
//                 return cryptoPrimitives[`${prefix}_SECP192k1`]
//             case 19: // secp192r1
//                 return cryptoPrimitives[`${prefix}_SECP192r1`]
//             case 20: // secp224k1
//                 return cryptoPrimitives[`${prefix}_SECP224k1`]
//             case 21: // secp224r1
//                 return cryptoPrimitives[`${prefix}_SECP224r1`]
//             case 22: // secp256k1
//                 return cryptoPrimitives[`${prefix}_SECP256k1`]
//             case 23: // secp256r1
//                 return cryptoPrimitives[`${prefix}_SECP256r1`]
//             case 24: // secp384r1
//                 return cryptoPrimitives[`${prefix}_SECP384r1`]
//             case 25: // secp521r1
//                 return cryptoPrimitives[`${prefix}_SECP521r1`]
//             case 26: // brainpoolP256r1
//             case 31: // brainpoolP256r1tls13
//                 return cryptoPrimitives[`${prefix}_BRAINPOOL_P256r1`]
//             case 27: // brainpoolP384r1
//             case 32: // brainpoolP384r1tls13
//                 return cryptoPrimitives[`${prefix}_BRAINPOOL_P384r1`]
//             case 28: // brainpoolP512r1
//             case 33: // brainpoolP512r1tls13
//                 return cryptoPrimitives[`${prefix}_BRAINPOOL_P512r1`]
//             case 29: // x25519
//                 return cryptoPrimitives[`${prefix}_x25519`]
//             case 30: // x448
//                 return cryptoPrimitives[`${prefix}_x448`]
//             case 34: // GC256A
//                 return cryptoPrimitives[`${prefix}_GC256A`]
//             case 35: // GC256B
//                 return cryptoPrimitives[`${prefix}_GC256B`]
//             case 36: // GC256C
//                 return cryptoPrimitives[`${prefix}_GC256C`]
//             case 37: // GC256D
//                 return cryptoPrimitives[`${prefix}_GC256D`]
//             case 38: // GC512A
//                 return cryptoPrimitives[`${prefix}_GC512A`]
//             case 39: // GC512B
//                 return cryptoPrimitives[`${prefix}_GC512B`]
//             case 40: // GC512C
//                 return cryptoPrimitives[`${prefix}_GC512C`]
//             case 41: // curveSM2
//                 return cryptoPrimitives[`${prefix}_CurveSM2`]
//             default:
//                 return null
//         }
//     }

//     getFFDHPrimitive(prefix, sizeParameter) {
//         let cryptoPrimitives = allTypes['CryptoPrimitive']._enum.idByName
//         switch (sizeParameter) {
//             case 768:
//                 return cryptoPrimitives[`${prefix}_768`]
//             case 1024:
//                 return cryptoPrimitives[`${prefix}_1024`]
//             case 1536:
//                 return cryptoPrimitives[`${prefix}_1536`]
//             case 2048:
//                 return cryptoPrimitives[`${prefix}_2048`]
//             case 3072:
//                 return cryptoPrimitives[`${prefix}_3072`]
//             case 4096:
//                 return cryptoPrimitives[`${prefix}_4096`]
//             case 6144:
//                 return cryptoPrimitives[`${prefix}_6144`]
//             case 8192:
//                 return cryptoPrimitives[`${prefix}_8192`]
//             default:
//                 return null
//         }
//     }

//     // All IANA defined TLS supported signature schemes:
//     // https://www.iana.org/assignments/tls-parameters/tls-parameters.xhtml#tls-signaturescheme
//     getAuthHashPrimitive(sigSchemeCodePoint) {
//         let cryptoPrimitives = allTypes['CryptoPrimitive']._enum.idByName
//         switch (sigSchemeCodePoint) {
//             case 0x0201: // rsa_pkcs1_sha1
//             case 0x0203: // ecdsa_sha1
//                 return cryptoPrimitives['SHA_1']
//             case 0x0401: // rsa_pkcs1_sha256
//             case 0x0403: // ecdsa_secp256r1_sha256
//             case 0x0420: // rsa_pkcs1_sha256_legacy
//             case 0x0704: // eccsi_sha256
//             case 0x0804: // rsa_pss_rsae_sha256
//             case 0x0809: // rsa_pss_pss_sha256
//             case 0x081A: // ecdsa_brainpoolP256r1tls13_sha256
//                 return cryptoPrimitives['SHA_256']
//             case 0x0501: // rsa_pkcs1_sha384
//             case 0x0503: // ecdsa_secp384r1_sha384
//             case 0x0520: // rsa_pkcs1_sha384_legacy
//             case 0x0805: // rsa_pss_rsae_sha384
//             case 0x080A: // rsa_pss_pss_sha384
//             case 0x081B: // ecdsa_brainpoolP384r1tls13_sha384
//                 return cryptoPrimitives['SHA_384']
//             case 0x0601: // rsa_pkcs1_sha512
//             case 0x0603: // ecdsa_secp521r1_sha512
//             case 0x0620: // rsa_pkcs1_sha512_legacy
//             case 0x0806: // rsa_pss_rsae_sha512
//             case 0x080B: // rsa_pss_pss_sha512
//             case 0x081C: // ecdsa_brainpoolP512r1tls13_sha512
//                 return cryptoPrimitives['SHA_512']
//             case 0x0708: // sm2sig_sm3
//                 return cryptoPrimitives['SM3']
//             case 0x0709: // gostr34102012_256a
//             case 0x070A: // gostr34102012_256b
//             case 0x070B: // gostr34102012_256c
//             case 0x070C: // gostr34102012_256d
//             case 0x070D: // gostr34102012_512a
//             case 0x070E: // gostr34102012_512b
//             case 0x070F: // gostr34102012_512c
//                 // IETF "draft-smyshlyaev-tls13-gost-suites", section 4.2.
//                 return cryptoPrimitives['GOST_HASH']
//             default:
//                 return null
//         }

//         // TODO: GAP1325 - We may need to add "intrinsic" hash primitive to account
//         // for the case when the external hash is not needed because the sig algo's
//         // internal hash is used instead. This is for ed25519 and ed448.

//         // TODO: GAP1618 - Figure out what hash algorithm is used for sig schemes "iso_ibs1",
//         // "iso_ibs2", "iso_chinese_ibs".
//     }

//     async getConnectionObject() {
//         // ISARATLSParamsTCPRecords are only ever used as companions to extract the primitive for TLSMainRecord
//         return null
//     }
// }

// exports.ISARATLSParamsTCPRecord = ISARATLSParamsTCPRecord
