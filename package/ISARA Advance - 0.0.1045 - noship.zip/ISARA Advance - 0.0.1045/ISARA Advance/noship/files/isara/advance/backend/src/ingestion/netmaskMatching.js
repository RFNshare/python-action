/**
 * @file netmaskMatching.js - 0.0.1045 - ea4595bfd3488684d225574ed7d4c198074d49ba
 * 
 * @copyright Copyright (C) 2016-2023, ISARA Corporation, All Rights Reserved.
 * 
 * @license The code and other content set out herein is not in the public
 * domain, is considered a trade secret and is confidential to ISARA
 * Corporation. Use, reproduction or distribution, in whole or in part, of such
 * code or other content is strictly prohibited except by express written
 * permission of ISARA Corporation. Please contact ISARA Corporation at
 * info@isara.com for more information.
 */

const log = require('../util/log')(module)
const { Session } = require('../isaraql/session')
const { getMatch } = require('ip-matching')
const { PurgingDictionary } = require('../util/purgingDictionary')

log.debug = true

class NetmaskMatchMode {
    #name
    #isServer
    constructor(name, isServer) {
        this.#name = name
        this.#isServer = isServer
    }
    get isServer() {
        return this.#isServer
    }
}

class NetmaskMatchModes {
    static DO_NOT_MATCH = new NetmaskMatchMode('Do not match')
    static CLIENT = new NetmaskMatchMode('Client', false)
    static SERVER = new NetmaskMatchMode('Server', true)
}

/**
 * All server side Netmask converters.
 * @type Array.<Netmask>
 */

let serverMasks = []
let serverZones = []

/**
 * All client side Netmask converters.
 * @type Array.<Netmask>
 */
let clientMasks = []
let clientZones = []

/**
 * Dictionary of already converted server addresses.
 */
let serverConvertCache = new PurgingDictionary('netmaskMatching/server')

/**
 * Dictionary of already converted client addresses.
 */
let clientConvertCache = new PurgingDictionary('netmaskMatching/client')

/**
 * Flag recording if the serverMasks and clientMasks have been loaded.
 * @type Boolean
 */
let initialised = false

/**
 * Promise that is currently working on initialising
 */
let initialising = null

class Netmask {
    /**
     * @type Object
     */
    #row

    /**
     * @type String
     */
    #name

    /**
     * @type String
     */
    #netmask

    /**
     * @type String
     */
    #zoneIn

    /**
     * @type String
     */
    #zoneOut

    /**
     * @type Boolean
     */
    #storeName

    /**
     * @type Boolean
     */
    #squashAddresses

    /**
     * @type {Array.<IPMatch>}
     */
    #netmasks = []

    constructor(row) {
        this.#row = row

        this.#name = row.name
        this.#netmask = row.netmask
        this.#zoneIn = row.zoneIn
        this.#zoneOut = row.zoneOut
        this.#storeName = row.storeName
        this.#squashAddresses = row.squashAddresses
    
        /**
         * @type String
         */
        let netmask

        for (netmask of this.#netmask.split(',')) {
            netmask = netmask.trim()
            try {
                this.#netmasks.push(getMatch(netmask))
            } catch (error) {
                log.e('Error processing netmasks', netmask, error)
            }
        }
        if (row.enabled) {
            if (row.forClients) {
                clientMasks.push(this)
                clientZones.push({zone:row.zoneIn, name:this.#name })
            }
            if (row.forServers) {
                serverMasks.push(this)
                serverZones.push({zone:row.zoneOut, name:this.#name })
            }
            if (!row.forClients && !row.forServers) {
                log.w('Ignoring a netmask that is not for clients, and is not for servers', row)
            }
        } else {
            log.log('Ignoring a netmask (it is disabled)',row)
        }
    }

    /**
     * @param {String} ipAddress 
     * @returns {String|undefined}
     */
    convert(ipAddress) {
        for (let mask of this.#netmasks) {
            if (mask.matches(ipAddress)) {
                if (this.#squashAddresses) {
                    if (this.#storeName) {
                        return this.#name
                    } else {
                        return mask.toString()
                    }
                } else {
                    return ipAddress
                }
            }
        }
        return undefined
    }

    getMatchingNetmask(ipAddress){
        for (let mask of this.#netmasks) {
            /* eslint-disable */
            try{ // in case of flattened match
                if (mask.matches(ipAddress)) {
                    return this.#name
                }
            }catch(e){
            }
            /* eslint-enable */
        }
        return ipAddress
    }
}

/**
 * Load netmasks. If a session is provided, it will reload.
 * @param {[Session]} session Optional session that will trigger reloading netmasks.
 * @returns 
 */
async function init(session) {
    if (initialised && !session) {
        return
    }

    if (!initialising) {
        initialising = initInternal() // Note: no await
    }

    return await initialising
}

async function initInternal(session) {
    session = session ?? new Session()

    log.d('Loading netmasks')
    let rows = (await session.query('select * from "Netmask" order by "sortOrder" asc')).rows

    clientMasks.length = 0
    serverMasks.length = 0
    clientConvertCache.purge()
    serverConvertCache.purge()

    log.d(`Loaded ${rows.length} rows.`)
    rows.forEach(row => new Netmask(row))
    initialised = true
    initialising = null
}

/**
 * 
 * @param {String} ipAddress 
 * @param {Boolean} isServer 
 * @param {DictWithCount} whichCache 
 * @returns {String}
 */
function attemptMatch(ipAddress, isServer, whichCache) {
    if (!initialised) {
        log.w('Not initialised - results unreliable')
    }
    let whichMasks = isServer ? serverMasks : clientMasks    
    for (let mask of whichMasks) {
        let converted = mask.convert(ipAddress)
        if (converted) {
            return whichCache.put(ipAddress, converted)
        }
    }
    return whichCache.put(ipAddress, ipAddress)
}

function matchNetmasks(ipAddress, mode = NetmaskMatchModes.DO_NOT_MATCH) {
    if (mode === NetmaskMatchModes.DO_NOT_MATCH) {
        return ipAddress
    }
    const isServer = mode?.isServer
    if (isServer == undefined) {
        throw new Error('Unexpected argument to matchNetmasks')
    }
    
    let whichCache = isServer ? serverConvertCache : clientConvertCache
    return whichCache.get(ipAddress) ?? attemptMatch(ipAddress, isServer, whichCache)
}
function hasNetmaskZone(ipAddress, mode){
    const list = mode == NetmaskMatchModes.CLIENT ? clientZones : serverZones
    let whichMasks = mode == NetmaskMatchModes.CLIENT ? clientMasks : serverMasks     
    for (let mask of whichMasks) {
        let matchMask = mask.getMatchingNetmask(ipAddress)
        const test = list.filter(mask => mask.name== matchMask)
        if(test.length>0){
            return test[0] && test[0].zone
        }
    }
}

exports.NetmaskMatchMode = NetmaskMatchMode
exports.NetmaskMatchModes = NetmaskMatchModes
exports.loadNetmasks = init
exports.matchNetmasks = matchNetmasks
exports.hasNetmaskZone = hasNetmaskZone

async function test() {
    await init()
    log.log(matchNetmasks('192.168.21.1', NetmaskMatchModes.CLIENT))
    log.log(matchNetmasks('192.168.21.1', NetmaskMatchModes.SERVER))
    log.log(matchNetmasks('192.168.2.1', NetmaskMatchModes.CLIENT))
    log.log(matchNetmasks('192.168.2.1', NetmaskMatchModes.SERVER))
}

if (require.main === module) {
    test().then(() => {
        console.log('GOOD')
        process.exit(0)
    }).catch(error => {
        console.log(error)
        console.log('BAD')
        process.exit(1)
    })
}
