/**
 * @file taniumClient.js - 0.0.1045 - ea4595bfd3488684d225574ed7d4c198074d49ba
 * 
 * @copyright Copyright (C) 2016-2023, ISARA Corporation, All Rights Reserved.
 * 
 * @license The code and other content set out herein is not in the public
 * domain, is considered a trade secret and is confidential to ISARA
 * Corporation. Use, reproduction or distribution, in whole or in part, of such
 * code or other content is strictly prohibited except by express written
 * permission of ISARA Corporation. Please contact ISARA Corporation at
 * info@isara.com for more information.
 */

/**
 * Connect and authenticate for a session with the Tanium REST API.
 * @module ingestion/tanium/taniumClient
 */

const axios = require('../../util/axiosFactory').createFactory('Tanium')
const URI = require('uri-js')
const { IngestionAuthError, IngestionCommError } = require('../commonIngestion')
const log = require('../../util/log')(module)

const AUTH_ERROR_MESSAGE = 'Advance failed to authenticate with the remote Tanium server.'

/**
 * Compose a Tanium server error response message suitable for exceptions.
 * @param {object} errorResponse - From the Tanium server https://www.npmjs.com/package/axios#response-schema
 * @returns A message string explaining the error
 */
// For #2261, commented off the following as a piece of unreachable code 
// function errorMessage(response) {
//     const method = response.config.method.toUpperCase()
//     const url = response.config.url
//     const status = response.status
//     const message = (
//         (response.data && response.data.text)
//         || response.data
//         || ''
//     )
//     if (message.includes('InvalidGroupQueryText')) {
//         return `Invalid Term in Computer Group`
//     }
//     return `${method} '${url}' failed with ${status} '${message}'`
// }

/** @class */
class Session {

    /**
     * Construct an authenticated session.
     * @param {object} connection 
     * @param {object} token - An API token, or a login session token
     * @param {object} user - An API user object tanium_rest_api_v7/#api-Objects-NoneUser
     */
    constructor(connection, token, user) {
        this.connection = connection
        this.token = token
        this.user = user
    }

    /**
     * Perform an API request.
     * @param {Object} axiosRequestConfig - https://www.npmjs.com/package/axios#request-config
     * @return {Object} A promise that yields the response.data object or throws an IngestionError
     * 
     * TODO: GAP1610 - file:///tanium_rest_api_v7/index.html#api-Objects-Post_get_patchAuth
     * In some situations, the session string may change, so after each request the returned session string should be checked.
     */
    async request(axiosRequestConfig) {
        const method = axiosRequestConfig.method || 'GET'
        const url = axiosRequestConfig.url || ''
        const headers = Object.assign(axiosRequestConfig.headers || {}, { session: this.token })
        const config = Object.assign(axiosRequestConfig, { method, url, headers })
        let response = await this.connection.server.request(config)
        if (response?.data) {
            return response.data
        }
        log.e('Unexpected response format',response)
        throw new IngestionCommError('Tanium response did not include expected data.')
    }
}

/** @class */
class Connection {
    /**
     * @type TaniumClient
     */
    server

    /**
     * Construct a connection.
     * @param {TaniumClient} server 
     */
    constructor(server) {
        this.server = server
    }

    /**
     * Obtain an authenticated session using an API token.
     * @param {string} apiToken - Tanium > Administration > API Tokens
     * @return {object} A promise that yields a Session or throws an IngestionError
     * 
     * @example
     * token-4835862df2480c87abb1fb9710cec8d5dd07d237d79925a2411acbcc9b
     */
    async authenticate(apiToken) {
        let response
        try {
            response = await this.server.request(
                {
                    method: 'GET',
                    url: 'session/current',
                    headers: {
                        session: apiToken
                    }
                })
            if (response?.data?.data?.user) {
                return new Session(this, apiToken, response.data.data.user)
            } else {
                throw new IngestionAuthError(`${AUTH_ERROR_MESSAGE}\nThe server response did not match the Tanium API.`)
            }
        } catch (error) {
            log.e('Did not get expected response from Tanium server', new IngestionCommError(`${AUTH_ERROR_MESSAGE}\n${error.message}`), response)
            if (!(error instanceof IngestionAuthError)) {
                throw new IngestionCommError(`${AUTH_ERROR_MESSAGE}\n${error.message}`)
            }
            throw error
        }
    }
}

/** @class */
class TaniumClient {

    /**
     * Construct a Tanium client.
     * @param {string} name - The name of the server, as a simple display label for logs, etc.
     * @param {string} schemeAuthority - The URI scheme and authority
     * @param {string} apiPath - The version-specific API endpoint
     * @param {object} parameters - Server configuration parameters - timeout: ms
     */
    constructor(name, schemeAuthority, apiPath, parameters) {
        this.name = name
        this.baseURL = URI.resolve(schemeAuthority, apiPath)
        parameters = parameters || {}
        this.timeout = parameters.timeout || 1000
        this.axios = axios.create({
            baseURL: this.baseURL,
            timeout: this.timeout
        })
    }

    /**
     * Perform a server request and apply callBack or (optional) errBack to transform the response.
     * @param {object} axiosRequestConfig
     * @returns {object} - The result of callBack or errBack applied to the server response
     * @throws {ServerError} If the server cannot perform the request or responds with an HTTP error and errBack is undefined
     */
    async request(config) {
        if (arguments.length > 1) {
            log.e(new Error('Unused arguments passed to request'))
        }
        try {
            const response = await this.axios.request(config)
            if (log.debug) {
                log.d('Tanium request URL', this.baseURL)
                log.d('Tanium response', { headers: response.headers, data: response.data, status: response.status, statusText: response.statusText })
            }
            if (200 <= response.status < 300) {
                return response
            }
            throw new IngestionCommError(`Unexpected HTTP status from Tanium server (${response.status})`)
        } catch (error) {
            log.e('Failed Tanium request', error)
            if (error?.response?.status === 403) {
                throw new IngestionAuthError(`${AUTH_ERROR_MESSAGE}.\nThe server rejected the API token.`)
            }
            throw error
        }
    }

    /**
     * Connect to the server.
     * @returns {Connection} connection - A new connection
     * @throws {ServerError} - If the server cannot be reached or cannot complete a simple HTTP request
     */
    async connect() {
        return new Connection(this)
    }
}
exports.TaniumClient = TaniumClient

/**
 * Create an authenticated Tanium Session.
 * @param {*} name The name of the server, as a simple display label for logs, etc.
 * @param {*} schemeAuthority - The URI scheme and authority, e.g., https://acme-api.cloud.tanium.com/
 * @param {*} apiPath - The version-specific API endpoint, e.g., /api/v2
 * @param {*} apiToken An API token, or a login session token
 * @param {*} parameters Client configuration parameters - timeout: ms
 */
exports.createTaniumSession = async function (name, schemeAuthority, apiPath, apiToken, parameters) {
    let client = new TaniumClient(name, schemeAuthority, apiPath, parameters)
    try {
        let connection = await client.connect()
        return connection.authenticate(apiToken)
    } catch (error) {
        log.e('Error creating Tanium session', error)
        throw error
    }
}
