/**
 * @file constants.js - 0.0.1045 - ea4595bfd3488684d225574ed7d4c198074d49ba
 * 
 * @copyright Copyright (C) 2016-2023, ISARA Corporation, All Rights Reserved.
 * 
 * @license The code and other content set out herein is not in the public
 * domain, is considered a trade secret and is confidential to ISARA
 * Corporation. Use, reproduction or distribution, in whole or in part, of such
 * code or other content is strictly prohibited except by express written
 * permission of ISARA Corporation. Please contact ISARA Corporation at
 * info@isara.com for more information.
 */



exports.backendPath = 'https://localhost:4000/service/'

exports.deviceTypes = {
    BAD_SERVER : 'BAD_SERVER',
    GOOD_SERVER: 'GOOD_SERVER',
    CLIENT: 'CLIENT'
}

exports.badServerReasons = {
    WEAK_CRYPTO_PRIMITIVE : 'WEAK_CRYPTO_PRIMITIVE',
    WEAK_VERSION_TLS : 'WEAK_VERSION_TLS',
    WEAK_CIPHER_SUITE : 'WEAK_CIPHER_SUITE',
}

exports.badServerReasonsArray = ['WEAK_CRYPTO_PRIMITIVE', 'WEAK_VERSION_TLS', 'WEAK_CIPHER_SUITE']

exports.popularStrongCipherSuite = [
    'TLS_CHACHA20_POLY1305_SHA256',
    'TLS_AES_128_CCM_8_SHA256',
    'TLS_SM4_GCM_SM3',
    'TLS_AES_128_GCM_SHA256',
    'TLS_SM4_GCM_SM3'
]

exports.popularBadCipherSuite = [
    'TLS_ECDHE_ECDSA_WITH_AES_256_CCM',
    'TLS_ECDHE_SIDH_RSA_WITH_AES_256_GCM_SHA384',
    'TLS_ECDHE_KYBER_ECDSA_WITH_AES_256_GCM_SHA384',
    'TLS_DHE_DSS_WITH_AES_128_CBC_SHA',
    'TLS_GOSTR341112_256_WITH_28147_CNT_IMIT',
    'TLS_PSK_WITH_AES_128_CCM',
]

exports.optionalArguments = {
    help: 'Display this insightful message.',
    baselineOnly: 'Only provision user objects and minimal required data.',
    goodServerPorts: 'Ports and number of ports count for good servers e.g. [{ \\"port\\":443, \\"count\\":2}].',
    badServerPorts: 'Ports and number of ports count for bad servers e.g. [{ \\"port\\":443, \\"count\\":2}].',
    numGoodServers: 'Number of good servers.',
    numBadServers: 'Number of bad servers.',
    numClients: 'Number of clients.',
    pocGoodServers: 'Probability of connecting to a good server.',
    minGoodConnections: 'Minimum number of good connections.',
    minBadConnections: 'Minimum number of bad connections.',
    pocBadServers: 'Probability of connecting to a bad server.',
    maxCertificates: 'Maximum number of certificates.',
    badCiphers: 'Ciphers and priority to use for bad servers e.g. [{ \\"cipher\\":\\"TLS_DHE_DSS_WITH_AES_128_CBC_SHA\\", \\"priority\\":1},{ \\"cipher\\":\\"TLS_PSK_WITH_AES_128_CCM\\", \\"priority\\":2}].',
    configFile: 'Use a json file with config details',
    userPassword: "Password to assign default users, instead of 'password'"
}


exports.sampleSoftware = {
    'OS': ['Windows', 'macOS', 'Linux'],
    'SERVER': ['Apache', 'Nginx', 'Mongoose'],
    'APP': ['AngryBirds', 'Outlook', 'Sublime Text'],
    'WEB_SERVER': ['Tomcat', 'Apache'],
    'DATABASE': ['MongoDB', 'SQLite', 'Oracle', 'Redis', 'MariaDB', 'Couchbase'],
    'ARCHIVE': ['Winzip', 'WinRAR', '7-Zip', 'Zip Archiver'],
    'FINANCIAL': ['QuickBooks', 'Xero', 'FreshBooks', 'Sage', 'Zoho Books'],
    'BROWSER': ['Firefox', 'Chrome', 'Internet Explorer', 'Safari', 'Brave'],
    'CMS': ['WordPress', 'Drupal', 'Joomla', 'SharePoint', 'Magneto'],
    'CRYPTOGRAPHIC': ['LastPass', 'BitLocker', 'VeraCrypt', 'FileVault', 'DiskCryptor'],
    'OTHER': ['REAPER', 'Random', 'Other']
}

exports.tagTypeValuesMap = {
    EXCEPTION: ['OK', 'NOT OK'],
    ZONE: ['York', 'Waterloo', 'Kitchener', 'Vancouver', 'Berlin', 'London', 'New York', 'Montréal'],
    PRIORITY: ['HIGH', 'LOW'],
    DEVICE_PURPOSE: ['Finance Dept Machine', 'Print Checks', 'Jenkins Server', 'CI Machine', 'Student Services Server'],
    CPU_FAMILY: ['Intel', 'ARM'],
    HOSTNAME: ['alice', 'bob', 'charlie123', 'alice.isara.com', 'bob.isara.com', 'charlie123.uwaterloo.ca'],
    DOMAIN: ['isara.com', 'uwaterloo.ca', 'google.com', 'aws.amazon.com'],
    NORMAL_ADDRESS: ['1234 Physical St', '567 Mylocation Ave Unit 123', '890 YetAnotherPlace Rd']
}


exports.sampleReportDataConnection = [
    {
        "filters": {
            "cryptoStrength": [
                {
                    "label": "Unacceptable",
                    "value": [
                        "Caution"
                    ],
                    "count": 14828,
                    "isRefined": true
                },
                {
                    "label": "Caution",
                    "value": [
                        "Unacceptable"
                    ],
                    "count": 4585,
                    "isRefined": true
                },
                {
                    "label": "Broken",
                    "value": [
                        "Unacceptable",
                        "Caution",
                        "Broken"
                    ],
                    "count": 12141,
                    "isRefined": false
                },
                {
                    "label": "Weak",
                    "value": [
                        "Unacceptable",
                        "Caution",
                        "Weak"
                    ],
                    "count": 1969,
                    "isRefined": false
                },
                {
                    "label": "Not Recommended",
                    "value": [
                        "Unacceptable",
                        "Caution",
                        "Not Recommended"
                    ],
                    "count": 1690,
                    "isRefined": false
                },
                {
                    "label": "Unknown or Custom",
                    "value": [
                        "Unacceptable",
                        "Caution",
                        "Unknown or Custom"
                    ],
                    "count": 1624,
                    "isRefined": false
                },
                {
                    "label": "Nonstandard QSC",
                    "value": [
                        "Unacceptable",
                        "Caution",
                        "Nonstandard QSC"
                    ],
                    "count": 1267,
                    "isRefined": false
                },
                {
                    "label": "Misused",
                    "value": [
                        "Unacceptable",
                        "Caution",
                        "Misused"
                    ],
                    "count": 718,
                    "isRefined": false
                },
                {
                    "label": "Strong",
                    "value": [
                        "Unacceptable",
                        "Caution",
                        "Strong"
                    ],
                    "count": 302,
                    "isRefined": false
                },
                {
                    "label": "Quantum Safe",
                    "value": [
                        "Unacceptable",
                        "Caution",
                        "Quantum Safe"
                    ],
                    "count": 295,
                    "isRefined": false
                },
                {
                    "label": "Strong - Quantum Broken",
                    "value": [
                        "Unacceptable",
                        "Caution",
                        "Strong - Quantum Broken"
                    ],
                    "count": 217,
                    "isRefined": false
                },
                {
                    "label": "QS - Security Level 1",
                    "value": [
                        "Unacceptable",
                        "Caution",
                        "QS - Security Level 1"
                    ],
                    "count": 140,
                    "isRefined": false
                },
                {
                    "label": "QS - Security Level 2",
                    "value": [
                        "Unacceptable",
                        "Caution",
                        "QS - Security Level 2"
                    ],
                    "count": 91,
                    "isRefined": false
                },
                {
                    "label": "Strong - Quantum Unknown",
                    "value": [
                        "Unacceptable",
                        "Caution",
                        "Strong - Quantum Unknown"
                    ],
                    "count": 85,
                    "isRefined": false
                },
                {
                    "label": "QS - Security Level 4",
                    "value": [
                        "Unacceptable",
                        "Caution",
                        "QS - Security Level 4"
                    ],
                    "count": 64,
                    "isRefined": false
                },
                {
                    "label": "Unspecified Parameters",
                    "value": [
                        "Unacceptable",
                        "Caution",
                        "Unspecified Parameters"
                    ],
                    "count": 4,
                    "isRefined": false
                }
            ],
            "keyExchange": [
                {
                    "label": "PSK_KE",
                    "value": [
                        "PSK_KE"
                    ],
                    "count": 1287,
                    "isRefined": false
                },
                {
                    "label": "KRB5",
                    "value": [
                        "KRB5"
                    ],
                    "count": 720,
                    "isRefined": false
                },
                {
                    "label": "SIKE",
                    "value": [
                        "SIKE"
                    ],
                    "count": 649,
                    "isRefined": false
                },
                {
                    "label": "RSA_KE_3072",
                    "value": [
                        "RSA_KE_3072"
                    ],
                    "count": 597,
                    "isRefined": false
                },
                {
                    "label": "RSA_KE_1024",
                    "value": [
                        "RSA_KE_1024"
                    ],
                    "count": 552,
                    "isRefined": false
                },
                {
                    "label": "RSA_KE_512",
                    "value": [
                        "RSA_KE_512"
                    ],
                    "count": 537,
                    "isRefined": false
                },
                {
                    "label": "RSA_KE_4096",
                    "value": [
                        "RSA_KE_4096"
                    ],
                    "count": 535,
                    "isRefined": false
                },
                {
                    "label": "RSA_KE_2048",
                    "value": [
                        "RSA_KE_2048"
                    ],
                    "count": 510,
                    "isRefined": false
                },
                {
                    "label": "KYBER",
                    "value": [
                        "KYBER"
                    ],
                    "count": 484,
                    "isRefined": false
                },
                {
                    "label": "SRP",
                    "value": [
                        "SRP"
                    ],
                    "count": 450,
                    "isRefined": false
                },
                {
                    "label": "SABER",
                    "value": [
                        "SABER"
                    ],
                    "count": 445,
                    "isRefined": false
                },
                {
                    "label": "FFDHE_512",
                    "value": [
                        "FFDHE_512"
                    ],
                    "count": 421,
                    "isRefined": false
                },
                {
                    "label": "FFDH_3072",
                    "value": [
                        "FFDH_3072"
                    ],
                    "count": 410,
                    "isRefined": false
                },
                {
                    "label": "FFDHE_4096",
                    "value": [
                        "FFDHE_4096"
                    ],
                    "count": 407,
                    "isRefined": false
                },
                {
                    "label": "FFDHE_6144",
                    "value": [
                        "FFDHE_6144"
                    ],
                    "count": 407,
                    "isRefined": false
                },
                {
                    "label": "FFDHE_768",
                    "value": [
                        "FFDHE_768"
                    ],
                    "count": 403,
                    "isRefined": false
                },
                {
                    "label": "FFDHE_1536",
                    "value": [
                        "FFDHE_1536"
                    ],
                    "count": 398,
                    "isRefined": false
                },
                {
                    "label": "FFDHE_1024",
                    "value": [
                        "FFDHE_1024"
                    ],
                    "count": 392,
                    "isRefined": false
                },
                {
                    "label": "FFDH_6144",
                    "value": [
                        "FFDH_6144"
                    ],
                    "count": 387,
                    "isRefined": false
                },
                {
                    "label": "FFDH_2048",
                    "value": [
                        "FFDH_2048"
                    ],
                    "count": 381,
                    "isRefined": false
                },
                {
                    "label": "FFDHE_2048",
                    "value": [
                        "FFDHE_2048"
                    ],
                    "count": 372,
                    "isRefined": false
                },
                {
                    "label": "FFDH_768",
                    "value": [
                        "FFDH_768"
                    ],
                    "count": 372,
                    "isRefined": false
                },
                {
                    "label": "FFDHE_8192",
                    "value": [
                        "FFDHE_8192"
                    ],
                    "count": 370,
                    "isRefined": false
                },
                {
                    "label": "FFDH_1024",
                    "value": [
                        "FFDH_1024"
                    ],
                    "count": 369,
                    "isRefined": false
                },
                {
                    "label": "FFDH_1536",
                    "value": [
                        "FFDH_1536"
                    ],
                    "count": 366,
                    "isRefined": false
                },
                {
                    "label": "GOSTR341112",
                    "value": [
                        "GOSTR341112"
                    ],
                    "count": 362,
                    "isRefined": false
                },
                {
                    "label": "FFDHE_3072",
                    "value": [
                        "FFDHE_3072"
                    ],
                    "count": 355,
                    "isRefined": false
                },
                {
                    "label": "FFDH_4096",
                    "value": [
                        "FFDH_4096"
                    ],
                    "count": 348,
                    "isRefined": false
                },
                {
                    "label": "FFDH_8192",
                    "value": [
                        "FFDH_8192"
                    ],
                    "count": 338,
                    "isRefined": false
                },
                {
                    "label": "FFDH_512",
                    "value": [
                        "FFDH_512"
                    ],
                    "count": 310,
                    "isRefined": false
                },
                {
                    "label": "ECCPWD",
                    "value": [
                        "ECCPWD"
                    ],
                    "count": 252,
                    "isRefined": false
                },
                {
                    "label": "ECDHE_BRAINPOOL_P384r1",
                    "value": [
                        "ECDHE_BRAINPOOL_P384r1"
                    ],
                    "count": 206,
                    "isRefined": false
                },
                {
                    "label": "ECDHE_BRAINPOOL_P512r1",
                    "value": [
                        "ECDHE_BRAINPOOL_P512r1"
                    ],
                    "count": 200,
                    "isRefined": false
                },
                {
                    "label": "ECDHE_BRAINPOOL_P256r1",
                    "value": [
                        "ECDHE_BRAINPOOL_P256r1"
                    ],
                    "count": 196,
                    "isRefined": false
                },
                {
                    "label": "NHDH",
                    "value": [
                        "NHDH"
                    ],
                    "count": 177,
                    "isRefined": false
                },
                {
                    "label": "ECDHE_GC256A",
                    "value": [
                        "ECDHE_GC256A"
                    ],
                    "count": 122,
                    "isRefined": false
                },
                {
                    "label": "ECDHE_SECT193r2",
                    "value": [
                        "ECDHE_SECT193r2"
                    ],
                    "count": 117,
                    "isRefined": false
                },
                {
                    "label": "ECDHE_SECT571k1",
                    "value": [
                        "ECDHE_SECT571k1"
                    ],
                    "count": 117,
                    "isRefined": false
                },
                {
                    "label": "ECDHE_SECP160r1",
                    "value": [
                        "ECDHE_SECP160r1"
                    ],
                    "count": 115,
                    "isRefined": false
                },
                {
                    "label": "ECDHE_SECT571r1",
                    "value": [
                        "ECDHE_SECT571r1"
                    ],
                    "count": 115,
                    "isRefined": false
                },
                {
                    "label": "ECDHE_GC512A",
                    "value": [
                        "ECDHE_GC512A"
                    ],
                    "count": 113,
                    "isRefined": false
                },
                {
                    "label": "ECDHE_SECT409r1",
                    "value": [
                        "ECDHE_SECT409r1"
                    ],
                    "count": 112,
                    "isRefined": false
                },
                {
                    "label": "ECDHE_SECP521r1",
                    "value": [
                        "ECDHE_SECP521r1"
                    ],
                    "count": 109,
                    "isRefined": false
                },
                {
                    "label": "ECDHE_GC512C",
                    "value": [
                        "ECDHE_GC512C"
                    ],
                    "count": 107,
                    "isRefined": false
                },
                {
                    "label": "ECDH_BRAINPOOL_P384r1",
                    "value": [
                        "ECDH_BRAINPOOL_P384r1"
                    ],
                    "count": 107,
                    "isRefined": false
                },
                {
                    "label": "ECDHE_SECT163k1",
                    "value": [
                        "ECDHE_SECT163k1"
                    ],
                    "count": 106,
                    "isRefined": false
                },
                {
                    "label": "ECDHE_GC256C",
                    "value": [
                        "ECDHE_GC256C"
                    ],
                    "count": 103,
                    "isRefined": false
                },
                {
                    "label": "ECDHE_GC256D",
                    "value": [
                        "ECDHE_GC256D"
                    ],
                    "count": 102,
                    "isRefined": false
                },
                {
                    "label": "ECDHE_SECP224r1",
                    "value": [
                        "ECDHE_SECP224r1"
                    ],
                    "count": 101,
                    "isRefined": false
                },
                {
                    "label": "ECDHE_SECT163r1",
                    "value": [
                        "ECDHE_SECT163r1"
                    ],
                    "count": 100,
                    "isRefined": false
                }
            ],
            "bulkEncryption": [
                {
                    "label": "AES_256",
                    "value": [
                        "AES_256"
                    ],
                    "count": 4636,
                    "isRefined": false
                },
                {
                    "label": "AES_128",
                    "value": [
                        "AES_128"
                    ],
                    "count": 3142,
                    "isRefined": false
                },
                {
                    "label": "CAMELLIA_256",
                    "value": [
                        "CAMELLIA_256"
                    ],
                    "count": 1692,
                    "isRefined": false
                },
                {
                    "label": "CAMELLIA_128",
                    "value": [
                        "CAMELLIA_128"
                    ],
                    "count": 1675,
                    "isRefined": false
                },
                {
                    "label": "ARIA_256",
                    "value": [
                        "ARIA_256"
                    ],
                    "count": 1477,
                    "isRefined": false
                },
                {
                    "label": "ARIA_128",
                    "value": [
                        "ARIA_128"
                    ],
                    "count": 1425,
                    "isRefined": false
                },
                {
                    "label": "NULL_ENC",
                    "value": [
                        "NULL_ENC"
                    ],
                    "count": 1133,
                    "isRefined": false
                },
                {
                    "label": "TDES",
                    "value": [
                        "TDES"
                    ],
                    "count": 1048,
                    "isRefined": false
                },
                {
                    "label": "RC4_128",
                    "value": [
                        "RC4_128"
                    ],
                    "count": 752,
                    "isRefined": false
                },
                {
                    "label": "DES_56",
                    "value": [
                        "DES_56"
                    ],
                    "count": 563,
                    "isRefined": false
                },
                {
                    "label": "CHACHA_20_POLY1305",
                    "value": [
                        "CHACHA_20_POLY1305"
                    ],
                    "count": 326,
                    "isRefined": false
                },
                {
                    "label": "SEED",
                    "value": [
                        "SEED"
                    ],
                    "count": 313,
                    "isRefined": false
                },
                {
                    "label": "DES_40",
                    "value": [
                        "DES_40"
                    ],
                    "count": 297,
                    "isRefined": false
                },
                {
                    "label": "RC4_40",
                    "value": [
                        "RC4_40"
                    ],
                    "count": 227,
                    "isRefined": false
                },
                {
                    "label": "RC2_40",
                    "value": [
                        "RC2_40"
                    ],
                    "count": 143,
                    "isRefined": false
                },
                {
                    "label": "IDEA",
                    "value": [
                        "IDEA"
                    ],
                    "count": 135,
                    "isRefined": false
                },
                {
                    "label": "FORTEZZA",
                    "value": [
                        "FORTEZZA"
                    ],
                    "count": 111,
                    "isRefined": false
                },
                {
                    "label": "FORTEZZA_CBC",
                    "value": [
                        "FORTEZZA_CBC"
                    ],
                    "count": 50,
                    "isRefined": false
                },
                {
                    "label": "SM4",
                    "value": [
                        "SM4"
                    ],
                    "count": 11,
                    "isRefined": false
                }
            ],
            "modeOfOperation": [
                {
                    "label": "CBC",
                    "value": [
                        "CBC"
                    ],
                    "count": 8749,
                    "isRefined": false
                },
                {
                    "label": "GCM",
                    "value": [
                        "GCM"
                    ],
                    "count": 5880,
                    "isRefined": false
                },
                {
                    "label": "CCM",
                    "value": [
                        "CCM"
                    ],
                    "count": 1222,
                    "isRefined": false
                },
                {
                    "label": "CTR",
                    "value": [
                        "CTR"
                    ],
                    "count": 107,
                    "isRefined": false
                }
            ],
            "signature": [
                {
                    "label": "PSK_AUTH",
                    "value": [
                        "PSK_AUTH"
                    ],
                    "count": 4510,
                    "isRefined": false
                },
                {
                    "label": "RSA_SIG_2048",
                    "value": [
                        "RSA_SIG_2048"
                    ],
                    "count": 3379,
                    "isRefined": false
                },
                {
                    "label": "ECDSA_SECP256r1",
                    "value": [
                        "ECDSA_SECP256r1"
                    ],
                    "count": 2394,
                    "isRefined": false
                },
                {
                    "label": "ANON",
                    "value": [
                        "ANON"
                    ],
                    "count": 1429,
                    "isRefined": false
                },
                {
                    "label": "RSA_SIG_512",
                    "value": [
                        "RSA_SIG_512"
                    ],
                    "count": 1212,
                    "isRefined": false
                },
                {
                    "label": "RSA_SIG_4096",
                    "value": [
                        "RSA_SIG_4096"
                    ],
                    "count": 1149,
                    "isRefined": false
                },
                {
                    "label": "RSA_SIG_1024",
                    "value": [
                        "RSA_SIG_1024"
                    ],
                    "count": 1142,
                    "isRefined": false
                },
                {
                    "label": "DSA_DSS_3072",
                    "value": [
                        "DSA_DSS_3072"
                    ],
                    "count": 644,
                    "isRefined": false
                },
                {
                    "label": "DSA_DSS_2048",
                    "value": [
                        "DSA_DSS_2048"
                    ],
                    "count": 630,
                    "isRefined": false
                },
                {
                    "label": "DSA_DSS_1024",
                    "value": [
                        "DSA_DSS_1024"
                    ],
                    "count": 624,
                    "isRefined": false
                },
                {
                    "label": "DSA_DSS_7680",
                    "value": [
                        "DSA_DSS_7680"
                    ],
                    "count": 586,
                    "isRefined": false
                },
                {
                    "label": "DILITHIUM",
                    "value": [
                        "DILITHIUM"
                    ],
                    "count": 568,
                    "isRefined": false
                },
                {
                    "label": "KEA",
                    "value": [
                        "KEA"
                    ],
                    "count": 111,
                    "isRefined": false
                },
                {
                    "label": "RSA_SIG",
                    "value": [
                        "RSA_SIG"
                    ],
                    "count": 104,
                    "isRefined": false
                },
                {
                    "label": "DSA",
                    "value": [
                        "DSA"
                    ],
                    "count": 100,
                    "isRefined": false
                },
                {
                    "label": "ECDSA_ED448",
                    "value": [
                        "ECDSA_ED448"
                    ],
                    "count": 49,
                    "isRefined": false
                },
                {
                    "label": "NULL_SIG",
                    "value": [
                        "NULL_SIG"
                    ],
                    "count": 48,
                    "isRefined": false
                },
                {
                    "label": "ECDSA_ED25519",
                    "value": [
                        "ECDSA_ED25519"
                    ],
                    "count": 46,
                    "isRefined": false
                },
                {
                    "label": "ECDSA",
                    "value": [
                        "ECDSA"
                    ],
                    "count": 3,
                    "isRefined": false
                }
            ],
            "hash": [
                {
                    "label": "SHA_1",
                    "value": [
                        "SHA_1"
                    ],
                    "count": 5992,
                    "isRefined": false
                },
                {
                    "label": "SHA_256",
                    "value": [
                        "SHA_256"
                    ],
                    "count": 5673,
                    "isRefined": false
                },
                {
                    "label": "SHA_384",
                    "value": [
                        "SHA_384"
                    ],
                    "count": 5628,
                    "isRefined": false
                },
                {
                    "label": "MD5",
                    "value": [
                        "MD5"
                    ],
                    "count": 718,
                    "isRefined": false
                },
                {
                    "label": "NULL_HASH",
                    "value": [
                        "NULL_HASH"
                    ],
                    "count": 48,
                    "isRefined": false
                },
                {
                    "label": "SM3",
                    "value": [
                        "SM3"
                    ],
                    "count": 11,
                    "isRefined": false
                }
            ],
            "mac": [
                {
                    "label": "HMAC_SHA1_LT_160",
                    "value": [
                        "HMAC_SHA1_LT_160"
                    ],
                    "count": 5992,
                    "isRefined": false
                },
                {
                    "label": "HMAC_SHA2_256",
                    "value": [
                        "HMAC_SHA2_256"
                    ],
                    "count": 5673,
                    "isRefined": false
                },
                {
                    "label": "HMAC_SHA2_384",
                    "value": [
                        "HMAC_SHA2_384"
                    ],
                    "count": 5628,
                    "isRefined": false
                },
                {
                    "label": "HMAC_MD5_LT_128",
                    "value": [
                        "HMAC_MD5_LT_128"
                    ],
                    "count": 718,
                    "isRefined": false
                }
            ],
            "osType": [],
            "protocol": [
                {
                    "label": "TLS 1.2",
                    "value": [
                        "TLS 1.2"
                    ],
                    "count": 8483,
                    "isRefined": false
                },
                {
                    "label": "TLS 1.1",
                    "value": [
                        "TLS 1.1"
                    ],
                    "count": 5400,
                    "isRefined": false
                },
                {
                    "label": "TLS 1.0",
                    "value": [
                        "TLS 1.0"
                    ],
                    "count": 5380,
                    "isRefined": false
                },
                {
                    "label": "SSL 3",
                    "value": [
                        "SSL 3"
                    ],
                    "count": 112,
                    "isRefined": false
                },
                {
                    "label": "TLS 1.3",
                    "value": [
                        "TLS 1.3"
                    ],
                    "count": 38,
                    "isRefined": false
                }
            ],
            "clientos": [],
            "serveros": []
        },
        "count": 20010,
        "bubbles": [
            {
                "count": 12141,
                "name": "Broken",
                "value": "12,141",
                "groupName": "UNACCEPTABLE",
                "order": 0,
                "x": 62.5647616421535,
                "y": 30.20449468016522,
                "radius": 7,
                "filter": "url(#bubble-filter-0)"
            },
            {
                "count": 1969,
                "name": "Weak",
                "value": "1,969",
                "groupName": "UNACCEPTABLE",
                "order": 0,
                "x": 54.35421161405085,
                "y": 37.88413137235354,
                "radius": 3.647606492543462,
                "filter": "url(#bubble-filter-0)"
            },
            {
                "count": 1690,
                "name": "Not Recommended",
                "value": "1,690",
                "groupName": "CAUTION",
                "order": 1,
                "x": 45.623270191926494,
                "y": 37.876499376271525,
                "radius": 3.5556562577243143,
                "filter": "url(#bubble-filter-1)"
            },
            {
                "count": 1624,
                "name": "Unknown or Custom",
                "value": "1,624",
                "groupName": "CAUTION",
                "order": 1,
                "x": 38.75322435886134,
                "y": 32.64657032125449,
                "radius": 3.5339045892724723,
                "filter": "url(#bubble-filter-1)"
            },
            {
                "count": 1267,
                "name": "Nonstandard QSC",
                "value": "1,267",
                "groupName": "CAUTION",
                "order": 1,
                "x": 36.411880319726755,
                "y": 24.43166598327135,
                "radius": 3.4162478371920573,
                "filter": "url(#bubble-filter-1)"
            },
            {
                "count": 718,
                "name": "Misused",
                "value": "718",
                "groupName": "UNACCEPTABLE",
                "order": 0,
                "x": 39.28579866244337,
                "y": 16.62349179560482,
                "radius": 3.2353135041608305,
                "filter": "url(#bubble-filter-0)"
            },
            {
                "count": 4,
                "name": "Unspecified Parameters",
                "value": "4",
                "groupName": "CAUTION",
                "order": 1,
                "x": 45.84804499868442,
                "y": 12.04927532270682,
                "radius": 3,
                "filter": "url(#bubble-filter-1)"
            }
        ],
        "currentRefinement": {
            "Connection Crypto": [
                "Unacceptable",
                "Caution"
            ],
            "Key Exchange": [],
            "Bulk Encryption": [],
            "Mode of Operation": [],
            "Signature": [],
            "HASH": [],
            "MAC": [],
            "OS": [],
            "Protocol": [],
            "Client OS": [],
            "Server OS": [],
            "Device Crypto": [
                "Unacceptable",
                "Caution"
            ]
        },
        "posture": "connections",
        "q": "",
        "refinementList": {
            "refinementList": "cryptoStrength:=[`Unacceptable`,`Caution`] && cryptoStrength:=[`Unacceptable`,`Caution`] "
        },
        "reportWidget": []
    },
    {
        "filters": {
            "cryptoStrength": [
                {
                    "label": "Strong",
                    "value": [
                        "Quantum Safe"
                    ],
                    "count": 302,
                    "isRefined": true
                },
                {
                    "label": "Quantum Safe",
                    "value": [
                        "Strong"
                    ],
                    "count": 295,
                    "isRefined": true
                },
                {
                    "label": "Unacceptable",
                    "value": [
                        "Strong",
                        "Quantum Safe",
                        "Unacceptable"
                    ],
                    "count": 14828,
                    "isRefined": false
                },
                {
                    "label": "Broken",
                    "value": [
                        "Strong",
                        "Quantum Safe",
                        "Broken"
                    ],
                    "count": 12141,
                    "isRefined": false
                },
                {
                    "label": "Caution",
                    "value": [
                        "Strong",
                        "Quantum Safe",
                        "Caution"
                    ],
                    "count": 4585,
                    "isRefined": false
                },
                {
                    "label": "Weak",
                    "value": [
                        "Strong",
                        "Quantum Safe",
                        "Weak"
                    ],
                    "count": 1969,
                    "isRefined": false
                },
                {
                    "label": "Not Recommended",
                    "value": [
                        "Strong",
                        "Quantum Safe",
                        "Not Recommended"
                    ],
                    "count": 1690,
                    "isRefined": false
                },
                {
                    "label": "Unknown or Custom",
                    "value": [
                        "Strong",
                        "Quantum Safe",
                        "Unknown or Custom"
                    ],
                    "count": 1624,
                    "isRefined": false
                },
                {
                    "label": "Nonstandard QSC",
                    "value": [
                        "Strong",
                        "Quantum Safe",
                        "Nonstandard QSC"
                    ],
                    "count": 1267,
                    "isRefined": false
                },
                {
                    "label": "Misused",
                    "value": [
                        "Strong",
                        "Quantum Safe",
                        "Misused"
                    ],
                    "count": 718,
                    "isRefined": false
                },
                {
                    "label": "Strong - Quantum Broken",
                    "value": [
                        "Strong",
                        "Quantum Safe",
                        "Strong - Quantum Broken"
                    ],
                    "count": 217,
                    "isRefined": false
                },
                {
                    "label": "QS - Security Level 1",
                    "value": [
                        "Strong",
                        "Quantum Safe",
                        "QS - Security Level 1"
                    ],
                    "count": 140,
                    "isRefined": false
                },
                {
                    "label": "QS - Security Level 2",
                    "value": [
                        "Strong",
                        "Quantum Safe",
                        "QS - Security Level 2"
                    ],
                    "count": 91,
                    "isRefined": false
                },
                {
                    "label": "Strong - Quantum Unknown",
                    "value": [
                        "Strong",
                        "Quantum Safe",
                        "Strong - Quantum Unknown"
                    ],
                    "count": 85,
                    "isRefined": false
                },
                {
                    "label": "QS - Security Level 4",
                    "value": [
                        "Strong",
                        "Quantum Safe",
                        "QS - Security Level 4"
                    ],
                    "count": 64,
                    "isRefined": false
                },
                {
                    "label": "Unspecified Parameters",
                    "value": [
                        "Strong",
                        "Quantum Safe",
                        "Unspecified Parameters"
                    ],
                    "count": 4,
                    "isRefined": false
                }
            ],
            "keyExchange": [
                {
                    "label": "FFDHE_2048",
                    "value": [
                        "FFDHE_2048"
                    ],
                    "count": 41,
                    "isRefined": false
                },
                {
                    "label": "FFDHE_3072",
                    "value": [
                        "FFDHE_3072"
                    ],
                    "count": 40,
                    "isRefined": false
                },
                {
                    "label": "ECDHE_x25519",
                    "value": [
                        "ECDHE_x25519"
                    ],
                    "count": 37,
                    "isRefined": false
                },
                {
                    "label": "ECDHE_SECP384r1",
                    "value": [
                        "ECDHE_SECP384r1"
                    ],
                    "count": 35,
                    "isRefined": false
                },
                {
                    "label": "ECDHE_x448",
                    "value": [
                        "ECDHE_x448"
                    ],
                    "count": 35,
                    "isRefined": false
                },
                {
                    "label": "ECDHE_SECP256r1",
                    "value": [
                        "ECDHE_SECP256r1"
                    ],
                    "count": 29,
                    "isRefined": false
                }
            ],
            "bulkEncryption": [
                {
                    "label": "AES_128",
                    "value": [
                        "AES_128"
                    ],
                    "count": 204,
                    "isRefined": false
                },
                {
                    "label": "SM4",
                    "value": [
                        "SM4"
                    ],
                    "count": 97,
                    "isRefined": false
                },
                {
                    "label": "AES_256",
                    "value": [
                        "AES_256"
                    ],
                    "count": 78,
                    "isRefined": false
                },
                {
                    "label": "CHACHA_20_POLY1305",
                    "value": [
                        "CHACHA_20_POLY1305"
                    ],
                    "count": 62,
                    "isRefined": false
                },
                {
                    "label": "ARIA_128",
                    "value": [
                        "ARIA_128"
                    ],
                    "count": 19,
                    "isRefined": false
                },
                {
                    "label": "CAMELLIA_256",
                    "value": [
                        "CAMELLIA_256"
                    ],
                    "count": 16,
                    "isRefined": false
                },
                {
                    "label": "CAMELLIA_128",
                    "value": [
                        "CAMELLIA_128"
                    ],
                    "count": 15,
                    "isRefined": false
                },
                {
                    "label": "ARIA_256",
                    "value": [
                        "ARIA_256"
                    ],
                    "count": 12,
                    "isRefined": false
                }
            ],
            "modeOfOperation": [
                {
                    "label": "GCM",
                    "value": [
                        "GCM"
                    ],
                    "count": 247,
                    "isRefined": false
                },
                {
                    "label": "CCM",
                    "value": [
                        "CCM"
                    ],
                    "count": 194,
                    "isRefined": false
                }
            ],
            "signature": [
                {
                    "label": "RSA_SIG_2048",
                    "value": [
                        "RSA_SIG_2048"
                    ],
                    "count": 82,
                    "isRefined": false
                },
                {
                    "label": "RSA_SIG_4096",
                    "value": [
                        "RSA_SIG_4096"
                    ],
                    "count": 31,
                    "isRefined": false
                },
                {
                    "label": "ECDSA_SECP256r1",
                    "value": [
                        "ECDSA_SECP256r1"
                    ],
                    "count": 30,
                    "isRefined": false
                },
                {
                    "label": "ECDSA_ED448",
                    "value": [
                        "ECDSA_ED448"
                    ],
                    "count": 10,
                    "isRefined": false
                },
                {
                    "label": "ECDSA_ED25519",
                    "value": [
                        "ECDSA_ED25519"
                    ],
                    "count": 8,
                    "isRefined": false
                }
            ],
            "hash": [
                {
                    "label": "SHA_256",
                    "value": [
                        "SHA_256"
                    ],
                    "count": 327,
                    "isRefined": false
                },
                {
                    "label": "SHA_384",
                    "value": [
                        "SHA_384"
                    ],
                    "count": 127,
                    "isRefined": false
                },
                {
                    "label": "SM3",
                    "value": [
                        "SM3"
                    ],
                    "count": 97,
                    "isRefined": false
                }
            ],
            "mac": [
                {
                    "label": "HMAC_SHA2_256",
                    "value": [
                        "HMAC_SHA2_256"
                    ],
                    "count": 327,
                    "isRefined": false
                },
                {
                    "label": "HMAC_SHA2_384",
                    "value": [
                        "HMAC_SHA2_384"
                    ],
                    "count": 127,
                    "isRefined": false
                }
            ],
            "osType": [],
            "protocol": [
                {
                    "label": "TLS 1.3",
                    "value": [
                        "TLS 1.3"
                    ],
                    "count": 443,
                    "isRefined": false
                },
                {
                    "label": "TLS 1.2",
                    "value": [
                        "TLS 1.2"
                    ],
                    "count": 154,
                    "isRefined": false
                }
            ],
            "clientos": [],
            "serveros": []
        },
        "count": 20010,
        "bubbles": [
            {
                "count": 217,
                "name": "Strong - Quantum Broken",
                "value": "217",
                "groupName": "STRONG_CLASSIC",
                "order": 2,
                "x": 63.809396057092194,
                "y": 31.351423504881918,
                "radius": 8.333333333333334,
                "filter": "url(#bubble-filter-2)"
            },
            {
                "count": 140,
                "name": "QS - Security Level 1",
                "value": "140",
                "groupName": "STRONG_QSC",
                "order": 3,
                "x": 52.03385995890232,
                "y": 40.063313502266816,
                "radius": 5.98474945533769,
                "filter": "url(#bubble-filter-3)"
            },
            {
                "count": 91,
                "name": "QS - Security Level 2",
                "value": "91",
                "groupName": "STRONG_QSC",
                "order": 3,
                "x": 40.151851470449365,
                "y": 36.578167840375684,
                "radius": 4.490196078431373,
                "filter": "url(#bubble-filter-3)"
            },
            {
                "count": 85,
                "name": "Strong - Quantum Unknown",
                "value": "85",
                "groupName": "STRONG_CLASSIC",
                "order": 2,
                "x": 34.91299057825718,
                "y": 26.849904513277227,
                "radius": 4.30718954248366,
                "filter": "url(#bubble-filter-2)"
            },
            {
                "count": 64,
                "name": "QS - Security Level 4",
                "value": "64",
                "groupName": "STRONG_QSC",
                "order": 3,
                "x": 37.29688347043953,
                "y": 16.65309455927482,
                "radius": 3.6666666666666665,
                "filter": "url(#bubble-filter-3)"
            }
        ],
        "currentRefinement": {
            "Connection Crypto": [
                "Strong",
                "Quantum Safe"
            ],
            "Key Exchange": [],
            "Bulk Encryption": [],
            "Mode of Operation": [],
            "Signature": [],
            "HASH": [],
            "MAC": [],
            "OS": [],
            "Protocol": [],
            "Client OS": [],
            "Server OS": []
        },
        "posture": "connections",
        "q": "",
        "refinementList": {
            "refinementList": "cryptoStrength:=[`Strong`,`Quantum Safe`] "
        },
        "reportWidget": []
    },
    
]

exports.sampleReportDataDevice = [
    {
        "filters": {
            "cryptoStrength": [
                {
                    "label": "Unacceptable",
                    "value": [
                        "Caution"
                    ],
                    "count": 29643,
                    "isRefined": true
                },
                {
                    "label": "Caution",
                    "value": [
                        "Unacceptable"
                    ],
                    "count": 9158,
                    "isRefined": true
                },
                {
                    "label": "Broken",
                    "value": [
                        "Unacceptable",
                        "Caution",
                        "Broken"
                    ],
                    "count": 24275,
                    "isRefined": false
                },
                {
                    "label": "Weak",
                    "value": [
                        "Unacceptable",
                        "Caution",
                        "Weak"
                    ],
                    "count": 3933,
                    "isRefined": false
                },
                {
                    "label": "Not Recommended",
                    "value": [
                        "Unacceptable",
                        "Caution",
                        "Not Recommended"
                    ],
                    "count": 3379,
                    "isRefined": false
                },
                {
                    "label": "Unknown or Custom",
                    "value": [
                        "Unacceptable",
                        "Caution",
                        "Unknown or Custom"
                    ],
                    "count": 3243,
                    "isRefined": false
                },
                {
                    "label": "Nonstandard QSC",
                    "value": [
                        "Unacceptable",
                        "Caution",
                        "Nonstandard QSC"
                    ],
                    "count": 2532,
                    "isRefined": false
                },
                {
                    "label": "Misused",
                    "value": [
                        "Unacceptable",
                        "Caution",
                        "Misused"
                    ],
                    "count": 1435,
                    "isRefined": false
                },
                {
                    "label": "Strong",
                    "value": [
                        "Unacceptable",
                        "Caution",
                        "Strong"
                    ],
                    "count": 600,
                    "isRefined": false
                },
                {
                    "label": "Quantum Safe",
                    "value": [
                        "Unacceptable",
                        "Caution",
                        "Quantum Safe"
                    ],
                    "count": 587,
                    "isRefined": false
                },
                {
                    "label": "Strong - Quantum Broken",
                    "value": [
                        "Unacceptable",
                        "Caution",
                        "Strong - Quantum Broken"
                    ],
                    "count": 431,
                    "isRefined": false
                },
                {
                    "label": "QS - Security Level 1",
                    "value": [
                        "Unacceptable",
                        "Caution",
                        "QS - Security Level 1"
                    ],
                    "count": 279,
                    "isRefined": false
                },
                {
                    "label": "QS - Security Level 2",
                    "value": [
                        "Unacceptable",
                        "Caution",
                        "QS - Security Level 2"
                    ],
                    "count": 180,
                    "isRefined": false
                },
                {
                    "label": "Strong - Quantum Unknown",
                    "value": [
                        "Unacceptable",
                        "Caution",
                        "Strong - Quantum Unknown"
                    ],
                    "count": 169,
                    "isRefined": false
                },
                {
                    "label": "QS - Security Level 4",
                    "value": [
                        "Unacceptable",
                        "Caution",
                        "QS - Security Level 4"
                    ],
                    "count": 128,
                    "isRefined": false
                },
                {
                    "label": "Unspecified Parameters",
                    "value": [
                        "Unacceptable",
                        "Caution",
                        "Unspecified Parameters"
                    ],
                    "count": 4,
                    "isRefined": false
                },
                {
                    "label": "Pending",
                    "count": 82,
                    "isRefined": false,
                    "value": [
                        "Pending"
                    ]
                }
            ],
            "keyExchange": [
                {
                    "label": "KRB5",
                    "value": [
                        "KRB5"
                    ],
                    "count": 1440,
                    "isRefined": false
                },
                {
                    "label": "SIKE",
                    "value": [
                        "SIKE"
                    ],
                    "count": 1298,
                    "isRefined": false
                },
                {
                    "label": "KYBER",
                    "value": [
                        "KYBER"
                    ],
                    "count": 968,
                    "isRefined": false
                },
                {
                    "label": "SRP",
                    "value": [
                        "SRP"
                    ],
                    "count": 900,
                    "isRefined": false
                },
                {
                    "label": "SABER",
                    "value": [
                        "SABER"
                    ],
                    "count": 890,
                    "isRefined": false
                },
                {
                    "label": "GOSTR341112",
                    "value": [
                        "GOSTR341112"
                    ],
                    "count": 724,
                    "isRefined": false
                },
                {
                    "label": "ECCPWD",
                    "value": [
                        "ECCPWD"
                    ],
                    "count": 504,
                    "isRefined": false
                },
                {
                    "label": "NHDH",
                    "value": [
                        "NHDH"
                    ],
                    "count": 354,
                    "isRefined": false
                }
            ],
            "bulkEncryption": [
                {
                    "label": "SEED",
                    "value": [
                        "SEED"
                    ],
                    "count": 626,
                    "isRefined": false
                },
                {
                    "label": "IDEA",
                    "value": [
                        "IDEA"
                    ],
                    "count": 270,
                    "isRefined": false
                },
                {
                    "label": "FORTEZZA",
                    "value": [
                        "FORTEZZA"
                    ],
                    "count": 222,
                    "isRefined": false
                },
                {
                    "label": "SM4",
                    "value": [
                        "SM4"
                    ],
                    "count": 23,
                    "isRefined": false
                }
            ],
            "modeOfOperation": [
                {
                    "label": "CBC",
                    "value": [
                        "CBC"
                    ],
                    "count": 17492,
                    "isRefined": false
                },
                {
                    "label": "GCM",
                    "value": [
                        "GCM"
                    ],
                    "count": 11755,
                    "isRefined": false
                },
                {
                    "label": "CCM",
                    "value": [
                        "CCM"
                    ],
                    "count": 2445,
                    "isRefined": false
                },
                {
                    "label": "CTR",
                    "value": [
                        "CTR"
                    ],
                    "count": 214,
                    "isRefined": false
                }
            ],
            "signature": [
                {
                    "label": "KEA",
                    "value": [
                        "KEA"
                    ],
                    "count": 222,
                    "isRefined": false
                },
                {
                    "label": "ECDSA",
                    "value": [
                        "ECDSA"
                    ],
                    "count": 4,
                    "isRefined": false
                }
            ],
            "hash": [
                {
                    "label": "MD5",
                    "value": [
                        "MD5"
                    ],
                    "count": 1436,
                    "isRefined": false
                },
                {
                    "label": "SM3",
                    "value": [
                        "SM3"
                    ],
                    "count": 23,
                    "isRefined": false
                }
            ],
            "mac": [],
            "osType": [],
            "protocol": [
                {
                    "label": "TLS 1.2",
                    "value": [
                        "TLS 1.2"
                    ],
                    "count": 16958,
                    "isRefined": false
                },
                {
                    "label": "TLS 1.1",
                    "value": [
                        "TLS 1.1"
                    ],
                    "count": 10799,
                    "isRefined": false
                },
                {
                    "label": "TLS 1.0",
                    "value": [
                        "TLS 1.0"
                    ],
                    "count": 10759,
                    "isRefined": false
                },
                {
                    "label": "SSL 3",
                    "value": [
                        "SSL 3"
                    ],
                    "count": 224,
                    "isRefined": false
                },
                {
                    "label": "TLS 1.3",
                    "value": [
                        "TLS 1.3"
                    ],
                    "count": 81,
                    "isRefined": false
                }
            ],
            "clientos": [],
            "serveros": []
        },
        "count": 38801,
        "bubbles": [
            {
                "count": 24275,
                "groupName": "UNACCEPTABLE",
                "name": "Broken",
                "order": 0,
                "value": "24,275",
                "x": 61.92927773024188,
                "y": 29.64029447715932,
                "radius": 6.333333333333334,
                "filter": "url(#bubble-filter-0)"
            },
            {
                "count": 3933,
                "groupName": "UNACCEPTABLE",
                "name": "Weak",
                "order": 0,
                "value": "3,933",
                "x": 54.969188389498555,
                "y": 36.796065731830794,
                "radius": 3.260228255943307,
                "filter": "url(#bubble-filter-0)"
            },
            {
                "count": 3379,
                "groupName": "CAUTION",
                "name": "Not Recommended",
                "order": 1,
                "value": "3,379",
                "x": 47.345819426455456,
                "y": 37.52179402014818,
                "radius": 3.176534410064137,
                "filter": "url(#bubble-filter-1)"
            },
            {
                "count": 3243,
                "groupName": "CAUTION",
                "name": "Unknown or Custom",
                "order": 1,
                "value": "3,243",
                "x": 40.73535557455975,
                "y": 33.832121130858596,
                "radius": 3.155988628404269,
                "filter": "url(#bubble-filter-1)"
            },
            {
                "count": 2532,
                "groupName": "CAUTION",
                "name": "Nonstandard QSC",
                "order": 1,
                "value": "2,532",
                "x": 37.38002088517972,
                "y": 27.139188430573583,
                "radius": 3.0485764904618686,
                "filter": "url(#bubble-filter-1)"
            },
            {
                "count": 1435,
                "groupName": "UNACCEPTABLE",
                "name": "Misused",
                "order": 0,
                "value": "1,435",
                "x": 38.257744160124794,
                "y": 19.90496047209478,
                "radius": 2.882850589867194,
                "filter": "url(#bubble-filter-0)"
            },
            {
                "count": 82,
                "groupName": "PENDING",
                "name": "pending",
                "order": 4,
                "value": "82",
                "x": 42.69860844107628,
                "y": 14.48669027835299,
                "radius": 2.6784502767362977,
                "filter": "url(#bubble-filter-4)"
            },
            {
                "count": 4,
                "groupName": "CAUTION",
                "name": "Unspecified Parameters",
                "order": 1,
                "value": "4",
                "x": 49.11873518531989,
                "y": 12.230373054532608,
                "radius": 2.666666666666667,
                "filter": "url(#bubble-filter-1)"
            }
        ],
        "currentRefinement": {
            "Device Crypto": [
                "Unacceptable",
                "Caution"
            ],
            "Key Exchange": [],
            "Bulk Encryption": [],
            "Mode of Operation": [],
            "Signature": [],
            "HASH": [],
            "MAC": [],
            "OS": [],
            "Protocol": [],
            "Client OS": [],
            "Server OS": []
        },
        "posture": "devices",
        "q": "",
        "refinementList": {
            "refinementList": "cryptoStrength:=[`Unacceptable`,`Caution`] "
        },
        "reportWidget": []
    },
    {
        "filters": {
            "cryptoStrength": [
                {
                    "label": "Strong",
                    "value": [
                        "Quantum Safe"
                    ],
                    "count": 600,
                    "isRefined": true
                },
                {
                    "label": "Quantum Safe",
                    "value": [
                        "Strong"
                    ],
                    "count": 587,
                    "isRefined": true
                },
                {
                    "label": "Unacceptable",
                    "value": [
                        "Strong",
                        "Quantum Safe",
                        "Unacceptable"
                    ],
                    "count": 29643,
                    "isRefined": false
                },
                {
                    "label": "Broken",
                    "value": [
                        "Strong",
                        "Quantum Safe",
                        "Broken"
                    ],
                    "count": 24275,
                    "isRefined": false
                },
                {
                    "label": "Caution",
                    "value": [
                        "Strong",
                        "Quantum Safe",
                        "Caution"
                    ],
                    "count": 9158,
                    "isRefined": false
                },
                {
                    "label": "Weak",
                    "value": [
                        "Strong",
                        "Quantum Safe",
                        "Weak"
                    ],
                    "count": 3933,
                    "isRefined": false
                },
                {
                    "label": "Not Recommended",
                    "value": [
                        "Strong",
                        "Quantum Safe",
                        "Not Recommended"
                    ],
                    "count": 3379,
                    "isRefined": false
                },
                {
                    "label": "Unknown or Custom",
                    "value": [
                        "Strong",
                        "Quantum Safe",
                        "Unknown or Custom"
                    ],
                    "count": 3243,
                    "isRefined": false
                },
                {
                    "label": "Nonstandard QSC",
                    "value": [
                        "Strong",
                        "Quantum Safe",
                        "Nonstandard QSC"
                    ],
                    "count": 2532,
                    "isRefined": false
                },
                {
                    "label": "Misused",
                    "value": [
                        "Strong",
                        "Quantum Safe",
                        "Misused"
                    ],
                    "count": 1435,
                    "isRefined": false
                },
                {
                    "label": "Strong - Quantum Broken",
                    "value": [
                        "Strong",
                        "Quantum Safe",
                        "Strong - Quantum Broken"
                    ],
                    "count": 431,
                    "isRefined": false
                },
                {
                    "label": "QS - Security Level 1",
                    "value": [
                        "Strong",
                        "Quantum Safe",
                        "QS - Security Level 1"
                    ],
                    "count": 279,
                    "isRefined": false
                },
                {
                    "label": "QS - Security Level 2",
                    "value": [
                        "Strong",
                        "Quantum Safe",
                        "QS - Security Level 2"
                    ],
                    "count": 180,
                    "isRefined": false
                },
                {
                    "label": "Strong - Quantum Unknown",
                    "value": [
                        "Strong",
                        "Quantum Safe",
                        "Strong - Quantum Unknown"
                    ],
                    "count": 169,
                    "isRefined": false
                },
                {
                    "label": "QS - Security Level 4",
                    "value": [
                        "Strong",
                        "Quantum Safe",
                        "QS - Security Level 4"
                    ],
                    "count": 128,
                    "isRefined": false
                },
                {
                    "label": "Unspecified Parameters",
                    "value": [
                        "Strong",
                        "Quantum Safe",
                        "Unspecified Parameters"
                    ],
                    "count": 4,
                    "isRefined": false
                },
                {
                    "label": "Pending",
                    "count": 82,
                    "isRefined": false,
                    "value": [
                        "Pending"
                    ]
                }
            ],
            "keyExchange": [],
            "bulkEncryption": [
                {
                    "label": "SM4",
                    "value": [
                        "SM4"
                    ],
                    "count": 193,
                    "isRefined": false
                }
            ],
            "modeOfOperation": [
                {
                    "label": "GCM",
                    "value": [
                        "GCM"
                    ],
                    "count": 490,
                    "isRefined": false
                },
                {
                    "label": "CCM",
                    "value": [
                        "CCM"
                    ],
                    "count": 387,
                    "isRefined": false
                }
            ],
            "signature": [],
            "hash": [
                {
                    "label": "SM3",
                    "value": [
                        "SM3"
                    ],
                    "count": 193,
                    "isRefined": false
                }
            ],
            "mac": [],
            "osType": [],
            "protocol": [
                {
                    "label": "TLS 1.3",
                    "value": [
                        "TLS 1.3"
                    ],
                    "count": 880,
                    "isRefined": false
                },
                {
                    "label": "TLS 1.2",
                    "value": [
                        "TLS 1.2"
                    ],
                    "count": 307,
                    "isRefined": false
                }
            ],
            "clientos": [],
            "serveros": []
        },
        "count": 1187,
        "bubbles": [
            {
                "count": 431,
                "groupName": "STRONG_CLASSIC",
                "name": "Strong - Quantum Broken",
                "order": 2,
                "value": "431",
                "x": 63.19106064921863,
                "y": 30.775458332343483,
                "radius": 7.666666666666667,
                "filter": "url(#bubble-filter-2)"
            },
            {
                "count": 279,
                "groupName": "STRONG_QSC",
                "name": "QS - Security Level 1",
                "order": 3,
                "value": "279",
                "x": 52.685307398513814,
                "y": 39.14740697709255,
                "radius": 5.7793696275071635,
                "filter": "url(#bubble-filter-3)"
            },
            {
                "count": 180,
                "groupName": "STRONG_QSC",
                "name": "QS - Security Level 2",
                "order": 3,
                "value": "180",
                "x": 41.36653360855474,
                "y": 36.52489731267855,
                "radius": 4.5501432664756445,
                "filter": "url(#bubble-filter-3)"
            },
            {
                "count": 169,
                "groupName": "STRONG_CLASSIC",
                "name": "Strong - Quantum Unknown",
                "order": 2,
                "value": "169",
                "x": 35.82121134379413,
                "y": 27.5143492682298,
                "radius": 4.413562559694365,
                "filter": "url(#bubble-filter-2)"
            },
            {
                "count": 128,
                "groupName": "STRONG_QSC",
                "name": "QS - Security Level 4",
                "order": 3,
                "value": "128",
                "x": 37.691110366888545,
                "y": 17.526631549302458,
                "radius": 3.9044890162368677,
                "filter": "url(#bubble-filter-3)"
            },
            {
                "count": 82,
                "groupName": "PENDING",
                "name": "pending",
                "order": 4,
                "value": "82",
                "x": 44.86736742681199,
                "y": 11.54577825109719,
                "radius": 3.3333333333333335,
                "filter": "url(#bubble-filter-4)"
            }
        ],
        "currentRefinement": {
            "Device Crypto": [
                "Strong",
                "Quantum Safe"
            ],
            "Key Exchange": [],
            "Bulk Encryption": [],
            "Mode of Operation": [],
            "Signature": [],
            "HASH": [],
            "MAC": [],
            "OS": [],
            "Protocol": [],
            "Client OS": [],
            "Server OS": []
        },
        "posture": "devices",
        "q": "",
        "refinementList": {
            "refinementList": "cryptoStrength:=[`Strong`,`Quantum Safe`] "
        },
        "reportWidget": []
    }
]


