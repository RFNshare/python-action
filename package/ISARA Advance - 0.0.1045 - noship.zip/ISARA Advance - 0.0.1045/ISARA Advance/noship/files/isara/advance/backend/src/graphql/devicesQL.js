/**
 * @file devicesQL.js - 0.0.1045 - ea4595bfd3488684d225574ed7d4c198074d49ba
 * 
 * @copyright Copyright (C) 2016-2023, ISARA Corporation, All Rights Reserved.
 * 
 * @license The code and other content set out herein is not in the public
 * domain, is considered a trade secret and is confidential to ISARA
 * Corporation. Use, reproduction or distribution, in whole or in part, of such
 * code or other content is strictly prohibited except by express written
 * permission of ISARA Corporation. Please contact ISARA Corporation at
 * info@isara.com for more information.
 */

/**
 * This module contains device focused queries.
 * @module graphql/devicesQL
 */

var { filterQuery } = require('./filterQL')

const { collectAggregateResultsLikeFacet, getSort, pathsToAggregates, roles, postureModifiableTables, postureCheckExistingTables, populateAddedBy, updateTagUsedDate } = require('./commonQL')
const {postureCategories} = require('../graphql/categoryConstants')
const { paths, allTypes } = require('../isaraql/schemaDiscovery')

const { makeFilterCategories } = require('../util/filterCategoryHelpers')
const { getProtocolVariantsForDevices } = require('../util/flatFacetHelpers')
const { createUpdateDelete, registerHook, registerTreeHook, CUD_OP_INSERT, CUD_OP_PRE, CUD_OP_UPDATE, CUD_OP_POST, CUD_OP_POST_CHILDREN } = require('../isaraql/cud')

const { ipAddressToHex } = require('../util/ipUtils')

const { updateCryptoScoresForDevice } = require('../util/scoreHelpers')
const { generatePlaceholders, AdvancedSort } = require('../isaraql/fetch')
const { getRequestState } = require('../util/requestState')
const { getCptForRequest } = require('../util/cptHelpers')

const log = require('../util/log')(module)

async function deviceQuery(fields, request, graphQLState) {
    return deviceFilterQuery(fields, request, graphQLState, [fields.id])
}

/**
 * Main query to see devices.
 * @param {Object} fields Fields from GraphQL Query
 * @param {string} [fields.asOf] When the data should be reported on. If not provided the counts will be as of now.
 * @param {Object} request GraphQL request
 * @param {Object} graphQLState GraphQL State
 * @param {number[]} [ids] Set of IDs to run query for (instead of filter)
 */
async function deviceFilterQuery(fields, request, graphQLState, ids) {
    if (!('paging' in fields)) {
        fields.paging = { offset: 0n, limit: 5n }
    }
    if (!('connectionPaging' in fields)) {
        fields.connectionPaging = { offset: 0n, limit: 5n }
    }

    var wpcs = { Device: { paging: fields.paging }, Connection: { paging: fields.connectionPaging } }
    if (ids && ids.length !== 0) {
        wpcs.Device.where = { in: { column: 'id', value: ids } }
    }

    if ('sorting' in fields) {
        wpcs.Device.sort = await getSort(sortDictionary, fields.sorting)
    }
    return filterQuery('Device', 'devices', fields.filter, graphQLState, wpcs, fields.asOf, fields.cryptoPostureTemplate, makeMetaAndSummaries)
}

async function makeMetaAndSummaries(graphQLResult, wanted, session) {

    let activeCpt = await getCptForRequest()

    if (wanted.meta) {
        let start = Date.now()
        log.d('Computing device meta....')
        await makeDeviceMeta(graphQLResult, wanted, session)
        log.d(`Computed device meta: ${Date.now() - start} msec.`)
    }

    if (wanted.deviceSummaries) {
        let start = Date.now()
        log.d('Computing device summaries....')
        await makeDeviceSummaries(graphQLResult, wanted, session)
        log.d(`Computed device summaries: ${Date.now() - start} msec.`)
    }

    if (wanted.filterCategories) {
        let start = Date.now()
        log.d('Computing filter categories....')
        await makeFilterCategories(graphQLResult, postureCategories.DEVICE, wanted, session, activeCpt)
        log.d(`Computed filter categories: ${Date.now() - start} msec.`)
    }
}

async function makeDeviceMeta(graphQLResult, wanted, session) {
    let state = getRequestState()
    let filterTable = state.filterTable
    graphQLResult.meta = []
    let query = `SELECT dt.name AS name, count(*) AS count FROM "Device" JOIN "DeviceType" dt ON "Device"."deviceType" = dt.id `
    if (filterTable !== undefined) {
        query += `WHERE "Device".id IN (SELECT id FROM "${filterTable.table}") `
    }
    query += ' GROUP BY 1 ORDER BY 1'
    let results = await session.query(query)
    for (let result of results.rows) {
        graphQLResult.meta.push({
            key: result.name,
            value: result.count,
            name: result.name // TODO: GAP1598 - this needs to pull a human friendly name
        })
    }
}

async function pathsToDeviceAggregates(deviceIDs, paths, session, destinationTable) {
    return await pathsToAggregates(deviceIDs, paths, session, 'Device', destinationTable)
}

async function makeDeviceSummaries(graphQLResult, wanted, session) {
    graphQLResult.deviceSummaries = []

    if (graphQLResult.devices.length === 0) {
        return
    }

    var deviceIDs = []
    var resultsByDeviceID = {}
    var deviceSummary = graphQLResult.deviceSummaries
    graphQLResult.devices.forEach(device => {
        deviceIDs.push(device.id)
        var resultForDeviceID = {
            id: device.id, serverConnectionCount: 0, clientConnectionCount: 0,
            cipherSuites: [], software: [], cryptoPrimitives: [], protocols: [], protocolVariants: [], certificateAlgorithms: []
        }

        resultsByDeviceID[device.id] = resultForDeviceID
        deviceSummary.push(resultForDeviceID)
    })

    if (wanted.deviceSummaries.serverConnectionCount) {
        const incoming = (await session.query(`SELECT d.id, d."incomingConnectionCount" FROM "Device" d WHERE d.id in (${generatePlaceholders(deviceIDs)})`, deviceIDs)).rows
        incoming.forEach(result =>
            resultsByDeviceID[result.id].serverConnectionCount = result.incomingConnectionCount
        )
    }

    if (wanted.deviceSummaries.clientConnectionCount) {
        const outgoing = (await session.query(`SELECT d.id, d."outgoingConnectionCount" FROM "Device" d WHERE d.id in (${generatePlaceholders(deviceIDs)})`, deviceIDs)).rows
        outgoing.forEach(result =>
            resultsByDeviceID[result.id].clientConnectionCount = result.outgoingConnectionCount
        )
    }

    if (wanted.deviceSummaries.bytesTransferred) {
        // ensure all rows have a value, as some devices may not have any known connections.
        for (let id of deviceIDs) {
            resultsByDeviceID[id].bytesTransferred = 0
        }

        /* TODO: GAP1201 - GAP796 - re-enable this when we actually decide to display bytesTransferred again, c.f. GAP1201 / GAP 796
        let query = `select d.id, COALESCE(SUM("bytesTransferred"), 0) AS "bytesTransferred" FROM "Device" d
                        JOIN "DeviceAddress" da ON da.device = d.id
                        JOIN "DeviceAddressPort" dap on dap."deviceAddress" = da.id
                        JOIN "Connection" c on (c."clientDeviceAddressPort" = dap.id OR c."serverDeviceAddressPort" = dap.id)
                        WHERE d.id in (${generatePlaceholders(params)}) GROUP BY 1`

        let results = await session.query(query, params)

        results.rows.forEach(row => {
            resultsByDeviceID[row.id].bytesTransferred = row.bytesTransferred
        })
        */
    }
    if (wanted.deviceSummaries.cipherSuites) {
        await collectAggregateResultsLikeFacet('Device', 'CipherSuite', 'ciphersuite', deviceIDs, resultsByDeviceID, 'cipherSuites', session)
    }
    if (wanted.deviceSummaries.software) {
        await collectAggregateResultsLikeFacet('Device', 'Software', 'software', deviceIDs, resultsByDeviceID, 'software', session)

    }
    if (wanted.deviceSummaries.cryptoPrimitives) {
        await collectAggregateResultsLikeFacet('Device', 'CryptoPrimitive', 'cryptoprim', deviceIDs, resultsByDeviceID, 'cryptoPrimitives', session)
    }

    if (wanted.deviceSummaries.nonNormalCryptoPrimitives) {
        const primitives   = (await session.query(`WITH t1 AS (
            SELECT da.device AS device,cp.*,ccp."keyLength" FROM "CryptoPrimitive" cp
            JOIN "ConnectionCryptoPrimitive" ccp ON ccp."cryptoPrimitive" = cp.id
            JOIN "Connection" c on ccp.connection = c.id
            JOIN "DeviceAddressPort" dap ON (c."serverDeviceAddressPort" = dap.id OR c."clientDeviceAddressPort" = dap.id)
            JOIN "DeviceAddress" da on dap."deviceAddress" = da.id
            UNION
            SELECT dc.device AS device, cp.*,ccp."keyLength" FROM "CryptoPrimitive" cp
            JOIN "CertificateCryptoPrimitive" ccp ON ccp."cryptoPrimitive" = cp.id
            JOIN "DeviceCertificate" dc ON dc.certificate = ccp.certificate)
            SELECT "device", "name", "keyLength", count(*) as "count" FROM t1 WHERE "keyLength" IS NOT NULL AND "device" in (${generatePlaceholders(deviceIDs)}) GROUP BY 1,2,3` ,deviceIDs)).rows

        for(let id of deviceIDs) {
            resultsByDeviceID[id].nonNormalCryptoPrimitives = primitives.filter(result => result.device === id).map(result =>{
                return {name: result.name, keyLength: result.keyLength, count: result.count}
            })
        }
    }

    if (wanted.deviceSummaries.protocols) {
        await collectAggregateResultsLikeFacet('Device', 'Protocol', 'protocol', deviceIDs, resultsByDeviceID, 'protocols', session)
    }
    if (wanted.deviceSummaries.protocolVariants) {
        let results = await getProtocolVariantsForDevices(deviceIDs, session)

        results.forEach(result =>
            resultsByDeviceID[result.object_id].protocolVariants.push({name: result.name, count: result.count})
        )
    }
    if (wanted.deviceSummaries.certificateAlgorithms) {
        // Build out all certificate-related paths
        let excludes = { 'Agent': true, 'Connection': true, 'CipherSuite': true, 'CryptoScore': true, 'User': true, }
        let countingPaths = paths({ from: 'Device', to: 'CryptoPrimitive', excludes: excludes })
        // try again without DeviceCertificate so as to find paths to e.g. configuration files with certs.
        excludes.DeviceCertificate = true
        countingPaths = countingPaths.concat(paths({ from: 'Device', to: 'CryptoPrimitive', excludes: excludes }))
        countingPaths = countingPaths.filter(x => x.includes('Certificate'))
        let results = await pathsToDeviceAggregates(deviceIDs, countingPaths, session, 'CryptoPrimitive')
        results.forEach(result => resultsByDeviceID[result.id].certificateAlgorithms.push({ name: result.name, count: result.count }))
    }
}

const deletableTables = (() => {
    var result = Object.assign({}, postureModifiableTables)
    // Preventing Software deletion as many devices may use this Software - deletion through here is probably unintended.
    delete result.Software
    delete result.SoftwareVersion

    // Preventing Tag deletion as the Tag records are shared.
    delete result.Tag

    result.Agent = true
    result.AgentCertificate = true

    return result
})()

const checkExistingTables = (() => {
    var result = Object.assign({}, postureCheckExistingTables)
    result.Software = true
    result.SoftwareVersion = true
    return result
})()

async function deviceUpdateMutation(fields, request, graphQLState) {
    var devices = fields.devices
    var config = {
        allowDelete: true,
        allowInsert: true,
        allowUpdate: true,
        checkExistingTables,
        deletableTables,
        modifiableTables: postureModifiableTables
    }
    var ids = await createUpdateDelete('Device', devices, config)
    return deviceFilterQuery(fields, request, graphQLState, ids)
}

/**
 * This function will be called before a new Device is inserted.
 * @param {CUDHook} params
 */
async function preInsertDevice(params) {
    if (!('lastTimeOnline' in params.record)) {
        params.record['lastTimeOnline'] = new Date()
    }

    populateAddedBy(params)
}

/**
 * This function will be called after a new Device is inserted.
 * @param {CUDHook} params
 */
async function postInsertDevice(params) {
    // insert pending score records for all CPTs.
    await params.session.query('WITH cpts AS (SELECT id as score, "cryptoPostureTemplate" as cpt FROM "CryptoScore" WHERE score=?) INSERT INTO "DeviceScore" (device, "cryptoScore", "cryptoPostureTemplate") SELECT ?, cpts.score, cpts.cpt FROM cpts',
        [-1, params.record.id])
}

/**
 * This function will be called before a new Device is updated.
 * @param {CUDHook} params
 */
async function preUpdateDevice(params) {
    populateAddedBy(params)
}

/**
 * This function will be called after a Device is inserted or updated.
 * @param {CUDHook} params
 */
async function postWriteDevice(params) {
    await updateCryptoScoresForDevice(params.record.id, params.session)
}

async function preWriteDeviceAddress(params) {
    if ('address' in params.record) {
        var hexAndVersion = ipAddressToHex(params.record.address)
        params.record['addressHex'] = hexAndVersion.hex
        params.record['addressIPVersion'] = hexAndVersion.version
    }
}

/**
 * This function is called before a DeviceAddressPort is added
 * @param {CUDHook} params
 */
async function preInsertDeviceAddressPort(params) {
    if (!('l4Protocol' in params.record)) {
        params.record['l4Protocol'] = allTypes['Layer4Protocol']._enum.idByName['UNKNOWN']
    }
}

async function preWriteDeviceTag(params) {
    await updateTagUsedDate(params)
}

/**
 * This dictionary will hold the SQL fragments needed by `fetch.js` to build a table spanning sort query.
 */
const sortDictionary = {}

/**
 * Builds the sorting dictionary showing `fetch` how to sort for named parameters.
 */
function buildSortDictionary() {
    var commonTagSortJoins = `
    left join
        "DeviceTag" on "DeviceTag".device = "Device".id
    left join
        "Tag" on "Tag".id = "DeviceTag".tag and "Tag"."tagType" = ?`

    var commonTagSortOrderBys = `min("Tag".value) %DIR%`

    var tagTypes = allTypes.TagType._enum

    for (var name of tagTypes.names) {
        sortDictionary[name] = new AdvancedSort(commonTagSortJoins,
            `"Device".id`,
            commonTagSortOrderBys,
            tagTypes.idByName[name]
        )
    }

    // All the simple sorts that use a field which exists ON the Device table.
    sortDictionary['ADDED_DATE'] = `"addedDate" %DIR%`
    sortDictionary['NICKNAME'] = `NULLIF("friendlyName", '') %DIR% %NULLS%`
    sortDictionary['LAST_TIME_ONLINE'] = `"lastTimeOnline" %DIR%`

    // Special sort for CRYPTO_SCORE...it has some joins.
    let cryptoScoreJoins = `
        LEFT JOIN "DeviceScore" on "DeviceScore"."device" = "Device".id
        LEFT JOIN "CryptoScore" on "CryptoScore".id = "DeviceScore"."cryptoScore"`
    sortDictionary['CRYPTO_SCORE'] = new AdvancedSort(cryptoScoreJoins, [],`"CryptoScore"."score" %DIR%`)

    // Special sort for TYPE...it has a join.
    var typeSortJoin = `
    left join
        "DeviceType" on "DeviceType".id = "Device"."deviceType"`
    sortDictionary['TYPE'] = new AdvancedSort(typeSortJoin,
        [],
        `"DeviceType".name %DIR%`,
        null
    )
}

function initialise() {
    registerHook('Device', CUD_OP_INSERT, CUD_OP_PRE, preInsertDevice)
    registerHook('Device', CUD_OP_INSERT, CUD_OP_POST, postInsertDevice)
    registerHook('Device', CUD_OP_UPDATE, CUD_OP_PRE, preUpdateDevice)
    registerTreeHook('Device', CUD_OP_POST_CHILDREN, postWriteDevice)
    registerHook('DeviceAddress', CUD_OP_INSERT, CUD_OP_PRE, preWriteDeviceAddress)
    registerHook('DeviceAddress', CUD_OP_UPDATE, CUD_OP_PRE, preWriteDeviceAddress)
    registerHook('DeviceAddressPort', CUD_OP_INSERT, CUD_OP_PRE, preInsertDeviceAddressPort)
    registerHook('DeviceTag', CUD_OP_INSERT, CUD_OP_PRE, preWriteDeviceTag)
    registerHook('DeviceTag', CUD_OP_UPDATE, CUD_OP_PRE, preWriteDeviceTag)

    buildSortDictionary()
}

exports.graphQL = {
    types: `
        enum SortableDeviceFields {
            ADDED_DATE
            AGENT_STATE
            AGILITY_SCORE
            COORDINATE
            CORPORATE_ASSET_TAG_TRACKING_NUMBER
            CRYPTO_SCORE
            CPU_FAMILY
            CPU_SERIAL_NUMBER
            CPU_SPEED
            DOMAIN
            HOSTNAME
            LAST_TIME_ONLINE
            MACHINE_SERIAL_NUMBER
            NICKNAME
            NORMAL_ADDRESS
            OS_SERIAL_NUMBER
            PRIORITY
            RACK_ADDRESS
            RAM_SIZE
            SERVER_ROOM_NUMBER
            TYPE
        }

        input DeviceSortingInput {
            field: SortableDeviceFields!,
            direction: SortDirection!,
        }

        type DeviceSummary {
            id: BigInt!
            serverConnectionCount: BigInt!
            clientConnectionCount: BigInt!
            cipherSuites: [AttributeSummary!]!
            software: [AttributeSummary!]!
            cryptoPrimitives: [AttributeSummary!]!
            nonNormalCryptoPrimitives: [NonNormalCryptoPrimitives!]!
            protocols: [AttributeSummary!]!
            protocolVariants: [AttributeSummary!]!
            certificateAlgorithms: [AttributeSummary!]!
            bytesTransferred: String!
        }

        type FilteredDevices {
            paging: Paging!
            devices: [Device!]!
            deviceSummaries: [DeviceSummary!]!
            filterCategories: [FilterCategory!]!
            meta: [MetaTag!]!
        }

        type NonNormalCryptoPrimitives {
            name: String!
            keyLength: String!
            count: BigInt!
        }
    `,
    queries: `
        deviceById(
            id: BigInt!
            connectionPaging: PagingInput
            cryptoPostureTemplate: BigInt
        ): FilteredDevices!

        filteredDevices(
            filter: String
            paging: PagingInput
            sorting: DeviceSortingInput
            connectionPaging: PagingInput
            asOf: DateTime
            cryptoPostureTemplate: BigInt
        ) : FilteredDevices!
    `,
    mutations: `
        deviceUpdate(
            devices: [DeviceInput!]!
        ): FilteredDevices!
    `,
    root: {
        deviceById: deviceQuery,
        filteredDevices: deviceFilterQuery,
        deviceUpdate: deviceUpdateMutation,
    },
    restrictions: {
        deviceById: [roles.AUTHENTICATED],
        filteredDevices: [roles.AUTHENTICATED],
        deviceUpdate: [roles.AUTHENTICATED],
    },
    initialise
}
