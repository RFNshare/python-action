/**
 * @file streamTokens.js - 0.0.1045 - ea4595bfd3488684d225574ed7d4c198074d49ba
 * 
 * @copyright Copyright (C) 2016-2023, ISARA Corporation, All Rights Reserved.
 * 
 * @license The code and other content set out herein is not in the public
 * domain, is considered a trade secret and is confidential to ISARA
 * Corporation. Use, reproduction or distribution, in whole or in part, of such
 * code or other content is strictly prohibited except by express written
 * permission of ISARA Corporation. Please contact ISARA Corporation at
 * info@isara.com for more information.
 */

const { Session } = require('../../isaraql/session')
const { systemStatusClient } = require('../../util/systemStatusClient')
const { CountTracker } = require('./countTracker')
const log = require('../../util/log')(module)
const { STREAM_TOKEN_SYSTEM_STATUS_EVENT_NAME } = require('../../graphql/streamTokenQL')

const TOKEN_HEADER_NAME = 'x-isara-advance-auth'

const STREAM_STATUS_COMMIT_DELAY_MS = 15 * 1000


/**
 * Flag tracks if any tokens have been loaded.
 */
let tokensLoaded = false

/**
 * Interval used for attempting to reload the tokens.
 */
const RELOAD_TOKENS_INTERVAL_MS = 60 * 60 * 1000 // 1 hour

/**
 * @typedef TokenAndExpiry
 * @property token {String} The token
 * @property expires {Number} When it expires (in ms from Date.getTime())
 */

let state = {
    tokens: {},
    /**
     * @type Array.<TokenAndExpiry>
     */
    expiries: []
}

exports.validateToken = (token) => {
    if (!tokensLoaded) {
        log.e('Token validation attempt prior to token loading')
        return false
    }

    while (state.expiries.length > 0 && Date.now() >= state.expiries[0].expires) {
        delete state.tokens[state.expiries[0].token]
        state.expiries.splice(0, 1)
    }

    return token in state.tokens
}

let loggedExpired = new Set()

/**
 * Interval for attempting token reloads.
 */
let reloadInterval

const loadTokens = async () => {
    if (!reloadInterval) {
        reloadInterval = setInterval(loadTokens, RELOAD_TOKENS_INTERVAL_MS)
    }
    try {
        let tokens = {}
        let expiries = []
        let session = new Session()
        let tokenRows = (await session.query('select * from "StreamToken"')).rows
        let now = Date.now()
        for (let row of tokenRows) {
            if (row.expires) {
                if (now >= row.expires.getTime()) {
                    if (!loggedExpired.has(row.token)) {
                        loggedExpired.add(row.token)
                        log.log('Ignoring expired token', row.token)
                    }
                    continue
                }
                expiries.push({ expires: row.expires.getTime(), token: row.token })
            }
            tokens[row.token] = row
        }
        expiries.sort((a, b) => a.expires - b.expires)
        state = { tokens, expiries }
        tokensLoaded = true
        log.log('Loaded stream tokens', expiries.length)
    } catch (error) {
        log.e('Failed to load stream tokens', error)
    }
}

systemStatusClient.on(STREAM_TOKEN_SYSTEM_STATUS_EVENT_NAME, loadTokens)

class StreamStatusTracker {
    #streamName = ''
    #initialised = false

    #interval

    #eventCount = 0
    #countTrackerGood = new CountTracker()
    #countTrackerBad = new CountTracker()

    constructor(streamName) {
        if (!streamName) {
            throw new Error('Stream name required')
        }
        this.#streamName = streamName
    }

    async #insertInitialRecord() {
        let session = new Session()
        await session.query(`insert into "StreamStatus" (name) values (?) on conflict do nothing`, [this.#streamName])
    }

    async #commitUpdate() {
        const session = new Session()
        const ec = this.#eventCount
        this.#eventCount = 0
        const status = JSON.stringify({ good: this.#countTrackerGood, bad: this.#countTrackerBad })
        await session.query(`update "StreamStatus" set "lastStatus" = ?, total = total + ? where name = ?`, [status, ec, this.#streamName])
    }

    bump(good) {
        this.#eventCount++
        (good ? this.#countTrackerGood : this.#countTrackerBad).bump()
    }

    async init() {
        if (!this.#initialised) {
            this.#initialised = true
            await this.#insertInitialRecord()

            this.#interval = setInterval(() => {
                this.#commitUpdate().catch(e => {
                    log.e('Commit fail during background update', e)
                })
            }, STREAM_STATUS_COMMIT_DELAY_MS)
        }
    }
}

loadTokens()

exports.TOKEN_HEADER_NAME = TOKEN_HEADER_NAME
exports.StreamStatusTracker = StreamStatusTracker
