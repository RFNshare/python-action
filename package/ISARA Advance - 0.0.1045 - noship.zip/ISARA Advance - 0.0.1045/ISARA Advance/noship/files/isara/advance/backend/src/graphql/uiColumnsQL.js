/**
 * @file uiColumnsQL.js - 0.0.1045 - ea4595bfd3488684d225574ed7d4c198074d49ba
 * 
 * @copyright Copyright (C) 2016-2023, ISARA Corporation, All Rights Reserved.
 * 
 * @license The code and other content set out herein is not in the public
 * domain, is considered a trade secret and is confidential to ISARA
 * Corporation. Use, reproduction or distribution, in whole or in part, of such
 * code or other content is strictly prohibited except by express written
 * permission of ISARA Corporation. Please contact ISARA Corporation at
 * info@isara.com for more information.
 */

/**
 * This module contains the ui columns query.
 * @module graphql/featureQL
 */
const { roles } = require('./commonQL')

// columns are grouped by the roles allowed to view them.
// IDs are taken from the UI's respective .ts files defining their
// visual representation properties
let columnMeta = {
    DEVICE: {
        AUTHENTICATED: [
            // Device
            'cryptoScore',
            'bytesTransferred',
            'exception',
            'cryptoScoreCategory',
            'cryptoScoreCoarse',
            'osType',
            'taniumName',
            'observedAt',
            'application',
            'protocol',
            'ciphersuite',
            'listenport',
            'cryptoprimitives',
            // Device Overview
            // 'deviceType',
            'friendlyName',
            'zone',
            'macAddress',
            'port',
            'lastTimeOnline',
            'ipAddress',
            'addedBy',
            'addedDate',
            'isServer',
            'isClient',
            // Context & Tags
            'devicePurpose',
            'priority',
            'deviceTags',
            'sensitivity',
            // Address & Serial Numbers
            'address',
            'serverRoom',
            'rackAddress',
            'machineSerial',
            'cpuSerial',
            'osSerial',
            'osName',
            'corpTag',
            'coordinates',
            // Network & Connections
            'importance',
            'peer',
            'connectionName',
            'connectionCount',
            'connectionIncoming',
            'connectionOutgoing',
            'host',
            'domain',
            'protocols',
            'protocolVariants',
            'cipherSuites',
            'cryptoPrimitives',
            'certAlgorithms',
            'certificate',
            'certIssuers',
            'abnormalKeySize',
            // Additional Properties
            'software',
            'softwareVendor',
            'cpu',
            'cpuSpeed',
            'ramSize',
            //Typesense new column
            'keyExchange',
            'bulkEncryption',
            'modeOfOperation',
            'signature',
            'hash',
            'mac',
            'cipherSuite',
        ]
    },
    CONNECTION: {
        AUTHENTICATED: [
            // Device
            'clientAddress',
            'serverAddress',
            'serverPort',
            'hostName',
            'serverHostName',
            'clientHostName',
            'clientPriority',
            'serverPriority',
            'clientZone',
            'serverZone',
            'clientDeviceType',
            'serverDeviceType',
            'clientOs',
            'serverOs',
            'clientName',
            'serverName',
            'port',
            'isServer',
            'isClient',
            // Connection
            'connectionName',
            'id',
            'cipherSuites',
            'certificates',
            'importance',
            'sensitivity',
            'bytesTransferred',
            'cryptoPrimitives',
            'certificateAlgorithms',
            'abnormalKeySize',
            'deviceTags',
            'addedBy',
            'addedDate',
            'addedAt',
            'agentCert',
            'agentCertIssuer',
            'conCryptoCategory',
            'conCryptoScore',
            'conAgilityScore',
            'protocol',
            'protocolVariants',
            'certIssuer',
            'connCount',
            //Connection Typesence
            'advanceId',
            'observedAt',
            'addressIpVersion',
            'keyExchange',
            'bulkEncryption',
            'modeOfOperation',
            'signature',
            'mac',
            'hash',
            'cryptoScore',
            'cryptoScoreCoarse',
            'technology',
            'connectionCount',
            // 'serverType',
            // 'clientType',
            'scryptoScore',
            'scryptoScoreCoarse',
            'ccryptoScore',
            'ccryptoScoreCoarse',
            'cipherSuite',
            'issuer',
            'fingerprint',
            'application',
            // "Software"
            'clientSoftware',
            'serverSoftware',
            'zoneIn',
            'zoneOut'
        ]
    },
    SOFTWARE: {
        AUTHENTICATED: [
            // Software
            'softwareID',
            'name',
            'softwareType',
            'softwareVersion',
            'binaryHash',
            'softTag',
            'softwarevendor',
            'softwareAddedDate',
            'softwareVersionName',
            'softwarePaths',
            // Usage
            'devUsage',
            'connUsage',
            'connUsageUnacceptable',
            'connUsageCaution',
            'connUsageStrongClassic',
            'connUsageStrongQSC',
            'softwareOS',
            //Typesence
            'user',
            'device',
            'type',
            'port',
            'osType',
            // 'taniumName',
            // 'macAddress',
            // 'deviceType'
            'version',
            'DeviceCount',
            'connectionCount',
            'protocol',
            'keyExchange',
            'bulkEncryption',
            'modeOfOperation',
            'signature',
            'hash',
            'mac',
            'observedAt'
        ]
    }
}

async function columnGroupsQuery(fields, request) {
    if (!(fields.posture in columnMeta)) {
        throw `Unsupported posture: ${fields.posture}`
    }

    let columns = columnMeta[fields.posture]
    let response = []
    let userRole = request.user.roles[0]
    for (let role of Object.keys(columns)) {
        if (roles[role] > userRole) {
            continue
        }

        response.push(...columns[role])
    }

    return response
}

exports.graphQL = {
    // Types is using a getter as the final list is not known when this file is loaded.
    types: `
        enum ColumnPosture {
            CONNECTION
            DEVICE
            SOFTWARE
        }

    `,
    queries: `
        "Returns the list of columns the current user is permitted to see by their roles."
        columnGroups(posture: ColumnPosture!): [String!]!
    `,
    root: {
        columnGroups: columnGroupsQuery,
    },
    restrictions: {
        columnGroups: [roles.AUTHENTICATED],
    }
}
