/**
 * @file csvIngestionScanner.js - 0.0.1045 - ea4595bfd3488684d225574ed7d4c198074d49ba
 * 
 * @copyright Copyright (C) 2016-2023, ISARA Corporation, All Rights Reserved.
 * 
 * @license The code and other content set out herein is not in the public
 * domain, is considered a trade secret and is confidential to ISARA
 * Corporation. Use, reproduction or distribution, in whole or in part, of such
 * code or other content is strictly prohibited except by express written
 * permission of ISARA Corporation. Please contact ISARA Corporation at
 * info@isara.com for more information.
 */

/**
 * This module contains device focused mutations with input from csv file.
 * @module ingestion/csv/csvIngestionScanner
 */

const fs = require('fs')
const path = require('path')
const fastcsv = require('fast-csv')
const urlJoin = require('url-join')
const StreamZip = require('node-stream-zip')
const _ = require('lodash')
const fse = require('fs-extra')

const isMac = require('is-mac')
const { Session } = require('../../isaraql/session')
const LazySingleton = require('../../util/lazySingleton')
const { sleep } = require('../../util/sleep')
const log = require('../../util/log')(module)

const { SQLUpdateOp } = require('../../isaraql/fetch')
const { allTypes } = require('../../isaraql/schemaDiscovery')
const { createUpdateDelete } = require('../../isaraql/cud')
const {
    IngestionStatus,
    updateTables,
    reportResultDetail,
    normalizeMacAddress,
    normalizePrefixedUnit,
    validatePrefixedUnit,
    parseAndInsertCertificates,
    populateTags,
    inspectIPAddress,
    updateScanResultSummary
} = require('../commonIngestion')

const netscoutCrypto = require('../netscout/netscoutCryptoMapping')
const { NetmaskMatchModes } = require('../netmaskMatching')
const NETSCOUT_TLS_RECORD = 65
const NETSCOUT_CERT_RECORD = 92

const ZIP_MIME_TYPES = ['application/zip', 'application/zip-compressed', 'application/x-zip-compressed']

let TLSMaps = {
    cipherSuiteIDMap: {},
    protocolVariantIDMap: {}
}

async function ingestCSV(dataSourceScan, results, onFulfilled, onRejected, onFinally, netscoutFilesConfig) {
    let session = new Session()
    let headersMap = {}

    await updateScanResultSummary(results, 'Processing rows...', session)

    function getField(row, name, converter) {
        let value = (row[name.toLowerCase()] ?? '').trim()
        if (converter) {
            value = converter(value)
        }
        return value ? value : null
    }

    async function attachTag(device, row, column, tagType, converter, expectedValues, exclusive) {
        let value = getField(row, column, converter)
        if (value) {
            let tagTypeId = allTypes['TagType']._enum.idByName[tagType]
            device.deviceTags = device.deviceTags ?? []
            if (expectedValues) {
                let expectedLookup = expectedValues.reduce(function (obj, item) {
                    obj[item.toLowerCase()] = item
                    return obj
                }, {})
                let lookupValue = expectedLookup[value.toLowerCase()]
                if (!lookupValue) {
                    throw `Invalid value '${value}' in column ${column}`
                }
                value = lookupValue
            }

            if (device.id && exclusive) {
                let existingTags = await session.query(
                    `select dt.id as id from "DeviceTag" dt join "Tag" t on dt.tag = t.id where dt.device = ? and t."tagType" = ?`,
                    [device.id, tagTypeId])

                for (let existingTag of existingTags.rows) {
                    device.deviceTags.push({ DELETE: true, id: existingTag.id })
                }
            }

            device.deviceTags.push({
                tag: {
                    value,
                    tagType: tagTypeId
                }
            })
        }
    }

    async function findSingleDeviceId(id, hostname) {
        if (id) {
            let deviceIds = await session.query(`SELECT id FROM "Device" where id = ?`, [id])
            if (deviceIds.rows.length > 0) {
                return id
            }

            throw `Device with id '${id}' not found.`
        }

        let deviceIds = await session.query(`
            select dt.device as id from "Tag" t
            join "DeviceTag" dt on dt.tag = t.id
            where value = ? and t."tagType" = ?`,
        [hostname, allTypes['TagType']._enum.idByName['HOSTNAME']])
        if (deviceIds.rows.length === 1) {
            return deviceIds.rows[0].id
        } else if (deviceIds.rows.length > 1) {
            throw `Found multiple matching devices with hostname '${hostname}'.`
        }

        return null
    }

    const cipherSuiteCache = {}

    async function findCipherSuiteId(value) {
        if (Object.keys(cipherSuiteCache).length === 0) {
            let cipherSuiteResults = await session.query(`select id, name from "CipherSuite"`)
            for (let row of cipherSuiteResults.rows) {
                cipherSuiteCache[row.name.toLowerCase()] = row.id
            }
        }

        return cipherSuiteCache[value.toLowerCase()]
    }

    const protocolVariantCache = {}

    async function findProtocolVariantId(value) {
        if (Object.keys(protocolVariantCache).length === 0) {
            let protocolVariantResults = await session.query(`select id, name from "ProtocolVariant"`)
            for (let row of protocolVariantResults.rows) {
                protocolVariantCache[row.name.toLowerCase()] = row.id
            }
        }

        return protocolVariantCache[value.toLowerCase()]
    }

    const enumLookupCache = {}

    /*
     * Performs a case-insensitive enum value lookup.
     * Uses a cache to increase performance.
     */
    function findEnumId(enumType, value) {
        if (!enumLookupCache[enumType]) {
            enumLookupCache[enumType] = Object.keys(allTypes[enumType]._enum.idByName).reduce(function (obj, item) {
                obj[item.toLowerCase()] = allTypes[enumType]._enum.idByName[item]
                return obj
            }, {})
        }

        return enumLookupCache[enumType][value.toLowerCase()]
    }

    function updateEnum(row, column, object, property, enumType, defaultValue) {
        let value = getField(row, column) || defaultValue
        if (value) {
            let enumId = findEnumId(enumType, value)
            if (!enumId) {
                throw `Invalid value '${value}' in column '${column}'.`
            }

            object[property] = new SQLUpdateOp('=', enumId, enumId)
        }
    }

    function attachCryptoPrimitive(row, column, connection, converter) {
        let value = getField(row, column, converter)
        if (value) {
            let enumId = findEnumId('CryptoPrimitive', value)
            if (!enumId) {
                throw `Invalid value '${value}' in column '${column}'.`
            }

            connection.connectionCryptoPrimitives = connection.connectionCryptoPrimitives ?? []
            connection.connectionCryptoPrimitives.push({
                cryptoPrimitive: enumId
            })
        }
    }

    function validateAndNormalizePrefixedUnits(value, units, column, scale) {
        if (value) {
            if (!validatePrefixedUnit(value, units)) {
                throw `Invalid value '${value}' in column '${column}'.`
            }

            return normalizePrefixedUnit(value, scale)
        }

        return value
    }

    /*
     * If a software name is specified, we want to set/update it, but not use
     * it to determine if a software version entry already exists. If a name
     * is not specified, a CUD Hook to populate the version name by default.
    */
    function setSoftwareNameUpdate(software, name) {
        if (name) {
            software.name = new SQLUpdateOp('=', name, name)
        }
    }

    async function processDeviceRow(row, tags) {
        let deviceId = getField(row, 'id')
        let hostname = getField(row, 'hostname')
        let device = {}

        if (!deviceId && !hostname) {
            throw `Device id or hostname must be specified at a minimum.`
        }

        deviceId = await findSingleDeviceId(deviceId, hostname)
        let isUpdate = !!deviceId

        if (isUpdate) {
            device.id = deviceId
        }

        // Text tags
        await attachTag(device, row, 'hostname', 'HOSTNAME')
        await attachTag(device, row, 'domain', 'DOMAIN')
        await attachTag(device, row, 'zone', 'ZONE')
        await attachTag(device, row, 'tag', 'CUSTOM')

        await attachTag(device, row, 'devicepurpose', 'DEVICE_PURPOSE', null, null, true)
        await attachTag(device, row, 'cpufamily', 'CPU_FAMILY', null, null, true)
        await attachTag(device, row, 'normaladdress', 'NORMAL_ADDRESS', null, null, true)
        await attachTag(device, row, 'coord', 'COORDINATE', null, null, true)
        await attachTag(device, row, 'serverroom', 'SERVER_ROOM_NUMBER', null, null, true)
        await attachTag(device, row, 'rackaddress', 'RACK_ADDRESS', null, null, true)
        await attachTag(device, row, 'machineserial', 'MACHINE_SERIAL_NUMBER', null, null, true)
        await attachTag(device, row, 'corptag', 'CORPORATE_ASSET_TAG_TRACKING_NUMBER', null, null, true)

        // Numeric tags with prefixed-units
        await attachTag(device, row, 'cpuspeed', 'CPU_SPEED', v => validateAndNormalizePrefixedUnits(v, 'hz', 'cpuspeed', 1000), null, true)
        await attachTag(device, row, 'ramsize', 'RAM_SIZE', v => validateAndNormalizePrefixedUnits(v, 'b', 'ramsize'), null, true)

        // Enum-style tags
        await attachTag(device, row, 'priority', 'PRIORITY', null, ['LOW', 'MEDIUM', 'HIGH'], true)
        await attachTag(device, row, 'exception', 'EXCEPTION', null, ['OK', 'NOT OK'], true)

        let lastTimeOnline = getField(row, 'lasttimeonline')
        if (lastTimeOnline) {
            let parsedDate = Date.parse(lastTimeOnline)
            if (!isNaN(parsedDate)) {
                // Date.parse() returns msec directly. However, in order to ensure node-postgres formats the date correctly for
                // input regardless of server date style, we need to wrap that in a Date object.
                device.lastTimeOnline = new Date(parsedDate)
            } else {
                throw `Could not parse last time online '${lastTimeOnline}'`
            }
        }

        // Scan-level tags
        for (let tag of tags) {
            device.deviceTags = device.deviceTags ?? []
            device.deviceTags.push({ tag: { id: tag.tag.id } })
        }

        let friendlyName = getField(row, 'friendlyname')
        if (!isUpdate) {
            device.friendlyName = friendlyName ?? hostname
        } else if (friendlyName) {
            device.friendlyName = friendlyName
        }

        let deviceType = getField(row, 'devicetype')
        if (!isUpdate && !deviceType) {
            device.deviceType = allTypes['DeviceType']._enum.idByName['UNKNOWN']
        } else if (deviceType) {
            device.deviceType = findEnumId('DeviceType', deviceType)
            if (device.deviceType === undefined) {
                throw `Invalid device type specified '${deviceType}'.`
            }
        }

        let address = getField(row, 'address')
        if (address) {
            let addressInfo = inspectIPAddress(address, NetmaskMatchModes.DO_NOT_MATCH)
            if (addressInfo.isIngestible) {
                device.deviceAddresses = [{ address: addressInfo.address }]
            } else {
                throw `Invalid device address specified '${address}' of type '${addressInfo.addressType}'.`
            }
        }

        let mac = normalizeMacAddress(getField(row, 'mac'))
        if (mac) {
            if (isMac(mac)) {
                if (device.deviceAddresses) {
                    device.deviceAddresses[0].deviceAddressMACAddresses = [{ deviceMACAddress: { mac } }]
                } else {
                    device.deviceMACAddresses = [{ mac }]
                }
            } else {
                throw `Invalid mac address specified '${mac}'`
            }
        }

        let osName = getField(row, 'osname')
        let osVersion = getField(row, 'osversion') ?? '0.0'
        let osVersionName = getField(row, 'osversionname')
        if (osName) {
            device.deviceSoftwares = []
            if (isUpdate) {
                let existingOperatingSystems = await session.query(
                    `select ds.id as id from "DeviceSoftware" ds
                    join "SoftwareVersion" sv on sv.id = ds."softwareVersion"
                    join "Software" s on s.id = sv.software
                    where ds.device = ? and s."softwareType" = ?`,
                    [deviceId, allTypes['SoftwareType']._enum.idByName['OS']])
                for (let existingOperatingSystem of existingOperatingSystems.rows) {
                    device.deviceSoftwares.push({ DELETE: true, id: existingOperatingSystem.id })
                }
            }
            let newOperatingSystem = {
                softwareVersion: {
                    version: osVersion,
                    sortableVersion: 0,
                    software: {
                        name: osName,
                        softwareType: allTypes['SoftwareType']._enum.idByName['OS']
                    }
                }
            }
            setSoftwareNameUpdate(newOperatingSystem.softwareVersion, osVersionName)
            device.deviceSoftwares.push(newOperatingSystem)
        }

        const deviceTables = {
            Device: true,
            DeviceAddress: true,
            DeviceMACAddress: true,
            DeviceAddressMACAddress: true,
            DeviceSoftware: true,
            SoftwareVersion: true,
            Software: true,
            DeviceTag: true,
            SoftwareVersionTag: true,
            Tag: true,
        }

        const insertCheckTables = {
            SoftwareVersion: true,
            Software: true,
            DeviceTag: true,
            SoftwareVersionTag: true,
            Tag: true,
        }

        const deletableTables = {
            DeviceSoftware: true,
            DeviceTag: true
        }

        const config = {
            allowDelete: true,
            allowInsert: true,
            allowUpdate: true,
            deletableTables: deletableTables,
            modifiableTables: deviceTables,
            checkExistingTables: isUpdate ? deviceTables : insertCheckTables,
            session,
        }
        await createUpdateDelete('Device', [device], config)
    }

    async function processConnectionRow(row, tags) {
        // server attributes
        let serverHostname = getField(row, 'serverhostname')
        let serverAddress = getField(row, 'serveraddress')
        let serverMacAddress = normalizeMacAddress(getField(row, 'servermacaddress'))
        let serverPort = getField(row, 'serverport')
        let layer4protocol = getField(row, 'layer4protocol') ?? 'UNKNOWN'

        if (!serverHostname || !serverAddress || !serverPort) {
            throw `Server hostname, address, and port must be specified at a minimum.`
        }

        let serverId = await findSingleDeviceId(null, serverHostname)
        if (!serverId) {
            throw `Server with hostname '${serverHostname}' not found.`
        }

        let serverAddressInfo = inspectIPAddress(serverAddress, NetmaskMatchModes.SERVER)
        if (!serverAddressInfo.isIngestible) {
            throw `Invalid server address specified '${serverAddress}' of type '${serverAddressInfo.addressType}'.`
        }

        let serverPortNumber = parseInt(serverPort)
        if (isNaN(serverPortNumber) || serverPortNumber < 0 || serverPortNumber > 65535) {
            throw `Server port must be an integer between 0 and 65535.`
        }

        let l4Protocol = allTypes['Layer4Protocol']._enum.idByName[layer4protocol]
        if (!l4Protocol) {
            throw `Invalid layer4Protocol specified '${layer4protocol}'.`
        }

        let connection = {
            serverDeviceAddressPort: {
                port: serverPortNumber,
                l4Protocol: l4Protocol,
                deviceAddress: {
                    address: serverAddressInfo.address,
                    device: {
                        id: serverId
                    }
                }
            }
        }

        if (serverMacAddress) {
            if (isMac(serverMacAddress)) {
                connection.serverDeviceAddressPort.deviceAddress.deviceAddressMACAddresses = [{
                    deviceMACAddress: {
                        mac: serverMacAddress,
                        device: {
                            id: serverId
                        }
                    }
                }]
            } else {
                throw `Invalid server mac address specified '${serverMacAddress}'`
            }
        }

        // update fields directly on Connection
        let bytesTransferred = getField(row, 'bytestransferred', v => parseInt(normalizePrefixedUnit(v)))
        if (bytesTransferred) {
            connection.bytesTransferred = new SQLUpdateOp('+', bytesTransferred, bytesTransferred)
        }

        connection.connectionCount = new SQLUpdateOp('+', 1, 1)

        updateEnum(row, 'sensitivity', connection, 'sensitivity', 'ConnectionRatingScale')
        updateEnum(row, 'importance', connection, 'importance', 'ConnectionRatingScale')

        // client attributes
        let clientHostname = getField(row, 'clienthostname')
        let clientAddress = getField(row, 'clientaddress')
        let clientmacaddress = normalizeMacAddress(getField(row, 'clientmacaddress'))
        let clientPort = getField(row, 'clientport') ?? '-1'
        let clientId = null
        let clientAddressInfo = null

        if (clientHostname && clientAddress) {
            clientId = await findSingleDeviceId(null, clientHostname)
            if (!clientId) {
                throw `Client with hostname '${clientHostname}' not found.`
            }

            clientAddressInfo = inspectIPAddress(clientAddress, NetmaskMatchModes.CLIENT)
            if (!clientAddressInfo.isIngestible) {
                throw `Invalid client address specified '${clientAddress}' of type '${clientAddressInfo.addressType}'.`
            }

            let clientPortNumber = parseInt(clientPort)
            if (isNaN(clientPortNumber) || clientPortNumber < -1 || clientPortNumber > 65535) {
                throw `Client port must be an integer between -1 and 65535.`
            }

            connection.clientDeviceAddressPort = {
                port: clientPortNumber,
                l4Protocol: l4Protocol,
                deviceAddress: {
                    address: clientAddressInfo.address,
                    device: {
                        id: clientId
                    }
                }
            }

            if (clientmacaddress) {
                if (isMac(clientmacaddress)) {
                    connection.clientDeviceAddressPort.deviceAddress.deviceAddressMACAddresses = [{
                        deviceMACAddress: {
                            mac: clientmacaddress,
                            device: {
                                id: clientId
                            }
                        }
                    }]
                } else {
                    throw `Invalid server mac address specified '${clientmacaddress}'`
                }
            }
        } else if (clientHostname || clientAddress) {
            throw `Client hostname and address must both be specified.`
        }

        // server software
        let serverSoftwareName = getField(row, 'serversoftware')
        let serverSoftwareVersionName = getField(row, 'serversoftwareversionname')
        let serverSoftwareVersion = getField(row, 'serversoftwareversion') ?? '0.0'
        let serverSoftwareVendor = getField(row, 'serversoftwarevendor') ?? ''

        if (serverSoftwareName) {
            let serverSoftwareConnection = {
                deviceSoftware: {
                    device: {
                        id: serverId
                    },
                    softwareVersion: {
                        version: serverSoftwareVersion,
                        sortableVersion: 0,
                        software: {
                            name: serverSoftwareName,
                            softwareVendor: serverSoftwareVendor
                        }
                    }
                }
            }

            setSoftwareNameUpdate(
                serverSoftwareConnection.deviceSoftware.softwareVersion,
                serverSoftwareVersionName
            )
            updateEnum(
                row,
                'serversoftwaretype',
                serverSoftwareConnection.deviceSoftware.softwareVersion.software,
                'softwareType',
                'SoftwareType',
                'APP')

            connection.deviceSoftwareConnections = [serverSoftwareConnection]
        }

        // client software
        let clientSoftwareName = getField(row, 'clientsoftware')
        let clientSoftwareVersionName = getField(row, 'clientsoftwareversionname')
        let clientSoftwareVersion = getField(row, 'clientsoftwareversion') ?? '0.0'
        let clientSoftwareVendor = getField(row, 'clientsoftwarevendor') ?? ''

        if (clientSoftwareName && clientId) {
            let clientSoftwareConnection = {
                deviceSoftware: {
                    device: {
                        id: clientId
                    },
                    softwareVersion: {
                        version: clientSoftwareVersion,
                        sortableVersion: 0,
                        software: {
                            name: clientSoftwareName,
                            softwareVendor: clientSoftwareVendor
                        }
                    }
                }
            }

            setSoftwareNameUpdate(
                clientSoftwareConnection.deviceSoftware.softwareVersion,
                clientSoftwareVersionName
            )
            updateEnum(
                row,
                'clientsoftwaretype',
                clientSoftwareConnection.deviceSoftware.softwareVersion.software,
                'softwareType',
                'SoftwareType',
                'UNKNOWN')

            connection.deviceSoftwareConnections = connection.deviceSoftwareConnections ?? []
            connection.deviceSoftwareConnections.push(clientSoftwareConnection)
        } else if (clientSoftwareName) {
            throw `Client software cannot be added without a client device specified.`
        }

        // Certificate
        let connectionProtocolVariantCertificates = []
        let serverCertData = getField(row, 'serverCertificate')
        let clientCertData = getField(row, 'clientCertificate')
        if (serverCertData || clientCertData) {
            connection.connectionCertificates = []
            if (clientId) {
                connection.clientDeviceAddressPort.deviceAddress.device.deviceCertificates = []
            }
            connection.serverDeviceAddressPort.deviceAddress.device.deviceCertificates = []
            for (const [certType, certData] of [['SERVER', serverCertData], ['CLIENT', clientCertData]]) {
                if (certData) {
                    const cert = await parseAndInsertCertificates(certData)

                    for (let i = 0; i < cert.certificateCryptoPrimitives.length; i++) {
                        cert.certificateCryptoPrimitives[i].cryptoPrimitive = findEnumId('CryptoPrimitive', cert.certificateCryptoPrimitives[i].cryptoPrimitive)
                    }


                    connection.connectionCertificates.push({
                        certificate: cert
                    })
                    connectionProtocolVariantCertificates.push({
                        certificate: cert,
                        connectionCertificateType: findEnumId('ConnectionCertificateType', certType)
                    })
                    if (certType === 'CLIENT') {
                        if (!clientId) {
                            throw 'Client certificate provided but client identifiers not provided.'
                        }
                        connection.clientDeviceAddressPort.deviceAddress.device.deviceCertificates.push({
                            certificate: cert
                        })
                    } else {
                        connection.serverDeviceAddressPort.deviceAddress.device.deviceCertificates.push({
                            certificate: cert
                        })
                    }
                }
            }
        }

        // protocol
        const protocolVariant = getField(row, 'protocol')
        if (protocolVariant) {
            let protocolVariantId = await findProtocolVariantId(protocolVariant)
            if (!protocolVariantId) {
                throw `Invalid protocol specified '${protocolVariant}'.`
            }

            connection.connectionProtocolVariants = [{
                protocolVariant: {
                    id: protocolVariantId
                },
                connectionProtocolVariantCertificates: connectionProtocolVariantCertificates
            }]
        }

        // ciphersuite
        let cipherSuite = getField(row, 'ciphersuite')
        if (cipherSuite) {
            let cipherSuiteId = await findCipherSuiteId(cipherSuite)
            if (!cipherSuiteId) {
                throw `Invalid ciphersuite specified '${cipherSuite}'.`
            }

            connection.connectionCipherSuites = [{
                cipherSuite: {
                    id: cipherSuiteId
                }
            }]
        }

        // crypto primitives
        // if 'RSA_2048' (or the like) is passed into KE/SIG, map to appropriate KE/SIG
        // if 'NULL' is passed into KE/SIG/ENC/HASH, map to appropriate KE/SIG/ENC/HASH
        attachCryptoPrimitive(row, 'keyexchange', connection,
            v => v.replace(/^RSA(?!(_KE|_SIG))(?=_\d+)/i, 'RSA_KE').replace(/^NULL$/i, 'NULL_KE'))
        attachCryptoPrimitive(row, 'signature', connection,
            v => v.replace(/^RSA(?!(_KE|_SIG))(?=_\d+)/i, 'RSA_SIG').replace(/^NULL$/i, 'NULL_SIG'))
        attachCryptoPrimitive(row, 'encryption', connection, v => v.replace(/^NULL$/i, 'NULL_ENC'))
        attachCryptoPrimitive(row, 'operationmode', connection)
        attachCryptoPrimitive(row, 'authentication', connection)
        attachCryptoPrimitive(row, 'digest', connection, v => v.replace(/^NULL$/i, 'NULL_HASH'))

        // scan-level tags
        for (let tag of tags) {
            connection.connectionTags = connection.connectionTags ?? []
            connection.connectionTags.push({ tag: { id: tag.tag.id } })
        }

        let checkTables = JSON.parse(JSON.stringify(updateTables))
        checkTables.ConnectionRatingScale = true

        let config = {
            allowDelete: false,
            allowInsert: true,
            allowUpdate: true,
            deletableTables: {},
            modifiableTables: updateTables,
            checkExistingTables: checkTables,
            session,
        }

        await createUpdateDelete('Connection', [connection], config)
    }

    async function buildTLSMaps(session, maps) {
        let cipherSuites = await session.query('SELECT id, name FROM "CipherSuite"')
        for (let suite of cipherSuites.rows) {
            maps.cipherSuiteIDMap[suite.name] = suite.id
        }

        let protocolVariants = await session.query('SELECT id, name FROM "ProtocolVariant"')
        for (let variant of protocolVariants.rows) {
            maps.protocolVariantIDMap[variant.name] = variant.id
        }
    }

    function getDeviceAddress(addressInfo, recordDate, hostName, tags) {
        let deviceAddress = {
            address: addressInfo.address,
            addressIPVersion: addressInfo.version,
            manuallyAdded: new SQLUpdateOp('=', false, false),
            observedAt: new SQLUpdateOp('=', recordDate, recordDate)
        }

        let friendlyName

        if (!hostName) {
            friendlyName = `NetScout-${addressInfo.address}`
        } else {
            friendlyName = `NetScout-${hostName}`
        }

        deviceAddress.device = {
            deviceType: allTypes['DeviceType']._enum.idByName['UNKNOWN'],
            lastTimeOnline: new SQLUpdateOp('=', recordDate, recordDate),
            friendlyName: friendlyName,
            deviceCertificates : [],
            deviceTags : []
        }

        if (!hostName) {
            deviceAddress.device.deviceTags.push({
                tag: {
                    tagType: allTypes['TagType']._enum.idByName['HOSTNAME'],
                    value: addressInfo.address
                }
            })
        } else {
            deviceAddress.device.deviceTags.push({
                tag: {
                    tagType: allTypes['TagType']._enum.idByName['HOSTNAME'],
                    value: hostName
                }
            })
        }

        populateTags(deviceAddress.device, 'deviceTags', tags)

        return deviceAddress
    }

    class PortZeroError extends Error { }

    async function processNetScoutTLSRow(row, tags) {
        // Get record type.
        let recordTypeStr = getField(row, 'xdr_type')
        if (recordTypeStr === null) {
            throw `Record type must be specified.`
        }

        let recordType = parseInt(recordTypeStr)
        if (recordType !== NETSCOUT_TLS_RECORD && recordType !== NETSCOUT_CERT_RECORD) {
            throw `The record type cannot be recognized.`
        }

        // The protocol type for NetScout TLS records is TCP.
        let l4Protocol = allTypes['Layer4Protocol']._enum.idByName['TCP']

        // Get record time.
        let recordTimestamp = getField(row, 'session_start_time')
        let recordDate

        if (!recordTimestamp) {
            recordDate = new Date()
        } else {
            // Change seconds to milliseconds and get rid of any fractions.
            recordDate = new Date(Math.round(recordTimestamp * 1000))
        }

        // Get server info.
        let serverAddress = getField(row, 'server_addr')

        let serverPort = null
        if (recordType === NETSCOUT_TLS_RECORD) {
            serverPort = getField(row, 'server_port')
        } else {
            // For NetScout cert CSV, we assume that the port is 443. This is
            // used to match records in NetScout TLS CSV, which contains just
            // HTTPS connections based on the samples NetScout have provided
            // (and hence with port 443).
            serverPort = '443'
        }

        if (!serverAddress || !serverPort) {
            throw `Server address and port must both be specified.`
        }

        let serverHostname = getField(row, 'sni')
        if (serverHostname) {
            serverHostname = serverHostname.toLowerCase()
        }

        // Process server info.
        let serverAddressInfo = inspectIPAddress(serverAddress, NetmaskMatchModes.SERVER)
        if (!serverAddressInfo.isIngestible) {
            throw `Invalid server address specified '${serverAddress}' of type '${serverAddressInfo.addressType}'.`
        }

        let serverPortNumber = parseInt(serverPort)
        if (isNaN(serverPortNumber) || serverPortNumber <= 0 || serverPortNumber > 65535) {
            // Create a new error type for the case where the port number is 0,
            // so that it can be filtered out and ignored, as it may appear
            // quite frequently in NetScout's data. This is likely the result
            // of failed handshake.
            if (serverPortNumber === 0) {
                throw new PortZeroError('Server port number cannot be 0.')
            }

            throw `Server port must be an integer between 1 and 65535.`
        }

        // Get server device address.
        let serverDeviceAddress = getDeviceAddress(serverAddressInfo, recordDate, serverHostname, tags)

        // Compose server device address port.
        let serverDAP = {
            deviceAddress: serverDeviceAddress,
            port: serverPortNumber,
            l4Protocol: l4Protocol,
            manuallyAdded: new SQLUpdateOp('=', false, false),
            observedAt: new SQLUpdateOp('=', recordDate, recordDate)
        }

        // Get client info.
        let clientAddress = getField(row, 'client_addr')
        if (!clientAddress) {
            throw `Client address must be specified.`
        }

        // Process client info.
        let clientAddressInfo = inspectIPAddress(clientAddress, NetmaskMatchModes.CLIENT)
        if (!clientAddressInfo.isIngestible) {
            throw `Invalid client address specified '${clientAddress}' of type '${clientAddressInfo.addressType}'.`
        }

        // Get client device address.
        let clientDeviceAddress = getDeviceAddress(clientAddressInfo, recordDate, null, tags)

        // Compose client device address port.
        let clientDAP = {
            deviceAddress: clientDeviceAddress,
            port: -1,
            l4Protocol: l4Protocol,
            manuallyAdded: new SQLUpdateOp('=', false, false),
            observedAt: new SQLUpdateOp('=', recordDate, recordDate)
        }

        // Compose connection.
        let connection = {
            clientDeviceAddressPort: clientDAP,
            serverDeviceAddressPort: serverDAP,
            connectionCryptoPrimitives: [],
            connectionCipherSuites: [],
            connectionProtocolVariants: [],
            connectionCertificates: []
        }

        if (recordType === NETSCOUT_TLS_RECORD) {
            // We are dealing with NetScout TLS CSV record.

            // Get key exchange algorithm.
            let kexAlgo = getField(row, 'cipher_exch_algo')

            // Get authentication algorithm.
            let authAlgo = getField(row, 'cipher_auth_algo')

            // Get bulk encryption algorithm.
            let encAlgo = getField(row, 'cipher_enc_algo')

            // Get MAC algorithm.
            let macAlgo = getField(row, 'cipher_mac_algo')

            // If no crypto primitives are available (e.g., missing from the
            // data source, or unrecognized primitives), we'd then still create
            // a connection for this record. This aligns with Tanium.

            if (kexAlgo) {
                let kexAlgoPrimitive = netscoutCrypto.getKeyExchangePrimitive(Number(kexAlgo))

                if (kexAlgoPrimitive) {
                    connection.connectionCryptoPrimitives.push({
                        cryptoPrimitive: kexAlgoPrimitive
                    })

                    _.last(connection.connectionCryptoPrimitives).manuallyAdded = new SQLUpdateOp('=', false, false)
                    _.last(connection.connectionCryptoPrimitives).observedAt = new SQLUpdateOp('=', recordDate, recordDate)
                }
            }

            if (authAlgo) {
                let authAlgoPrimitive = netscoutCrypto.getAuthenticationPrimitive(Number(authAlgo))

                if (authAlgoPrimitive) {
                    connection.connectionCryptoPrimitives.push({
                        cryptoPrimitive: authAlgoPrimitive
                    })

                    _.last(connection.connectionCryptoPrimitives).manuallyAdded = new SQLUpdateOp('=', false, false)
                    _.last(connection.connectionCryptoPrimitives).observedAt = new SQLUpdateOp('=', recordDate, recordDate)
                }
            }

            if (encAlgo) {
                let encAlgoPrimitive = netscoutCrypto.getEncryptionPrimitive(Number(encAlgo))

                if (encAlgoPrimitive) {
                    connection.connectionCryptoPrimitives.push({
                        cryptoPrimitive: encAlgoPrimitive
                    })

                    _.last(connection.connectionCryptoPrimitives).manuallyAdded = new SQLUpdateOp('=', false, false)
                    _.last(connection.connectionCryptoPrimitives).observedAt = new SQLUpdateOp('=', recordDate, recordDate)
                }
            }

            if (macAlgo) {
                let macAlgoPrimitive = netscoutCrypto.getMACPrimitive(Number(macAlgo))

                if (macAlgoPrimitive) {
                    connection.connectionCryptoPrimitives.push({
                        cryptoPrimitive: macAlgoPrimitive
                    })

                    _.last(connection.connectionCryptoPrimitives).manuallyAdded = new SQLUpdateOp('=', false, false)
                    _.last(connection.connectionCryptoPrimitives).observedAt = new SQLUpdateOp('=', recordDate, recordDate)
                }
            }

            netscoutCrypto.calculateCipherSuiteAndPrimitives(
                connection.connectionCryptoPrimitives,
                connection.connectionCipherSuites,
                connection.connectionProtocolVariants,
                TLSMaps,
                recordDate
            )

            if (connection.connectionCipherSuites.length !== 0) {
                _.last(connection.connectionCipherSuites).manuallyAdded = new SQLUpdateOp('=', false, false)
                _.last(connection.connectionCipherSuites).observedAt = new SQLUpdateOp('=', recordDate, recordDate)
            }

            if (connection.connectionProtocolVariants.length !== 0) {
                _.last(connection.connectionProtocolVariants).manuallyAdded = new SQLUpdateOp('=', false, false)
                _.last(connection.connectionProtocolVariants).observedAt = new SQLUpdateOp('=', recordDate, recordDate)
            } else {
                connection.connectionProtocolVariants.push({
                    protocolVariant: TLSMaps.protocolVariantIDMap['TLS Unknown']
                })
            }

            connection.connectionCount = new SQLUpdateOp('+', 1, 1)
        } else {
            // We are dealing with NetScout Cert CSV record.

            // As per our conversation with NetScout, certificate records are
            // sampled mainly for the purpose of tracking certs' expiry dates.
            // Certs info are not saved/sampled for every TLS connection.
            // This means that we will not be able to correlate every cert
            // record to a connection record, or every connection record to a
            // cert record. Nevertheless, our implementation tries its best to
            // establish a correlation based on SNI, client IP, and server IP
            // matching. In order to carry out correlation, we also assume the
            // server port for cert records is "443", given that all TLS connection
            // records are from HTTPS so far.
            //
            // We create a connection even if a cert record cannot be correlated
            // to an existing connection. The new connection would contain only
            // cert info. This allows the user to ingest NetScout CSV files in
            // any order, such as cert files followed by connection files, or
            // vice versa.

            // Get server cert subject name.
            let serverCertSubjectName = getField(row, 'sub_name')
            if (serverCertSubjectName === null) {
                throw `No server cert subject name available.`
            }

            // Get server cert issuer name.
            let serverCertIssuerName = getField(row, 'issuer_name')
            if (serverCertIssuerName === null) {
                throw `No server cert issuer name available.`
            }

            // Get cert creation date.
            let serverCertCreationTimestamp = getField(row, 'activation')
            let serverCertNotBefore = null
            if (serverCertCreationTimestamp !== null) {
                serverCertNotBefore = new Date(serverCertCreationTimestamp * 1000)
            }

            // Get cert expiry date.
            let serverCertExpiryTimestamp = getField(row, 'expiry')
            let serverCertNotAfter = null
            if (serverCertExpiryTimestamp !== null) {
                serverCertNotAfter = new Date(serverCertExpiryTimestamp * 1000)
            }

            let serverCertificate = {
                subject: serverCertSubjectName,
                issuer: serverCertIssuerName,
                certificateType: allTypes['CertificateType']._enum.idByName['X509'],
                notBefore: serverCertNotBefore,
                notAfter: serverCertNotAfter,
                manuallyAdded: new SQLUpdateOp('=', false, false),
                observedAt: new SQLUpdateOp('=', recordDate, recordDate)
            }

            connection.connectionCertificates.push({
                certificate: serverCertificate
            })

            connection.serverDeviceAddressPort.deviceAddress.device.deviceCertificates.push({
                certificate: serverCertificate
            })
        }

        // TODO: GAP1840 - Implement connection caching and aggregation and batch commit.

        let checkTables = JSON.parse(JSON.stringify(updateTables))
        checkTables.ConnectionRatingScale = true

        let config = {
            allowDelete: false,
            allowInsert: true,
            allowUpdate: true,
            deletableTables: {},
            modifiableTables: updateTables,
            checkExistingTables: checkTables,
            session
        }

        populateTags(connection, 'connectionTags', tags)

        await createUpdateDelete('Connection', [connection], config)
    }

    let errorHeaders = []
    const csvWriter = new LazySingleton(async () => {
        errorHeaders[0] = 'error_message'
        for (let key of Object.keys(headersMap)) {
            errorHeaders[headersMap[key] + 1] = key
        }
        let appRoot = '/isara/'
        if (!fs.existsSync(appRoot)) {
            appRoot = process.cwd()
        }
        const errorPath = '/csv/errors'
        const errorDir = path.join(appRoot, 'data', errorPath)
        fs.mkdirSync(errorDir, { recursive: true })

        let reportFilename = `csv_upload_error_report_${results.id}.csv`
        let config = {
            allowUpdate: true,
            modifiableTables: {
                DataSourceScanResult: true
            },
            session
        }
        let errorReport = urlJoin(errorPath, reportFilename)
        let meta = JSON.stringify({ errorReport })
        await createUpdateDelete('DataSourceScanResult', [{ id: results.id, meta }], config)

        let stream = fs.createWriteStream(path.join(errorDir, reportFilename))
        let writer = fastcsv.format()
        writer.pipe(stream)
        writer.write(errorHeaders)
        return writer
    },
    async (writer) => {
        writer.end()
    })

    async function updateSummary(rowCount, additionalText) {
        if (rowCount % 100 === 0) {
            await updateScanResultSummary(results, `Processed ${rowCount.toLocaleString()} rows ${additionalText}`, session)
        }
    }

    async function moveFileToDone(source, module) {
        let appRoot = '/isara/'
        if (!fs.existsSync(appRoot)) {
            appRoot = process.cwd()
        }

        if (module === 'csv') {
            const donePath = '/csv/done'
            const destinationDir = path.join(appRoot, 'data', donePath)
            fse.move(source, `${destinationDir}/${path.basename(source)}`).then(() => log.log(`Data file ${source} has been archived successfully`)).catch((e) => log.log(e))
        } else if (module === 'netscout') {
            const donePath = '/netscout/done'
            const destinationDir = path.join(appRoot, 'data', donePath)
            // Append timestamp to the filename when archiving it. This allows
            // files with the same name to be ingested. We don't need to do this
            // for generic CSV files explicitly (above), as the filename has already
            // been updated at the POST endpoint.
            let dateNow = new Date()
            let dateString = dateNow.toString()

            // Replace spaces and colons in the date string with hyphens.
            dateString = dateString.replace(/(\s+|:+)/g, '-')

            // Append time in milliseconds to the date string. This further
            // differentiates the timestamp among files ingested within the
            // same second.
            let suffix = dateString + '-' + dateNow.getTime()
            fse.move(source, `${destinationDir}/${path.basename(source)}.${suffix}`).then(() => log.log(`Data file ${source} has been archived successfully`)).catch((e) => log.log(e))
        } else {
            log.log('Ingestion module not recognized')
        }
    }

    function isZip(mimeType) {
        return ZIP_MIME_TYPES.includes(mimeType)
    }

    function getErrorRow(errorMessage, row) {
        let errorRow = []
        errorRow[0] = errorMessage
        for (let i = 1; i < errorHeaders.length; ++i) {
            errorRow[i] = row[errorHeaders[i]]
        }
        return errorRow
    }

    const formatHandlers = {
        devices: processDeviceRow,
        connections: processConnectionRow,
        netscout_tls: processNetScoutTLSRow
    }

    let successCount = 0
    let errorCount = 0
    let metadata = JSON.parse(dataSourceScan.metadata)
    let config = JSON.parse(dataSourceScan.configuration)
    let tags = dataSourceScan.dataSourceScanTags ? dataSourceScan.dataSourceScanTags : null
    let isNetscoutIngestion = Boolean(netscoutFilesConfig?.length)
    let stream

    if (!isZip(metadata?.mimeType) && !isNetscoutIngestion) {
        stream = fs.createReadStream(metadata.tmpFile)

        stream.on('error', async function (e) {
            await onRejected(e)
            await onFinally(e)
        })
    }

    let processRow = formatHandlers[config.type]

    if (!processRow) {
        throw `Invalid file type '${config.type}'`
    }

    buildTLSMaps(session, TLSMaps)

    /**
     * @param {fs.ReadStream} stream Read Stream for the csv parser
     * @param {boolean} isLast If this is the last stream, only then on end should write a summary to the database and remove the uploaded file
     * @param {string} filePath The path to the csv file to parse
     * @param {string} additionalText Additional text to pass to the summary update
     * @returns {Promise<any>} Resolves the parser when it is done with parsing
     */
    function csvParser(stream, isLast = true, filePath, module = 'csv', additionalText = '') {
        let csvStream = fastcsv.parse({
            ignoreEmpty: true,
            headers: (headers) => {
                let index = 0
                headers = headers.map(header => {
                    header = header.toLowerCase().trim()
                    headersMap[header] = index
                    ++index
                    return header
                })
                return headers
            }
        })

        return new Promise((resolve, reject) => stream.pipe(csvStream).on('error', async function (e) {
            await onRejected(e)
            await onFinally()
            return reject()
        }).on('data', async function (row) {
            csvStream.pause()
            try {
                await session.asTransaction(async () => await processRow(row, tags))
                successCount++
                await updateSummary(successCount + errorCount, additionalText)
            } catch (e) {
                if (e instanceof PortZeroError) {
                    // Ignore the rows where server port is 0, which may appear fairly often for NetScout.
                    console.log(`${e.message}  Record ignored.`)
                } else {
                    errorCount++
                    await updateSummary(successCount + errorCount, additionalText)
                    let message = e.message
                    if (!message) {
                        message = JSON.stringify(e)
                    }
                    await reportResultDetail(
                        results,
                        message,
                        getField(row, 'hostname') || getField(row, 'serverhostname') || getField(row, 'sni') || '',
                        'CSV Row',
                        row
                    );
                    (await csvWriter.get()).write(getErrorRow(message, row))
                }
            } finally {
                csvStream.resume()
            }
        }).on('end', async function () {
            // grace period to allow async 'data' event to finish
            // TODO: GAP1631 - replace with mutex or something?
            await sleep(2000)
            stream.close()
            if (isLast) {
                moveFileToDone(filePath, module)
                await csvWriter.purge()
                let status = IngestionStatus.SUCCESS
                let errorMessage = null
                let summary = `Processed ${Number(successCount).toLocaleString()} row${successCount !== 1 ? 's' : ''} ${additionalText}${additionalText.length ? ' ' : ''}successfully`
                if (errorCount > 0) {
                    status = successCount > 0 ? IngestionStatus.PARTIAL_SUCCESS : IngestionStatus.FAILED,
                    errorMessage = 'See error report for details.'
                    summary += `; ${errorCount.toLocaleString()} error${errorCount !== 1 ? 's' : ''} occurred`
                }

                await onFulfilled(status, summary, errorMessage)
                await onFinally()
            }
            return resolve()
        }))
    }
    /**
     * @param {string} filePath The path to the zip file to parse
     * @param {boolean} isLastZip If this is the last zip, only then on end should write a summary to the database and remove the uploaded file
     * @param {string} additionalText Additional text to pass to the summary update
     */
    async function zipParser(filePath, isLastZip = true, module = 'csv', additionalText = '') {
        const zip = new StreamZip.async({ file: filePath })
        // Ignore __MACOSX directory
        // and all the directories that node-stream-zip lists as entries
        // as we only want to ingest CSV files.
        const entries = Object.values((await zip.entries())).filter(entry => !entry.name.toLowerCase().includes('__macosx') && entry.name.toLowerCase().endsWith('.csv'))

        if (entries.length === 0) {
            let status = IngestionStatus.FAILED
            let summary = 'Uploaded zip file does not contain any CSV'
            await onFulfilled(status, summary, '')
            await onFinally()
        }
        for (let i = 0; i < entries.length; i++) {
            try {
                const stm = await zip.stream(entries[i])
                await csvParser(stm, isLastZip && entries.length - 1 === i, filePath, module, additionalText)
            } catch (e) {
                await onRejected(e)
                await onFinally(e)
            }
        }
        await zip.close()
    }


    /**
     * @param {Array.<{mimeType: string, tmpFile: string}>} filesConfig Array of objects containing the file information
     */
    async function startNetscoutIngestion(filesConfig) {
        const total = filesConfig.length
        let current = 0
        for (let i = 0; i < filesConfig.length; i++) {
            const isLastFile = total - 1 === i
            const { mimeType, tmpFile } = filesConfig[i]
            current++
            const additionalText = `in ${current} of ${total} file${total === 1 ? '' : 's'}`
            if (mimeType === 'csv') {
                const stm = fs.createReadStream(tmpFile)

                stm.on('error', async function (e) {
                    await onRejected(e)
                    await onFinally(e)
                })

                await csvParser(stm, isLastFile, tmpFile, 'netscout', additionalText)

                if (!isLastFile) {
                    moveFileToDone(tmpFile, 'netscout')
                    await csvWriter.purge()
                }
            } else {
                await zipParser(
                    tmpFile,
                    isLastFile,
                    'netscout',
                    additionalText
                )
            }
        }
    }

    if (isZip(metadata?.mimeType)) {
        await zipParser(metadata.tmpFile)
    } else if (isNetscoutIngestion) {
        await startNetscoutIngestion(netscoutFilesConfig)
    } else {
        csvParser(stream, true, metadata.tmpFile)
    }
}

module.exports = {
    name: 'CSV',
    test: async () => { },
    scan: ingestCSV,
}
