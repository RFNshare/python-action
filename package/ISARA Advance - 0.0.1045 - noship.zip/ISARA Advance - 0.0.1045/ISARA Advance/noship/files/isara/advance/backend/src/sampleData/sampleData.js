/**
 * @file sampleData.js - 0.0.1045 - ea4595bfd3488684d225574ed7d4c198074d49ba
 * 
 * @copyright Copyright (C) 2016-2023, ISARA Corporation, All Rights Reserved.
 * 
 * @license The code and other content set out herein is not in the public
 * domain, is considered a trade secret and is confidential to ISARA
 * Corporation. Use, reproduction or distribution, in whole or in part, of such
 * code or other content is strictly prohibited except by express written
 * permission of ISARA Corporation. Please contact ISARA Corporation at
 * info@isara.com for more information.
 */

var randomWords = require('random-words')

const {
    dumpObjectTimingStats,
    initDbConnection,
    insertObject,
    bulkInsertRecords,
    resetObjectTimingStats
} = require('./dbHelpers')

const {
    Session
} = require('../isaraql/session')

const {
    pickOne,
    pickOneAndRemove,
    randomBelow,
    randomCompany,
} = require('./sampleHelpers')

const {
    loadDatabaseTypes,
} = require('./dbTypeHelpers')

const {
    allCryptoPrimitives,
    protocolVariants,
    roles,
    softwareTypes,
    tagTypes,
    users
} = require('./dbTypes')

var {
    hashPassword
} = require('../util/passwordUtils')

const { updateCryptoScoresForDevice, updateCryptoScoresForConnection } = require('../util/scoreHelpers')

const { rebuildAllFlatFacetTables } = require('../util/flatFacetHelpers')

const { Mutex } = require('async-mutex')

const {
    allTypes,
    discoverSchema
} = require('../isaraql/schemaDiscovery')

const {
    Agent,
    AgentCertificate,
    CAIssuedCertificate,
    Certificate,
    CertificateCryptoPrimitive,
    CertificationAuthority,
    Connection,
    ConnectionCertificate,
    ConnectionCipherSuite,
    ConnectionProtocolVariant,
    ConnectionProtocolVariantCertificate,
    ConnectionTag,
    Device,
    DeviceAddress,
    DeviceAddressMACAddress,
    DeviceAddressPort,
    DeviceCertificate,
    DeviceMACAddress,
    DeviceSoftware,
    DeviceSoftwareConnection,
    DeviceTag,
    KeyStore,
    KeyStoreKey,
    OneTimeKey,
    Netmask,
    Notification,
    NotificationAction,
    Software,
    SoftwareVersion,
    SoftwareVersionTag,
    Tag,
    User,
    UserRole
} = require('./dbObjects')

var log = require('../util/log')(module)

var connection = null

var allConnections = []
var allDevices = []
var allDeviceSoftware = {}
var allSoftware = {}
var allSoftwareVersions = {}
var allTags = []
var notifications = []
var connectionTags = []
var connectionTagAssociations = []
var softwareVersionTags = []
var softwareVersionTagAssociations = []

const sampleSoftware = {
    'OS': ['Windows', 'macOS', 'Linux'],
    'SERVER': ['Apache', 'Nginx', 'Mongoose'],
    'APP': ['AngryBirds', 'Outlook', 'Sublime Text'],
    'WEB_SERVER': ['Tomcat', 'Apache'],
    'DATABASE': ['MongoDB', 'SQLite', 'Oracle', 'Redis', 'MariaDB', 'Couchbase'],
    'ARCHIVE': ['Winzip', 'WinRAR', '7-Zip', 'Zip Archiver'],
    'FINANCIAL': ['QuickBooks', 'Xero', 'FreshBooks', 'Sage', 'Zoho Books'],
    'BROWSER': ['Firefox', 'Chrome', 'Internet Explorer', 'Safari', 'Brave'],
    'CMS': ['WordPress', 'Drupal', 'Joomla', 'SharePoint', 'Magneto'],
    'CRYPTOGRAPHIC': ['LastPass', 'BitLocker', 'VeraCrypt', 'FileVault', 'DiskCryptor'],
    'OTHER': ['REAPER', 'Random', 'Other']
}

const tagTypeValuesMap = {
    EXCEPTION: ['OK', 'NOT OK'],
    ZONE: ['York', 'Waterloo', 'Kitchener', 'Vancouver', 'Berlin', 'London', 'New York', 'Montréal'],
    PRIORITY: ['HIGH', 'LOW'],
    DEVICE_PURPOSE: ['Finance Dept Machine', 'Print Checks', 'Jenkins Server', 'CI Machine', 'Student Services Server'],
    CPU_FAMILY: ['Intel', 'ARM'],
    NETWORK_CARD_TYPE: ['Intel Carrot', 'Broadcom NetXtreme'],
    HOSTNAME: ['alice', 'bob', 'charlie123', 'alice.isara.com', 'bob.isara.com', 'charlie123.uwaterloo.ca'],
    DOMAIN: ['isara.com', 'uwaterloo.ca', 'google.com', 'aws.amazon.com'],
    NORMAL_ADDRESS: ['1234 Physical St', '567 Mylocation Ave Unit 123', '890 YetAnotherPlace Rd']
}

async function populateSoftware() {
    for (let typeName of Object.keys(softwareTypes)) {
        if (sampleSoftware[typeName]) {
            for (let softwareName of sampleSoftware[typeName]) {
                if (!(softwareName in Object.keys(allSoftware))) {
                    let software = new Software(softwareName, randomCompany(), softwareTypes[typeName].id)
                    await insertObject(software)
                    allSoftware[softwareName] = software
                    let versionsCount = randomBelow(7, 1)
                    for (let k = 0; k < versionsCount; ++k) {
                        let softwareVersion = new SoftwareVersion(software.id, softwareName, k)
                        await insertObject(softwareVersion)
                        if (!Object.keys(allSoftwareVersions).includes(typeName)) {
                            allSoftwareVersions[typeName] = []
                        }
                        allSoftwareVersions[typeName].push(softwareVersion)
                    }
                }
            }
        }
    }
}

async function insertUsers() {
    var names = [
        { name: 'callum', fullName: 'Callum Craig' },
        { name: 'fred', fullName: 'Fred Ferguson' },
        { name: 'sara', fullName: 'Sara Smith' }
    ]

    let usersArray = []
    for (var name of names) {
        var user = new User(name.name, name.fullName,
            await hashPassword('password'))
        usersArray.push(user.nameValues)
    }
    let results = await bulkInsertRecords('User', usersArray, session)
    users.push(...results.rows)
}

async function insertUserRoles() {
    var roleIndex = 0
    let userRoleArray = []
    for (var user of users) {
        var roleNames = Object.keys(roles)
        var roleName = roleNames[roleIndex++]
        if (roleIndex == roleNames.length) {
            roleIndex = 0
        }
        var role = roles[roleName]
        var userRole = new UserRole(user.id, role.id)
        userRoleArray.push(userRole.nameValues)
    }
    await bulkInsertRecords('UserRole', userRoleArray, session)
}

async function insertNotifications() {
    let notificationArray = []
    for (var i = 0; i < 100; ++i) {
        var notification = new Notification()

        notificationArray.push(notification.nameValues)
    }
    let results = await bulkInsertRecords('Notification', notificationArray, session)
    notifications.push(...results.rows)
}

async function insertNotificationActions() {
    let notificationActionArray = []
    for (var notification of notifications) {
        for (var user of users) {
            if (Math.random() < 0.1) {
                var notificationAction = new NotificationAction(notification, user)
                notificationActionArray.push(notificationAction.nameValues)
            }
        }
    }
    await bulkInsertRecords('NotificationAction', notificationActionArray, session)
}

async function insertNetmasks() {
    let netmaskArray = []
    for (var i = 0; i < 20; ++i) {
        var netmask = new Netmask()
        netmaskArray.push(netmask.nameValues)
    }
    await bulkInsertRecords('Netmask', netmaskArray, session)
}

function tagType() {
    var types = Object.keys(tagTypes)
    var which = Math.floor(Math.random() * types.length)
    return tagTypes[types[which]]
}

async function tidyOldRecords() {
    // Do not tidy Enum tables.
    const tables = {
        'Netmask': `netmask != ''`,
        'AgentCertificate': null,
        'Agent': null,
        'DataSourceScanResultDetail': null,
        'DataSourceScanResult': null,
        'DataSourceScanSchedule': null,
        'DataSourceScanTag': null,
        'DataSourceScan': null,
        'DataSource': null,
        'NotificationAction': null,
        'Notification': null,
        'ConnectionCipherSuite': null,
        'ConnectionCryptoPrimitive': null,
        'DeviceSoftwareConnection': null,
        'ConnectionProtocolVariantCertificate': null,
        'ConnectionProtocolVariant': null,
        'ConnectionScore': null,
        'ConnectionTag': null,
        'Connection': null,
        'DeviceScore': null,
        'DeviceCertificate': null,
        'CAIssuedCertificate': null,
        'CertificateCryptoPrimitive': null,
        'ConfigurationFileCipherSuite': null,
        'ConfigurationFileCertificate': null,
        'ConfigurationFile': null,
        'Certificate': null,
        'OneTimeKey': null,
        'CertificationAuthority': null,
        'KeyStoreKey': null,
        'KeyStore': null,
        'DeviceSoftware': null,
        'Device': null,
        'SoftwareVersionTag': null,
        'Tag': null,
        'SoftwareVersion': `software NOT IN (select id FROM "Software" WHERE "softwareType" = ${allTypes['SoftwareType']._enum.idByName['DATA']})`,
        'Software': `"softwareType" != ${allTypes['SoftwareType']._enum.idByName['DATA']}`,
        'View': null,
        'UserPreference': null,
        'UserRole': null,
        'User': null
    }
    for (var table in tables) {
        let where = ''
        if (tables[table]) {
            where = `where ${tables[table]}`
        }
        await connection.query(`delete from "${table}" ${where}`)
    }
}

async function insertTag(tag) {
    let index = allTags.findIndex((x) => x.tagType === tag.tagType && x.value === tag.value)
    if (index < 0) {
        await insertObject(tag)
        allTags.push(tag)
    } else {
        tag = allTags[index]
    }

    return tag.id
}

const SoftwareVersionTagsText = ['STABLE', 'ALPHA1', 'ALPHA2', 'BETA1', 'BETA2']

async function generateAndInsertSoftwareVersionTags() {
    var custom_id = tagTypes['CUSTOM'].id
    let softwareVersionTagsArray = []
    for (var i = 0; i < SoftwareVersionTagsText.length; i++) {
        let tag = new Tag(SoftwareVersionTagsText[i], custom_id)
        softwareVersionTagsArray.push(tag.nameValues)
    }
    let results = await bulkInsertRecords('Tag', softwareVersionTagsArray, session)
    softwareVersionTags.push(...results.rows)
}

let softwareVersionTagArray=[]
function insertSoftwareVersionTag(version) {
    var randomVersionTag = pickOne(softwareVersionTags)

    if (softwareVersionTagAssociations.findIndex((x) => x.softwareVersion == version.id && x.tag == randomVersionTag.id) == -1) {
        let softwareVersionTag = new SoftwareVersionTag(version.id, randomVersionTag.id)
        softwareVersionTagArray.push(softwareVersionTag.nameValues)
        softwareVersionTagAssociations.push(softwareVersionTag)
    }
}

const ConnectionTagsText = [`Tunneled`, `VPN`, `Timed_Out`, `Error_Detected`]

async function generateAndInsertConnectionTags() {
    var custom_id = tagTypes['CUSTOM'].id
    let connectionTagsArray = []
    for (var i = 0; i < ConnectionTagsText.length; i++) {
        let tag = new Tag(ConnectionTagsText[i], custom_id)
        connectionTagsArray.push(tag.nameValues)
    }
    let results = await bulkInsertRecords('Tag', connectionTagsArray, session)
    connectionTags.push(...results.rows)
}

let connectionsTags =[]
function insertConnectionTag(connection) {
    var randomConnectionTag = pickOne(connectionTags)

    if (connectionTagAssociations.findIndex((x) => x.connection == connection.id && x.tag == randomConnectionTag.id) == -1) {
        let connectionTag = new ConnectionTag(connection.id, randomConnectionTag.id)
        connectionsTags.push(connectionTag.nameValues)
        connectionTagAssociations.push(connectionTag)
    }
}

async function generateTag(tagType) {
    var tagValue = ''
    // Map tag type to generate a new random tag
    if (tagType.isNumeric) {
        var numericValue = -1
        switch (tagType.name) {
        case 'RAM_SIZE': {
        // Reasonable RAM size in Bytes: 1 GB to 1 TB?
            var sizeInGB = 1 << randomBelow(11)
            numericValue = sizeInGB * Math.pow(10, 9)
            break
        }
        case 'CPU_SPEED': {
        // CPU Speed: 500 MHz to 5 GHz
            let sizeInMHz = randomBelow(5000, 500)
            numericValue = sizeInMHz * Math.pow(10, 6)
            break
        }
        default:
            throw `Unknown numeric tag type`
        }
        tagValue = `${numericValue}`
    } else {
    // Non-numeric
        var mapValue = tagTypeValuesMap[tagType.name]
        if (!mapValue || !mapValue.length) {
            switch (tagType.name) {
            case 'COORDINATE':
                tagValue = `${randomBelow(90)} ${pickOne(['N', 'S'])} ${randomBelow(180)} ${pickOne(['W', 'E'])}`
                break
            case 'CPU_SERIAL_NUMBER':
            case 'SERVER_ROOM_NUMBER':
            case 'RACK_ADDRESS':
            case 'MACHINE_SERIAL_NUMBER':
            case 'OS_SERIAL_NUMBER':
            case 'CORPORATE_ASSET_TAG_TRACKING_NUMBER':
                break
            default:
                // randomWords can return an array of length 1 *or* a raw string ; make sure to catch this.
                tagValue = randomWords(1)
                if (Array.isArray(tagValue)) {
                    tagValue = tagValue[0]
                }
                break
            }
        } else {
            tagValue = pickOne(mapValue)
        }
    }

    return new Tag(tagValue, tagType.id)
}


function readIntFromArgs(args) {
    if (args.length < 2) {
        throw new Error('Missing int argument')
    }
    var toReturn = +args[1]
    args.splice(0, 2)
    return toReturn
}

var DEVICE_COUNT = 100
var CONNECTION_COUNT = 600
var SERVER_COUNT = 10
let chunkSize = 10
let createBaselineOnly = false
let session = new Session()

function usage() {
    console.log(`Usage: node ${process.argv[1]}`)
    console.log('\n')
    console.log('Optional arguments:\n\n')
    console.log(`\t--deviceCount: Number of devices to create (default ${DEVICE_COUNT})`)
    console.log(`\t--connectionCount: Number of connections to create (default ${CONNECTION_COUNT})`)
    console.log(`\t--serverCount: Number of servers to create (default ${SERVER_COUNT})`)
    console.log(`\t--baselineOnly: Only provision user objects and minimal required data.`)
    process.exit(0)
}

async function main() {
    log.log('Entered main')

    connection = await initDbConnection()
    await discoverSchema()
    var myArgs = process.argv.slice(2)

    while (myArgs.length > 0) {
        switch (myArgs[0]) {
        case '--deviceCount':
            DEVICE_COUNT = readIntFromArgs(myArgs)
            break
        case '--serverCount':
            SERVER_COUNT = readIntFromArgs(myArgs)
            break
        case '--connectionCount':
            CONNECTION_COUNT = readIntFromArgs(myArgs)
            break
        case '--baselineOnly':
            createBaselineOnly = true
            myArgs.shift()
            break
        default:
            console.log(`Unsupported argument: ${myArgs[0]}`)
            usage()
        }
    }



    log.log('Purging database...')
    await tidyOldRecords()

    log.log('Discovering schema...')
    await discoverSchema()

    log.log('Loading database types...')
    await loadDatabaseTypes()

    log.log('Adding users...')
    await insertUsers()
    await insertUserRoles()

    if (createBaselineOnly) {
        await connection.end()
        return
    }


    let startTime = new Date()

    log.log('Adding software version tags...')
    await generateAndInsertSoftwareVersionTags()

    log.log('Adding connection tags...')
    await generateAndInsertConnectionTags()

    log.log('Adding notifications...')
    await insertNotifications()
    await insertNotificationActions()

    log.log('Adding network masks...')
    await insertNetmasks()

    log.log('Adding software...')
    await populateSoftware()

    dumpObjectTimingStats()
    resetObjectTimingStats()

    let anyDeviceAddressPorts = []
    let listeningDeviceAddressPorts = []
    let allCipherSuites = (await connection.query(`SELECT id FROM "CipherSuite" `)).rows


    // add device functions
    let deviceAgents = {}
    let allDevicesValues = []

    const mutex = new Mutex()
    let addDevice = async function () {
        let device = new Device()
        await device.populate()
        allDevicesValues.push(device.nameValues)
    }

    let addDeviceSoftware = async function(devices){
        let deviceSoftwareArray = []
        for(let device of devices){
            if (Math.random() > 0.2) {
                let softwareCount = randomBelow(20, 1)
                let hasOS = false
                for (let i = 0; i < softwareCount; ++i) {
                    let softwareType = pickOne(Object.keys(allSoftwareVersions))
                    if (hasOS && softwareType == 'OS') {
                        continue
                    } else {
                        hasOS = true
                    }

                    let versions = allSoftwareVersions[softwareType]
                    let software = pickOne(versions)
                    let deviceSoftware = new DeviceSoftware(device, software)
                    deviceSoftwareArray.push(deviceSoftware.nameValues)
                }
            }
        }
        let results  = await bulkInsertRecords('DeviceSoftware',deviceSoftwareArray,session)

        for(let software of results.rows){
            if (!allDeviceSoftware[software.device]) {
                allDeviceSoftware[software.device] = []
            }
            allDeviceSoftware[software.device].push(software.id)
        }
    }

    let addDeviceTags = async function(devices){
        let deviceTagArray = []
        for(let device of devices){
            let tagCount = Math.floor(Math.random() * 10)
            let usedTags = []
            await mutex.runExclusive(async () => {
                for (let j = 0; j < tagCount; ++j) {
                    // Add random tags
                    let randomTagType = tagType()
                    let randomTag = await generateTag(randomTagType)
                    let result = await insertTag(randomTag)
                    if (usedTags.includes(result)) {
                        continue
                    }
                    usedTags.push(result)
                    var deviceTag = new DeviceTag(device.id,result)
                    deviceTagArray.push(deviceTag.nameValues)
                }
            })
        }
        await bulkInsertRecords('DeviceTag',deviceTagArray,session)
    }

    let addDeviceAddressPort = async function(deviceAddressArray, devices) {
        let deviceAddressPortArray = []
        for(let deviceAddress of deviceAddressArray){
            let existingPorts = []
            let portCount = randomBelow(3, 1)
            for (var k = 0; k < portCount; ++k) {
                let deviceAddressPort = new DeviceAddressPort(deviceAddress, existingPorts)
                await deviceAddressPort.populate()
                deviceAddressPortArray.push(deviceAddressPort.nameValues)
                existingPorts.push(deviceAddressPort.port)
            }
            let deviceAddressPort = new DeviceAddressPort(deviceAddress)
            deviceAddressPort.port = -1
            await deviceAddressPort.populate()
            deviceAddressPortArray.push(deviceAddressPort.nameValues)
        }

        let results = await bulkInsertRecords('DeviceAddressPort', deviceAddressPortArray, session)

        for(let port of results.rows){
            let deviceAddress = deviceAddressArray.find(deviceAddress => deviceAddress.id === port.deviceAddress)
            let device = devices.find(device => device.id === deviceAddress.device)
            if(port.port === -1){
                anyDeviceAddressPorts.push({ port: port, device: device, address: deviceAddress })
            }else{
                listeningDeviceAddressPorts.push({ port: port, device: device, address: deviceAddress })
            }
        }
    }

    let addDeviceAddressMACAddress = async function (deviceAddressArray,deviceMACAddressArray) {

        let deviceAddressMACAddressArray = []

        for(let i = 0 ; i < deviceAddressArray.length; i++){
            let deviceAddressMACAddress = new DeviceAddressMACAddress(deviceAddressArray[i], deviceMACAddressArray[i])
            deviceAddressMACAddressArray.push(deviceAddressMACAddress.nameValues)
        }

        await bulkInsertRecords('DeviceAddressMACAddress', deviceAddressMACAddressArray, session)
    }

    let addDeviceAddress = async function (devices) {

        let agentsArray = []
        let deviceAddressArray = []
        let deviceMACAddressArray = []

        for(let device of devices){

            // TODO: GAP1629 - this should probably be further narrowed down to only include an agent on devices which can actually install one
            // e.g. servers/workstations/VMs
            if (pickOne([true, false])) {
                let agent = new Agent(device.id)
                agentsArray.push(agent.nameValues)
                deviceAgents[device.id] = agent
            }


            let addressCount = Math.random() > 0.7 ? 2 : 1
            for (var j = 0; j < addressCount; ++j) {

                let deviceAddress = new DeviceAddress(device)
                await deviceAddress.populate()
                deviceAddressArray.push(deviceAddress.nameValues)

                let deviceMACAddress = new DeviceMACAddress(device)
                deviceMACAddressArray.push(deviceMACAddress.nameValues)

            }

        }

        let agentResult = await bulkInsertRecords('Agent', agentsArray, session)
        for(let agent of agentResult.rows){
            deviceAgents[agent.device] = agent
        }

        let deviceAddressArrayResult =  await bulkInsertRecords('DeviceAddress', deviceAddressArray , session)
        let deviceMACAddressArrayResult = await bulkInsertRecords('DeviceMACAddress', deviceMACAddressArray, session)
        await addDeviceAddressMACAddress(deviceAddressArrayResult.rows,deviceMACAddressArrayResult.rows)
        await addDeviceAddressPort(deviceAddressArrayResult.rows,devices)
        await addDeviceTags(devices)
        await addDeviceSoftware(devices)

    }

    let addOneTimeKey = async function (certificationAuthoritys){
        let oneTimeKeyArray = []
        for(let certificationAuthority of certificationAuthoritys){
            let oneTimeKey = new OneTimeKey(certificationAuthority)
            await oneTimeKey.populate()
            oneTimeKeyArray.push(oneTimeKey.nameValues)
        }
        await bulkInsertRecords('OneTimeKey', oneTimeKeyArray, session)
    }

    let addCertificationAuthority = async function (keyStoreKeys, certAuthorities){
        let certificationAuthorityArray =[]
        for(let keyStoreKey of keyStoreKeys){
            let certificationAuthority = new CertificationAuthority(keyStoreKey)
            certificationAuthorityArray.push(certificationAuthority.nameValues)
        }
        let results = await bulkInsertRecords('CertificationAuthority', certificationAuthorityArray, session)
        for(let certificationAuthority of results.rows){
            certAuthorities.push(certificationAuthority)
        }
        await addOneTimeKey(results.rows)
    }

    let addKeyStoreKey = async function(keyStores,certAuthorities){
        let keyStoreKeyArray = []
        for(let keyStore of keyStores){
            let keyStoreKey = new KeyStoreKey(keyStore)
            await keyStoreKey.populate()
            keyStoreKeyArray.push(keyStoreKey.nameValues)
        }
        let result = await bulkInsertRecords('KeyStoreKey', keyStoreKeyArray, session)
        await addCertificationAuthority(result.rows, certAuthorities)
    }

    let addKeyStore= async function(certAuthorities){
        let caCount = Math.floor(Math.random() * 10 + 1)
        let keyStoreArray =[]
        for (let i = 0; i < caCount; i++) {
            let keyStore = new KeyStore()
            keyStoreArray.push(keyStore.nameValues)
        }
        let results = await bulkInsertRecords('KeyStore', keyStoreArray, session, true)
        await addKeyStoreKey(results.rows, certAuthorities)
    }

    let addConnectionCertificate = async function(connections,certificate){
        let connectionCertificates  = []
        for(let connection of connections){
            let connCert = new ConnectionCertificate(connection.id, certificate.id)
            connectionCertificates.push(connCert.nameValues)
        }
        await bulkInsertRecords('ConnectionCertificate', connectionCertificates, session)
    }

    let addConnectionProtocolVariantCertificate = async function(connectionProtocolVariants, certificate){
        let connectionProtocolVariantCertificate = []
        for(let connectionProtocolVariant of connectionProtocolVariants){
            let connProtVarCert = new ConnectionProtocolVariantCertificate(
                connectionProtocolVariant.id, certificate.certificateType, certificate.id)
            connectionProtocolVariantCertificate.push(connProtVarCert.nameValues)
        }
        await bulkInsertRecords('ConnectionProtocolVariantCertificate', connectionProtocolVariantCertificate, session)
    }

    let addConnectionProtocolVariant = async function(connections, certificate){
        let connectionProtocolVariant = []
        if (certificate) {
            for(let connection of connections){
                let protocolVariantCount = randomBelow(4)
                let addedProtocolVariants = {}

                for (let k = 0; k < protocolVariantCount; ++k) {
                    let protocolVariant = pickOne(protocolVariants)
                    if (!addedProtocolVariants[protocolVariant.id]) {
                        let connProtVar = new ConnectionProtocolVariant(connection.id, protocolVariant.id)
                        connectionProtocolVariant.push(connProtVar.nameValues)
                        addedProtocolVariants[protocolVariant.id] = connProtVar
                    }
                }
            }
            if(connectionProtocolVariant.length > 0){
                let results =  await bulkInsertRecords('ConnectionProtocolVariant', connectionProtocolVariant, session)
                await addConnectionProtocolVariantCertificate(results.rows,certificate)
                await addConnectionCertificate(connections,certificate)
            }
        }
    }

    let addConnectionCipherSuites = async function(connections){
        let connectionCipherSuites = []
        for(let connection of connections){
            let numCipherSuites = pickOne([0, 1, 1, 1, 1, 1, 1, 1, 2, 3])
            let usedCipherSuites = []
            // not all Connections will have a CipherSuite
            if (pickOne([true, false])) {
                while (usedCipherSuites.length < numCipherSuites) {
                    let connectionCipherSuite = new ConnectionCipherSuite(connection, pickOne(allCipherSuites))
                    if (usedCipherSuites.includes(connectionCipherSuite.cipherSuite)) {
                        continue
                    }
                    connectionCipherSuites.push(connectionCipherSuite.nameValues)
                    usedCipherSuites.push(connectionCipherSuite.cipherSuite)
                }
            }
        }
        if(connectionCipherSuites.length > 0){
            await bulkInsertRecords('ConnectionCipherSuite', connectionCipherSuites, session)
        }
    }

    let addDeviceSoftwareConnection = async function(connections,server){
        let deviceSoftwareConnection = []
        for(let connection of connections){
            // // Not all connections will have detected software on both ends
            if (pickOne([true, false]) && allDeviceSoftware[server.device.id]) {
                let serverSoftware = pickOne(allDeviceSoftware[server.device.id])
                let softwareConnection = new DeviceSoftwareConnection(serverSoftware, connection)
                deviceSoftwareConnection.push(softwareConnection.nameValues)
            }
        }
        if(deviceSoftwareConnection.length > 0){
            await bulkInsertRecords('DeviceSoftwareConnection', deviceSoftwareConnection, session)
        }
    }

    let clientsArray = []
    let addClientSoftwareConnection = async function(connections,clients){
        let allClientSoftwareConnections = []
        for(let connection of connections){
            let client = clients.find(client => client.port.id === connection.clientDeviceAddressPort)
            if (pickOne([true, false]) && allDeviceSoftware[client.device.id]) {
                let clientSoftware = pickOne(allDeviceSoftware[client.device.id])
                let softwareConnection = new DeviceSoftwareConnection(clientSoftware, connection)
                allClientSoftwareConnections.push(softwareConnection.nameValues)
            }
        }
        if(allClientSoftwareConnections.length > 0){
            await bulkInsertRecords('DeviceSoftwareConnection', allClientSoftwareConnections, session)
        }
    }

    let allConnectionValues = []
    let addConnection = async function (client, server) {
        const newConnection = new Connection()

        if(client){
            newConnection.clientDeviceAddressPort = client.port.id
        }
        newConnection.serverDeviceAddressPort = server.port.id
        if (Math.random() > .7) {
            newConnection.addedBy = pickOne(users).id
        }
        let clientAddress = (client) ? client.address.address : '\u2015'
        let serverAddress = server.address.address
        let serverPort = server.port.port
        newConnection.friendlyName = clientAddress + ' \u2192 ' + serverAddress + ' : ' + serverPort
        allConnectionValues.push(newConnection.nameValues)
    }

    const defineChunkArray = () => {
        let toReturn = []
        for (let y = 0; y < Math.ceil(DEVICE_COUNT / chunkSize); y++) {
            toReturn.push(chunkSize)
        }
        return toReturn
    }

    let chunkArray = defineChunkArray()
    let connectionsPerChunk = CONNECTION_COUNT / (chunkArray.length * SERVER_COUNT)

    for (let i = 0; i < chunkArray.length; i++) {
        anyDeviceAddressPorts = []
        listeningDeviceAddressPorts = []
        deviceAgents = {}
        allDeviceSoftware = {}

        if (global.gc) {
            global.gc()
        }

        DEVICE_COUNT = chunkArray[i]

        let promises = []
        allDevicesValues = []
        for (let i = 0; i < DEVICE_COUNT; ++i) {
            await addDevice()
            if (allDevicesValues.length >= DEVICE_COUNT) {
                let results =  await bulkInsertRecords('Device', allDevicesValues, session)
                await addDeviceAddress(results.rows)
                allDevices.push(...results.rows)
            }
            showCount('Device', i + 1, DEVICE_COUNT)
        }

        log.log(`Heap memory used: ${Math.round(process.memoryUsage().heapUsed / 1024 / 1024 * 100) / 100} MB`)

        showCount('Device', DEVICE_COUNT, DEVICE_COUNT)
        dumpObjectTimingStats()

        //add the connections
        let certAuthorities = []

        await addKeyStore(certAuthorities)

        resetObjectTimingStats()

        let copyOfListeningDeviceAddressPorts = [...listeningDeviceAddressPorts]

        for (let i = 0; i < SERVER_COUNT; ++i) {
            try {
                const server = pickOneAndRemove(copyOfListeningDeviceAddressPorts)
                let candidates = [...anyDeviceAddressPorts]

                let certificate = null

                // not all Servers will have a Certificate
                if (pickOne([true, false])) {
                    certificate = new Certificate(pickOne(certAuthorities))
                    await certificate.populate()
                    await insertObject(certificate)

                    let deviceCertificate = new DeviceCertificate(server.device.id, certificate.id)
                    await insertObject(deviceCertificate)

                    let certPrimitiveCount = randomBelow(4, 1)
                    let certPrimitives = []
                    for (let k = 0; k < certPrimitiveCount; ++k) {
                        let primitive = pickOne(allCryptoPrimitives)
                        let primitiveId = primitive.id
                        let keyLength = null
                        let upperLimit = null
                        let nameSplit = primitive.name.split('_')
                        let standardRSA = [512, 1024, 2048, 3072, 4096, 6000]
                        let standardDSA = [1024, 2048, 3072, 7680, 15360, 16000]
                        if (primitive.name.includes('RSA')) {
                            if (randomBelow(3)) {
                                let roundDown = parseInt(nameSplit[nameSplit.length - 1])
                                upperLimit = standardRSA[standardRSA.indexOf(roundDown) + 1]
                                keyLength = randomBelow(upperLimit, roundDown + 1)
                            }
                        }
                        if (primitive.name.includes('DSA_DSS')) {
                            if (randomBelow(3)) {
                                let roundDown = parseInt(nameSplit[nameSplit.length - 2])
                                upperLimit = standardDSA[standardDSA.indexOf(roundDown) + 1]
                                keyLength = randomBelow(upperLimit, roundDown + 1)
                            }
                        }
                        if (!certPrimitives.includes(primitiveId)) {
                            certPrimitives.push(primitiveId)
                            await insertObject(new CertificateCryptoPrimitive(certificate.id, primitiveId, keyLength))
                        }
                    }
                    let caIssuedCertificate = new CAIssuedCertificate(pickOne(certAuthorities), certificate)
                    await insertObject(caIssuedCertificate)

                    if (deviceAgents[server.device.id]) {
                        let agent = deviceAgents[server.device.id]
                        let agentCertificate = new AgentCertificate(agent, certificate)
                        await insertObject(agentCertificate)

                    }
                }


                for (let j = 0; j < connectionsPerChunk; ++j) {
                    let addServerOnlyConnection = candidates.length > 0 ? pickOne([true, false]) : false
                    let client
                    if (addServerOnlyConnection) {
                        client = pickOneAndRemove(candidates)
                        clientsArray.push(client)
                    }
                    await addConnection(client, server)
                    if (allConnectionValues.length >= connectionsPerChunk) {
                        let results =  await bulkInsertRecords('Connection', allConnectionValues, session)
                        for(let connection of results.rows){
                            allConnections.push(connection)
                        }
                        await addConnectionProtocolVariant(results.rows, certificate)
                        await addConnectionCipherSuites(results.rows)
                        await addDeviceSoftwareConnection(results.rows,server)

                        let connectionsWithClients = results.rows.filter(connection => connection.clientDeviceAddressPort !== null)
                        await addClientSoftwareConnection(connectionsWithClients,clientsArray)
                        clientsArray = []
                        allConnectionValues = []
                    }
                }

                await Promise.all(promises)
                promises = []

            } catch (error) {
                console.log('Failed to create connection', error)
            }
            showCount('Server', i + 1, SERVER_COUNT)

        }

        const clients = (await connection.query(
            `select d.id,count(*) FROM "Device" d JOIN "DeviceAddress" da ON da.device = d.id JOIN "DeviceAddressPort" dap ON dap."deviceAddress" = da.id JOIN "Connection" c on c."clientDeviceAddressPort" = dap.id GROUP BY 1 ORDER BY  1 DESC LIMIT ${DEVICE_COUNT}`,
        )).rows
        const servers = (await connection.query(
            `select d.id,count(*) FROM "Device" d JOIN "DeviceAddress" da ON da.device = d.id JOIN "DeviceAddressPort" dap ON dap."deviceAddress" = da.id JOIN "Connection" c on c."serverDeviceAddressPort" = dap.id GROUP BY 1 ORDER BY  1 DESC LIMIT ${DEVICE_COUNT}`,
        )).rows

        let outgoingConnectionCounts = []
        if (clients.length > 0) {
            let i = 0
            for (let client of clients) {
                outgoingConnectionCounts.push(`(${client.count},${client.id})`)
                showCount('Update Client Connection Counts', i, clients.length)
                i++
            }
            showCount('Update Client Connection Counts', i, clients.length)
        }

        await connection.query(`UPDATE "Device" as t SET "outgoingConnectionCount"=c.outgoingConnectionCount from (values ${outgoingConnectionCounts.join(',')} ) as c(outgoingConnectionCount, id) WHERE c.id=t.id`)

        let incomingConnectionCount = []
        if (servers.length > 0) {
            let i = 0
            for (let server of servers) {
                incomingConnectionCount.push(`(${server.count},${server.id})`)
                showCount('Update Server Connection Counts', i, servers.length)
                i++
            }
            showCount('Update Server Connection Counts', i, servers.length)
        }

        await connection.query(`UPDATE "Device" as t SET "incomingConnectionCount"=c.incomingConnectionCount from (values ${incomingConnectionCount.join(',')} ) as c(incomingConnectionCount, id) WHERE c.id=t.id`)

        showCount('Server', SERVER_COUNT, SERVER_COUNT)
        dumpObjectTimingStats()
        await Promise.all(promises)

    }

    await rebuildAllFlatFacetTables(true)
    dumpObjectTimingStats(true)

    console.log('Adding software version tags...')
    let versionCount = Math.floor(Math.random() * 100)
    for (let j = 0; j < versionCount; ++j) {
    // Add random version tags
        var randomVersion = pickOne(pickOne(allSoftwareVersions))
        insertSoftwareVersionTag(randomVersion)
        showCount('SoftwareVersionTag', j + 1, versionCount)
    }

    await bulkInsertRecords('SoftwareVersionTag', softwareVersionTagArray, session)
    softwareVersionTagArray =[]

    console.log('Adding connection tags...')
    let connectionCount = Math.floor(Math.random() * 100)
    for (let j = 0; j < connectionCount; ++j) {
    // Add random version tags
        let randomConnection = pickOne(allConnections)
        insertConnectionTag(randomConnection)
        showCount('ConnectionTag', j + 1, connectionCount)
    }

    await bulkInsertRecords('ConnectionTag', connectionsTags, session)
    connectionsTags = []

    console.log('Calculating crypto scores...')
    let j = 0
    let promises = []
    for (let connection of allConnections) {
        promises.push(updateCryptoScoresForConnection(connection.id))
        if (promises.length >= 10) {
            await Promise.allSettled(promises)
            promises = []
        }

        showCount('Connection Score', ++j, allConnections.length)
    }

    await Promise.allSettled(promises)
    promises = []

    j = 0
    for (let device of allDevices) {
        promises.push(updateCryptoScoresForDevice(device.id))
        if (promises.length >= 10) {
            await Promise.allSettled(promises)
            promises = []
        }

        showCount('Device Score', ++j, allDevices.length)
    }

    await Promise.allSettled(promises)

    await connection.end()
    let endTime = new Date()
    log.log(`Run Time in milliseconds ${endTime.getTime()-startTime.getTime()}`)

}

function showCount(title, number, total) {

    var lastPercentage = showCount.last[title]
    var percentage = Math.round(number / total * 1000) / 10
    if (lastPercentage === undefined || (percentage === 100 && lastPercentage != 100) || (percentage - lastPercentage > 1)) {
        log.log(`${title}: Created ${number} of ${total} (${percentage}%)`)
        showCount.last[title] = percentage
    }
}
showCount.last = {}

main().then(() => {
    log.log('Done!')
}).catch(e => {
    log.e('Sad now. :(', e)
    process.exit(1)
})
