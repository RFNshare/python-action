/**
 * @file whereUtil.js - 0.0.1045 - ea4595bfd3488684d225574ed7d4c198074d49ba
 * 
 * @copyright Copyright (C) 2016-2023, ISARA Corporation, All Rights Reserved.
 * 
 * @license The code and other content set out herein is not in the public
 * domain, is considered a trade secret and is confidential to ISARA
 * Corporation. Use, reproduction or distribution, in whole or in part, of such
 * code or other content is strictly prohibited except by express written
 * permission of ISARA Corporation. Please contact ISARA Corporation at
 * info@isara.com for more information.
 */

/**
 * This module helps build where clauses.
 * @module isaraql/whereUtil
 */

const chrono = require('chrono-node')

/**
 * Build a where expression for the given column and date time comparison.
 * @param {string} column The name of the column
 * @param {object} dateTimeComparison The date time comparison from GraphQL.
 * @param {string[]} coalesceValues Optional array of default date time strings to coalesce to.
 */

function getDateFromInput(input) {
    let tempInput = input
    if (!(input instanceof String)) {
        tempInput = JSON.stringify(input)
    }
    let parsedValue = chrono.parse(tempInput)
    if (parsedValue.length > 0) {
        return parsedValue[0].date()
    }

    throw `Unable to understand date string: "${tempInput}"`
}

function dateTimeComparisonToWhere(column, dateTimeComparison, coalesceValues) {
    let before
    let after
    if (dateTimeComparison.before) {
        try {
            before = { lte: { column: column, value: getDateFromInput(dateTimeComparison.before), coalesce: coalesceValues } }
        } catch (e) {
            throw `Unable to understand before: ${dateTimeComparison.before}`
        }
    }
    if (dateTimeComparison.after) {
        try {
            after = { gte: { column: column, value: getDateFromInput(dateTimeComparison.after), coalesce: coalesceValues } }
        } catch (e) {
            throw `Unable to understand before: ${dateTimeComparison.after}`
        }
    }
    if (!before && !after) {
        throw 'Expect at least one field of DateTimeComparison to be set'
    } else if (before && after) {
        return { and: [before, after] }
    } else if (before) {
        return before
    } else {
        return after
    }
}

/**
 * Takes an object with values set to what you want, and builds a where with the matching values.
 * @param {object} values The values to place into the where clause.
 * @return {object} An equals clause based on the given values.
 */
function buildEquals(values) {
    var parts = []
    for (var column in values) {
        var value = values[column]
        parts.push({ equals: { column, value } })
    }
    if (parts.length === 0) {
        throw 'No fields set in object to copy columns from'
    }
    if (parts.length === 1) {
        return parts[0]
    }
    return { and: parts }
}

/**
 * Returns a table named where equal clause.
 * @param {string} table The table the where clause will be named for.
 * @param {object} equals The values to place into the where clause as an equals.
 */
function buildTableWhereEquals(table, equals) {
    return { [table]: { where: buildEquals(equals) } }
}

/**
 * Returns an `in` clause.
 * @param {string} column The column name to compare.
 * @param {any} value The values to compare to.
 */
function buildIn(column, value) {
    return { in: { column, value } }
}

/**
 * Returns a table named where in clause.
 * @param {string} table The table the where clause will be named for.
 * @param {object} equals The values to place into the where clause as an in.
 */
function buildTableWhereIn(table, values) {
    let parts = []
    for (let column in values) {
        let value = values[column]
        parts.push(buildIn(column, value))
    }
    if (parts.length === 0) {
        throw 'No fields set in object to copy columns from'
    }
    if (parts.length === 1) {
        return { [table]: { where: parts[0] } }
    }
    return { [table]: { where: { and: parts } } }
}

/**
 * Returns an `and` clause.
 * @param {...Object} arguments all the clauses to place in the and. Does not expect an array.
 */
function buildAnd() {
    return { and: [...arguments] }
}

/**
 * Build a WPCS like structure for the given `table` and `where` component.
 * @param {string} table The table name
 * @param {Object} where The `where` component.
 */
function buildTableWhere(table, where) {
    return { [table]: { where } }
}

exports.dateTimeComparisonToWhere = dateTimeComparisonToWhere
exports.buildEquals = buildEquals
exports.buildTableWhereEquals = buildTableWhereEquals
exports.buildIn = buildIn
exports.buildTableWhereIn = buildTableWhereIn
exports.buildAnd = buildAnd
exports.buildTableWhere = buildTableWhere
