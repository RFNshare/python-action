/**
 * @file userAdministrationQL.js - 0.0.1045 - ea4595bfd3488684d225574ed7d4c198074d49ba
 * 
 * @copyright Copyright (C) 2016-2023, ISARA Corporation, All Rights Reserved.
 * 
 * @license The code and other content set out herein is not in the public
 * domain, is considered a trade secret and is confidential to ISARA
 * Corporation. Use, reproduction or distribution, in whole or in part, of such
 * code or other content is strictly prohibited except by express written
 * permission of ISARA Corporation. Please contact ISARA Corporation at
 * info@isara.com for more information.
 */

/**
 * This module contains queries to manage user administration.
 * @module graphql/userAdministrationQL
 */

const {
    Session
} = require('../isaraql/session')

var {
    deleteRecords, updateRecord, insertRecord, fetchWanted
} = require('../isaraql/fetch')

var {
    roles
} = require('./commonQL')

var {
    allTypes
} = require('../isaraql/schemaDiscovery')

var {
    hashPassword, randomSleep, verifyPassword
} = require('../util/passwordUtils')

var {
    dateTimeComparisonToWhere
} = require('../isaraql/whereUtil')

const { graphQLStateToWanted } = require('../isaraql/wantedUtil')

/**
 * Validates that the password satisfies minimum complexity requirements. Currently, this is nothing more than a min length of
 * 8 characters.
 *
 * @param {string} password
 *
 * @returns `true` if the password satisfies complexity requirements.
 */
function checkPasswordRequirements(password) {
    if (password && password.length >= 8) {
        return true
    }

    return false
}
exports.checkPasswordRequirements = checkPasswordRequirements

/**
 * Retrieves a user record from the database.
 *
 * @param {int} id Unique ID of the user to be queried for.
 * @param {*} wanted Dictionary describing the tree of fields to retrieve from the database.
 * @param {*} session Optional database session if the query is participating in a transaction.
 *
 * @returns {Promise<any>} A record structure containing the requested user fields.
 * @throws An exception is thrown if the requested ID cannot be found, or an error occurs while querying.
 */
async function fetchUserById(id, wanted, session) {
    var tableName = 'User'
    var records = await fetchWanted(tableName, wanted,
        { [tableName]: { where: { and: [{ equals: { column: 'id', value: id } }] } } }, session)
    if (records.length != 1)
        throw "Unable to retrieve user '" + id + "'"

    return records[0]
}

/**
 * Builds a where structure for use by queries.
 *
 * @param {*} fields The GraphQL fields structure dictating what parameters to query by.
 *
 * @returns An appropriate structure containing the where structure for the specified fields. Sort order defaults to ascending by ID.
 */
function buildUsersWPCS(fields) {
    var wpcs = {
        User: { where: { and: [{ equals: { column: 'hidden', value: 0 } }] }, sort: ['id asc'] },
    }

    var fieldsWhere = fields['where']
    if (fieldsWhere) {
        if (fieldsWhere.userName) {
            wpcs['User'].where.and.push({ equals: { column: 'userName', value: fieldsWhere.userName } })
        }
        if (fieldsWhere.lockedOut) {
            wpcs['User'].where.and.push({ equals: { column: 'lockedOut', value: fieldsWhere.lockedOut } })
        }
        if (fieldsWhere.passwordExpiry) {
            wpcs['User'].where.and.push(dateTimeComparisonToWhere('passwordExpiry', fieldsWhere.passwordExpiry))
        }
        if (fieldsWhere.ids) {
            wpcs['User'].where.and.push({ in: { column: 'id', value: fieldsWhere.ids } })
        }
    }

    return wpcs
}

/**
 * Resolver function to query for user objects.
 *
 * @param {object} fields The GraphQL fields structure dictating what parameters to query by.
 * @param {object} request HTTP request headers object.
 * @param {object} graphQLState The GraphQL response structure dictating the desired field selections.
 *
 * @returns {object[]} An array of record structures containing matching users.
 * @throws An exception is thrown if an error occurs while querying.
 */
async function usersQuery(fields, request, graphQLState) {
    var wpcs = buildUsersWPCS(fields)


    if (fields.paging) {
        wpcs['User'].paging = fields.paging
    }

    var wanted = graphQLStateToWanted(graphQLState)
    if (wanted.users.paging && wanted.users.paging.count) {
        wpcs['User'].count = true
    }

    var users = await fetchWanted('User', wanted.users.users, wpcs)

    var toReturn = { users }
    if (fields.paging) {
        toReturn.paging = fields.paging
    }

    if (wanted.users.paging) {
        toReturn.paging = { count: wpcs['User'].count[0] }
    }

    return toReturn
}

/**
 * Resolver function to handle new user creation requests.
 *
 * @param {*} fields The GraphQL fields structure dictating the parameters for the new user.
 * @param {*} request HTTP request headers object.
 * @param {*} graphQLState The GraphQL structure dictating the desired field selections for the resulting User.
 * @returns {Promise<any>} The record structure for the newly created user.
 * @throws An exception is thrown if an error occurs while querying.
 */
async function createUserMutation(fields, request, graphQLState) {
    var session = new Session()
    return await session.asTransaction(async () => {
        var tableName = 'User'

        var requiredFields = ['userName', 'humanName', 'password', 'roles']
        requiredFields.forEach(element => {
            if (!(element in fields)) {
                throw `Required field ${element} missing`
            }
        })

        if (!checkPasswordRequirements(fields.password)) {
            throw 'Minimum password complexity requirements not met.'
        }

        let values = {
            userName: fields.userName,
            humanName: fields.humanName,
            passwordHash: await hashPassword(fields.password),
            passwordExpiry: new Date(),
            lockedOut: false
        }

        var result = await insertRecord(tableName, values, session)
        if (result.affectedRows != 1) {
            throw 'Failed to add user to database.'
        }

        var uid = result.id
        for (var role of fields.roles) {
            var intRole = allTypes['Role']._enum.idByName[role]
            values = { user: uid, role: intRole }
            result = await insertRecord('UserRole', values, session)
            if (result.affectedRows != 1)
                throw 'Failed to update roles'
        }

        var wanted = graphQLStateToWanted(graphQLState).createUser

        return await fetchUserById(uid, wanted, session)
    })
}

/**
 * Resolver function to handle user update requests.
 *
 * Note that this function's behaviour is conditional based on the passed in fields: If an ID is explicitly passed
 * as part of the fields, the expectation is that an admin is attempting to modify a user, and consequently permissions
 * are access-checked to verify the presence of the admin role. If the ID is omitted, then it is inferred from the user's
 * authentication token, ergo the user is modifying their own attributes, such as updating their password.
 * In either case, changes to a user's list of roles are restricted to administrators only.
 *
 * @param {*} fields The GraphQL fields structure dictating what parameters to modify on the target user.
 * @param {*} request HTTP request headers object.
 * @param {*} graphQLState The GraphQL structure dictating the desired field selections for the resulting User.
 * @returns {Promise<any>} The record structure for the updated user.
 * @throws An exception is thrown if an error occurs while querying or updating.
 */
async function updateUserMutation(fields, request, graphQLState) {
    var session = new Session()
    return await session.asTransaction(async () => {
        var tableName = 'User'
        var uid = -1
        var isAdmin = request.user.roles.includes('ADMIN')
        if (!('id' in fields)) {
            uid = request.user.uid
        } else {
            if (!isAdmin) {
                throw 'User update requires admin.'
            }

            uid = fields.id
        }

        await checkUserExists(uid, session)

        var key = { id: uid }
        var update = {}

        if ('userName' in fields) {
            update.userName = fields.userName
        }

        if ('password' in fields) {
            if (uid === request.user.uid) {
                if (!('oldPassword' in fields)) {
                    throw 'Previous password required.'
                }

                let wanted = { passwordHash: true }
                let user = await fetchUserById(uid, wanted, session)
                if (!(await verifyPassword(fields.oldPassword, user.passwordHash))) {
                    await randomSleep()
                    throw "Previous password doesn't match"
                }
            }

            if (!checkPasswordRequirements(fields.password)) {
                throw 'Minimum password complexity requirements not met.'
            }

            update.passwordHash = await hashPassword(fields.password)
        }

        if ('humanName' in fields) {
            update.humanName = fields.humanName
        }

        if ('cryptoPostureTemplate' in fields) {
            update.cryptoPostureTemplate = fields.cryptoPostureTemplate
        }

        if (Object.keys(update).length > 0) {
            let result = await updateRecord(tableName, key, update, session)
            if (!result) {
                throw 'Failed to update user record, aborting.'
            }
        }

        if ('roles' in fields) {
            if (!isAdmin) {
                throw 'Role changes require admin.'
            }

            key = { user: fields.id }
            let result = await deleteRecords('UserRole', key, session)
            for (var role of fields.roles) {
                var intRole = allTypes['Role']._enum.idByName[role]
                let values = { user: fields.id, role: intRole }
                result = await insertRecord('UserRole', values, session)
                if (result.affectedRows != 1)
                    throw 'Failed to update roles'
            }

        }

        var wanted = graphQLStateToWanted(graphQLState).updateUser

        return await fetchUserById(uid, wanted, session)
    })
}

/**
 * Resolver function to handle enable/disabling a user.
 *
 * @param {*} fields The GraphQL fields structure specifying the user ID, and their new state.
 * @param {*} request HTTP request headers object.
 * @param {*} graphQLState The GraphQL structure dictating the desired field selections for the updated User.
 * @returns {Promise<any>} The updated record structure for the user.
 * @throws An exception is thrown if an error occurs while updating.
 */
async function setUserStateMutation(fields, request, graphQLState) {
    if (!('id' in fields)) {
        throw 'User ID required.'
    }
    if (!('enabled' in fields)) {
        throw 'State required.'
    }
    if (fields.id === request.user.uid) {
        throw 'Suspending own user forbidden.'
    }


    await checkUserExists(fields.id)

    var key = { id: fields.id }
    var update = { lockedOut: !fields.enabled }
    if (!await updateRecord('User', key, update)) {
        throw 'Failed to update user state.'
    }

    var wanted = graphQLStateToWanted(graphQLState).setUserState
    return await fetchUserById(fields.id, wanted)
}

/**
 *
 * Verifies that a user ID exists and has not been deleted.
 *
 * @param {int} id The user ID to validate.
 * @param {Session} session? Optional session object, if check is part of an existing session.
 * @returns {Promise<bool>} True if user exists.
 * @throws An exception is thrown if an error occurs while querying or the user is not found. Calling functions are assumed to want
 * to short circuit in the latter case.
 */
async function checkUserExists(id, session) {
    if (!session) {
        session = new Session()
    }

    let results = await session.query(`SELECT count(*) AS count FROM "User" WHERE id=? AND hidden=false`, [id])
    if (results.rows[0].count != 1) {
        throw 'User not found'
    }

    return true
}

/**
 * Resolver function to handle deleting a user.
 *
 * @param {*} fields The GraphQL fields structure specify the ID to delete.
 * @param {*} request HTTP request headers object.
 * @param {*} graphQLState The GraphQL structure dictating the desired field selections for the deleted User.
 * @returns {Promise<any>} The updated record structure for the user.
 * @throws An exception is thrown if an error occurs while updating.
 */
async function deleteUserMutation(fields, request, graphQLState) {
    if (!('id' in fields)) {
        throw 'User ID required.'
    }

    if (fields.id === request.user.uid) {
        throw 'Deleting own user forbidden.'
    }

    await checkUserExists(fields.id)

    var key = { id: fields.id }
    var update = { hidden: true }
    if (!(await updateRecord('User', key, update))) {
        throw 'Failed to delete user.'
    }

    var wanted = graphQLStateToWanted(graphQLState).deleteUser
    return await fetchUserById(fields.id, wanted)
}




exports.graphQL = {
    types: `
        input UserWhere {
            ids: [Int!]
            userName: String
            lockedOut: Boolean
            passwordExpiry: DateTimeComparison
        }

        type PagedUsers {
            paging: Paging
            users: [User!]!
        }
    `,
    queries: `
        users(
            where: UserWhere,
            paging: PagingInput
        ) : PagedUsers!
    `,
    mutations: `
        createUser(userName: String!, humanName: String!, password: String!, roles: [Role]!) : User!,
        updateUser(id: BigInt, userName: String, humanName: String, oldPassword: String, password: String, roles: [Role], cryptoPostureTemplate: BigInt) : User!
        setUserState(id: BigInt!, enabled: Boolean!): User!
        deleteUser(id: BigInt!) : User!
    `,
    root: {
        users: usersQuery,
        createUser: createUserMutation,
        updateUser: updateUserMutation,
        setUserState: setUserStateMutation,
        deleteUser: deleteUserMutation
    },
    restrictions: {
        users: [roles.ADMIN],
        createUser: [roles.ADMIN],
        updateUser: [roles.AUTHENTICATED],
        setUserState: [roles.ADMIN],
        deleteUser: [roles.ADMIN]
    }
}
