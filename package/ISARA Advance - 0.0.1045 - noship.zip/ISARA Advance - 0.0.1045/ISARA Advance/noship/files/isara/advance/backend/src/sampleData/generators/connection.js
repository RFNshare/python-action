/**
 * @file connection.js - 0.0.1045 - ea4595bfd3488684d225574ed7d4c198074d49ba
 * 
 * @copyright Copyright (C) 2016-2023, ISARA Corporation, All Rights Reserved.
 * 
 * @license The code and other content set out herein is not in the public
 * domain, is considered a trade secret and is confidential to ISARA
 * Corporation. Use, reproduction or distribution, in whole or in part, of such
 * code or other content is strictly prohibited except by express written
 * permission of ISARA Corporation. Please contact ISARA Corporation at
 * info@isara.com for more information.
 */


const {
    Agent,
    AgentCertificate,
    CAIssuedCertificate,
    Certificate,
    CertificateCryptoPrimitive,
    CertificationAuthority,
    Connection,
    ConnectionCertificate,
    ConnectionCipherSuite,
    ConnectionCryptoPrimitive,
    ConnectionProtocolVariant,
    ConnectionProtocolVariantCertificate,
    ConnectionTag,
    Device,
    DeviceAddress,
    DeviceAddressMACAddress,
    DeviceAddressPort,
    DeviceCertificate,
    DeviceMACAddress,
    DeviceSoftware,
    DeviceSoftwareConnection,
    DeviceTag,
    KeyStore,
    KeyStoreKey,
    OneTimeKey,
    Netmask,
    Notification,
    NotificationAction,
    Software,
    SoftwareVersion,
    SoftwareVersionTag,
    Tag,
    User,
    UserRole,
} = require('../dbObjects')
const {
    certificateType,
    deviceType,
    generateHostName,
    ipAddress,
    l4Protocol,
    macAddress,
    pickOne,
    port,
    randomBelow,
    randomDate,
    randomPastDate
} = require('../sampleHelpers')

const {
    dumpObjectTimingStats,
    initDbConnection,
    insertObject,
    bulkInsertRecords,
    resetObjectTimingStats
} = require('../dbHelpers')
var log = require('../../util/log')(module)
const getPort = async (ports, data) => {
    // for now random

    const list = ports.map((p) => p.port)
    let portIndex = Math.floor(Math.random() * list.length)
    return list[portIndex]
}
const getCryptoPrimitive = async (primitives, data) => {
    // for now random
    let primitiveIndex = Math.floor(Math.random() * primitives.length)
    return primitives[primitiveIndex]
}
exports.getPort = getPort;
exports.getCryptoPrimitive = getCryptoPrimitive;
exports.generateConnections = async (session, config, data, numDConnections) => {
    const bulkInsertAtCount = 100;
    log.log('generating connections...')

    data.overallDevices

    data.overallServers
    data.totalConnections = 0
    data.committedConnections = []
    data.uncommittedConnections = []
    data.committedConnectionProtocolVariants = []
    data.uncommittedConnectionProtocolVariants = []
    data.committedConnectionCipherSuites = []
    data.uncommittedConnectionCipherSuites = []

    data.committedConnectionCryptoPrimitives = []
    data.uncommittedConnectionCryptoPrimitives = []

    data.usedClientDevices = []

    // make connections
    do {
        // get a client
        let client = pickOne(data.overallDevices) //Math.floor(Math.random() * data.overallDevices.length)
        //if (data.overallServers.indexOf(clientIndex) == (-1)) {
            // yes, this is a client index
            //log.log(data.overallServers)
            data.usedClientDevices.push(client)
            // get a server
            const serverIndex =pickOne(data.overallServers) //data.overallDevices[
//                data.overallServers[Math.floor(Math.random() * data.overallServers.length)]
  //          ]
            //log.log(serverIndex)
            const server = data.overallDevices[serverIndex]
            //log.log(server)
            // pick ports
            const portClient = await getPort(config.Connections.ports, data)
            const portServer = await getPort(config.Connections.ports, data)
            // pick crypto
            const cryptoPrimitive = getCryptoPrimitive(config.Connections.crypto.primitives, data)
            try {
               // const client = data.overallDevices[clientIndex]
                //log.log(client)
                if(client?.ipAddress){
                const newConnection = {};//new Connection()
                newConnection.observedAt= new Date()
                newConnection.port=portClient;
                newConnection.clientAddress = client?.ipAddress;//+":"+portClient;
                newConnection.serverAddress = server?.ipAddress;//+":"+portServer;
                newConnection.l4Protocol = "TCP"
                newConnection.friendlyName = client?.ipAddress + ' \u2192 ' + server?.ipAddress + ' : ' + portServer

                const newProtocolVariant = {};
                newProtocolVariant.observedAt= new Date()
                newProtocolVariant.port=portClient;
                newProtocolVariant.clientAddress = client?.ipAddress;//+":"+portClient;
                newProtocolVariant.serverAddress = server?.ipAddress;//+":"+portServer;
                newProtocolVariant.l4Protocol = "TCP"
                newProtocolVariant.protocolVariant = "TLS 1.2"
                
                data.uncommittedConnectionProtocolVariants.push(newProtocolVariant)

                const newCipherSuite = {};
                newCipherSuite.observedAt= new Date()
                newCipherSuite.port=portClient;
                newCipherSuite.clientAddress = client?.ipAddress;//+":"+portClient;
                newCipherSuite.serverAddress = server?.ipAddress;//+":"+portServer;
                newCipherSuite.l4Protocol = "TCP"
                newCipherSuite.cipherSuite = "TLS_DH_DSS_WITH_CAMELLIA_256_GCM_SHA384"
                data.uncommittedConnectionCipherSuites.push(newCipherSuite)
                //connectionsItems.push({server: server, certificate:certificate, serverType:serverType, badReason:badReason, client:client})
                //{
                //    client:clientIndex, server, portClient, portServer,cryptoPrimitive
                //}
                const newCryptoPrimitive = {};
                newCryptoPrimitive.observedAt= new Date()
                newCryptoPrimitive.port=portClient;
                newCryptoPrimitive.clientAddress = client?.ipAddress;//+":"+portClient;
                newCryptoPrimitive.serverAddress = server?.ipAddress;//+":"+portServer;
                newCryptoPrimitive.l4Protocol = "TCP"
                newCryptoPrimitive.cryptoPrimitive = "HMAC_SHA1_LT_160"
                data.uncommittedConnectionCryptoPrimitives.push(newCryptoPrimitive)

                data.uncommittedConnections.push(newConnection)
                data.totalConnections++;
                }
            } catch (error) {
                console.log('Failed to create connection', error)
            }
//log.log(data.uncommittedConnections.length)
            if (data.uncommittedConnections.length > bulkInsertAtCount) {
                // commit this batch
                let results
                log.log(`generated ${data.totalConnections.length} total connections... doing bulk insert of ${bulkInsertAtCount}`)
                try{
                    results = await bulkInsertRecords('Connection', data.uncommittedConnections, session)
                    let resultsProtocol = await bulkInsertRecords('ConnectionProtocolVariant', data.uncommittedConnectionProtocolVariants, session)
                    let resultsCipher = await bulkInsertRecords('ConnectionCipherSuite', data.uncommittedConnectionCipherSuites, session)
                    let resultsConnectionCryptoPrimitive = await bulkInsertRecords('ConnectionCryptoPrimitive', data.uncommittedConnectionCryptoPrimitives, session)
                }catch(e){console.log(e)}
                //done commit
                log.log(`batch has been committed`)//, results)
                data.committedConnections = [...data.committedConnections, ...data.uncommittedConnections]
                data.uncommittedConnections = []
                data.committedConnectionProtocolVariants =[...data.committedConnectionProtocolVariants, ...data.uncommittedConnectionProtocolVariants]
                data.uncommittedConnectionProtocolVariants=[]

                data.committedConnectionCipherSuites =[...data.committedConnectionCipherSuites, ...data.uncommittedConnectionCipherSuites]
                data.uncommittedConnectionCipherSuites = []

                data.committedConnectionCryptoPrimitives =[...data.committedConnectionCryptoPrimitives, ...data.uncommittedConnectionCryptoPrimitives]
                data.uncommittedConnectionCryptoPrimitives = []
            }
        //}
    } while (data.totalConnections < numDConnections)
    log.log(`completed generating ${numDConnections} connections`)
}

let addConnection = async function (addServerOnlyConnection, candidate, server, certificate, serverType, badReason) {
    try {
        const newConnection = new Connection()
        let client
        if (addServerOnlyConnection) {
            addServerOnlyConnection = false
        } else {
            client = candidate
            newConnection.clientDeviceAddressPort = client.port.id
        }
        newConnection.serverDeviceAddressPort = server.port.id
        if (Math.random() > .7) {
            newConnection.addedBy = pickOne(users).id
        }

        clientAddress = (client) ? client.address.address : '\u2015'
        serverAddress = server.address.address
        serverPort = server.port.port
        newConnection.friendlyName = clientAddress + ' \u2192 ' + serverAddress + ' : ' + serverPort
        if (bulkAddConnectionsArray.length >= bulkSize) {
            await bulkAddConnections()
        }
        bulkAddConnectionsArray.push(newConnection.nameValues)
        connectionsItems.push({ server: server, certificate: certificate, serverType: serverType, badReason: badReason, client: client })
    } catch (error) {
        console.log('Failed to create connection', error)
    }
}

let callAddConnection = async function (serverType, server, client, badReason) {
    try {
        let certificate = null
        let iscertificate = (serverType == deviceTypes.GOOD_SERVER || badReason == badServerReasons.WEAK_CRYPTO_PRIMITIVE || badReason == badServerReasons.WEAK_VERSION_TLS) ? true : pickOne([true, false])
        // not all Servers will have a Certificate but should enforce if the badReason is a WEAK_CRYPTO_PRIMITIVE
        if (iscertificate) {
            if (maxCertificateCount > 0) {
                certificate = new Certificate(pickOne(certAuthorities))
                await certificate.populate()
                await insertObject(certificate)
                existingCertificates.push(certificate)
                maxCertificateCount--
            } else {
                certificate = pickOne(lodash.shuffle(existingCertificates))
            }

            let deviceCertificate = new DeviceCertificate(server.device.id, certificate.id)
            await insertObject(deviceCertificate)

            let certPrimitiveCount = randomBelow(4, 1)
            let certPrimitives = []
            for (let k = 0; k < certPrimitiveCount; ++k) {
                let isStrongCryptoPrimitives = serverType == deviceTypes.GOOD_SERVER || badReason != badServerReasons.WEAK_CRYPTO_PRIMITIVE
                let primitive = isStrongCryptoPrimitives ? pickOne(allStrongCryptoPrimitives) : pickOne(allWeakCryptoPrimitives)
                let primitiveId = primitive.id
                let keyLength = null
                let upperLimit = null
                let nameSplit = primitive.name.split('_')
                let standardRSA = [512, 1024, 2048, 3072, 4096, 6000]
                let standardDSA = [1024, 2048, 3072, 7680, 15360, 16000]
                if (primitive.name.includes('RSA')) {
                    if (randomBelow(3)) {
                        roundDown = parseInt(nameSplit[nameSplit.length - 1])
                        upperLimit = standardRSA[standardRSA.indexOf(roundDown) + 1]
                        keyLength = randomBelow(upperLimit, roundDown + 1)
                    }
                }
                if (primitive.name.includes('DSA_DSS')) {
                    if (randomBelow(3)) {
                        roundDown = parseInt(nameSplit[nameSplit.length - 2])
                        upperLimit = standardDSA[standardDSA.indexOf(roundDown) + 1]
                        keyLength = randomBelow(upperLimit, roundDown + 1)
                    }
                }
                if (!certPrimitives.includes(primitiveId) && !CertsWithPrimitives.includes(certificate.id)) {
                    certPrimitives.push(primitiveId)
                    CertsWithPrimitives.push(certificate.id)
                    await insertObject(new CertificateCryptoPrimitive(certificate.id, primitiveId, keyLength))
                }
            }
            let caIssuedCertificate = new CAIssuedCertificate(pickOne(certAuthorities), certificate)
            await insertObject(caIssuedCertificate)

            if (deviceAgents[server.device.id]) {
                let agent = deviceAgents[server.device.id]
                let agentCertificate = new AgentCertificate(agent, certificate)
                await insertObject(agentCertificate)

            }
        }

        let addServerOnlyConnection = Math.random() < 0.01
        await addConnection(addServerOnlyConnection, client, server, certificate, serverType, badReason)

    } catch (error) {
        console.log('Failed to call addConnection', error)
    }
}


let bulkAddConnections = async function () {
    try {
        if (bulkAddConnectionsArray.length > 0) {
            let results = await bulkInsertRecords('Connection', bulkAddConnectionsArray, session)
            allConnections.push(...results.rows)
            await addConnectionProtocolVariant(results.rows)
            await addConnectionCryptoPrimitives(results.rows)
            await addConnectionCipherSuites(results.rows)
            await addDeviceSoftwareConnection(results.rows)
        }
        bulkAddConnectionsArray = []
        connectionsItems = []

    } catch (error) {
        log.log(`bulkAddConnections ${error}`)
    }

}


let addDeviceSoftwareConnection = async function (connections) {
    try {
        let deviceSoftwareConnection = []
        let index = 0
        for (let connection of connections) {
            let connItem = connectionsItems[index]
            // Not all connections will have detected software on both ends
            if (pickOne([true, false]) && allDeviceSoftware[connItem.server.device.id]) {
                let serverSoftware = pickOne(allDeviceSoftware[connItem.server.device.id])
                let softwareConnection = new DeviceSoftwareConnection(serverSoftware, connection)
                deviceSoftwareConnection.push(softwareConnection.nameValues)
            }
            if (connItem.client && pickOne([true, false]) && allDeviceSoftware[connItem.client.device.id]) {
                let clientSoftware = pickOne(allDeviceSoftware[connItem.client.device.id])
                let softwareConnection = new DeviceSoftwareConnection(clientSoftware, connection)
                deviceSoftwareConnection.push(softwareConnection.nameValues)
            }
            index++
        }
        if (deviceSoftwareConnection.length > 0) {
            await bulkInsertRecords('DeviceSoftwareConnection', deviceSoftwareConnection, session)
        }
    } catch (error) {
        log.log(`addDeviceSoftwareConnection ${error}`)
    }
}


let addConnectionCipherSuites = async function (connections) {
    try {
        let cipherSuites = []
        let index = 0
        for (let connection of connections) {
            let connItem = connectionsItems[index]
            let numCipherSuites = pickOne([1, 1, 1, 2, 1, 3, 2])
            let usedCipherSuites = []

            //not all Connections will have a CipherSuite but enforce it if the badReason === WEAK_CIPHER_SUITE
            let isCipherSuite = connItem.badReason == badServerReasons.WEAK_CIPHER_SUITE ? true : pickOne([true, false])
            if (isCipherSuite) {
                let isStrongCipherSuites = connItem.serverType == deviceTypes.GOOD_SERVER || connItem.badReason != badServerReasons.WEAK_CIPHER_SUITE
                while (usedCipherSuites.length < numCipherSuites) {
                    let connectionCipherSuite = new ConnectionCipherSuite(connection, isStrongCipherSuites ? pickOne(strongCipherSuites) : pickOne(badCipherSuites))
                    if (usedCipherSuites.includes(connectionCipherSuite.cipherSuite)) {
                        continue
                    }
                    cipherSuites.push(connectionCipherSuite.nameValues)
                    usedCipherSuites.push(connectionCipherSuite.cipherSuite)
                }
            }
            index++
        }
        await bulkInsertRecords('ConnectionCipherSuite', cipherSuites, session)
    } catch (error) {
        log.log(`addConnectionCipherSuites ${error}`)
    }
}



let bulkInsertConnectionProtocolVariant = async function (bulkProtocolVariants, bulkProtocolVariantsCerts) {
    try {
        let connProtVarCerts = []
        let index = 0
        let results = await bulkInsertRecords('ConnectionProtocolVariant', bulkProtocolVariants, session)
        for (let protocolVariant of results.rows) {
            let connItem = bulkProtocolVariantsCerts[index]
            let connProtVarCert = new ConnectionProtocolVariantCertificate(
                protocolVariant.id, connItem.certificateType, connItem.id)
            connProtVarCerts.push(connProtVarCert.nameValues)
            index++
        }
        await bulkInsertRecords('ConnectionProtocolVariantCertificate', connProtVarCerts, session)
    } catch (error) {
        log.log(`bulkInsertConnectionProtocolVariant ${error}`)
    }
}

let addConnectionProtocolVariant = async function (connections) {
    try {
        let bulkProtocolVariants = []
        let bulkProtocolVariantsCerts = []
        let connCertificates = []
        let index = 0
        for (let connection of connections) {
            let connItem = connectionsItems[index]
            if (connItem.certificate) {
                let protocolVariantCount = pickOne([1, 1, 2, 3])
                let addedProtocolVariants = {}
                for (let k = 0; k < protocolVariantCount; ++k) {
                    let isStrongProtocolVariant = connItem.serverType == deviceTypes.GOOD_SERVER || connItem.badReason != badServerReasons.WEAK_VERSION_TLS
                    let protocolVariant = isStrongProtocolVariant ? pickOne(strongProtocolVariants) : pickOne(weakProtocolVariants)
                    if (!addedProtocolVariants[protocolVariant.id]) {
                        let connProtVar = new ConnectionProtocolVariant(connection.id, protocolVariant.id)
                        bulkProtocolVariants.push(connProtVar.nameValues)
                        bulkProtocolVariantsCerts.push(connItem.certificate)
                        addedProtocolVariants[protocolVariant.id] = connProtVar
                    }
                }
                let connCert = new ConnectionCertificate(connection.id, connItem.certificate.id)
                connCertificates.push(connCert.nameValues)
            }
            index++
        }
        if (bulkProtocolVariants.length > 0) {
            await bulkInsertConnectionProtocolVariant(bulkProtocolVariants, bulkProtocolVariantsCerts)
        }
        if (connCertificates.length > 0) {
            await bulkInsertRecords('ConnectionCertificate', connCertificates, session)
        }
    } catch (error) {
        log.log(`addConnectionProtocolVariant ${error}`)
    }

}

let addConnectionCryptoPrimitives = async function (connections) {
    let bulkConnectionCryptoPrimitives = []
    let index = 0
    try {
        for (let connection of connections) {
            let connItem = connectionsItems[index].badReason
            if (connItem === badServerReasons.WEAK_CRYPTO_PRIMITIVE) {
                let connectionCryptoPrim = new ConnectionCryptoPrimitive(connection, pickOne(allWeakCryptoPrimitives))
                bulkConnectionCryptoPrimitives.push(connectionCryptoPrim.nameValues)
            }
            index++
        }
        if (bulkConnectionCryptoPrimitives.length > 0) {
            await bulkInsertRecords('ConnectionCryptoPrimitive', bulkConnectionCryptoPrimitives, session)
        }
    } catch (error) {
        log.log(`addConnectionCryptoPrimitives ${error}`)
    }

}

