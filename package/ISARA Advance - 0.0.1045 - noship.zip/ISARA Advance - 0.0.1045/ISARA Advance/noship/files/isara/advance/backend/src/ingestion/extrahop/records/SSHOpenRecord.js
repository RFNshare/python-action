/**
 * @file SSHOpenRecord.js - 0.0.1045 - ea4595bfd3488684d225574ed7d4c198074d49ba
 * 
 * @copyright Copyright (C) 2016-2023, ISARA Corporation, All Rights Reserved.
 * 
 * @license The code and other content set out herein is not in the public
 * domain, is considered a trade secret and is confidential to ISARA
 * Corporation. Use, reproduction or distribution, in whole or in part, of such
 * code or other content is strictly prohibited except by express written
 * permission of ISARA Corporation. Please contact ISARA Corporation at
 * info@isara.com for more information.
 */

// /**
//  * Handling for Extrahop SSH Open record. Attempts to pull out ciphersuite
//  * and protocol variant metadata.
//  *
//  * @module extrahop/records/SSHOpenRecord
// */

// const { RecordBase } = require('./RecordBase')
// const { populateObservedFields } = require('../extrahopUtils')

// function resolveSSHPrimitiveToEnums(primitive) {
//     let resolvedPrimitives = []
//     return resolvedPrimitives
// }

// class SSHOpenRecord extends RecordBase {
//     constructor(record, cacheMaps) {
//         super(record, cacheMaps)

//         this.connectionCryptoPrimitives = []
//         Array.prototype.push.apply(this.connectionCryptoPrimitives,
//             resolveSSHPrimitiveToEnums(record._source.kexAlgorithm))
//         Array.prototype.push.apply(this.connectionCryptoPrimitives,
//             resolveSSHPrimitiveToEnums(record._source.clientMacAlgorithm))
//         Array.prototype.push.apply(this.connectionCryptoPrimitives,
//             resolveSSHPrimitiveToEnums(record._source.clientMacAlgorithm))
//         Array.prototype.push.apply(this.connectionCryptoPrimitives,
//             resolveSSHPrimitiveToEnums(record._source.clientCipherAlgorithm))
//         Array.prototype.push.apply(this.connectionCryptoPrimitives,
//             resolveSSHPrimitiveToEnums(record._source.serverCipherAlgorithm))

//         this.connectionCryptoPrimitives.forEach(x => populateObservedFields(x, this.observationTime))
//     }

//     async getConnectionObject(cacheMaps) {
//         let connection = this.getBaseConnectionObject(cacheMaps)
//         connection.connectionProtocolVariants = [
//             {
//                 // TODO: GAP1623 - this could conceivably vary, and should probably take record._source.{client,server}Version into account
//                 protocolVariant: this.cacheMaps.protocolVariantIDMap['SSH 2.0']
//             }
//         ]
//         populateObservedFields(connection.connectionProtocolVariants[0], this.observationTime)

//         if (this.connectionCryptoPrimitives.length > 0) {
//             connection.connectionCryptoPrimitives = this.connectionCryptoPrimitives
//         }

//         return connection
//     }
// }

// exports.SSHOpenRecord = SSHOpenRecord