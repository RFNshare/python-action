/**
 * @file generateNode.js - 0.0.1045 - ea4595bfd3488684d225574ed7d4c198074d49ba
 * 
 * @copyright Copyright (C) 2016-2023, ISARA Corporation, All Rights Reserved.
 * 
 * @license The code and other content set out herein is not in the public
 * domain, is considered a trade secret and is confidential to ISARA
 * Corporation. Use, reproduction or distribution, in whole or in part, of such
 * code or other content is strictly prohibited except by express written
 * permission of ISARA Corporation. Please contact ISARA Corporation at
 * info@isara.com for more information.
 */

/**
 * This module contains the transform function to generate AST node
 * objects.
 * @module filterql/generateNode
 */
const ASTNode = require('./ASTNode')

// function isLiteralCompatible(literal, type) {
//     switch (type) {
//     case 'boolean':
//         return literal instanceof ASTNode.BooleanLiteral
//     case 'integer':
//     case 'float':
//         return literal instanceof ASTNode.IntegerLiteral ||
//                literal instanceof ASTNode.FloatLiteral
//     case 'enum':
//         return literal instanceof ASTNode.UnquotedStringLiteral
//     case 'string':
//         return literal instanceof ASTNode.StringLiteral ||
//                literal instanceof ASTNode.UnquotedStringLiteral
//     case 'datetime':
//         return literal instanceof ASTNode.DateLiteral
//     default:
//         throw `Not implemented: ${type}`
//     }
// }

function generateNode(node/*, arg*/) {
    switch(node.type) {
        case 'TermExpression':
            return new ASTNode.TermExpression(node.term)
        case 'NotExpression':
            return new ASTNode.NotExpression(node.term)
        case 'ParenthesesExpression':
            return new ASTNode.ParenthesesExpression(node.expression)
        case 'AndExpression':
            return new ASTNode.AndExpression(node.term, node.expression)
        case 'OrExpression':
            return new ASTNode.OrExpression(node.term, node.expression)
        case 'Term':
            return new ASTNode.Term(node.attribute, node.comparison)
        case 'AnonymousAttribute':
            return new ASTNode.AnonymousAttribute()
        case 'NamedAttribute':
            return new ASTNode.NamedAttribute(node.name)
        case 'NamedTagAttribute':
            return new ASTNode.NamedTagAttribute(node.name)
        case 'QualifiedAttribute':
            return new ASTNode.QualifiedAttribute(node.qualifier, node.name)
        case 'QualifiedTagAttribute':
            return new ASTNode.QualifiedTagAttribute(node.qualifier, node.name)
        case 'ValueComparison':
            return new ASTNode.ValueComparison(node.comparator, node.literal)
        case 'Contains':
            return new ASTNode.Contains()
        case 'ContainsCase':
            return new ASTNode.ContainsCase()
        case 'Equals':
            return new ASTNode.Equals()
        case 'EqualsCase':
            return new ASTNode.EqualsCase()
        case 'BeforeComparison':
            return new ASTNode.BeforeComparison(node.comparator, node.literal)
        case 'AfterComparison':
            return new ASTNode.AfterComparison(node.comparator, node.literal)
        case 'InsideComparison':
            return new ASTNode.InsideComparison(node.comparator1, node.literal1,
                node.comparator2, node.literal2)
        case 'OutsideComparison':
            return new ASTNode.OutsideComparison(node.comparator1, node.literal1,
                node.comparator2, node.literal2)
        case 'LessThan':
            return new ASTNode.LessThan()
        case 'LessThanOrEqual':
            return new ASTNode.LessThanOrEqual()
        case 'GreaterThan':
            return new ASTNode.GreaterThan()
        case 'GreaterThanOrEqual':
            return new ASTNode.GreaterThanOrEqual()
        case 'BooleanLiteral':
            return new ASTNode.BooleanLiteral(node.boolean)
        case 'IntegerLiteral':
            return new ASTNode.IntegerLiteral(node.integer)
        case 'FloatLiteral':
            return new ASTNode.FloatLiteral(node.float)
        case 'StringLiteral':
            return new ASTNode.StringLiteral(node.string, true)
        case 'UnquotedStringLiteral':
            return new ASTNode.StringLiteral(node.string, false)
        case 'DateLiteral':
            return new ASTNode.DateLiteral(node.year,
                node.month,
                node.day,
                node.hour,
                node.minute,
                node.second)
        default: {
            let message = `Unknown AST node type: ${node.type}`
            throw message
        }
    }
    // Should not reach here
}

module.exports = {
    generateNode: generateNode,
}
