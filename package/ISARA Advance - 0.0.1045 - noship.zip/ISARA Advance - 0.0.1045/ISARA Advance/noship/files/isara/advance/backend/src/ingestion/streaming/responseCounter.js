/**
 * @file responseCounter.js - 0.0.1045 - ea4595bfd3488684d225574ed7d4c198074d49ba
 * 
 * @copyright Copyright (C) 2016-2023, ISARA Corporation, All Rights Reserved.
 * 
 * @license The code and other content set out herein is not in the public
 * domain, is considered a trade secret and is confidential to ISARA
 * Corporation. Use, reproduction or distribution, in whole or in part, of such
 * code or other content is strictly prohibited except by express written
 * permission of ISARA Corporation. Please contact ISARA Corporation at
 * info@isara.com for more information.
 */

const { Writable } = require('stream')

class ResponseCounter extends Writable {
    #closed = false
    #success = 0
    #failure = 0
    #resolve
    #reject
    #promise
    #partial = ''

    /**
     * 
     * @param {Readable} source 
     */
    constructor(source) {
        super()

        source.on('error', (err) => {
            this._destroy(err)
        })

        source.pipe(this)

        this.#promise = new Promise((resolve, reject) => {
            this.#resolve = resolve
            this.#reject = reject
        })
    }

    /**
     * Check if the line 'looks' like success.
     * @param {string} item 
     */
    #processString(item) {
        if (item.indexOf('success":true') != -1) {
            this.#success++
        } else {
            this.#failure++
        }
    }

    /**
     * Write a chunk to this Writable.
     * @param {Buffer} chunk 
     * @param {string} encoding 
     * @param {function} callback 
     */
    _write(chunk, encoding, callback) {
        let asString = chunk.toString('utf8')
        let partial = this.#partial
        let start = 0
        let end = 0
        while ((end = asString.indexOf('\n', start)) !== -1) {
            if (partial != '') {
                this.#processString(partial + asString.substring(start, end))
                this.#partial = partial = ''
            } else {
                this.#processString(asString.substring(start, end))
            }
            start = end + 1
        }
        if (start != asString.length) {
            this.#partial = asString.substring(start)
        }
        if (callback) callback()
    }

    _final(callback) {
        if (callback) callback()
    }

    _destroy(err, callback) {
        if (!this.#closed) {
            if (this.#partial.length !== 0) {
                this.#processString(this.#partial)
                this.#partial = ''
            }
            this.#closed = true
            if (err) {
                this.#reject(err)
            } else {
                this.#resolve({ success: this.#success, failure: this.#failure, total: this.#success + this.#failure })
            }
        }
        if (callback) callback()
    }

    /**
     * @typedef ResponseCounterResponse
     * @property {number} success The number of rows that were successful
     * @property {number} failure The number of rows that were not successful
     * @property {number} total The total number of rows. (success + failure)
     */

    /**
     * Returns the counts (eventually) processed by this Writable.
     * @return {ResponseCounterResponse} Counted results
     */
    async wait() {
        return this.#promise
    }

}

exports.ResponseCounter = ResponseCounter
