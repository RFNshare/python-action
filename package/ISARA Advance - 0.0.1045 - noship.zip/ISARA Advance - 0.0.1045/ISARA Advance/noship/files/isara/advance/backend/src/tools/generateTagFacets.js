/**
 * @file generateTagFacets.js - 0.0.1045 - ea4595bfd3488684d225574ed7d4c198074d49ba
 * 
 * @copyright Copyright (C) 2016-2023, ISARA Corporation, All Rights Reserved.
 * 
 * @license The code and other content set out herein is not in the public
 * domain, is considered a trade secret and is confidential to ISARA
 * Corporation. Use, reproduction or distribution, in whole or in part, of such
 * code or other content is strictly prohibited except by express written
 * permission of ISARA Corporation. Please contact ISARA Corporation at
 * info@isara.com for more information.
 */

/*
* Generates JSON that can be copied into facets.js to support all TagTypes present in database.
*/

let log = require('../util/log')(module)

async function loadTagTypes(connection) {
    let result = await connection.query(
        `SELECT id, name, expressionKey, isNumeric, unit FROM TagType ORDER BY name ASC`)
    let tagTypes = []

    for (let row of result) {
        tagTypes.push(row)
    }

    return tagTypes
}

function generateTagFacets(tagTypes) {
    let tagFacets = []

    for (let tagType of tagTypes) {
        tagFacets.push({
            name: tagType.expressionKey,
            type: tagType.isNumeric == 0 ?'string' : 'integer',
            table: 'Tag',
            tagType: tagType.name,
            isTag: true,
        })
    }

    return tagFacets
}

async function main() {
    let connection = await require('../isaraql/dbPool').getPool()
    if (connection === null) {
        throw 'Could not create connection!'
    }

    let tagTypes = await loadTagTypes(connection)
    let tagFacets = await generateTagFacets(tagTypes)

    // remove quotes from object properties
    let json = JSON.stringify(tagFacets, null, 4)
    let unquotedJson = json.replace(/"([^"]+)":/g, '$1:')

    log.log(unquotedJson)

    await connection.end()
}

main().then(() => {
}).catch(e => {
    log.e('Exception occurred:', e)
    process.exit(1)
})
