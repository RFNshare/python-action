/**
 * @file netscoutCryptoMapping.js - 0.0.1045 - ea4595bfd3488684d225574ed7d4c198074d49ba
 * 
 * @copyright Copyright (C) 2016-2023, ISARA Corporation, All Rights Reserved.
 * 
 * @license The code and other content set out herein is not in the public
 * domain, is considered a trade secret and is confidential to ISARA
 * Corporation. Use, reproduction or distribution, in whole or in part, of such
 * code or other content is strictly prohibited except by express written
 * permission of ISARA Corporation. Please contact ISARA Corporation at
 * info@isara.com for more information.
 */

/**
 * Crypto primitives mapping for NetScout code points.
 *
 * @module csv/netscoutCryptoMapping
 */

function getKeyExchangePrimitive(codePoint) {
    // The following code points mapping is defined by NetScout.
    switch (codePoint) {
        case 256:
        case 261:
        case 262:
            // NetScout doesn't provide info on whether (EC)DH key exchanges
            // are ephemeral or not. So, we made the decision to assume they
            // are ephemeral, which is the most common case.
            return 'ECDHE'
        case 257:
            return 'SRP'
        case 258:
        case 259:
        case 260:
        case 275:
        case 276:
            return 'FFDHE'
        case 263:
        case 272:
            return 'RSA_KE'
        case 264:
            return 'PSK_KE'
        case 265:
            return 'FFDHE_512'
        case 266:
            return 'RSA_KE_512'
        case 267:
            return 'FORTEZZA'
        case 268:
            return 'KRB5'
        case 269:
            return 'KRB5_EXPORT'
        case 270:
            return 'RSA_EXPORT'
        case 271:
            return 'VKO_GOST'
        case 273:
            return 'NULL_KE'
        case 274:
            return 'UNKNOWN'
        default:
            return null
    }
}

function getAuthenticationPrimitive(codePoint) {
    // The following code points mapping is defined by NetScout.
    switch (codePoint) {
        case 384:
        case 396:
            return 'RSA_SIG'
        case 385:
            return 'ECDSA'
        case 386:
            return 'DSA'
        case 387:
            return 'SRP'
        case 389:
            return 'NULL_SIG'
        case 391:
            return 'PSK_AUTH'
        case 394:
            return 'RSA_EXPORT'
        case 397:
            return 'KEA'
            // NetScout includes the following KEX algorithms in auth section,
            // without info on why. It could be that if these are used non-ephemerally,
            // their public keys could appear in certs. Or, some can be deemed as
            // both KEX and AUTH, such as KRB5.
        case 388:
            return 'FFDH'
        case 390:
            return 'ECDH'
        case 392:
            return 'KRB5'
        case 393:
            return 'KRB5_EXPORT'
        case 395:
            return 'VKO_GOST'
        default:
            return null
    }
}

function getEncryptionPrimitive(codePoint) {
    // The following code points mapping is defined by NetScout.
    switch (codePoint) {
        case 513:
            return 'AES_256_GCM'
        case 514:
            return 'AES_256'
        case 515:
            return 'CAMELLIA_256'
        case 516:
            return 'AES_128_GCM'
        case 517:
            return 'AES_128'
        case 518:
            return 'SEED'
        case 519:
            return 'CAMELLIA_128'
        case 520:
            return 'IDEA'
        case 521:
            return 'RC4_128'
        case 522:
            return 'TDES'
        case 523:
            return 'NULL_ENC'
        case 524:
            return 'DES_56'
        case 525:
            return 'DES_40'
        case 526:
            return 'RC2_40'
        case 527:
            return 'RC4_40'
        case 528:
            return 'RC2_128'
        case 529:
            return 'FORTEZZA_CBC'
        case 530:
            return 'RC4_56'
        case 531:
            return 'RC2_56'
        case 532:
            return 'GOST_ENC'
        case 533:
            return 'CHACHA'
        case 534:
            return 'RC4_64'
        case 535:
            return 'AES_128_CCM'
        case 536:
            return 'AES_256_CCM'
        case 537:
            return 'AES_128_CCM_8'
        case 538:
            return 'AES_256_CCM_8'
        default:
            return null
    }
}

function getMACPrimitive(codePoint) {
    // The following code points mapping is defined by NetScout.
    switch (codePoint) {
        // NetScout has code point "640" for "Mac_AEAD". AEAD means that
        // the message integrity protection is done at the bulk encryption
        // level, and no dedicated MAC is needed. Hence, we should not
        // return any MAC for this code point.
        case 641:
            return 'HMAC_SHA2_384'
        case 642:
            return 'HMAC_SHA1_LT_160'
        case 643:
            return 'HMAC_SHA2_256'
        case 644:
            return 'HMAC_MD5_LT_128'
        case 645:
            return 'NULL_MAC'
        case 646:
            return 'GOST_HASH'
        default:
            return null
    }
}

// Use the key exchange algorithm, authentication algorithm, encryption
// algorithm, and MAC algorithm to calculate the cipher suite used for the
// TLS session.
//
// We can also calculate the crypto algorithm used for PRF (which is used for
// key derivation and key confirmation), which is not given by NetScout, as
// well as other crypto info such as mode of operation and TLS version.
function calculateCipherSuiteAndPrimitives(connectionPrimitives) {

    // Note that since we don't known which version of TLS we are dealing
    // with, the cipher suite reconstruction is based on TLS 1.2 (which also
    // applies to TLS 1.1, 1.0 and SSL 3.0). TLS 1.3 would be different.
    // But, until we get the TLS version info, we will use TLS 1.2.

    let cipherSuite = null
    let protocolVariant = 'TLS Unknown'
    const tls12 = 'TLS 1.2 (calculated)'
    const ssl3 = 'SSL 3'

    // ECDHE for key exchange.
    if (connectionPrimitives.some(entry => entry === 'ECDHE')) {

        // RSA for authentication.
        if (connectionPrimitives.some(entry => entry === 'RSA_SIG')) {
            if (connectionPrimitives.some(entry => entry === 'AES_256_GCM')) {
                // We don't need to test MAC algo, as these three pieces of crypto info
                // can uniquely identify the cipher suite. The MAC algo provided by
                // NetScout is likely "640" (MAC_AEAD) which is ignored by us,
                // since it just points to the fact that "AES_256_GCM" is AEAD.

                // (256 384 513 640)
                // This is the NetScout (KEX, AUTH, ENC, MAC) code points combo
                // from which we calculate the following cipher suite. We don't use
                // the code points directly in deducing the cipher suite. We use
                // our crypto primitives mapped from these code points. This gives
                // us some conveniences such as we don't have to deal with the cases
                // where multiple code points map to the same primitive.
                // ( NOTE: "256" may also be "261" or "262", and "384" may also be
                // "396", but we've encapsulated these cases.)
                cipherSuite = 'TLS_ECDHE_RSA_WITH_AES_256_GCM_SHA384'

                // As per the constructed cipher suite, we can calculate the crypto used
                // for PRF, even though this was not given from the data source.
                if (!connectionPrimitives.some(entry => entry === 'HMAC_SHA2_384')) {
                    connectionPrimitives.push('HMAC_SHA2_384')
                }

                // As noted above, we are synthesizing cipher suites with the assumption
                // that the TLS version is 1.2 and lower. Here we add TLS v1.2 to the
                // connection, as AEAD cipher suites are not back-ported to TLS v1.1
                // and lower. Note however that the version could be TLS 1.3 as per this
                // particular combo of crypto primitives from NetScout, but again we are
                // synthesizing the cipher suites assuming TLS version is 1.2 and lower.
                protocolVariant = tls12
            } else if (connectionPrimitives.some(entry => entry === 'AES_128_GCM')) {
                // (256 384 516 640)
                cipherSuite = 'TLS_ECDHE_RSA_WITH_AES_128_GCM_SHA256'

                if (!connectionPrimitives.some(entry => entry === 'HMAC_SHA2_256')) {
                    connectionPrimitives.push('HMAC_SHA2_256')
                }

                protocolVariant = tls12
            } else if (connectionPrimitives.some(entry => entry === 'AES_256')) {
                if (connectionPrimitives.some(entry => entry === 'HMAC_SHA2_384')) {
                    // (256 384 514 641)
                    cipherSuite = 'TLS_ECDHE_RSA_WITH_AES_256_CBC_SHA384'

                    // NOTE: If we know the version of TLS, we could calculate the PRF at
                    // this point when the hash in ciphersuite is used for MAC. For instance,
                    // TLS 1.2 uses HMAC-SHA256 for PRF by default.
                } else if (connectionPrimitives.some(entry => entry === 'HMAC_SHA1_LT_160')) {
                    // (256 384 514 642)
                    cipherSuite = 'TLS_ECDHE_RSA_WITH_AES_256_CBC_SHA'
                }
            } else if (connectionPrimitives.some(entry => entry === 'AES_128')) {
                if (connectionPrimitives.some(entry => entry === 'HMAC_SHA2_256')) {
                    // (256 384 517 643)
                    cipherSuite = 'TLS_ECDHE_RSA_WITH_AES_128_CBC_SHA256'
                } else if (connectionPrimitives.some(entry => entry === 'HMAC_SHA1_LT_160')) {
                    // (256 384 517 642)
                    cipherSuite = 'TLS_ECDHE_RSA_WITH_AES_128_CBC_SHA'
                }
            } else if (connectionPrimitives.some(entry => entry === 'CAMELLIA_256')) {
                if (connectionPrimitives.some(entry => entry === 'HMAC_SHA2_384')) {
                    // This is the case where MAC is provided.
                    // (256 384 515 641)
                    cipherSuite = 'TLS_ECDHE_RSA_WITH_CAMELLIA_256_CBC_SHA384'
                } else {
                    // This is the case where no MAC was specified (e.g., we were given "MAC_AEAD").
                    // (256 384 515 640)
                    cipherSuite = 'TLS_ECDHE_RSA_WITH_CAMELLIA_256_GCM_SHA384'

                    connectionPrimitives.push('HMAC_SHA2_384')

                    protocolVariant = tls12
                }
            } else if (connectionPrimitives.some(entry => entry === 'CAMELLIA_128')) {
                if (connectionPrimitives.some(entry => entry === 'HMAC_SHA2_256')) {
                    // (256 384 519 643)
                    cipherSuite = 'TLS_ECDHE_RSA_WITH_CAMELLIA_128_CBC_SHA256'
                } else {
                    // (256 384 519 640)
                    cipherSuite = 'TLS_ECDHE_RSA_WITH_CAMELLIA_128_GCM_SHA256'

                    connectionPrimitives.push('HMAC_SHA2_256')

                    protocolVariant = tls12
                }
            } else if (connectionPrimitives.some(entry => entry === 'CHACHA')) {
                // (256 384 533 640)
                cipherSuite = 'TLS_ECDHE_RSA_WITH_CHACHA20_POLY1305_SHA256'

                if (!connectionPrimitives.some(entry => entry === 'HMAC_SHA2_256')) {
                    connectionPrimitives.push('HMAC_SHA2_256')
                }

                protocolVariant = tls12
            } else if (connectionPrimitives.some(entry => entry === 'NULL_ENC')) {
                if (connectionPrimitives.some(entry => entry === 'HMAC_SHA1_LT_160')) {
                    // (256 384 523 642)
                    cipherSuite = 'TLS_ECDHE_RSA_WITH_NULL_SHA'
                }
            } else if (connectionPrimitives.some(entry => entry === 'RC4_128')) {
                if (connectionPrimitives.some(entry => entry === 'HMAC_SHA1_LT_160')) {
                    // (256 384 521 642)
                    cipherSuite = 'TLS_ECDHE_RSA_WITH_RC4_128_SHA'
                }
            } else if (connectionPrimitives.some(entry => entry === 'TDES')) {
                if (connectionPrimitives.some(entry => entry === 'HMAC_SHA1_LT_160')) {
                    // (256 384 522 642)
                    cipherSuite = 'TLS_ECDHE_RSA_WITH_3DES_EDE_CBC_SHA'
                }
            }
        } else

        // ECDSA for authentication.
        if (connectionPrimitives.some(entry => entry === 'ECDSA')) {
            if (connectionPrimitives.some(entry => entry === 'AES_256_GCM')) {
                // (256 385 513 640)
                cipherSuite = 'TLS_ECDHE_ECDSA_WITH_AES_256_GCM_SHA384'

                if (!connectionPrimitives.some(entry => entry === 'HMAC_SHA2_384')) {
                    connectionPrimitives.push('HMAC_SHA2_384')
                }

                protocolVariant = tls12
            } else if (connectionPrimitives.some(entry => entry === 'AES_128_GCM')) {
                // (256 385 516 640)
                cipherSuite = 'TLS_ECDHE_ECDSA_WITH_AES_128_GCM_SHA256'

                if (!connectionPrimitives.some(entry => entry === 'HMAC_SHA2_256')) {
                    connectionPrimitives.push('HMAC_SHA2_256')
                }

                protocolVariant = tls12
            } else if (connectionPrimitives.some(entry => entry === 'AES_256_CCM')) {
                // (256 385 536 640)
                cipherSuite = 'TLS_ECDHE_ECDSA_WITH_AES_256_CCM'

                // The CCM cipher suites use the default TLS 1.2 PRF algorithm, which
                // is HMAC-SHA256.
                if (!connectionPrimitives.some(entry => entry === 'HMAC_SHA2_256')) {
                    connectionPrimitives.push('HMAC_SHA2_256')
                }

                protocolVariant = tls12
            } else if (connectionPrimitives.some(entry => entry === 'AES_128_CCM')) {
                // (256 385 535 640)
                cipherSuite = 'TLS_ECDHE_ECDSA_WITH_AES_128_CCM'

                if (!connectionPrimitives.some(entry => entry === 'HMAC_SHA2_256')) {
                    connectionPrimitives.push('HMAC_SHA2_256')
                }

                protocolVariant = tls12
            } else if (connectionPrimitives.some(entry => entry === 'AES_256_CCM_8')) {
                // (256 385 538 640)
                cipherSuite = 'TLS_ECDHE_ECDSA_WITH_AES_256_CCM_8'

                if (!connectionPrimitives.some(entry => entry === 'HMAC_SHA2_256')) {
                    connectionPrimitives.push('HMAC_SHA2_256')
                }

                protocolVariant = tls12
            } else if (connectionPrimitives.some(entry => entry === 'AES_128_CCM_8')) {
                // (256 385 537 640)
                cipherSuite = 'TLS_ECDHE_ECDSA_WITH_AES_128_CCM_8'

                if (!connectionPrimitives.some(entry => entry === 'HMAC_SHA2_256')) {
                    connectionPrimitives.push('HMAC_SHA2_256')
                }

                protocolVariant = tls12
            } else if (connectionPrimitives.some(entry => entry === 'AES_256')) {
                if (connectionPrimitives.some(entry => entry === 'HMAC_SHA2_384')) {
                    // (256 385 514 641)
                    cipherSuite = 'TLS_ECDHE_ECDSA_WITH_AES_256_CBC_SHA384'
                } else if (connectionPrimitives.some(entry => entry === 'HMAC_SHA1_LT_160')) {
                    // (256 385 514 642)
                    cipherSuite = 'TLS_ECDHE_ECDSA_WITH_AES_256_CBC_SHA'
                }
            } else if (connectionPrimitives.some(entry => entry === 'AES_128')) {
                if (connectionPrimitives.some(entry => entry === 'HMAC_SHA2_256')) {
                    // (256 385 517 643)
                    cipherSuite = 'TLS_ECDHE_ECDSA_WITH_AES_128_CBC_SHA256'
                } else if (connectionPrimitives.some(entry => entry === 'HMAC_SHA1_LT_160')) {
                    // (256 385 517 642)
                    cipherSuite = 'TLS_ECDHE_ECDSA_WITH_AES_128_CBC_SHA'
                }
            } else if (connectionPrimitives.some(entry => entry === 'CAMELLIA_256')) {
                if (connectionPrimitives.some(entry => entry === 'HMAC_SHA2_384')) {
                    // (256 385 515 641)
                    cipherSuite = 'TLS_ECDHE_ECDSA_WITH_CAMELLIA_256_CBC_SHA384'
                } else {
                    // (256 385 515 640)
                    cipherSuite = 'TLS_ECDHE_ECDSA_WITH_CAMELLIA_256_GCM_SHA384'

                    connectionPrimitives.push('HMAC_SHA2_384')

                    protocolVariant = tls12
                }
            } else if (connectionPrimitives.some(entry => entry === 'CAMELLIA_128')) {
                if (connectionPrimitives.some(entry => entry === 'HMAC_SHA2_256')) {
                    // (256 385 519 643)
                    cipherSuite = 'TLS_ECDHE_ECDSA_WITH_CAMELLIA_128_CBC_SHA256'
                } else {
                    // (256 385 519 640)
                    cipherSuite = 'TLS_ECDHE_ECDSA_WITH_CAMELLIA_128_GCM_SHA256'

                    connectionPrimitives.push('HMAC_SHA2_256')

                    protocolVariant = tls12
                }
            } else if (connectionPrimitives.some(entry => entry === 'CHACHA')) {
                // (256 385 533 640)
                cipherSuite = 'TLS_ECDHE_ECDSA_WITH_CHACHA20_POLY1305_SHA256'

                if (!connectionPrimitives.some(entry => entry === 'HMAC_SHA2_256')) {
                    connectionPrimitives.push('HMAC_SHA2_256')
                }

                protocolVariant = tls12
            } else if (connectionPrimitives.some(entry => entry === 'NULL_ENC')) {
                if (connectionPrimitives.some(entry => entry === 'HMAC_SHA1_LT_160')) {
                    // (256 385 523 642)
                    cipherSuite = 'TLS_ECDHE_ECDSA_WITH_NULL_SHA'
                }
            } else if (connectionPrimitives.some(entry => entry === 'RC4_128')) {
                if (connectionPrimitives.some(entry => entry === 'HMAC_SHA1_LT_160')) {
                    // (256 385 521 642)
                    cipherSuite = 'TLS_ECDHE_ECDSA_WITH_RC4_128_SHA'
                }
            } else if (connectionPrimitives.some(entry => entry === 'TDES')) {
                if (connectionPrimitives.some(entry => entry === 'HMAC_SHA1_LT_160')) {
                    // (256 385 522 642)
                    cipherSuite = 'TLS_ECDHE_ECDSA_WITH_3DES_EDE_CBC_SHA'
                }
            }
        } else

        // PSK for authentication (in addition to kex).
        if (connectionPrimitives.some(entry => entry === 'PSK_AUTH')) {
            if (connectionPrimitives.some(entry => entry === 'AES_256_GCM')) {
                // (256 391 513 640)
                cipherSuite = 'TLS_ECDHE_PSK_WITH_AES_256_GCM_SHA384'

                if (!connectionPrimitives.some(entry => entry === 'HMAC_SHA2_384')) {
                    connectionPrimitives.push('HMAC_SHA2_384')
                }

                protocolVariant = tls12
            } else if (connectionPrimitives.some(entry => entry === 'AES_128_GCM')) {
                // (256 391 516 640)
                cipherSuite = 'TLS_ECDHE_PSK_WITH_AES_128_GCM_SHA256'

                if (!connectionPrimitives.some(entry => entry === 'HMAC_SHA2_256')) {
                    connectionPrimitives.push('HMAC_SHA2_256')
                }

                protocolVariant = tls12
            } else if (connectionPrimitives.some(entry => entry === 'AES_128_CCM')) {
                // (256 391 535 640)
                cipherSuite = 'TLS_ECDHE_PSK_WITH_AES_128_CCM_SHA256'

                if (!connectionPrimitives.some(entry => entry === 'HMAC_SHA2_256')) {
                    connectionPrimitives.push('HMAC_SHA2_256')
                }

                protocolVariant = tls12
            } else if (connectionPrimitives.some(entry => entry === 'AES_128_CCM_8')) {
                // (256 391 537 640)
                cipherSuite = 'TLS_ECDHE_PSK_WITH_AES_128_CCM_8_SHA256'

                if (!connectionPrimitives.some(entry => entry === 'HMAC_SHA2_256')) {
                    connectionPrimitives.push('HMAC_SHA2_256')
                }

                protocolVariant = tls12
            } else if (connectionPrimitives.some(entry => entry === 'AES_256')) {
                if (connectionPrimitives.some(entry => entry === 'HMAC_SHA2_384')) {
                    // (256 391 514 641)
                    cipherSuite = 'TLS_ECDHE_PSK_WITH_AES_256_CBC_SHA384'
                } else if (connectionPrimitives.some(entry => entry === 'HMAC_SHA1_LT_160')) {
                    // (256 391 514 642)
                    cipherSuite = 'TLS_ECDHE_PSK_WITH_AES_256_CBC_SHA'
                }
            } else if (connectionPrimitives.some(entry => entry === 'AES_128')) {
                if (connectionPrimitives.some(entry => entry === 'HMAC_SHA2_256')) {
                    // (256 391 517 643)
                    cipherSuite = 'TLS_ECDHE_PSK_WITH_AES_128_CBC_SHA256'
                } else if (connectionPrimitives.some(entry => entry === 'HMAC_SHA1_LT_160')) {
                    // (256 391 517 642)
                    cipherSuite = 'TLS_ECDHE_PSK_WITH_AES_128_CBC_SHA'
                }
            } else if (connectionPrimitives.some(entry => entry === 'CAMELLIA_256')) {
                if (connectionPrimitives.some(entry => entry === 'HMAC_SHA2_384')) {
                    // (256 391 515 641)
                    cipherSuite = 'TLS_ECDHE_PSK_WITH_CAMELLIA_256_CBC_SHA384'
                }
            } else if (connectionPrimitives.some(entry => entry === 'CAMELLIA_128')) {
                if (connectionPrimitives.some(entry => entry === 'HMAC_SHA2_256')) {
                    // (256 391 519 643)
                    cipherSuite = 'TLS_ECDHE_PSK_WITH_CAMELLIA_128_CBC_SHA256'
                }
            } else if (connectionPrimitives.some(entry => entry === 'CHACHA')) {
                // (256 391 533 640)
                cipherSuite = 'TLS_ECDHE_PSK_WITH_CHACHA20_POLY1305_SHA256'

                if (!connectionPrimitives.some(entry => entry === 'HMAC_SHA2_256')) {
                    connectionPrimitives.push('HMAC_SHA2_256')
                }

                protocolVariant = tls12
            } else if (connectionPrimitives.some(entry => entry === 'NULL_ENC')) {
                if (connectionPrimitives.some(entry => entry === 'HMAC_SHA1_LT_160')) {
                    // (256 391 523 642)
                    cipherSuite = 'TLS_ECDHE_PSK_WITH_NULL_SHA'
                } else if (connectionPrimitives.some(entry => entry === 'HMAC_SHA2_256')) {
                    // (256 391 523 643)
                    cipherSuite = 'TLS_ECDHE_PSK_WITH_NULL_SHA256'
                } else if (connectionPrimitives.some(entry => entry === 'HMAC_SHA2_384')) {
                    // (256 391 523 641)
                    cipherSuite = 'TLS_ECDHE_PSK_WITH_NULL_SHA384'
                }
            } else if (connectionPrimitives.some(entry => entry === 'RC4_128')) {
                if (connectionPrimitives.some(entry => entry === 'HMAC_SHA1_LT_160')) {
                    // (256 391 521 642)
                    cipherSuite = 'TLS_ECDHE_PSK_WITH_RC4_128_SHA'
                }
            } else if (connectionPrimitives.some(entry => entry === 'TDES')) {
                if (connectionPrimitives.some(entry => entry === 'HMAC_SHA1_LT_160')) {
                    // (256 391 522 642)
                    cipherSuite = 'TLS_ECDHE_PSK_WITH_3DES_EDE_CBC_SHA'
                }
            }
        }
    } else

    // DHE for key exchange.
    if (connectionPrimitives.some(entry => entry === 'FFDHE') ||
        connectionPrimitives.some(entry => entry === 'FFDHE_512')) {

        // RSA for authentication.
        if (connectionPrimitives.some(entry => entry === 'RSA_SIG')) {
            if (connectionPrimitives.some(entry => entry === 'AES_256_GCM')) {
                // (259 384 513 640)
                cipherSuite = 'TLS_DHE_RSA_WITH_AES_256_GCM_SHA384'

                if (!connectionPrimitives.some(entry => entry === 'HMAC_SHA2_384')) {
                    connectionPrimitives.push('HMAC_SHA2_384')
                }

                protocolVariant = tls12
            } else if (connectionPrimitives.some(entry => entry === 'AES_128_GCM')) {
                // (259 384 516 640)
                cipherSuite = 'TLS_DHE_RSA_WITH_AES_128_GCM_SHA256'

                if (!connectionPrimitives.some(entry => entry === 'HMAC_SHA2_256')) {
                    connectionPrimitives.push('HMAC_SHA2_256')
                }

                protocolVariant = tls12
            } else if (connectionPrimitives.some(entry => entry === 'AES_256')) {
                if (connectionPrimitives.some(entry => entry === 'HMAC_SHA2_256')) {
                    // (259 384 514 643)
                    cipherSuite = 'TLS_DHE_RSA_WITH_AES_256_CBC_SHA256'
                } else if (connectionPrimitives.some(entry => entry === 'HMAC_SHA1_LT_160')) {
                    // (259 384 514 642)
                    cipherSuite = 'TLS_DHE_RSA_WITH_AES_256_CBC_SHA'
                }
            } else if (connectionPrimitives.some(entry => entry === 'AES_128')) {
                if (connectionPrimitives.some(entry => entry === 'HMAC_SHA2_256')) {
                    // (259 384 517 643)
                    cipherSuite = 'TLS_DHE_RSA_WITH_AES_128_CBC_SHA256'
                } else if (connectionPrimitives.some(entry => entry === 'HMAC_SHA1_LT_160')) {
                    // (259 384 517 642)
                    cipherSuite = 'TLS_DHE_RSA_WITH_AES_128_CBC_SHA'
                }
            } else if (connectionPrimitives.some(entry => entry === 'AES_256_CCM')) {
                // (259 384 536 640)
                cipherSuite = 'TLS_DHE_RSA_WITH_AES_256_CCM'

                if (!connectionPrimitives.some(entry => entry === 'HMAC_SHA2_256')) {
                    connectionPrimitives.push('HMAC_SHA2_256')
                }

                protocolVariant = tls12
            } else if (connectionPrimitives.some(entry => entry === 'AES_128_CCM')) {
                // (259 384 535 640)
                cipherSuite = 'TLS_DHE_RSA_WITH_AES_128_CCM'

                if (!connectionPrimitives.some(entry => entry === 'HMAC_SHA2_256')) {
                    connectionPrimitives.push('HMAC_SHA2_256')
                }

                protocolVariant = tls12
            } else if (connectionPrimitives.some(entry => entry === 'AES_256_CCM_8')) {
                // (259 384 538 640)
                cipherSuite = 'TLS_DHE_RSA_WITH_AES_256_CCM_8'

                if (!connectionPrimitives.some(entry => entry === 'HMAC_SHA2_256')) {
                    connectionPrimitives.push('HMAC_SHA2_256')
                }

                protocolVariant = tls12
            } else if (connectionPrimitives.some(entry => entry === 'AES_128_CCM_8')) {
                // (259 384 537 640)
                cipherSuite = 'TLS_DHE_RSA_WITH_AES_128_CCM_8'

                if (!connectionPrimitives.some(entry => entry === 'HMAC_SHA2_256')) {
                    connectionPrimitives.push('HMAC_SHA2_256')
                }

                protocolVariant = tls12
            } else if (connectionPrimitives.some(entry => entry === 'CAMELLIA_256')) {
                if (connectionPrimitives.some(entry => entry === 'HMAC_SHA2_256')) {
                    // (259 384 515 643)
                    cipherSuite = 'TLS_DHE_RSA_WITH_CAMELLIA_256_CBC_SHA256'
                } else if (connectionPrimitives.some(entry => entry === 'HMAC_SHA1_LT_160')) {
                    // (259 384 515 642)
                    cipherSuite = 'TLS_DHE_RSA_WITH_CAMELLIA_256_CBC_SHA'
                } else if (!connectionPrimitives.some(entry => entry === 'HMAC_SHA2_384')) {
                    // (259 384 515 640)
                    cipherSuite = 'TLS_DHE_RSA_WITH_CAMELLIA_256_GCM_SHA384'

                    connectionPrimitives.push('HMAC_SHA2_384')

                    protocolVariant = tls12
                }
            } else if (connectionPrimitives.some(entry => entry === 'CAMELLIA_128')) {
                if (connectionPrimitives.some(entry => entry === 'HMAC_SHA2_256')) {
                    // (259 384 519 643)
                    cipherSuite = 'TLS_DHE_RSA_WITH_CAMELLIA_128_CBC_SHA256'
                } else if (connectionPrimitives.some(entry => entry === 'HMAC_SHA1_LT_160')) {
                    // (259 384 519 642)
                    cipherSuite = 'TLS_DHE_RSA_WITH_CAMELLIA_128_CBC_SHA'
                } else {
                    // (259 384 519 640)
                    cipherSuite = 'TLS_DHE_RSA_WITH_CAMELLIA_128_GCM_SHA256'

                    connectionPrimitives.push('HMAC_SHA2_256')

                    protocolVariant = tls12
                }
            } else if (connectionPrimitives.some(entry => entry === 'DES_40')) {
                if (connectionPrimitives.some(entry => entry === 'HMAC_SHA1_LT_160')) {
                    // (259 384 525 642)
                    cipherSuite = 'TLS_DHE_RSA_EXPORT_WITH_DES40_CBC_SHA'
                }
            } else if (connectionPrimitives.some(entry => entry === 'DES_56')) {
                if (connectionPrimitives.some(entry => entry === 'HMAC_SHA1_LT_160')) {
                    // (259 384 524 642)
                    cipherSuite = 'TLS_DHE_RSA_WITH_DES_CBC_SHA'
                }
            } else if (connectionPrimitives.some(entry => entry === 'TDES')) {
                if (connectionPrimitives.some(entry => entry === 'HMAC_SHA1_LT_160')) {
                    // (259 384 522 642)
                    cipherSuite = 'TLS_DHE_RSA_WITH_3DES_EDE_CBC_SHA'
                }
            } else if (connectionPrimitives.some(entry => entry === 'SEED')) {
                if (connectionPrimitives.some(entry => entry === 'HMAC_SHA1_LT_160')) {
                    // (259 384 518 642)
                    cipherSuite = 'TLS_DHE_RSA_WITH_SEED_CBC_SHA'
                }
            } else if (connectionPrimitives.some(entry => entry === 'CHACHA')) {
                // (259 384 533 640)
                cipherSuite = 'TLS_DHE_RSA_WITH_CHACHA20_POLY1305_SHA256'

                if (!connectionPrimitives.some(entry => entry === 'HMAC_SHA2_256')) {
                    connectionPrimitives.push('HMAC_SHA2_256')
                }

                protocolVariant = tls12
            }
        } else

        // DSS for authentication.
        if (connectionPrimitives.some(entry => entry === 'DSA')) {
            if (connectionPrimitives.some(entry => entry === 'AES_256_GCM')) {
                // (259 386 513 640)
                cipherSuite = 'TLS_DHE_DSS_WITH_AES_256_GCM_SHA384'

                if (!connectionPrimitives.some(entry => entry === 'HMAC_SHA2_384')) {
                    connectionPrimitives.push('HMAC_SHA2_384')
                }

                protocolVariant = tls12
            } else if (connectionPrimitives.some(entry => entry === 'AES_128_GCM')) {
                // (259 386 516 640)
                cipherSuite = 'TLS_DHE_DSS_WITH_AES_128_GCM_SHA256'

                if (!connectionPrimitives.some(entry => entry === 'HMAC_SHA2_256')) {
                    connectionPrimitives.push('HMAC_SHA2_256')
                }

                protocolVariant = tls12
            } else if (connectionPrimitives.some(entry => entry === 'AES_256')) {
                if (connectionPrimitives.some(entry => entry === 'HMAC_SHA2_256')) {
                    // (259 386 514 643)
                    cipherSuite = 'TLS_DHE_DSS_WITH_AES_256_CBC_SHA256'
                } else if (connectionPrimitives.some(entry => entry === 'HMAC_SHA1_LT_160')) {
                    // (259 386 514 642)
                    cipherSuite = 'TLS_DHE_DSS_WITH_AES_256_CBC_SHA'
                }
            } else if (connectionPrimitives.some(entry => entry === 'AES_128')) {
                if (connectionPrimitives.some(entry => entry === 'HMAC_SHA2_256')) {
                    // (259 386 517 643)
                    cipherSuite = 'TLS_DHE_DSS_WITH_AES_128_CBC_SHA256'
                } else if (connectionPrimitives.some(entry => entry === 'HMAC_SHA1_LT_160')) {
                    // (259 386 517 642)
                    cipherSuite = 'TLS_DHE_DSS_WITH_AES_128_CBC_SHA'
                }
            } else if (connectionPrimitives.some(entry => entry === 'CAMELLIA_256')) {
                if (connectionPrimitives.some(entry => entry === 'HMAC_SHA2_256')) {
                    // (259 386 515 643)
                    cipherSuite = 'TLS_DHE_DSS_WITH_CAMELLIA_256_CBC_SHA256'
                } else if (connectionPrimitives.some(entry => entry === 'HMAC_SHA1_LT_160')) {
                    // (259 386 515 642)
                    cipherSuite = 'TLS_DHE_DSS_WITH_CAMELLIA_256_CBC_SHA'
                } else if (!connectionPrimitives.some(entry => entry === 'HMAC_SHA2_384')) {
                    // (259 386 515 640)
                    cipherSuite = 'TLS_DHE_DSS_WITH_CAMELLIA_256_GCM_SHA384'

                    connectionPrimitives.push('HMAC_SHA2_384')

                    protocolVariant = tls12
                }
            } else if (connectionPrimitives.some(entry => entry === 'CAMELLIA_128')) {
                if (connectionPrimitives.some(entry => entry === 'HMAC_SHA2_256')) {
                    // (259 386 519 643)
                    cipherSuite = 'TLS_DHE_DSS_WITH_CAMELLIA_128_CBC_SHA256'
                } else if (connectionPrimitives.some(entry => entry === 'HMAC_SHA1_LT_160')) {
                    // (259 386 519 642)
                    cipherSuite = 'TLS_DHE_DSS_WITH_CAMELLIA_128_CBC_SHA'
                } else {
                    // (259 386 519 640)
                    cipherSuite = 'TLS_DHE_DSS_WITH_CAMELLIA_128_GCM_SHA256'

                    connectionPrimitives.push('HMAC_SHA2_256')

                    protocolVariant = tls12
                }
            } else if (connectionPrimitives.some(entry => entry === 'DES_40')) {
                if (connectionPrimitives.some(entry => entry === 'HMAC_SHA1_LT_160')) {
                    // (259 386 525 642)
                    cipherSuite = 'TLS_DHE_DSS_EXPORT_WITH_DES40_CBC_SHA'
                }
            } else if (connectionPrimitives.some(entry => entry === 'DES_56')) {
                if (connectionPrimitives.some(entry => entry === 'HMAC_SHA1_LT_160')) {
                    // (259 386 524 642)
                    cipherSuite = 'TLS_DHE_DSS_WITH_DES_CBC_SHA'
                }
            } else if (connectionPrimitives.some(entry => entry === 'TDES')) {
                if (connectionPrimitives.some(entry => entry === 'HMAC_SHA1_LT_160')) {
                    // (259 386 522 642)
                    cipherSuite = 'TLS_DHE_DSS_WITH_3DES_EDE_CBC_SHA'
                }
            } else if (connectionPrimitives.some(entry => entry === 'SEED')) {
                if (connectionPrimitives.some(entry => entry === 'HMAC_SHA1_LT_160')) {
                    // (259 386 518 642)
                    cipherSuite = 'TLS_DHE_DSS_WITH_SEED_CBC_SHA'
                }
            }
        } else

        // PSK for authentication (in addition to kex).
        if (connectionPrimitives.some(entry => entry === 'PSK_AUTH')) {
            if (connectionPrimitives.some(entry => entry === 'AES_256_GCM')) {
                // (259 391 513 640)
                cipherSuite = 'TLS_DHE_PSK_WITH_AES_256_GCM_SHA384'

                if (!connectionPrimitives.some(entry => entry === 'HMAC_SHA2_384')) {
                    connectionPrimitives.push('HMAC_SHA2_384')
                }

                protocolVariant = tls12
            } else if (connectionPrimitives.some(entry => entry === 'AES_128_GCM')) {
                // (259 391 516 640)
                cipherSuite = 'TLS_DHE_PSK_WITH_AES_128_GCM_SHA256'

                if (!connectionPrimitives.some(entry => entry === 'HMAC_SHA2_256')) {
                    connectionPrimitives.push('HMAC_SHA2_256')
                }

                protocolVariant = tls12
            } else if (connectionPrimitives.some(entry => entry === 'AES_256')) {
                if (connectionPrimitives.some(entry => entry === 'HMAC_SHA2_384')) {
                    // (259 391 514 641)
                    cipherSuite = 'TLS_DHE_PSK_WITH_AES_256_CBC_SHA384'
                } else if (connectionPrimitives.some(entry => entry === 'HMAC_SHA1_LT_160')) {
                    // (259 391 514 642)
                    cipherSuite = 'TLS_DHE_PSK_WITH_AES_256_CBC_SHA'
                }
            } else if (connectionPrimitives.some(entry => entry === 'AES_128')) {
                if (connectionPrimitives.some(entry => entry === 'HMAC_SHA2_256')) {
                    // (259 391 517 643)
                    cipherSuite = 'TLS_DHE_PSK_WITH_AES_128_CBC_SHA256'
                } else if (connectionPrimitives.some(entry => entry === 'HMAC_SHA1_LT_160')) {
                    // (259 391 517 642)
                    cipherSuite = 'TLS_DHE_PSK_WITH_AES_128_CBC_SHA'
                }
            } else if (connectionPrimitives.some(entry => entry === 'AES_256_CCM')) {
                // (259 391 536 640)
                cipherSuite = 'TLS_DHE_PSK_WITH_AES_256_CCM'

                if (!connectionPrimitives.some(entry => entry === 'HMAC_SHA2_256')) {
                    connectionPrimitives.push('HMAC_SHA2_256')
                }

                protocolVariant = tls12
            } else if (connectionPrimitives.some(entry => entry === 'AES_128_CCM')) {
                // (259 391 537 640)
                cipherSuite = 'TLS_DHE_PSK_WITH_AES_128_CCM'

                if (!connectionPrimitives.some(entry => entry === 'HMAC_SHA2_256')) {
                    connectionPrimitives.push('HMAC_SHA2_256')
                }

                protocolVariant = tls12
            } else if (connectionPrimitives.some(entry => entry === 'AES_256_CCM_8')) {
                // (259 391 538 640)
                cipherSuite = 'TLS_DHE_PSK_WITH_AES_256_CCM_8'

                if (!connectionPrimitives.some(entry => entry === 'HMAC_SHA2_256')) {
                    connectionPrimitives.push('HMAC_SHA2_256')
                }

                protocolVariant = tls12
            } else if (connectionPrimitives.some(entry => entry === 'AES_128_CCM_8')) {
                // (259 391 537 640)
                cipherSuite = 'TLS_DHE_PSK_WITH_AES_128_CCM_8'

                if (!connectionPrimitives.some(entry => entry === 'HMAC_SHA2_256')) {
                    connectionPrimitives.push('HMAC_SHA2_256')
                }

                protocolVariant = tls12
            } else if (connectionPrimitives.some(entry => entry === 'CAMELLIA_256')) {
                if (connectionPrimitives.some(entry => entry === 'HMAC_SHA2_384')) {
                    // (259 391 515 641)
                    cipherSuite = 'TLS_DHE_PSK_WITH_CAMELLIA_256_CBC_SHA384'
                } else {
                    // (259 391 515 640)
                    cipherSuite = 'TLS_DHE_PSK_WITH_CAMELLIA_256_GCM_SHA384'

                    connectionPrimitives.push('HMAC_SHA2_384')

                    protocolVariant = tls12
                }
            } else if (connectionPrimitives.some(entry => entry === 'CAMELLIA_128')) {
                if (connectionPrimitives.some(entry => entry === 'HMAC_SHA2_256')) {
                    // (259 391 519 643)
                    cipherSuite = 'TLS_DHE_PSK_WITH_CAMELLIA_128_CBC_SHA256'
                } else {
                    // (259 391 519 640)
                    cipherSuite = 'TLS_DHE_PSK_WITH_CAMELLIA_128_GCM_SHA256'

                    connectionPrimitives.push('HMAC_SHA2_256')

                    protocolVariant = tls12
                }
            } else if (connectionPrimitives.some(entry => entry === 'TDES')) {
                if (connectionPrimitives.some(entry => entry === 'HMAC_SHA1_LT_160')) {
                    // (259 391 522 642)
                    cipherSuite = 'TLS_DHE_PSK_WITH_3DES_EDE_CBC_SHA'
                }
            } else if (connectionPrimitives.some(entry => entry === 'RC4_128')) {
                if (connectionPrimitives.some(entry => entry === 'HMAC_SHA1_LT_160')) {
                    // (259 391 521 642)
                    cipherSuite = 'TLS_DHE_PSK_WITH_RC4_128_SHA'
                }
            } else if (connectionPrimitives.some(entry => entry === 'CHACHA')) {
                // (259 391 533 640)
                cipherSuite = 'TLS_DHE_PSK_WITH_CHACHA20_POLY1305_SHA256'

                if (!connectionPrimitives.some(entry => entry === 'HMAC_SHA2_256')) {
                    connectionPrimitives.push('HMAC_SHA2_256')
                }

                protocolVariant = tls12
            } else if (connectionPrimitives.some(entry => entry === 'NULL_ENC')) {
                if (connectionPrimitives.some(entry => entry === 'HMAC_SHA2_384')) {
                    // (259 391 523 641)
                    cipherSuite = 'TLS_DHE_PSK_WITH_NULL_SHA384'
                } else if (connectionPrimitives.some(entry => entry === 'HMAC_SHA2_256')) {
                    // (259 391 523 643)
                    cipherSuite = 'TLS_DHE_PSK_WITH_NULL_SHA256'
                } else if (connectionPrimitives.some(entry => entry === 'HMAC_SHA1_LT_160')) {
                    // (259 391 523 642)
                    cipherSuite = 'TLS_DHE_PSK_WITH_NULL_SHA'
                }
            }
        }
    } else

    // RSA for key exchange
    if (connectionPrimitives.some(entry => entry === 'RSA_KE') ||
        connectionPrimitives.some(entry => entry === 'RSA_KE_512')) {

        // RSA for authentication.
        if (connectionPrimitives.some(entry => entry === 'RSA_SIG')) {
            if (connectionPrimitives.some(entry => entry === 'NULL_ENC')) {
                if (connectionPrimitives.some(entry => entry === 'HMAC_MD5_LT_128')) {
                    // (263 384 523 644)
                    cipherSuite = 'TLS_RSA_WITH_NULL_MD5'
                } else if (connectionPrimitives.some(entry => entry === 'HMAC_SHA1_LT_160')) {
                    // (263 384 523 642)
                    cipherSuite = 'TLS_RSA_WITH_NULL_SHA'
                } else if (connectionPrimitives.some(entry => entry === 'HMAC_SHA2_256')) {
                    // (263 384 523 643)
                    cipherSuite = 'TLS_RSA_WITH_NULL_SHA256'
                }
            } else if (connectionPrimitives.some(entry => entry === 'RC4_128')) {
                if (connectionPrimitives.some(entry => entry === 'HMAC_MD5_LT_128')) {
                    // (263 384 521 644)
                    cipherSuite = 'TLS_RSA_WITH_RC4_128_MD5'
                } else if (connectionPrimitives.some(entry => entry === 'HMAC_SHA1_LT_160')) {
                    // (263 384 521 642)
                    cipherSuite = 'TLS_RSA_WITH_RC4_128_SHA'
                }
            } else if (connectionPrimitives.some(entry => entry === 'IDEA')) {
                if (connectionPrimitives.some(entry => entry === 'HMAC_SHA1_LT_160')) {
                    // (263 384 520 642)
                    cipherSuite = 'TLS_RSA_WITH_IDEA_CBC_SHA'
                }
            } else if (connectionPrimitives.some(entry => entry === 'DES_56')) {
                if (connectionPrimitives.some(entry => entry === 'HMAC_SHA1_LT_160')) {
                    // (263 384 524 642)
                    cipherSuite = 'TLS_RSA_WITH_DES_CBC_SHA'
                }
            } else if (connectionPrimitives.some(entry => entry === 'TDES')) {
                if (connectionPrimitives.some(entry => entry === 'HMAC_SHA1_LT_160')) {
                    // (263 384 522 642)
                    cipherSuite = 'TLS_RSA_WITH_3DES_EDE_CBC_SHA'
                }
            } else if (connectionPrimitives.some(entry => entry === 'AES_128')) {
                if (connectionPrimitives.some(entry => entry === 'HMAC_SHA2_256')) {
                    // (263 384 517 643)
                    cipherSuite = 'TLS_RSA_WITH_AES_128_CBC_SHA256'
                } else if (connectionPrimitives.some(entry => entry === 'HMAC_SHA1_LT_160')) {
                    // (263 384 517 642)
                    cipherSuite = 'TLS_RSA_WITH_AES_128_CBC_SHA'
                }
            } else if (connectionPrimitives.some(entry => entry === 'AES_256')) {
                if (connectionPrimitives.some(entry => entry === 'HMAC_SHA2_256')) {
                    // (263 384 514 643)
                    cipherSuite = 'TLS_RSA_WITH_AES_256_CBC_SHA256'
                } else if (connectionPrimitives.some(entry => entry === 'HMAC_SHA1_LT_160')) {
                    // (263 384 514 642)
                    cipherSuite = 'TLS_RSA_WITH_AES_256_CBC_SHA'
                }
            } else if (connectionPrimitives.some(entry => entry === 'AES_256_GCM')) {
                // (263 384 513 640)
                cipherSuite = 'TLS_RSA_WITH_AES_256_GCM_SHA384'

                if (!connectionPrimitives.some(entry => entry === 'HMAC_SHA2_384')) {
                    connectionPrimitives.push('HMAC_SHA2_384')
                }

                protocolVariant = tls12
            } else if (connectionPrimitives.some(entry => entry === 'AES_128_GCM')) {
                // (263 384 516 640)
                cipherSuite = 'TLS_RSA_WITH_AES_128_GCM_SHA256'

                if (!connectionPrimitives.some(entry => entry === 'HMAC_SHA2_256')) {
                    connectionPrimitives.push('HMAC_SHA2_256')
                }

                protocolVariant = tls12
            } else if (connectionPrimitives.some(entry => entry === 'AES_256_CCM')) {
                // (263 384 536 640)
                cipherSuite = 'TLS_RSA_WITH_AES_256_CCM'

                if (!connectionPrimitives.some(entry => entry === 'HMAC_SHA2_256')) {
                    connectionPrimitives.push('HMAC_SHA2_256')
                }

                protocolVariant = tls12
            } else if (connectionPrimitives.some(entry => entry === 'AES_128_CCM')) {
                // (263 384 535 640)
                cipherSuite = 'TLS_RSA_WITH_AES_128_CCM'

                if (!connectionPrimitives.some(entry => entry === 'HMAC_SHA2_256')) {
                    connectionPrimitives.push('HMAC_SHA2_256')
                }

                protocolVariant = tls12
            } else if (connectionPrimitives.some(entry => entry === 'AES_256_CCM_8')) {
                // (263 384 538 640)
                cipherSuite = 'TLS_RSA_WITH_AES_256_CCM_8'

                if (!connectionPrimitives.some(entry => entry === 'HMAC_SHA2_256')) {
                    connectionPrimitives.push('HMAC_SHA2_256')
                }

                protocolVariant = tls12
            } else if (connectionPrimitives.some(entry => entry === 'AES_128_CCM_8')) {
                // (263 384 537 640)
                cipherSuite = 'TLS_RSA_WITH_AES_128_CCM_8'

                if (!connectionPrimitives.some(entry => entry === 'HMAC_SHA2_256')) {
                    connectionPrimitives.push('HMAC_SHA2_256')
                }

                protocolVariant = tls12
            } else if (connectionPrimitives.some(entry => entry === 'CAMELLIA_256')) {
                if (connectionPrimitives.some(entry => entry === 'HMAC_SHA2_256')) {
                    // (263 384 515 643)
                    cipherSuite = 'TLS_RSA_WITH_CAMELLIA_256_CBC_SHA256'
                } else if (connectionPrimitives.some(entry => entry === 'HMAC_SHA1_LT_160')) {
                    // (263 384 515 642)
                    cipherSuite = 'TLS_RSA_WITH_CAMELLIA_256_CBC_SHA'
                } else if (!connectionPrimitives.some(entry => entry === 'HMAC_SHA2_384')) {
                    // (263 384 515 640)
                    cipherSuite = 'TLS_RSA_WITH_CAMELLIA_256_GCM_SHA384'

                    connectionPrimitives.push('HMAC_SHA2_384')

                    protocolVariant = tls12
                }
            } else if (connectionPrimitives.some(entry => entry === 'CAMELLIA_128')) {
                if (connectionPrimitives.some(entry => entry === 'HMAC_SHA2_256')) {
                    // (263 384 519 643)
                    cipherSuite = 'TLS_RSA_WITH_CAMELLIA_128_CBC_SHA256'
                } else if (connectionPrimitives.some(entry => entry === 'HMAC_SHA1_LT_160')) {
                    // (263 384 519 642)
                    cipherSuite = 'TLS_RSA_WITH_CAMELLIA_128_CBC_SHA'
                } else {
                    // (263 384 519 640)
                    cipherSuite = 'TLS_RSA_WITH_CAMELLIA_128_GCM_SHA256'

                    connectionPrimitives.push('HMAC_SHA2_256')

                    protocolVariant = tls12
                }
            } else if (connectionPrimitives.some(entry => entry === 'SEED')) {
                if (connectionPrimitives.some(entry => entry === 'HMAC_SHA1_LT_160')) {
                    // (263 384 518 642)
                    cipherSuite = 'TLS_RSA_WITH_SEED_CBC_SHA'
                }
            }
        } else

        // PSK for authentication.
        if (connectionPrimitives.some(entry => entry === 'PSK_AUTH')) {
            if (connectionPrimitives.some(entry => entry === 'NULL_ENC')) {
                if (connectionPrimitives.some(entry => entry === 'HMAC_SHA2_384')) {
                    // (263 391 523 641)
                    cipherSuite = 'TLS_RSA_PSK_WITH_NULL_SHA384'
                } else if (connectionPrimitives.some(entry => entry === 'HMAC_SHA1_LT_160')) {
                    // (263 391 523 642)
                    cipherSuite = 'TLS_RSA_PSK_WITH_NULL_SHA'
                } else if (connectionPrimitives.some(entry => entry === 'HMAC_SHA2_256')) {
                    // (263 391 523 643)
                    cipherSuite = 'TLS_RSA_PSK_WITH_NULL_SHA256'
                }
            } else if (connectionPrimitives.some(entry => entry === 'RC4_128')) {
                if (connectionPrimitives.some(entry => entry === 'HMAC_SHA1_LT_160')) {
                    // (263 391 521 642)
                    cipherSuite = 'TLS_RSA_PSK_WITH_RC4_128_SHA'
                }
            } else if (connectionPrimitives.some(entry => entry === 'TDES')) {
                if (connectionPrimitives.some(entry => entry === 'HMAC_SHA1_LT_160')) {
                    // (263 391 522 642)
                    cipherSuite = 'TLS_RSA_PSK_WITH_3DES_EDE_CBC_SHA'
                }
            } else if (connectionPrimitives.some(entry => entry === 'AES_128')) {
                if (connectionPrimitives.some(entry => entry === 'HMAC_SHA2_256')) {
                    // (263 391 517 643)
                    cipherSuite = 'TLS_RSA_PSK_WITH_AES_128_CBC_SHA256'
                } else if (connectionPrimitives.some(entry => entry === 'HMAC_SHA1_LT_160')) {
                    // (263 391 517 642)
                    cipherSuite = 'TLS_RSA_PSK_WITH_AES_128_CBC_SHA'
                }
            } else if (connectionPrimitives.some(entry => entry === 'AES_256')) {
                if (connectionPrimitives.some(entry => entry === 'HMAC_SHA2_384')) {
                    // (263 391 514 641)
                    cipherSuite = 'TLS_RSA_PSK_WITH_AES_256_CBC_SHA384'
                } else if (connectionPrimitives.some(entry => entry === 'HMAC_SHA1_LT_160')) {
                    // (263 391 514 642)
                    cipherSuite = 'TLS_RSA_PSK_WITH_AES_256_CBC_SHA'
                }
            } else if (connectionPrimitives.some(entry => entry === 'AES_256_GCM')) {
                // (263 391 513 640)
                cipherSuite = 'TLS_RSA_PSK_WITH_AES_256_GCM_SHA384'

                if (!connectionPrimitives.some(entry => entry === 'HMAC_SHA2_384')) {
                    connectionPrimitives.push('HMAC_SHA2_384')
                }

                protocolVariant = tls12
            } else if (connectionPrimitives.some(entry => entry === 'AES_128_GCM')) {
                // (263 391 516 640)
                cipherSuite = 'TLS_RSA_PSK_WITH_AES_128_GCM_SHA256'

                if (!connectionPrimitives.some(entry => entry === 'HMAC_SHA2_256')) {
                    connectionPrimitives.push('HMAC_SHA2_256')
                }

                protocolVariant = tls12
            }  else if (connectionPrimitives.some(entry => entry === 'CAMELLIA_256')) {
                if (connectionPrimitives.some(entry => entry === 'HMAC_SHA2_384')) {
                    // (263 391 515 641)
                    cipherSuite = 'TLS_RSA_PSK_WITH_CAMELLIA_256_CBC_SHA384'
                } else if (!connectionPrimitives.some(entry => entry === 'HMAC_SHA2_384')) {
                    // (263 391 515 640)
                    cipherSuite = 'TLS_RSA_PSK_WITH_CAMELLIA_256_GCM_SHA384'

                    connectionPrimitives.push('HMAC_SHA2_384')

                    protocolVariant = tls12
                }
            } else if (connectionPrimitives.some(entry => entry === 'CAMELLIA_128')) {
                if (connectionPrimitives.some(entry => entry === 'HMAC_SHA2_256')) {
                    // (263 391 519 643)
                    cipherSuite = 'TLS_RSA_PSK_WITH_CAMELLIA_128_CBC_SHA256'
                } else {
                    // (263 391 519 640)
                    cipherSuite = 'TLS_RSA_PSK_WITH_CAMELLIA_128_GCM_SHA256'

                    connectionPrimitives.push('HMAC_SHA2_256')

                    protocolVariant = tls12
                }
            } else if (connectionPrimitives.some(entry => entry === 'CHACHA')) {
                // (263 391 533 640)
                cipherSuite = 'TLS_RSA_PSK_WITH_CHACHA20_POLY1305_SHA256'

                if (!connectionPrimitives.some(entry => entry === 'HMAC_SHA2_256')) {
                    connectionPrimitives.push('HMAC_SHA2_256')
                }

                protocolVariant = tls12
            }
        }
    } else

    // RSA-Export for key exchange
    if (connectionPrimitives.some(entry => entry === 'RSA_EXPORT')) {
        // RSA-Export for authentication.
        if (connectionPrimitives.some(entry => entry === 'RSA_EXPORT')) {
            if (connectionPrimitives.some(entry => entry === 'RC4_40')) {
                if (connectionPrimitives.some(entry => entry === 'HMAC_MD5_LT_128')) {
                    // (270 394 527 644)
                    cipherSuite = 'TLS_RSA_EXPORT_WITH_RC4_40_MD5'
                }
            } else if (connectionPrimitives.some(entry => entry === 'RC2_40')) {
                if (connectionPrimitives.some(entry => entry === 'HMAC_MD5_LT_128')) {
                    // (270 394 526 644)
                    cipherSuite = 'TLS_RSA_EXPORT_WITH_RC2_CBC_40_MD5'
                }
            } else if (connectionPrimitives.some(entry => entry === 'DES_40')) {
                if (connectionPrimitives.some(entry => entry === 'HMAC_SHA1_LT_160')) {
                    // (270 394 525 642)
                    cipherSuite = 'TLS_RSA_EXPORT_WITH_DES40_CBC_SHA'
                }
            }
        }
    } else

    // SRP for key exchange
    if (connectionPrimitives.some(entry => entry === 'SRP')) {

        // No server certs for authentication.
        if (connectionPrimitives.some(entry => entry === 'NULL_SIG')) {
            if (connectionPrimitives.some(entry => entry === 'TDES')) {
                if (connectionPrimitives.some(entry => entry === 'HMAC_SHA1_LT_160')) {
                    // (257 389 522 642)
                    cipherSuite = 'TLS_SRP_SHA_WITH_3DES_EDE_CBC_SHA'
                }
            } else if (connectionPrimitives.some(entry => entry === 'AES_128')) {
                if (connectionPrimitives.some(entry => entry === 'HMAC_SHA1_LT_160')) {
                    // (257 389 517 642)
                    cipherSuite = 'TLS_SRP_SHA_WITH_AES_128_CBC_SHA'
                }
            } else if (connectionPrimitives.some(entry => entry === 'AES_256')) {
                if (connectionPrimitives.some(entry => entry === 'HMAC_SHA1_LT_160')) {
                    // (257 389 514 642)
                    cipherSuite = 'TLS_SRP_SHA_WITH_AES_256_CBC_SHA'
                }
            }
        } else

        // RSA for authentication.
        if (connectionPrimitives.some(entry => entry === 'RSA_SIG')) {
            if (connectionPrimitives.some(entry => entry === 'TDES')) {
                if (connectionPrimitives.some(entry => entry === 'HMAC_SHA1_LT_160')) {
                    // (257 384 522 642)
                    cipherSuite = 'TLS_SRP_SHA_RSA_WITH_3DES_EDE_CBC_SHA'
                }
            } else if (connectionPrimitives.some(entry => entry === 'AES_128')) {
                if (connectionPrimitives.some(entry => entry === 'HMAC_SHA1_LT_160')) {
                    // (257 384 517 642)
                    cipherSuite = 'TLS_SRP_SHA_RSA_WITH_AES_128_CBC_SHA'
                }
            } else if (connectionPrimitives.some(entry => entry === 'AES_256')) {
                if (connectionPrimitives.some(entry => entry === 'HMAC_SHA1_LT_160')) {
                    // (257 384 514 642)
                    cipherSuite = 'TLS_SRP_SHA_RSA_WITH_AES_256_CBC_SHA'
                }
            }
        } else

        // DSS for authentication.
        if (connectionPrimitives.some(entry => entry === 'DSA')) {
            if (connectionPrimitives.some(entry => entry === 'TDES')) {
                if (connectionPrimitives.some(entry => entry === 'HMAC_SHA1_LT_160')) {
                    // (257 386 522 642)
                    cipherSuite = 'TLS_SRP_SHA_DSS_WITH_3DES_EDE_CBC_SHA'
                }
            } else if (connectionPrimitives.some(entry => entry === 'AES_128')) {
                if (connectionPrimitives.some(entry => entry === 'HMAC_SHA1_LT_160')) {
                    // (257 386 517 642)
                    cipherSuite = 'TLS_SRP_SHA_DSS_WITH_AES_128_CBC_SHA'
                }
            } else if (connectionPrimitives.some(entry => entry === 'AES_256')) {
                if (connectionPrimitives.some(entry => entry === 'HMAC_SHA1_LT_160')) {
                    // (257 386 514 642)
                    cipherSuite = 'TLS_SRP_SHA_DSS_WITH_AES_256_CBC_SHA'
                }
            }
        }
    } else

    // PSK for key exchange
    if (connectionPrimitives.some(entry => entry === 'PSK_KE')) {

        // PSK for authentication. The following cipher suites use PSK for
        // both key exchange and authentication.
        if (connectionPrimitives.some(entry => entry === 'PSK_AUTH')) {
            if (connectionPrimitives.some(entry => entry === 'NULL_ENC')) {
                if (connectionPrimitives.some(entry => entry === 'HMAC_SHA2_384')) {
                    // (264 391 523 641)
                    cipherSuite = 'TLS_PSK_WITH_NULL_SHA384'
                } else if (connectionPrimitives.some(entry => entry === 'HMAC_SHA1_LT_160')) {
                    // (264 391 523 642)
                    cipherSuite = 'TLS_PSK_WITH_NULL_SHA'
                } else if (connectionPrimitives.some(entry => entry === 'HMAC_SHA2_256')) {
                    // (264 391 523 643)
                    cipherSuite = 'TLS_PSK_WITH_NULL_SHA256'
                }
            } else if (connectionPrimitives.some(entry => entry === 'RC4_128')) {
                if (connectionPrimitives.some(entry => entry === 'HMAC_SHA1_LT_160')) {
                    // (264 391 521 642)
                    cipherSuite = 'TLS_PSK_WITH_RC4_128_SHA'
                }
            } else if (connectionPrimitives.some(entry => entry === 'TDES')) {
                if (connectionPrimitives.some(entry => entry === 'HMAC_SHA1_LT_160')) {
                    // (264 391 522 642)
                    cipherSuite = 'TLS_PSK_WITH_3DES_EDE_CBC_SHA'
                }
            } else if (connectionPrimitives.some(entry => entry === 'AES_128')) {
                if (connectionPrimitives.some(entry => entry === 'HMAC_SHA2_256')) {
                    // (264 391 517 643)
                    cipherSuite = 'TLS_PSK_WITH_AES_128_CBC_SHA256'
                } else if (connectionPrimitives.some(entry => entry === 'HMAC_SHA1_LT_160')) {
                    // (264 391 517 642)
                    cipherSuite = 'TLS_PSK_WITH_AES_128_CBC_SHA'
                }
            } else if (connectionPrimitives.some(entry => entry === 'AES_256')) {
                if (connectionPrimitives.some(entry => entry === 'HMAC_SHA2_384')) {
                    // (264 391 514 641)
                    cipherSuite = 'TLS_PSK_WITH_AES_256_CBC_SHA384'
                } else if (connectionPrimitives.some(entry => entry === 'HMAC_SHA1_LT_160')) {
                    // (264 391 514 642)
                    cipherSuite = 'TLS_PSK_WITH_AES_256_CBC_SHA'
                }
            } else if (connectionPrimitives.some(entry => entry === 'AES_256_GCM')) {
                // (264 391 513 640)
                cipherSuite = 'TLS_PSK_WITH_AES_256_GCM_SHA384'

                if (!connectionPrimitives.some(entry => entry === 'HMAC_SHA2_384')) {
                    connectionPrimitives.push('HMAC_SHA2_384')
                }

                protocolVariant = tls12
            } else if (connectionPrimitives.some(entry => entry === 'AES_128_GCM')) {
                // (264 391 516 640)
                cipherSuite = 'TLS_PSK_WITH_AES_128_GCM_SHA256'

                if (!connectionPrimitives.some(entry => entry === 'HMAC_SHA2_256')) {
                    connectionPrimitives.push('HMAC_SHA2_256')
                }

                protocolVariant = tls12
            } else if (connectionPrimitives.some(entry => entry === 'AES_256_CCM')) {
                // (264 391 536 640)
                cipherSuite = 'TLS_PSK_WITH_AES_256_CCM'

                if (!connectionPrimitives.some(entry => entry === 'HMAC_SHA2_256')) {
                    connectionPrimitives.push('HMAC_SHA2_256')
                }

                protocolVariant = tls12
            } else if (connectionPrimitives.some(entry => entry === 'AES_128_CCM')) {
                // (264 391 535 640)
                cipherSuite = 'TLS_PSK_WITH_AES_128_CCM'

                if (!connectionPrimitives.some(entry => entry === 'HMAC_SHA2_256')) {
                    connectionPrimitives.push('HMAC_SHA2_256')
                }

                protocolVariant = tls12
            } else if (connectionPrimitives.some(entry => entry === 'AES_256_CCM_8')) {
                // (264 391 538 640)
                cipherSuite = 'TLS_PSK_WITH_AES_256_CCM_8'

                if (!connectionPrimitives.some(entry => entry === 'HMAC_SHA2_256')) {
                    connectionPrimitives.push('HMAC_SHA2_256')
                }

                protocolVariant = tls12
            } else if (connectionPrimitives.some(entry => entry === 'AES_128_CCM_8')) {
                // (264 391 537 640)
                cipherSuite = 'TLS_PSK_WITH_AES_128_CCM_8'

                if (!connectionPrimitives.some(entry => entry === 'HMAC_SHA2_256')) {
                    connectionPrimitives.push('HMAC_SHA2_256')
                }

                protocolVariant = tls12
            } else if (connectionPrimitives.some(entry => entry === 'CAMELLIA_256')) {
                if (connectionPrimitives.some(entry => entry === 'HMAC_SHA2_384')) {
                    // (264 391 515 641)
                    cipherSuite = 'TLS_PSK_WITH_CAMELLIA_256_CBC_SHA384'
                } else {
                    // (264 391 515 640)
                    cipherSuite = 'TLS_PSK_WITH_CAMELLIA_256_GCM_SHA384'

                    connectionPrimitives.push('HMAC_SHA2_384')

                    protocolVariant = tls12
                }
            } else if (connectionPrimitives.some(entry => entry === 'CAMELLIA_128')) {
                if (connectionPrimitives.some(entry => entry === 'HMAC_SHA2_256')) {
                    // (264 391 519 643)
                    cipherSuite = 'TLS_PSK_WITH_CAMELLIA_128_CBC_SHA256'
                } else {
                    // (264 391 519 640)
                    cipherSuite = 'TLS_PSK_WITH_CAMELLIA_128_GCM_SHA256'

                    connectionPrimitives.push('HMAC_SHA2_256')

                    protocolVariant = tls12
                }
            } else if (connectionPrimitives.some(entry => entry === 'CHACHA')) {
                // (264 391 533 640)
                cipherSuite = 'TLS_PSK_WITH_CHACHA20_POLY1305_SHA256'

                if (!connectionPrimitives.some(entry => entry === 'HMAC_SHA2_256')) {
                    connectionPrimitives.push('HMAC_SHA2_256')
                }

                protocolVariant = tls12
            }
        }
    } else

    // Fortezza based cipher suites.
    // TODO: GAP1908 - we may need to change a few things on Fortezza.
    if (connectionPrimitives.some(entry => entry === 'FORTEZZA')) {
        // KEA for authentication. (Actually FORTEZZA_KEA is an integral thing,
        // but we separated them out and it happens to match NetScout's
        // categorization.)
        if (connectionPrimitives.some(entry => entry === 'KEA')) {
            if (connectionPrimitives.some(entry => entry === 'HMAC_SHA1_LT_160')) {
                if (connectionPrimitives.some(entry => entry === 'NULL_ENC')) {
                    // (267 397 523 642)
                    cipherSuite = 'SSL_FORTEZZA_KEA_WITH_NULL_SHA'

                    // For Fortezza cipher suites, we know they're SSL 3.0 only.
                    protocolVariant = ssl3
                } else if (connectionPrimitives.some(entry => entry === 'FORTEZZA_CBC')) {
                    // (267 397 529 642)
                    cipherSuite = 'SSL_FORTEZZA_KEA_WITH_FORTEZZA_CBC_SHA'

                    // For Fortezza cipher suites, we know they're SSL 3.0 only.
                    protocolVariant = ssl3
                }
            }
        }
    } else

    // KRB5 based cipher suites.
    if (connectionPrimitives.some(entry => entry === 'KRB5')) {
        if (connectionPrimitives.some(entry => entry === 'HMAC_SHA1_LT_160')) {
            if (connectionPrimitives.some(entry => entry === 'DES_56')) {
                // (268 392 524 642)
                cipherSuite = 'TLS_KRB5_WITH_DES_CBC_SHA'
            } else if (connectionPrimitives.some(entry => entry === 'TDES')) {
                // (268 392 522 642)
                cipherSuite = 'TLS_KRB5_WITH_3DES_EDE_CBC_SHA'
            } else if (connectionPrimitives.some(entry => entry === 'RC4_128')) {
                // (268 392 521 642)
                cipherSuite = 'TLS_KRB5_WITH_RC4_128_SHA'
            } else if (connectionPrimitives.some(entry => entry === 'IDEA')) {
                // (268 392 520 642)
                cipherSuite = 'TLS_KRB5_WITH_IDEA_CBC_SHA'
            }
        } else if (connectionPrimitives.some(entry => entry === 'HMAC_MD5_LT_128')) {
            if (connectionPrimitives.some(entry => entry === 'DES_56')) {
                // (268 392 524 644)
                cipherSuite = 'TLS_KRB5_WITH_DES_CBC_MD5'
            } else if (connectionPrimitives.some(entry => entry === 'TDES')) {
                // (268 392 522 644)
                cipherSuite = 'TLS_KRB5_WITH_3DES_EDE_CBC_MD5'
            } else if (connectionPrimitives.some(entry => entry === 'RC4_128')) {
                // (268 392 521 644)
                cipherSuite = 'TLS_KRB5_WITH_RC4_128_MD5'
            } else if (connectionPrimitives.some(entry => entry === 'IDEA')) {
                // (268 392 520 644)
                cipherSuite = 'TLS_KRB5_WITH_IDEA_CBC_MD5'
            }
        }
    } else

    // KRB5-Export based cipher suites.
    if (connectionPrimitives.some(entry => entry === 'KRB5_EXPORT')) {
        if (connectionPrimitives.some(entry => entry === 'HMAC_SHA1_LT_160')) {
            if (connectionPrimitives.some(entry => entry === 'DES_40')) {
                // (269 393 525 642)
                cipherSuite = 'TLS_KRB5_EXPORT_WITH_DES_CBC_40_SHA'
            } else if (connectionPrimitives.some(entry => entry === 'RC2_40')) {
                // (269 393 526 642)
                cipherSuite = 'TLS_KRB5_EXPORT_WITH_RC2_CBC_40_SHA'
            } else if (connectionPrimitives.some(entry => entry === 'RC4_40')) {
                // (269 393 527 642)
                cipherSuite = 'TLS_KRB5_EXPORT_WITH_RC4_40_SHA'
            }
        } else if (connectionPrimitives.some(entry => entry === 'HMAC_MD5_LT_128')) {
            if (connectionPrimitives.some(entry => entry === 'DES_40')) {
                // (269 393 525 644)
                cipherSuite = 'TLS_KRB5_EXPORT_WITH_DES_CBC_40_MD5'
            } else if (connectionPrimitives.some(entry => entry === 'RC2_40')) {
                // (269 393 526 644)
                cipherSuite = 'TLS_KRB5_EXPORT_WITH_RC2_CBC_40_MD5'
            } else if (connectionPrimitives.some(entry => entry === 'RC4_40')) {
                // (269 393 527 644)
                cipherSuite = 'TLS_KRB5_EXPORT_WITH_RC4_40_MD5'
            }
        }
    } else

    // NULL cipher suite.
    if (connectionPrimitives.some(entry => entry === 'NULL_KE')) {
        if (connectionPrimitives.some(entry => entry === 'NULL_SIG')) {
            if (connectionPrimitives.some(entry => entry === 'NULL_ENC')) {
                if (connectionPrimitives.some(entry => entry === 'NULL_MAC')) {
                    // (273 389 523 645)
                    cipherSuite = 'TLS_NULL_WITH_NULL_NULL'
                }
            }
        }
    }

    return {
        cipherSuite,
        protocolVariant,
    }
}

module.exports = {
    getKeyExchangePrimitive,
    getAuthenticationPrimitive,
    getEncryptionPrimitive,
    getMACPrimitive,
    calculateCipherSuiteAndPrimitives
}
