/**
 * @file cns.js - 0.0.1045 - ea4595bfd3488684d225574ed7d4c198074d49ba
 * 
 * @copyright Copyright (C) 2016-2023, ISARA Corporation, All Rights Reserved.
 * 
 * @license The code and other content set out herein is not in the public
 * domain, is considered a trade secret and is confidential to ISARA
 * Corporation. Use, reproduction or distribution, in whole or in part, of such
 * code or other content is strictly prohibited except by express written
 * permission of ISARA Corporation. Please contact ISARA Corporation at
 * info@isara.com for more information.
 */

/**
 * This module defines the ISARA Cryptographic Network Sensor
 * Ingestion Endpoint.
 * @module express/cns
 */

const StreamZip = require('node-stream-zip')
const multer = require('multer')
const os = require('os')
const path = require('path')
const fse = require('fs-extra')

const log = require('../util/log')(module)
const { roles } = require('../graphql/commonQL')
const { selectByLooks } = require('../ingestion/commonIngestion')
const ingestionJob = require('../ingestion/ingestionJob')
const { createUpdateDelete } = require('../isaraql/cud')
const { insertRecord } = require('../isaraql/fetch')
const { allTypes } = require('../isaraql/schemaDiscovery')
const { Session } = require('../isaraql/session')
const { getRequestState } = require('../util/requestState')
const {
    CNS_SOFTWARE_NAME,
    CNS_SOFTWARE_VERSION_NAME,
    CNS_SOFTWARE_VENDOR
} = require('../graphql/dataSourcesQL')
const { StreamStatusTracker, TOKEN_HEADER_NAME } = require('../ingestion/streaming/streamTokens')

let tracker = new StreamStatusTracker('CNS Upload')

async function startBackgroundTasks() {
    try {
        await tracker.init()
    } catch (e) {
        log.e('Failed to start CNS background tasks', e)
    }
}

async function findOrCreateDataSource(session) {
    let software = (await selectByLooks('Software', { name: CNS_SOFTWARE_NAME, softwareVendor: CNS_SOFTWARE_VENDOR }, session))[0]
    let softwareVersion = (await selectByLooks('SoftwareVersion', { name: CNS_SOFTWARE_VERSION_NAME, software: software.id }, session))[0]
    let dataSource = (await selectByLooks('DataSource', { softwareVersion: softwareVersion.id }, session))[0]

    if (!dataSource) {
        let now = new Date()
        let entryToInsert = {
            friendlyName: CNS_SOFTWARE_VERSION_NAME,
            configuration: '{}',
            softwareVersion: softwareVersion.id,
            addedBy: getRequestState()?.user?.uid,
            addedAt: now,
            status: allTypes['DataSourceStatus']._enum.idByName['ENABLED'],
            lastModified: now,
        }

        dataSource = await insertRecord('DataSource', entryToInsert, session)
    }

    return dataSource
}

async function createDataSourceScan(session, zipFile, dataDir, tagText, dataSource) {
    const now = new Date()

    let entryToInsert = {
        friendlyName: `${CNS_SOFTWARE_VERSION_NAME} '${zipFile}'`,
        dataSource: { id: dataSource.id },
        metadata: JSON.stringify({ dataDir }),
        configuration: JSON.stringify({ zipFile }),
        lastModified: now,
        scanCount: 0,
        addedAt: now,
    }

    if (tagText) {
        entryToInsert.dataSourceScanTags = [{ tag: { value: tagText, tagType: allTypes['TagType']._enum.idByName['CUSTOM'] } }]
    }

    let config = {
        allowInsert: true,
        populateIDs: true,
        modifiableTables: {
            DataSourceScan: true,
            DataSourceScanTag: true,
            Tag: true,
        },
        checkExistingTables: {
            DataSource: true,
            Tag: true,
            User: true,
        },
        session,
    }

    await createUpdateDelete('DataSourceScan', [entryToInsert], config)

    return entryToInsert
}

/**
 * Use disk storage engine to define upload destination and file name.
 */
let storage = multer.diskStorage({
    /*
     * Upload the zip file into the OS tmp dir.
     */
    destination: function (request, file, cb) {
        let uploadDir = path.join(os.tmpdir(), 'cns')
        fse.ensureDirSync(uploadDir)
        cb(null, uploadDir)
    },

    /*
     * Add timestamp to the uploaded zip file.
     */
    filename: function (request, file, cb) {
        cb(null, file.originalname.toLowerCase().replace('.zip', '_' + Date.now() + '.zip'))
    }
})

/**
 * Prevent non-zip files from being uploaded.
 */
function fileFilter(request, file, cb) {
    if (file.originalname.toLowerCase().endsWith('.zip')) {
        cb(null, true)
    } else {
        cb(null, false)
    }
}

let upload = multer({ storage: storage, fileFilter: fileFilter })

/**
 * Exposes the CNS POST Endpoint for file uploading.
 *
 * The file being uploaded must be a zip of the CNS output dir.
 *
 * Example usage (for token based user):
 *  curl -H "x-isara-advance-auth: l5udS552h+CwzhFYJtjHENWas3uKN575zNsp0lLm2zs=" -k -F "cns=@ncpat-500k-data-allcert.zip" https://advance/service/ingestion/cns
 * 
 * Example usage (for currently authenticated user):
 *  curl -H "authorization:Bearer [TOKEN]" -F 'cns=@/path/to/filename.zip' http://localhost:4000/service/ingestion/cns
 * 
 *  (On Windows, use curl.exe from PowerShell, not curl)
 * 
 */
exports.endpoint = {
    path: '/service/ingestion/cns',
    post: {
        middleware: upload.single('cns'),
        handler: async (request, response) => {
            const usingTracker = TOKEN_HEADER_NAME in request.headers
            let trackerGood = false         
            try {
                /*
                * For any non-zip file removed by the filter, request.file should
                * be undefined.
                */
                if (request.file == undefined) {
                    response.status(400).send('Invalid file input.')
                    return
                }

                /*
                * Decompress the zip file.
                */
                let unzipPath = path.join(os.tmpdir(), 'cns', path.parse(request.file.filename).name)
                fse.ensureDirSync(unzipPath)
                const zipFile = new StreamZip.async({ file: request.file.path })
                const numEntries = await zipFile.extract(null, unzipPath)
                log.log(`CNS Upload - Uploaded ${numEntries} entries`)
                await zipFile.close()

                /*
                * At this point, CNS artifacts have been uploaded and extracted.
                * Kick off ingestion.
                */
                let session = new Session()
                let dataSource = await findOrCreateDataSource(session)
                let dataSourceScan = await createDataSourceScan(session, request.file.path, unzipPath, request.query.tag, dataSource)
                await ingestionJob.runDataSourceScan(dataSourceScan.id)

                response.sendStatus(202)

                trackerGood = true
            } catch (error) {
                response.status(500).send(error)
                log.e('Error attempting to process CNS upload', error)
                throw error
            } finally {
                if (usingTracker) tracker.bump(trackerGood)
            }
        },
        notAuthenticated: () => {
            // This is called when a request comes in which is not authenticated
            tracker.bump(false)
        },
        restrictions: [roles.AUTHENTICATED, roles.TOKEN]
    },
}

exports.findOrCreateDataSource = findOrCreateDataSource
exports.createDataSourceScan = createDataSourceScan
exports.startBackgroundTasks = startBackgroundTasks