/**
 * @file heapMonitor.js - 0.0.1045 - ea4595bfd3488684d225574ed7d4c198074d49ba
 * 
 * @copyright Copyright (C) 2016-2023, ISARA Corporation, All Rights Reserved.
 * 
 * @license The code and other content set out herein is not in the public
 * domain, is considered a trade secret and is confidential to ISARA
 * Corporation. Use, reproduction or distribution, in whole or in part, of such
 * code or other content is strictly prohibited except by express written
 * permission of ISARA Corporation. Please contact ISARA Corporation at
 * info@isara.com for more information.
 */

const log = require('./log')(module)

let converters = [[Math.pow(10, 12), 'T'], [Math.pow(10, 9), 'G'], [Math.pow(10, 6), 'M'], [Math.pow(10, 3), 'k']]

function convert(value) {
    for (let converter of converters) {
        if (value >= converter[0]) {
            return `${(value / converter[0]).toFixed(3)}${converter[1]}`
        }
    }
    return `${value.toFixed(3)}`
}

class HeapMonitor {
    #lastUsed = -1
    #minUsed = -1
    #maxUsed = -1

    #interval

    #chunkSize = 10000
    #iteration = -1
    #samplesBeforePrint = 40

    constructor(sampleIntervalMS = 250, samplesBeforePrint = 120, chunkSize = 5 * Math.pow(10, 6)) {
        this.#chunkSize = chunkSize > 10000 ? chunkSize : 10000
        this.#interval = setInterval(() => {
            this.check()
        }, sampleIntervalMS)
        this.#samplesBeforePrint = samplesBeforePrint
        this.check()
    }

    check() {
        const usage = process.memoryUsage()
        if (this.#lastUsed === -1) {
            this.#minUsed = this.#maxUsed = this.#lastUsed = usage.heapUsed
        }

        this.#minUsed = Math.min(this.#minUsed, usage.heapUsed)
        this.#maxUsed = Math.max(this.#maxUsed, usage.heapUsed)

        const delta = usage.heapUsed - this.#lastUsed

        if (delta > this.#chunkSize) {
            log.log('Heap just grew over', convert(this.#chunkSize), `${convert(this.#lastUsed)}->${convert(usage.heapUsed)}`)
            // Only capture last used when something logged.
            this.#lastUsed = usage.heapUsed
        }
        ++this.#iteration
        if (this.#iteration % this.#samplesBeforePrint == 0) {
            // Only capture last used when something logged.
            this.#lastUsed = usage.heapUsed
            const toPrint = {...usage}
            for (let key in toPrint) {
                if (key) {
                    toPrint[key] = convert(toPrint[key])
                }
            }
            log.log('Heap stats:', JSON.stringify(toPrint))
        }
    }

    stop() {
        clearInterval(this.#interval)
        log.log('Heap Monitor (min,last,max):', convert(this.#minUsed), convert(this.#lastUsed), convert(this.#maxUsed))
    }
}

exports.HeapMonitor = HeapMonitor