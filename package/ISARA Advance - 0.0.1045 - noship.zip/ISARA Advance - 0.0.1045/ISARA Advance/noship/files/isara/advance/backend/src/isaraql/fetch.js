/**
 * @file fetch.js - 0.0.1045 - ea4595bfd3488684d225574ed7d4c198074d49ba
 * 
 * @copyright Copyright (C) 2016-2023, ISARA Corporation, All Rights Reserved.
 * 
 * @license The code and other content set out herein is not in the public
 * domain, is considered a trade secret and is confidential to ISARA
 * Corporation. Use, reproduction or distribution, in whole or in part, of such
 * code or other content is strictly prohibited except by express written
 * permission of ISARA Corporation. Please contact ISARA Corporation at
 * info@isara.com for more information.
 */

/**
 * Code intended to fetch records from the database.
 * @module isaraql/fetch
 */

const { Session } = require('./session')

/**
 * Functions to perform schema discovery
 */
const schemaDiscovery = require('./schemaDiscovery')
const { uniqBy } = require('lodash')

const FK_OUTBOUND = schemaDiscovery.FK_OUTBOUND
const FK_INBOUND = schemaDiscovery.FK_INBOUND

/**
 * Constant indicating a reference to the 'parent' record.
 */
const FK_PARENT = 'parent'

/**
 * Import logger.
 */
const log = require('../util/log')(module)

const fetchHooks = {}

/**
 * Class holding attributes useful for recursive row retrieval.
 * @property {boolean} ignore Indicates if inserting records should report failure on key violations.
 * @property {object} connection Tracks the connection being used, if in a transaction.
 * @property {object} pool A reference to the database pool.
*/

/**
 * This class holds an SQL operation for update or insert on a field. To be supplied for cases
 * when server-side operations are desired on update rather than an explicit value, i.e. column = column + value
 */
class SQLUpdateOp {
    constructor(op, value, defaultValue) {
        // TODO: GAP1605 - possibly make op an enum? May limit flexibility though.
        this.op = op
        this.value = value
        this.defaultValue = defaultValue
    }
}

exports.SQLUpdateOp = SQLUpdateOp

/**
 * This class holds SQL fragments needed to do a sort based on connected tables.
 */
class AdvancedSort {
    constructor(joins, groups, orderBys, params) {
        this.joins = Array.isArray(joins) ? joins : [joins]
        this.groups = Array.isArray(groups) ? groups : [groups]
        this.orderBys = Array.isArray(orderBys) ? orderBys : [orderBys]
        this.params = Array.isArray(params) ? [...params] : params ? [params] : []
    }
}
exports.AdvancedSort = AdvancedSort

const OPERATION_INSERT = 'insert'
const OPERATION_UPDATE = 'update'

exports.OPERATION_INSERT = OPERATION_INSERT
exports.OPERATION_UPDATE = OPERATION_UPDATE

/**
 * Take an object describing the fields wanted from the database, and return
 * a new object containing these fields and all of the required meta data for
 * fetchWanted to use the structure.
 *
 * Example call: buildWanted('User', { userName: true, userRoles: { role: { name: true }}})
 *
 * @param {string} table The name of the table to build the wanted structure for.
 * @param {object} wanted A simple structure describing which fields are wanted from the database.
 *
 * @return {object} A wanted structure suitable for passing to fetchWanted.
 */
async function buildWanted(table, wanted) {
    var type
    if (!(type = schemaDiscovery.allTypes[table])) {
        throw `Unknown table ${table}`
    }
    var toReturn = Object.assign({}, wanted)

    if (!toReturn._joins) {
        toReturn._joins = []
    }

    for (var field in wanted) {
        if (field.startsWith('_')) {
            continue
        }
        if (!type[field]) {
            throw `Unexpected field ${field} in table ${table}`
        }
        if (type._meta[field]) {
            var relationShip = type._meta[field]
            toReturn._joins.push({ name: field, meta: relationShip })
            toReturn[field] = await buildWanted(type._meta[field].table, wanted[field])
            if (relationShip.dir === FK_INBOUND) {
                var parentJoin = {}
                Object.assign(parentJoin, relationShip)
                parentJoin.dir = FK_PARENT
                toReturn[field]._joins.push({
                    name: relationShip.column,
                    meta: parentJoin
                })
            }
        }
    }

    return toReturn
}
exports.buildWanted = buildWanted

/**
 * Add required join logic to wanted structure to allow retrieval of foreign keyed values.
 * @param {string} table The name of the table to start from.
 * @param {Object} wanted Multi level dictionary of fields that should be returned from the query.
 * @returns `undefined`
 */
function addJoinsToWantedStructure(table, wanted) {
    if (wanted._joins) {
        return
    }
    var type = schemaDiscovery.allTypes[table]
    wanted._joins = []
    if (!type) {
        throw `Table ${table} not found`
    }
    for (var field in wanted) {
        if (field.startsWith('_')) {
            continue
        }
        if (type._meta[field] && wanted[field] !== true) {
            var relationShip = type._meta[field]
            wanted._joins.push({ name: field, meta: relationShip })
            addJoinsToWantedStructure(relationShip.table, wanted[field])
            if (relationShip.dir === FK_INBOUND) {
                var parentJoin = {}
                Object.assign(parentJoin, relationShip)
                parentJoin.dir = FK_PARENT
                wanted[field]._joins.push({
                    name: relationShip.column,
                    meta: parentJoin
                })
            }
        }
    }
}

/**
 * Generate a set of placeholders for an input array.
 *
 * Given an input array, generate an appropriate series of placeholders as a string. This is primarily intended for
 * substituting into a where clause using an IN () condition.
 *
 * @param {Array} params The set of parameters to generate placeholders for. Note that content is unimportant.
 * @param {Number} Optional offset to start the placeholder count
 * @returns {string} A positional placeholder string, e.g. $1,$2,$3.
 */
function generatePlaceholders(params, offset = 0) {
    let index = offset + 1
    return params.map(() => `$${index++}`).join(',')
}

exports.generatePlaceholders = generatePlaceholders


/**
 * paging mode constants for internal use by doFetchWanted. These are used to define behaviour for the generated queries, since
 * depending on the type of join, we may need to either ignore page constraints, or potentially apply a window function in order
 * to get the desired results if a fetch includes a paging clause for a joined table.
 */
let pagingModes = {
    IGNORE: 0,
    RESPECT: 1,
    WINDOW: 2
}

/**
 * Fetch all wanted fields for the given table.
 *
 * @param {string} table The name of the table to fetch from
 * @param {Object} wanted Hierarchy of attributes to fetch
 * @param {Object[]} wpcsArray Where Paging Counts Sorting - all are used, only the first is passed recursively.
 * @param {Session} [session] Session to use
 * @param {bool} [skipHooks] Skips fetch hooks if true.
 *
 * @return {object[]} of hierarchical data for the given table
 */
async function fetchWanted(table, wanted, wpcsArray, session, skipHooks) {
    if (session === undefined) {
        session = new Session()
    }

    return session.reuseConnection(async () => {
        return doFetchWanted(table, wanted, wpcsArray, session, pagingModes.RESPECT, null, skipHooks)
    })
}

exports.fetchWanted = fetchWanted

/**
 * Fetch all wanted fields for the given table.
 *
 * @param {string} table The name of the table to fetch from
 * @param {Object} wanted Hierarchy of attributes to fetch
 * @param {Object[]} wpcsArray Where Paging Counts Sorting - all are used, only the first is passed recursively.
 * @param {Session} [session] Session to use
 * @param {pagingModes} pagingMode The paging behaviour to use when generating the query.
 * @param {string} [pagingColumn] The column on which to partition the window when using windowed paging.
 */
async function doFetchWanted(table, wanted, wpcsArray, session, pagingMode, pagingColumn, skipHooks) {
    if (!wanted) {
        wanted = { id: true }
    }
    addJoinsToWantedStructure(table, wanted)
    if (!Array.isArray(wpcsArray)) {
        if (wpcsArray == null) {
            wpcsArray = [undefined]
        } else {
            wpcsArray = [wpcsArray]
        }
    }

    let type = schemaDiscovery.allTypes[table]
    if (type === undefined) {
        throw `Don't know type of table ${table}`
    }

    let columns = {}
    columns.id = 'id'
    let enumsToResolve = []

    for (let field of Object.keys(wanted)) {
        if (field.startsWith('_')) {
            continue
        }
        let value = wanted[field]
        if (value === true) {
            columns[field] = field
            if (field in type._meta && type._meta[field].dir === FK_OUTBOUND) {
                let outTable = type._meta[field].table
                let outTableType = schemaDiscovery.allTypes[outTable]
                if (outTableType._meta._isEnum) {
                    enumsToResolve.push({ field, table: outTableType })
                }
            }
        }
    }

    for (let join of wanted._joins) {
        let name = join.name
        let meta = join.meta
        if (meta.dir === FK_INBOUND) {
            // do nothing - we're already getting id
        } else if (meta.dir === FK_OUTBOUND || meta.dir === FK_PARENT) {
            columns[name] = `_${name}`
        }
    }

    let columnArray = []
    for (let column in columns) {
        columnArray.push(`"${table}"."${column}" as "${columns[column]}"`)
    }

    let tableList = [table]
    let joinClauses = []
    let groupClauses = []

    let where = []
    let queryParams = []
    let orderByList = []

    for (let wpcs of wpcsArray) {
        if (wpcs && wpcs[table] && wpcs[table].join) {
            let joinType = wpcs[table].join.type
            let joinColumn = wpcs[table].join.column

            let joinMeta = type._meta[joinColumn]

            if (!joinMeta) {
                throw `Column isn't a sensible join ${joinColumn}`
            }

            if (joinMeta.dir === FK_INBOUND) {
                // This means the other table has a column point at our ID.
                tableList.push(joinMeta.table)
                joinClauses.push(`${joinType} join "${joinMeta.table}" on "${table}".id = "${joinMeta.table}"."${joinMeta.column}"`)
            } else if (joinMeta.dir === FK_OUTBOUND) {
                tableList.push(joinMeta.table)
                joinClauses.push(`${joinType} join "${joinMeta.table}" on "${joinMeta.table}".id = "${table}"."${joinColumn}"`)
            } else {
                throw `Not implemented (yet)`
            }
        }
        if (wpcs && wpcs[table] && wpcs[table].sort && wpcs[table].sort instanceof AdvancedSort) {
            let sort = wpcs[table].sort
            sort.joins && joinClauses.push(...sort.joins)
            sort.params && queryParams.push(...sort.params)
            sort.groups && groupClauses.push(...sort.groups)
            sort.orderBys && orderByList.push(...sort.orderBys)
        }
    }

    let hasPagingWindow = false
    for (let wpcs of wpcsArray) {
        if (wpcs && wpcs[table] && wpcs[table].paging) {
            hasPagingWindow = true
        }
        for (var tableItem of tableList) {
            if (wpcs && wpcs[tableItem] && wpcs[tableItem].where) {
                var nextWhereClause = buildWhereClause(tableItem, wpcs[tableItem].where, queryParams)
                if (nextWhereClause != null) {
                    where.push(nextWhereClause)
                }
            }
        }
    }

    for (var wpcs of wpcsArray) {
        if (wpcs && wpcs[table] && wpcs[table].sort) {
            if (wpcs[table].sort instanceof AdvancedSort) {
                // do nothing
            } else {
                if (wpcs[table].sort instanceof Array) {
                    orderByList.push(...wpcs[table].sort)
                } else {
                    orderByList.push(wpcs[table].sort)
                }
            }
        }
    }
    if ('id' in type) {
        orderByList.push(`"${table}".id asc`)
    }

    let orderByClause
    if (orderByList.length > 0) {
        orderByList = orderByList.map((sort) => {
            if (sort.indexOf('"') < 0) {
                let elements = sort.split(' ')
                if (elements.length > 1) {
                    return `"${elements[0]}" ${elements[1]}`
                }
                return elements
            } else {
                return sort
            }
        })
        orderByClause = ` order by ${orderByList.join(',')} `
    }

    let selectStatement = `select ${columnArray.join(',')} `
    if (pagingMode === pagingModes.WINDOW && hasPagingWindow) {
        selectStatement += `, row_number() OVER (PARTITION by ${pagingColumn} `
        if (orderByClause !== undefined) {
            selectStatement += ` ${orderByClause})`
        } else {
            selectStatement += ` ORDER BY "${table}".id)`
        }
    }

    selectStatement += ` from "${table}" `

    if (joinClauses.length > 0) {
        selectStatement += ` ${joinClauses.join(' ')} `
    }

    if (where.length != 0) {
        selectStatement += ` where ${where.join('and')} `
    }

    if (groupClauses.length > 0) {
        selectStatement += `\n group by ${groupClauses.join(',\n')}\n`
    }

    if (wpcsArray[0] && table in wpcsArray[0] && ('count' in wpcsArray[0][table])) {
        let countField = wpcsArray[0][table].count
        let countStatement = `select count(*) as count from (${selectStatement}) as TableToCount`
        let countResult = await session.query(countStatement, queryParams)

        if (!Array.isArray(countField)) {
            countField = wpcsArray[0][table].count = []
        }

        countField.push(countResult.rows[0].count)
    }

    if (orderByClause !== undefined) {
        selectStatement += orderByClause
    }

    if (pagingMode !== pagingModes.IGNORE) {
        if (wpcsArray[0] &&
            (table in wpcsArray[0]) &&
            ('paging' in wpcsArray[0][table])) {
            let pagingTable = wpcsArray[0][table]
            let paging = Object.assign({}, pagingTable.paging)

            if (pagingMode === pagingModes.RESPECT) {
                if ('limit' in paging && 'offset' in paging) {
                    selectStatement += ` OFFSET ? LIMIT ?`
                    queryParams.push(paging.offset)
                    queryParams.push(paging.limit)

                    if (paging.limit === 0n) {
                        return []
                    }
                }
            } else if (pagingMode === pagingModes.WINDOW) {
                paging.offset += 1n
                selectStatement = `SELECT * from (${selectStatement}) t1 WHERE t1.row_number >= ? AND t1.row_number < ?`
                queryParams.push(paging.offset)
                queryParams.push(paging.offset + paging.limit)
            }
        }
    }

    let start
    if (log.debug) {
        start = new Date()
    }

    let result
    let tempTableName = await session.generateTempTable(`Fetch_${table}`, selectStatement, queryParams)
    // temp table creates do not return result rows, so we have to explicitly grab them afterwards.
    result = await session.query(`SELECT * FROM "${tempTableName}"`)

    if (log.debug) {
        let time = Math.abs(new Date() - start)
        log.d('Elapsed time for generated query :', selectStatement, `" ${time} msec, result: ${result.rowCount} rows`)
    }

    if (result.rowCount > 0) {

        // Fix enums
        if (enumsToResolve.length > 0) {
            for (var row of result.rows) {
                for (var enumToResolve of enumsToResolve) {
                    var field = enumToResolve.field
                    var currentValue = row[field]
                    row[field] = enumToResolve.table._enum.nameByID[currentValue]
                }
            }
        }

        for (var join of wanted._joins) {
            var name = join.name
            var meta = join.meta
            var joinTable = meta.table

            if (meta.dir === FK_INBOUND) {
                let resultTempTable = new TempTable(tempTableName, 'id')
                let whereForChild = { [joinTable]: { where: { in: { column: meta.column, value: resultTempTable } } } }

                let effectiveColumnName = `_${meta.column}`

                let subWPCSArray = [Object.assign({}, wpcsArray[0]), whereForChild]
                delete subWPCSArray[0][table]
                let linked = await doFetchWanted(meta.table, wanted[name], subWPCSArray, session, pagingModes.WINDOW, `"${joinTable}"."${meta.column}"`, skipHooks)
                let linkedByFor = {}
                linked.forEach(row => {
                    let key = row[effectiveColumnName]
                    if (!(key in linkedByFor)) {
                        linkedByFor[key] = []
                    }
                    linkedByFor[key].push(row)
                    delete row[effectiveColumnName]
                })

                result.rows.forEach(row => {
                    let id = row.id
                    if (id in linkedByFor) {
                        row[name] = linkedByFor[id]
                    } else {
                        row[name] = []
                    }
                })


            } else if (meta.dir === FK_OUTBOUND) {
                let usedName = `_${name}`
                let resultTempTable = new TempTable(tempTableName, usedName)

                let subWPCSArray = [wpcsArray[0]]
                subWPCSArray.push({ [meta.table]: { where: { in: { column: 'id', value: resultTempTable } } } })

                let linked = await doFetchWanted(meta.table, wanted[name], subWPCSArray, session, pagingModes.IGNORE, null, skipHooks)
                let linkedByID = {}
                linked.forEach(row => linkedByID[row.id] = row)
                result.rows.forEach(row => {
                    row[name] = linkedByID[row[usedName]]
                })
            }
        }
    }
    await convertBuffersToStrings(result.rows)

    if (skipHooks !== true && fetchHooks[table]) {
        for (let row of result.rows) {
            for (let hook of fetchHooks[table]) {
                await hook(row, session)
            }
        }
    }

    return result.rows
}

/**
 * Convert any (shallow) attributes of any object in the array from ByteBuffers to strings.
 *
 * @param {Object[]} array Array of objects
 */
async function convertBuffersToStrings(array) {
    for (var item of array) {
        for (var fieldName of Object.keys(item)) {
            var value = item[fieldName]
            if (value === null) {
                continue
            }
            var valueType = typeof (value)

            // Convert Buffers to strings for the return.
            if (valueType === 'object' && 'byteLength' in value) {
                item[fieldName] = value.toString()
            }
        }
    }

}

/**
 * Fetch records with the given column names.
 * @param {string} table The table to fetch records from
 * @param {string[]} [columns] The columns in the table that are wanted. If empty, all columns are returned.
 * @param {Object} wpcs Where, Paging, Count and Sorting for the query
 * @param {Session} [session] Database session.
 */
exports.fetchForColumns = async function fetchForColumns(table, columns, wpcs, session) {
    try {
        var wanted = {}
        if (!columns) {
            for (var column in schemaDiscovery.allTypes[table]) {
                if (!column.startsWith('_')) {
                    wanted[column] = true
                }
            }
        } else for (column of columns) {
            wanted[column] = true
        }
        return await fetchWanted(table, wanted, wpcs, session)
    } catch (e) {
        log.d('Failed in fetchForColumns', e)
        throw e
    }
}

var operators = {
    equals: ' = ',
    ne: ' != ',
    lte: ' <= ',
    gte: ' >= ',
    lt: ' < ',
    gt: ' > ',
    like: ' ilike '
}

/**
 *
 */
class TempTable {
    constructor(table, column) {
        this._table = table
        this._column = column
    }

    get table() { return this._table }
    get column() { return this._column }
}

exports.TempTable = TempTable

/**
 *
 */
class QueryAndParams {
    constructor(query, params) {
        if (typeof (query) !== 'string' || (typeof (params) !== 'object' && !Array.isArray(params))) {
            throw 'Expect string and array'
        }
        this._query = query
        this._params = params
    }

    get query() { return this._query }
    get params() { return this._params }
}
exports.QueryAndParams = QueryAndParams

/**
 * Build a where clause and place matching params into the provided array.
 * @param {string} table The table name the where will apply to. Used for field conversions.
 * @param {object} where
 * @param {Any[]} params
 * @returns {string} An SQL where clause.
 */
function buildWhereClause(table, where, params) {
    if ('and' in where || 'or' in where) {
        if ('or' in where && 'and' in where) {
            throw 'where has or and and'
        }
        var logicOp
        if ('or' in where) {
            logicOp = 'or'
        } else {
            logicOp = 'and'
        }
        var clause = where[logicOp].map(subWhere => buildWhereClause(table, subWhere, params)).filter(any => any).join(` ${logicOp} `)
        if (clause !== '') {
            clause = ` ( ${clause} ) `
        } else {
            clause = null
        }
        return clause
    } else if ('in' in where) {
        var theIn = where.in
        var theValue = theIn.value
        var subClause = ''
        if (theValue instanceof QueryAndParams) {
            subClause = theValue.query
            theValue.params.forEach(param => params.push(param))
        } else if (theValue instanceof TempTable) {
            subClause = `SELECT "${theValue.column}" FROM "${theValue.table}"`
        } else {
            if (!Array.isArray(theValue)) {
                theValue = Array.from(theValue)
            }

            // don't generate an empty IN clause.
            if (theValue.length == 0) {
                throw "Invalid wpcs with empty 'in' clause."
            }
            subClause = theValue.map(() => `?`).join(',')
            params.push(...theValue)
        }
        clause = ` "${table}"."${theIn.column}" in (${subClause}) `
        return clause
    } else if ('not' in where) {
        return ` not ( ${buildWhereClause(table, where.not, params)} )`
    }
    for (var operator in operators) {
        if (operator in where) {
            var type = schemaDiscovery.allTypes[table]
            if (!type) {
                throw 'Could not find type for ' + table
            }
            var part = where[operator]
            var value = part.value
            var column = part.column

            if (!column) {
                throw 'Column not set in where clause ' + JSON.stringify(where)
            }

            // Attempt to convert a string to an enum id, if this column is an enum.
            var referencedTable = type._meta._simpleTypes[column]
            var referencedType = undefined
            if (typeof (value) === 'string' && referencedTable && (referencedType = schemaDiscovery.allTypes[referencedTable])._meta._isEnum) {
                value = referencedType._enum.idByName[value]
                if (value === undefined) {
                    throw `Could not find enum on ${referencedTable} wth value ${part.value}`
                }
            }

            let lhs = `"${table}"."${column}"`
            let coalesce = part.coalesce
            if (coalesce && coalesce.length) {
                // Replace LHS with coalesced value if necessary
                let coalesceStmt = `coalesce("${table}"."${column}"`
                for (var coalesceValue of coalesce) {
                    coalesceStmt = coalesceStmt.concat(`, ?`)
                    params.push(coalesceValue)
                }
                coalesceStmt = coalesceStmt.concat(`)`)
                lhs = coalesceStmt
            }
            params.push(value)
            return ` ${lhs} ${operators[operator]} ? `
        }
    }
    throw 'Unhandled where type'
}

/*

where = {
    'UserPreference': {
        and: [
            equals: { column: 'userName', value: 6 }
        ]
    }

}

*/

/**
 * Fetch records from a single table, following no tree/graph nature.
 * @param {string} table The table name to retrieve records from.
 * @param {object} wpcs An object representing the where, paging, counts and sorting clause.
 * @param {Session} session An optional session to use
 * @returns {Object[]} An array of matching records.
 */
exports.fetchNoTree = async function fetchNoTree(table, wpcs, session) {
    try {
        if (!session) {
            session = new Session()
        }

        var selectStatement = `select * from "${table}" `
        if (wpcs && wpcs[table] && wpcs[table].where) {
            var params = []
            var whereClause = buildWhereClause(table, wpcs[table].where, params)
            if (whereClause !== null) {
                selectStatement += ` where ${whereClause}`
            }
        }

        var result = await session.query(selectStatement, params)

        await convertBuffersToStrings(result.rows)

        return result.rows
    } catch (e) {
        log.d('Failed in fetchNoTree', e)
        throw e
    }
}

/**
 * Update a record with the given keys and values.
 *
 * @param {*} table Table name of record.
 * @param {*} keys Keys to (hopefully) uniquely identify the record
 * @param {*} updatedValues The values that have changed.
 * @param {Session?} session Optional session.
 *
 * @returns true if a single record was updated. false is 0 records were updated.
 * @throws an error if more than 1 record was updated
 */
exports.updateRecord = async function updateRecord(table, keys, updatedValues, session) {
    if (!session) {
        session = new Session()
    }
    let updateColumns = []
    let updateWhere = []
    let params = []

    for (let column of Object.keys(updatedValues)) {
        let tempColumn = `"${column}"`
        let tempValue = updatedValues[column]
        if (tempValue instanceof SQLUpdateOp) {
            if (tempValue.op == '=') {
                tempColumn += ' = ?'
            } else {
                tempColumn += `= ${tempColumn} ${tempValue.op} ?`
            }
            tempValue = tempValue.value
        } else {
            tempColumn += `= ?`
        }

        updateColumns.push(tempColumn)
        params.push(tempValue)
    }
    for (let column of Object.keys(keys)) {
        updateWhere.push(`"${column}"`)
        params.push(keys[column])
    }

    updateWhere = updateWhere.map(name => `${name} = ?`)

    let updateStatement = `update "${table}" set ${updateColumns.join(',')} where ${updateWhere.join(' and ')}`

    let result = await session.query(updateStatement, params)

    if (result.rowCount === 0) {
        return false
    } else if (result.rowCount === 1) {
        return true
    } else {
        throw `An update record query updated ${result.affectedRows} rows. This is probably bad.`
    }
}

/**
 * Attempt to insert a (or many) record(s) into the given table.
 *
 * @param {string} table Table name to insert into
 * @param {object|object[]} values Objects containing the columns and values to insert.
 *        Note that the column names are chosen based on the single object or first object in the array.
 * @param {Session} [session] An optional session.
 */
exports.insertRecord = async function insertRecord(table, values, session) {
    if (!session) {
        session = new Session()
    }
    let insertColumns = []
    let insertParams = []

    if (!Array.isArray(values)) {
        values = [values]
    }

    if (values.length === 0) {
        throw `No values provided for insertRecord into ${table}`
    }

    for (let column in values[0]) {
        insertColumns.push(column)
    }

    for (let record of values) {
        for (let column of insertColumns) {
            const toPush = record[column]
            if (toPush === undefined) {
                insertParams.push(null)
            } else if (toPush instanceof SQLUpdateOp) {
                insertParams.push(toPush.defaultValue)
            } else {
                insertParams.push(toPush)
            }
        }
    }

    var questionMarks = '(' + Array(insertColumns.length).fill('?').join(',') + ')'
    var allQuestionMarks = Array(values.length).fill(questionMarks).join(',')

    var ignoreClause = session.ignore ? ' on conflict do nothing ' : ''

    var insertStatement = `insert into "${table}" ("${insertColumns.join('","')}") values ${allQuestionMarks} ${ignoreClause} RETURNING id `
    var result = await session.query(insertStatement, insertParams)
    log.d('Result', result)
    return {
        affectedRows: result.rowCount,
        id: result.rowCount > 0 ? result.rows[0].id : -1
    }
}

/**
 * Update or Insert record(s) into the given table.
 *
 * @param {*} table Table name of record.
 * @param {*} values The values to upsert.
 * @param {*} uniqueConstraints The unique constraints for `table`
 * @param {Session?} session Optional session.
 *
 */
exports.upsertRecord = async function upsertRecord(table, values, uniqueConstraints, session) {
    if (!session) {
        session = new Session()
    }
    let insertColumns = []
    let insertParams = []
    let updateParams = {}

    if (!Array.isArray(values)) {
        values = [values]
    }

    if (values.length === 0) {
        throw `No values provided for upsertRecord into ${table}`
    }

    // Don't allow multiple rows with the same value in one commit. (Postgres U126: Cannot update same row twice in same ON CONFLICT)
    if (uniqueConstraints.length > 0) {
        let uniqueColumns = uniqueConstraints.flatMap(u => u.columnsarray)
        values = uniqBy(values, v =>
            JSON.stringify(uniqueColumns.map(column => v[column]))
        )
    }

    for (let column in values[0]) {
        insertColumns.push(column)
    }

    let keys = []
    for (let record of values) {
        for (let column of insertColumns) {
            const toPush = record[column]
            if (toPush === undefined) {
                insertParams.push(null)
                updateParams[column] = null
            } else if (toPush instanceof SQLUpdateOp) {
                insertParams.push(toPush.defaultValue)
                updateParams[column] = toPush
            } else {
                insertParams.push(toPush)
                updateParams[column] = toPush
                keys.push(`"${column}"`)
            }
        }
    }



    let exclusion = []

    for (let updateColumn in updateParams) {
        let tempColumn = `"${updateColumn}"`
        let tempValue = updateParams[updateColumn]
        if (tempValue instanceof SQLUpdateOp) {
            if (tempValue.op === '=') {
                tempColumn += ` = excluded."${updateColumn}"`
            } else {
                tempColumn += `= "${table}".${tempColumn} ${tempValue.op} ${tempValue.value}`
            }
        } else {
            tempColumn += ` = excluded."${updateColumn}"`
        }
        exclusion.push(tempColumn)
    }

    exclusion = exclusion.join(',')

    let onConflict =
        `on conflict (${uniqueConstraints.length > 0 ? uniqueConstraints.map(c => c.columns).join(', ') : 'id'})
        DO UPDATE SET ${exclusion}`


    // Upsert in batches no greater than the PSQL 64k param limit
    const BATCH_SIZE = Math.floor(64000 / insertColumns.length)
    let questionMarks = '(' + Array(insertColumns.length).fill('?').join(',') + ')'

    let results = {rowCount: 0, rows: []}
    for (let batch = 0; batch < values.length; batch += BATCH_SIZE) {

        let batchValues = values.slice(batch, batch + BATCH_SIZE)
        let batchParams = insertParams.slice(batch * insertColumns.length, (batch + BATCH_SIZE) * insertColumns.length)

        let allQuestionMarks = Array(batchValues.length).fill(questionMarks).join(',')

        let insertStatement = `insert into "${table}" ("${insertColumns.join('","')}") values ${allQuestionMarks} ${onConflict}
            RETURNING id, "${insertColumns.join('","')}", CASE WHEN xmax::text::int > 0 THEN '${OPERATION_UPDATE}' ELSE '${OPERATION_INSERT}' END AS Operation;`

        let result = await session.query(insertStatement, [...batchParams])

        log.d('Result', result)
        results.rowCount += result.rowCount
        results.rows = [...results.rows, ...result.rows]

    }
    return {
        affectedRows: results.rowCount,
        id: results.rowCount === 1 ? results.rows[0].id : -1,
        rows: results.rows
    }
}

/**
 * Delete records based on WPCS.
 * @param {String} table Name of the table to delete records from.
 * @param {object} wpcs The Where component of `wpcs` controls which records are deleted. It is an error if there is
 *                      no Where component for the given `table`.
 * @param {Session} [session] Database session.
 * @returns The number of deleted records.
 * @throws If there is no where component of the `wpcs` for the given `table`.
 */
exports.deleteRecordsWPCS = async function deleteRecordsWPCS(table, wpcs, session) {
    if (!session) {
        session = new Session()
    }

    if (!wpcs) {
        throw 'deleteRecordsWhere requires wpcs'
    }

    var whereClause = null
    var whereParams = []

    if (wpcs && wpcs[table] && wpcs[table].where) {
        whereClause = buildWhereClause(table, wpcs[table].where, whereParams)
    }

    if (whereClause === null) {
        throw 'deleteRecordsWhere requires where for the relevant table'
    }

    var deleteStatement = `delete from "${table}" where ${whereClause}`
    var result = await session.query(deleteStatement, whereParams)

    return result.rowCount
}

/**
 *
 * @param {string} table Table name to delete from.
 * @param {object?} keys The keys to identify records by. If omitted, this implies deleting all records in the table.
 * @param {Session?}  session An optional database session.
 *
 * @returns The number of records deleted.
 */
exports.deleteRecords = async function deleteRecords(table, keys, session) {
    if (!session) {
        session = new Session()
    }

    var deleteWhere = []
    var params = []

    if (keys) {
        for (var column of Object.keys(keys)) {
            deleteWhere.push(column)
            params.push(keys[column])
        }
    }

    deleteWhere = deleteWhere.map(name => `"${name}" = ?`)

    var deleteStatement = `delete from "${table}"`
    if (deleteWhere.length > 0) {
        deleteStatement += ` where ${deleteWhere.join(' and ')}`
    }

    var result = await session.query(deleteStatement, params)

    return result.rowCount
}


/**
 * Store a single record, to the given table, using the given keys to identify the record,
 * and only update the values in updatedValues.
 *
 * An update will be attempted first, followed by an insert.
 *
 * @param {string} table The table name to store into
 * @param {object} keys The keys to find the record
 * @param {object} updatedValues The values that are modified
 * @param {Session?} session On optional session.
 *
 * @returns {undefined}
 */
exports.store = async function (table, keys, updatedValues, session) {
    try {
        if (!session) {
            session = new Session()
        }

        if (await exports.updateRecord(table, keys, updatedValues, session)) {
            return true
        }

        var combined = {}
        Object.assign(combined, keys)
        Object.assign(combined, updatedValues)

        await exports.insertRecord(table, combined, session)
    } catch (e) {
        log.d('Failed in store', e)
        throw e
    }
}

/**
 * Registers a hook for fetch operations.
 * @param {string} table The table entity name to run the hook against.
 * @param {function(Object,Session)} hook An async function that will be called on the fetched object.
 */
async function registerFetchHook(table, hook) {
    if (!table || !hook) {
        throw new Error('Missing required parameter')
    }
    fetchHooks[table] || (fetchHooks[table] = [])
    fetchHooks[table].push(hook)
}
exports.registerFetchHook = registerFetchHook
