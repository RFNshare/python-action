/**
 * @file SSLOpenRecord.js - 0.0.1045 - ea4595bfd3488684d225574ed7d4c198074d49ba
 * 
 * @copyright Copyright (C) 2016-2023, ISARA Corporation, All Rights Reserved.
 * 
 * @license The code and other content set out herein is not in the public
 * domain, is considered a trade secret and is confidential to ISARA
 * Corporation. Use, reproduction or distribution, in whole or in part, of such
 * code or other content is strictly prohibited except by express written
 * permission of ISARA Corporation. Please contact ISARA Corporation at
 * info@isara.com for more information.
 */

// /**
//  * Handling for Extrahop SSL Open record. Attempts to pull out ciphersuite
//  * and protocol variant metadata.
//  *
//  * @module extrahop/records/SSLOpenRecord
// */

// const { writeToString } = require('@fast-csv/format')

// const { RecordBase } = require('./RecordBase')
// const { allTypes } = require('../../../isaraql/schemaDiscovery')

// const { populateObservedFields } = require('../extrahopUtils')

// const log = require('../../../util/log')(module)
// class SSLOpenRecord extends RecordBase {
//     constructor(record, cacheMaps) {
//         super(record, cacheMaps)

//         let protocol = allTypes['Protocol']._enum.idByName

//         let protocolVersion = record._source.version.split('v')
//         let foundProtocol = protocolVersion[0]
//         if (protocolVersion.length === 1) {
//             this.protocolVariant = protocolVersion[0]
//         } else {
//             this.protocolVariant = protocolVersion.join(' ')
//         }

//         let protocolId = protocol[foundProtocol]
//         if (protocolId !== undefined) {
//             this.protocol = protocolId
//         } else {
//             this.protocol = null
//         }

//         this.cipherSuite = record._source.cipherSuite

//         // look for certificate details. These will not always be available.
//         if (record._source.certificateSubject) {
//             this.certificate = {
//                 subject: record._source.certificateSubject,
//                 // TODO: GAP1626 - look up issuer to see if we have a cert for them in order
//                 // to foreign key link them.
//                 issuer: record._source.certificateIssuer,
//                 // TODO: GAP1626 - Catalyst.
//                 certificateType: allTypes['CertificateType']._enum.idByName['X509'],
//                 serial: record._source.certificateSerial,
//                 notBefore: new Date(record._source.certificateNotBefore * 1000),
//                 notAfter: new Date(record._source.certificateNotAfter * 1000)
//             }

//             populateObservedFields(this.certificate, this.observationTime)

//             if (record._source.certificateSubjectAlternativeNames) {
//                 this.certificate.alternateNames = record._source.certificateSubjectAlternativeNames
//             }
//         }
//     }

//     async getConnectionObject() {
//         let connection = this.getBaseConnectionObject()
//         if (this.protocol) {
//             let variantID = this.cacheMaps.protocolVariantIDMap[this.protocolVariant]
//             if (variantID !== undefined) {
//                 connection.connectionProtocolVariants.push(
//                     {
//                         protocolVariant: variantID,
//                         connectionProtocolVariantCertificates: []
//                     })
//                 populateObservedFields(connection.connectionProtocolVariants[0], this.observationTime)
//             } else {
//                 log.log(`Unable to identify SSL protocol variant for: ${this.protocolVariant}`)
//             }
//         } else {
//             log.log(`Unable to identify SSL protocol for: ${this.protocolVariant}`)
//         }

//         if (this.cipherSuite) {
//             let suiteID = this.cacheMaps.cipherSuiteIDMap[this.cipherSuite]
//             if (suiteID !== undefined) {
//                 connection.connectionCipherSuites.push({
//                     cipherSuite: suiteID
//                 })
//                 populateObservedFields(connection.connectionCipherSuites[0], this.observationTime)
//             }
//         }

//         if (this.certificate) {
//             if (this.certificate.alternateNames) {
//                 this.certificate.alternateNames = await writeToString([this.certificate.alternateNames])
//             }

//             if (connection.connectionProtocolVariants) {
//                 let protocolVariantCertEntry = {
//                     connectionProtocolVariant: connection.connectionProtocolVariants[0],
//                     connectionCertificateType: allTypes['ConnectionCertificateType']._enum.idByName['SERVER'],
//                     certificate: this.certificate
//                 }
//                 populateObservedFields(protocolVariantCertEntry, this.observationTime)

//                 connection.connectionProtocolVariants[0].connectionProtocolVariantCertificates.push(
//                     // TODO: GAP1626 - handle client auth certs once we're able to get them from a trigger.
//                     protocolVariantCertEntry
//                 )
//             }

//             connection.connectionCertificates.push(
//                 {
//                     certificate: this.certificate
//                 }
//             )
//         }

//         return connection
//     }
// }

// exports.SSLOpenRecord = SSLOpenRecord