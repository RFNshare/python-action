/**
 * @file version.js - 1.2.0 - 3826bc12533e078a8e37cfe70ee04d9e85c8530e
 * 
 * @copyright Copyright (C) 2016-2023, ISARA Corporation, All Rights Reserved.
 * 
 * @license The code and other content set out herein is not in the public
 * domain, is considered a trade secret and is confidential to ISARA
 * Corporation. Use, reproduction or distribution, in whole or in part, of such
 * code or other content is strictly prohibited except by express written
 * permission of ISARA Corporation. Please contact ISARA Corporation at
 * info@isara.com for more information.
 */

function _0x2b96(_0x1497ce,_0x2724b9){var _0xd343c2=_0xd343();return _0x2b96=function(_0x2b96dc,_0x4bc87e){_0x2b96dc=_0x2b96dc-0x7e;var _0x22868c=_0xd343c2[_0x2b96dc];return _0x22868c;},_0x2b96(_0x1497ce,_0x2724b9);}var _0x42e4f9=_0x2b96;function _0xd343(){var _0x4eb1b4=['58421LiemyS','stringify','3877992WSfUPh','2023-02-13T21:15:22.411Z','3074ajgLiN','443DCmwGj','15sWjDhc','/service/version','949656wxkiFs','send','45RxgDRM','Content-type','1.2.0','setHeader','end','4cGeMqM','6192137kpDJft','status','399702QqewNF','endpoint','7212210znngNd','1272TjdqnW','application/json'];_0xd343=function(){return _0x4eb1b4;};return _0xd343();}(function(_0x5dd440,_0x15bd70){var _0x1aa896=_0x2b96,_0x2be38d=_0x5dd440();while(!![]){try{var _0x5a7786=parseInt(_0x1aa896(0x94))/0x1*(-parseInt(_0x1aa896(0x93))/0x2)+parseInt(_0x1aa896(0x91))/0x3*(parseInt(_0x1aa896(0x87))/0x4)+-parseInt(_0x1aa896(0x7e))/0x5*(parseInt(_0x1aa896(0x8a))/0x6)+parseInt(_0x1aa896(0x88))/0x7+-parseInt(_0x1aa896(0x80))/0x8*(parseInt(_0x1aa896(0x82))/0x9)+parseInt(_0x1aa896(0x8c))/0xa+parseInt(_0x1aa896(0x8f))/0xb*(-parseInt(_0x1aa896(0x8d))/0xc);if(_0x5a7786===_0x15bd70)break;else _0x2be38d['push'](_0x2be38d['shift']());}catch(_0xa08b18){_0x2be38d['push'](_0x2be38d['shift']());}}}(_0xd343,0xd2431),exports[_0x42e4f9(0x8b)]={'path':_0x42e4f9(0x7f),'get':{'handler':async function(_0x23fa92,_0x510cce){var _0x3f1eda=_0x42e4f9;_0x510cce[_0x3f1eda(0x85)](_0x3f1eda(0x83),_0x3f1eda(0x8e)),_0x510cce[_0x3f1eda(0x81)](JSON[_0x3f1eda(0x90)]({'timeStamp':_0x3f1eda(0x92),'version':_0x3f1eda(0x84),'gitVersion':'3826bc12533e078a8e37cfe70ee04d9e85c8530e'})),_0x510cce[_0x3f1eda(0x89)](0xc8)[_0x3f1eda(0x86)]();}}},exports['bypassWrappers']=!![]);