/**
 * @file purgingDictionary.js - 1.2.0 - 3826bc12533e078a8e37cfe70ee04d9e85c8530e
 * 
 * @copyright Copyright (C) 2016-2023, ISARA Corporation, All Rights Reserved.
 * 
 * @license The code and other content set out herein is not in the public
 * domain, is considered a trade secret and is confidential to ISARA
 * Corporation. Use, reproduction or distribution, in whole or in part, of such
 * code or other content is strictly prohibited except by express written
 * permission of ISARA Corporation. Please contact ISARA Corporation at
 * info@isara.com for more information.
 */

const _0x80bfe3=_0x4c98;(function(_0x1434dc,_0x59ecf4){const _0x44f87b=_0x4c98,_0x35f355=_0x1434dc();while(!![]){try{const _0x223369=-parseInt(_0x44f87b(0x17f))/0x1+parseInt(_0x44f87b(0x17e))/0x2+-parseInt(_0x44f87b(0x185))/0x3+-parseInt(_0x44f87b(0x17c))/0x4+-parseInt(_0x44f87b(0x187))/0x5*(parseInt(_0x44f87b(0x17a))/0x6)+-parseInt(_0x44f87b(0x186))/0x7+-parseInt(_0x44f87b(0x17d))/0x8*(-parseInt(_0x44f87b(0x179))/0x9);if(_0x223369===_0x59ecf4)break;else _0x35f355['push'](_0x35f355['shift']());}catch(_0x2201d4){_0x35f355['push'](_0x35f355['shift']());}}}(_0x3f1c,0x2517a));const log=require(_0x80bfe3(0x184))(module),PURGE_OVER=0x4c4b40,MILESTONE=0x186a0;function _0x3f1c(){const _0x40ab6a=['Purging\x20dictionary\x20named\x20','purge','\x20now\x20holding\x20','./log','494217uNVHBY','1877862iQsKfY','260065cXNqiL','put','has','3663JNZmtS','12njOcBg','log','866212NDeLDH','15304vRPojH','378514UqFSKR','62334lfAAaY','Purging\x20Dictionary\x20name\x20'];_0x3f1c=function(){return _0x40ab6a;};return _0x3f1c();}class PurgingDictionary{#count=0x0;#cache={};#name='';constructor(_0x540735){this.#name=_0x540735;}[_0x80bfe3(0x188)](_0x209bf7,_0x11485f){const _0x5d2d60=_0x80bfe3;return!(_0x209bf7 in this.#cache)&&(this.#count===PURGE_OVER&&this['purge'](),this.#count++,(this.#count===0x1||this.#count%MILESTONE===0x0)&&log[_0x5d2d60(0x17b)](_0x5d2d60(0x180)+this.#name+_0x5d2d60(0x183)+this.#count)),this.#cache[_0x209bf7]=_0x11485f,_0x11485f;}[_0x80bfe3(0x189)](_0x4010a7){return _0x4010a7 in this.#cache;}[_0x80bfe3(0x182)](){const _0x34fa45=_0x80bfe3;log[_0x34fa45(0x17b)](_0x34fa45(0x181)+this.#name),this.#count=0x0,this.#cache={};}['get'](_0x37625f){return this.#cache[_0x37625f];}}function _0x4c98(_0x2bc3d1,_0x17da9c){const _0x3f1c7c=_0x3f1c();return _0x4c98=function(_0x4c982f,_0x57c07c){_0x4c982f=_0x4c982f-0x179;let _0x3b2044=_0x3f1c7c[_0x4c982f];return _0x3b2044;},_0x4c98(_0x2bc3d1,_0x17da9c);}exports['PurgingDictionary']=PurgingDictionary;