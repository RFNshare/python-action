/**
 * @file sleep.js - 1.2.0 - 3826bc12533e078a8e37cfe70ee04d9e85c8530e
 * 
 * @copyright Copyright (C) 2016-2023, ISARA Corporation, All Rights Reserved.
 * 
 * @license The code and other content set out herein is not in the public
 * domain, is considered a trade secret and is confidential to ISARA
 * Corporation. Use, reproduction or distribution, in whole or in part, of such
 * code or other content is strictly prohibited except by express written
 * permission of ISARA Corporation. Please contact ISARA Corporation at
 * info@isara.com for more information.
 */

function _0x4e75(_0xeb67d7,_0x15252b){var _0x34a5c7=_0x34a5();return _0x4e75=function(_0x4e7586,_0x144f20){_0x4e7586=_0x4e7586-0x18b;var _0x519244=_0x34a5c7[_0x4e7586];return _0x519244;},_0x4e75(_0xeb67d7,_0x15252b);}function _0x34a5(){var _0x5a6519=['287axtHkz','4351446kFvjWW','20QDfBeh','36mgQFML','2135994GrBrQV','278187OdFwGS','204219yronKj','90944fNmbnO','26EUvjiC','300NOdXSp','3368195RproaR','8629HqUCDs'];_0x34a5=function(){return _0x5a6519;};return _0x34a5();}(function(_0x3b9cf2,_0x5ab231){var _0x551791=_0x4e75,_0x49b300=_0x3b9cf2();while(!![]){try{var _0x4dbbd0=parseInt(_0x551791(0x192))/0x1*(-parseInt(_0x551791(0x18f))/0x2)+parseInt(_0x551791(0x18c))/0x3*(-parseInt(_0x551791(0x195))/0x4)+-parseInt(_0x551791(0x191))/0x5+parseInt(_0x551791(0x18b))/0x6+parseInt(_0x551791(0x193))/0x7*(-parseInt(_0x551791(0x18e))/0x8)+parseInt(_0x551791(0x18d))/0x9*(parseInt(_0x551791(0x190))/0xa)+parseInt(_0x551791(0x194))/0xb*(parseInt(_0x551791(0x196))/0xc);if(_0x4dbbd0===_0x5ab231)break;else _0x49b300['push'](_0x49b300['shift']());}catch(_0x17703a){_0x49b300['push'](_0x49b300['shift']());}}}(_0x34a5,0x7c022),exports['sleep']=_0xbe8631=>{return new Promise(_0x150f63=>{setTimeout(()=>_0x150f63(),_0xbe8631);});});