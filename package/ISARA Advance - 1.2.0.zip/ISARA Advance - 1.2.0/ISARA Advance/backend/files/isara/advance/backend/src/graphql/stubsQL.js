/**
 * @file stubsQL.js - 1.2.0 - 3826bc12533e078a8e37cfe70ee04d9e85c8530e
 * 
 * @copyright Copyright (C) 2016-2023, ISARA Corporation, All Rights Reserved.
 * 
 * @license The code and other content set out herein is not in the public
 * domain, is considered a trade secret and is confidential to ISARA
 * Corporation. Use, reproduction or distribution, in whole or in part, of such
 * code or other content is strictly prohibited except by express written
 * permission of ISARA Corporation. Please contact ISARA Corporation at
 * info@isara.com for more information.
 */

function _0x2944(_0x280a41,_0x5bdad8){var _0x5e9121=_0x5e91();return _0x2944=function(_0x294437,_0x226c66){_0x294437=_0x294437-0x135;var _0x17f1ee=_0x5e9121[_0x294437];return _0x17f1ee;},_0x2944(_0x280a41,_0x5bdad8);}function _0x5e91(){var _0x4c5ffa=['481304HiIgbU','301744cQGQAb','2464940HWDgBC','34506fHaJuo','2KrXBDa','596701NynmCc','1260kLGWft','5142831WlWsWV','23799591uYAuIm','\x0a\x20\x20\x20\x20\x20\x20\x20\x20searchSuggestion(text:\x20String!)\x20:\x20[String]!\x0a\x20\x20\x20\x20','graphQL'];_0x5e91=function(){return _0x4c5ffa;};return _0x5e91();}var _0x222abd=_0x2944;(function(_0x589e7c,_0x29d42b){var _0x161413=_0x2944,_0x5ce59e=_0x589e7c();while(!![]){try{var _0x145db9=-parseInt(_0x161413(0x135))/0x1+-parseInt(_0x161413(0x13f))/0x2*(parseInt(_0x161413(0x137))/0x3)+parseInt(_0x161413(0x13b))/0x4+-parseInt(_0x161413(0x13d))/0x5+-parseInt(_0x161413(0x13e))/0x6*(-parseInt(_0x161413(0x136))/0x7)+-parseInt(_0x161413(0x13c))/0x8+parseInt(_0x161413(0x138))/0x9;if(_0x145db9===_0x29d42b)break;else _0x5ce59e['push'](_0x5ce59e['shift']());}catch(_0x37b0af){_0x5ce59e['push'](_0x5ce59e['shift']());}}}(_0x5e91,0xe9f0d),exports[_0x222abd(0x13a)]={'queries':_0x222abd(0x139),'root':{},'restrictions':{}});