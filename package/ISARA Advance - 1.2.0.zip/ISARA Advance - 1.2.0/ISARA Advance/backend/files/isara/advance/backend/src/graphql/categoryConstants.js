/**
 * @file categoryConstants.js - 1.2.0 - 3826bc12533e078a8e37cfe70ee04d9e85c8530e
 * 
 * @copyright Copyright (C) 2016-2023, ISARA Corporation, All Rights Reserved.
 * 
 * @license The code and other content set out herein is not in the public
 * domain, is considered a trade secret and is confidential to ISARA
 * Corporation. Use, reproduction or distribution, in whole or in part, of such
 * code or other content is strictly prohibited except by express written
 * permission of ISARA Corporation. Please contact ISARA Corporation at
 * info@isara.com for more information.
 */

var _0x3c3dbf=_0x11ad;function _0xc6f1(){var _0x1953d4=['1879090awPBAz','14178123qnCueq','CONNECTION','286496DzSlXB','Device\x20Crypto','CONNECTIONCRYPTO','8RbMPaE','28396ceiMsp','2653914GqzyoI','TECHNOLOGY','Agility','Technology','CRYPTO','NETWORKING','1430960TsweaQ','postureCategories','Device','1489200BnnXsq','Connection','33TfZbPV','Crypto','Networking','DEVICE'];_0xc6f1=function(){return _0x1953d4;};return _0xc6f1();}function _0x11ad(_0x17fe9c,_0x4170d5){var _0xc6f1bb=_0xc6f1();return _0x11ad=function(_0x11ad29,_0x59f67a){_0x11ad29=_0x11ad29-0xeb;var _0x49e16e=_0xc6f1bb[_0x11ad29];return _0x49e16e;},_0x11ad(_0x17fe9c,_0x4170d5);}(function(_0x469c9a,_0x56ea75){var _0x4bf5d6=_0x11ad,_0x179509=_0x469c9a();while(!![]){try{var _0x367e71=parseInt(_0x4bf5d6(0xf4))/0x1*(-parseInt(_0x4bf5d6(0xff))/0x2)+-parseInt(_0x4bf5d6(0xf2))/0x3+-parseInt(_0x4bf5d6(0xef))/0x4+-parseInt(_0x4bf5d6(0xf8))/0x5+parseInt(_0x4bf5d6(0x100))/0x6+-parseInt(_0x4bf5d6(0xfb))/0x7+parseInt(_0x4bf5d6(0xfe))/0x8*(parseInt(_0x4bf5d6(0xf9))/0x9);if(_0x367e71===_0x56ea75)break;else _0x179509['push'](_0x179509['shift']());}catch(_0x5cd187){_0x179509['push'](_0x179509['shift']());}}}(_0xc6f1,0x43ee6),exports['filterCategoryTypes']={'AGILITY':'AGILITY','CONNECTION':_0x3c3dbf(0xfa),'CONNECTIONCRYPTO':_0x3c3dbf(0xfd),'DEVICE':_0x3c3dbf(0xf7),'NETWORKING':_0x3c3dbf(0xee),'TECHNOLOGY':_0x3c3dbf(0x101),'DEVICECRYPTO':'DEVICECRYPTO','CRYPTO':_0x3c3dbf(0xed)},exports['filterCategoryNames']={'AGILITY':_0x3c3dbf(0xeb),'CONNECTION':_0x3c3dbf(0xf3),'CONNECTIONCRYPTO':'Connection\x20Crypto','DEVICE':_0x3c3dbf(0xf1),'NETWORKING':_0x3c3dbf(0xf6),'TECHNOLOGY':_0x3c3dbf(0xec),'DEVICECRYPTO':_0x3c3dbf(0xfc),'CRYPTO':_0x3c3dbf(0xf5)},exports[_0x3c3dbf(0xf0)]={'DEVICE':0x0,'CONNECTION':0x1,'SOFTWARE':0x2});