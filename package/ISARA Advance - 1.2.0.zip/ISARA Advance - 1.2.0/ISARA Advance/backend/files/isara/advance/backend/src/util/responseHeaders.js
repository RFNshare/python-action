/**
 * @file responseHeaders.js - 1.2.0 - 3826bc12533e078a8e37cfe70ee04d9e85c8530e
 * 
 * @copyright Copyright (C) 2016-2023, ISARA Corporation, All Rights Reserved.
 * 
 * @license The code and other content set out herein is not in the public
 * domain, is considered a trade secret and is confidential to ISARA
 * Corporation. Use, reproduction or distribution, in whole or in part, of such
 * code or other content is strictly prohibited except by express written
 * permission of ISARA Corporation. Please contact ISARA Corporation at
 * info@isara.com for more information.
 */

var _0x3c97d6=_0x8e52;function _0x8e52(_0x4b2fed,_0x30cd46){var _0x150564=_0x1505();return _0x8e52=function(_0x8e5229,_0x28645d){_0x8e5229=_0x8e5229-0x75;var _0x39e5fd=_0x150564[_0x8e5229];return _0x39e5fd;},_0x8e52(_0x4b2fed,_0x30cd46);}(function(_0x432101,_0x4fd2a6){var _0x568c6a=_0x8e52,_0xc8b8e9=_0x432101();while(!![]){try{var _0xbaae2b=parseInt(_0x568c6a(0x7e))/0x1*(-parseInt(_0x568c6a(0x7c))/0x2)+-parseInt(_0x568c6a(0x81))/0x3+-parseInt(_0x568c6a(0x77))/0x4*(-parseInt(_0x568c6a(0x84))/0x5)+parseInt(_0x568c6a(0x85))/0x6*(-parseInt(_0x568c6a(0x88))/0x7)+parseInt(_0x568c6a(0x7f))/0x8+-parseInt(_0x568c6a(0x76))/0x9+parseInt(_0x568c6a(0x82))/0xa*(parseInt(_0x568c6a(0x83))/0xb);if(_0xbaae2b===_0x4fd2a6)break;else _0xc8b8e9['push'](_0xc8b8e9['shift']());}catch(_0xe9e0c7){_0xc8b8e9['push'](_0xc8b8e9['shift']());}}}(_0x1505,0xd1b1e),exports[_0x3c97d6(0x86)]=function(_0x237853,_0x282d93,_0x3e5e5d){var _0x1e5b10=_0x3c97d6;_0x282d93['set'](_0x1e5b10(0x7d),'*'),_0x282d93[_0x1e5b10(0x75)](_0x1e5b10(0x80),'GET,HEAD,PUT,PATCH,POST,DELETE,OPTIONS'),_0x282d93[_0x1e5b10(0x75)](_0x1e5b10(0x79),_0x1e5b10(0x87));if(_0x237853[_0x1e5b10(0x7b)]===_0x1e5b10(0x7a)){_0x282d93[_0x1e5b10(0x78)]({'message':_0x1e5b10(0x89)});return;}_0x3e5e5d();});function _0x1505(){var _0x524024=['Access-Control-Allow-Origin','661NCInAq','2012312lCaPSa','Access-Control-Allow-Methods','4856028TlFuac','152980uNpcKU','2519MDKJBX','252905iKYQIa','6804834AtVoSb','insertResponseHeaders','Content-Type,Authorization,X-ISARA-Authorization','7TIuBrk','This\x20is\x20a\x20sample\x20\x22OPTIONS\x22\x20response','set','603891weYPRA','16vsLiom','send','Access-Control-Allow-Headers','OPTIONS','method','842WJjTmK'];_0x1505=function(){return _0x524024;};return _0x1505();}