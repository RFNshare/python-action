/**
 * @file scanTanium.js - 1.2.0 - 3826bc12533e078a8e37cfe70ee04d9e85c8530e
 * 
 * @copyright Copyright (C) 2016-2023, ISARA Corporation, All Rights Reserved.
 * 
 * @license The code and other content set out herein is not in the public
 * domain, is considered a trade secret and is confidential to ISARA
 * Corporation. Use, reproduction or distribution, in whole or in part, of such
 * code or other content is strictly prohibited except by express written
 * permission of ISARA Corporation. Please contact ISARA Corporation at
 * info@isara.com for more information.
 */

function _0x49dd(){const _0x3aa8fb=['209080BJYyDv','message','onFinally','1090BAwmrQ','4KAoszG','{\x20\x22url\x22:\x20\x22https://isara-api.cloud.tanium.com\x22,\x20\x22token\x22:\x20\x22token-0bc8513a4946e32e20c5754c493509b4e8e747870604a13f3d02d6d22e\x22\x20}','35387StltLZ','Tanium','40FOBAPD','212682BVTeGs','266CYNFKd','5528wAeucc','248139ZFPTgM','128457gLjrnH','log','155688xAOwqA','onFulfilled\x20','./ingestion/tanium/scanner'];_0x49dd=function(){return _0x3aa8fb;};return _0x49dd();}const _0x1a5489=_0x49bf;(function(_0x17db5d,_0x31788d){const _0x156cba=_0x49bf,_0x3f2266=_0x17db5d();while(!![]){try{const _0x837ff6=-parseInt(_0x156cba(0xf9))/0x1+parseInt(_0x156cba(0xf0))/0x2*(parseInt(_0x156cba(0xf5))/0x3)+-parseInt(_0x156cba(0xec))/0x4+-parseInt(_0x156cba(0xf4))/0x5*(parseInt(_0x156cba(0xe9))/0x6)+-parseInt(_0x156cba(0xf6))/0x7*(parseInt(_0x156cba(0xf7))/0x8)+parseInt(_0x156cba(0xf8))/0x9+parseInt(_0x156cba(0xef))/0xa*(parseInt(_0x156cba(0xf2))/0xb);if(_0x837ff6===_0x31788d)break;else _0x3f2266['push'](_0x3f2266['shift']());}catch(_0x39e648){_0x3f2266['push'](_0x3f2266['shift']());}}}(_0x49dd,0x19be3));function _0x49bf(_0x4eaeeb,_0x23dea6){const _0x49dd11=_0x49dd();return _0x49bf=function(_0x49bf1d,_0x31b814){_0x49bf1d=_0x49bf1d-0xe9;let _0x5506c0=_0x49dd11[_0x49bf1d];return _0x5506c0;},_0x49bf(_0x4eaeeb,_0x23dea6);}const {scan}=require(_0x1a5489(0xeb));async function main(){const _0x2aacb7=_0x1a5489,_0x4eb4f4={'configuration':'{\x20\x22computer_group\x22:\x20\x22All\x20Computers\x22\x20}','dataSource':{'softwareVersion':{'name':_0x2aacb7(0xf3)},'configuration':_0x2aacb7(0xf1)}};scan(_0x4eb4f4,null,async _0x476019=>{const _0x6005af=_0x2aacb7;console[_0x6005af(0xfa)](_0x6005af(0xea)+_0x476019);},async _0x2c8eaf=>{const _0x3d557c=_0x2aacb7;console[_0x3d557c(0xfa)]('onRejected\x20'+_0x2c8eaf[_0x3d557c(0xed)]);},async()=>{const _0x3e4183=_0x2aacb7;console['log'](_0x3e4183(0xee));});}main();