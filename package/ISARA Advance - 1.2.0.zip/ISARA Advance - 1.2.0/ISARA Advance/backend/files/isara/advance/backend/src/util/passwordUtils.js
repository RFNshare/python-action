/**
 * @file passwordUtils.js - 1.2.0 - 3826bc12533e078a8e37cfe70ee04d9e85c8530e
 * 
 * @copyright Copyright (C) 2016-2023, ISARA Corporation, All Rights Reserved.
 * 
 * @license The code and other content set out herein is not in the public
 * domain, is considered a trade secret and is confidential to ISARA
 * Corporation. Use, reproduction or distribution, in whole or in part, of such
 * code or other content is strictly prohibited except by express written
 * permission of ISARA Corporation. Please contact ISARA Corporation at
 * info@isara.com for more information.
 */

function _0x58a4(_0xb6e3f3,_0x4d1b74){const _0x252f5f=_0x252f();return _0x58a4=function(_0x58a4f8,_0x4b8a8a){_0x58a4f8=_0x58a4f8-0x1ec;let _0x30c3ab=_0x252f5f[_0x58a4f8];return _0x30c3ab;},_0x58a4(_0xb6e3f3,_0x4d1b74);}const _0x2722ea=_0x58a4;(function(_0x2bc894,_0x21cf20){const _0x4e4c37=_0x58a4,_0x28b650=_0x2bc894();while(!![]){try{const _0x40b66e=parseInt(_0x4e4c37(0x1f9))/0x1+parseInt(_0x4e4c37(0x1fb))/0x2+parseInt(_0x4e4c37(0x1f7))/0x3+parseInt(_0x4e4c37(0x1fa))/0x4*(-parseInt(_0x4e4c37(0x1f4))/0x5)+-parseInt(_0x4e4c37(0x1ec))/0x6+parseInt(_0x4e4c37(0x1ed))/0x7*(-parseInt(_0x4e4c37(0x1f1))/0x8)+parseInt(_0x4e4c37(0x1f2))/0x9*(parseInt(_0x4e4c37(0x1ef))/0xa);if(_0x40b66e===_0x21cf20)break;else _0x28b650['push'](_0x28b650['shift']());}catch(_0x5c6d4b){_0x28b650['push'](_0x28b650['shift']());}}}(_0x252f,0xdf138));function _0x252f(){const _0x5d4e3b=['1618371avHBew','hashPassword','18041RuPXMo','6742808SwBzbs','837922JhCdME','3014796DFfRQB','50701fUSjXd','verify','8240KhiRGR','randomSleep','968oqYLfg','32787AvmHwM','exports','5zkSdww','verifyPassword','argon2id'];_0x252f=function(){return _0x5d4e3b;};return _0x252f();}const argon2=require('argon2'),crypto=require('crypto');module[_0x2722ea(0x1f3)][_0x2722ea(0x1f0)]=async function(){let _0x568c14=crypto['randomInt'](0x1f4,0xbb8);return new Promise(_0x33cdd3=>{setTimeout(_0x33cdd3,_0x568c14);});},module[_0x2722ea(0x1f3)][_0x2722ea(0x1f5)]=async function(_0x5a71fb,_0x453557){const _0x442ff4=_0x2722ea;return argon2[_0x442ff4(0x1ee)](_0x453557,_0x5a71fb);},module['exports'][_0x2722ea(0x1f8)]=async function(_0x2d35ef){const _0x2c1b25=_0x2722ea;return argon2['hash'](_0x2d35ef,{'type':argon2[_0x2c1b25(0x1f6)]});};