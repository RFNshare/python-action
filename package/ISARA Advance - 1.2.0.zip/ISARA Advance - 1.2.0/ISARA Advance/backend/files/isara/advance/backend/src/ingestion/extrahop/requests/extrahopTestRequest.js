/**
 * @file extrahopTestRequest.js - 1.2.0 - 3826bc12533e078a8e37cfe70ee04d9e85c8530e
 * 
 * @copyright Copyright (C) 2016-2023, ISARA Corporation, All Rights Reserved.
 * 
 * @license The code and other content set out herein is not in the public
 * domain, is considered a trade secret and is confidential to ISARA
 * Corporation. Use, reproduction or distribution, in whole or in part, of such
 * code or other content is strictly prohibited except by express written
 * permission of ISARA Corporation. Please contact ISARA Corporation at
 * info@isara.com for more information.
 */

const _0x401713=_0x18e3;(function(_0x4c748a,_0x11f582){const _0x9db77c=_0x18e3,_0x1c878d=_0x4c748a();while(!![]){try{const _0x69d1af=-parseInt(_0x9db77c(0xb4))/0x1*(parseInt(_0x9db77c(0xb7))/0x2)+parseInt(_0x9db77c(0xb5))/0x3+-parseInt(_0x9db77c(0xbc))/0x4+-parseInt(_0x9db77c(0xbd))/0x5*(-parseInt(_0x9db77c(0xba))/0x6)+parseInt(_0x9db77c(0xb2))/0x7*(-parseInt(_0x9db77c(0xb1))/0x8)+-parseInt(_0x9db77c(0xb8))/0x9*(parseInt(_0x9db77c(0xb9))/0xa)+parseInt(_0x9db77c(0xbb))/0xb;if(_0x69d1af===_0x11f582)break;else _0x1c878d['push'](_0x1c878d['shift']());}catch(_0x551981){_0x1c878d['push'](_0x1c878d['shift']());}}}(_0x49e5,0xb4f68));const {ExtrahopRequest}=require(_0x401713(0xb6));function _0x18e3(_0x1e1d80,_0x153d01){const _0x49e508=_0x49e5();return _0x18e3=function(_0x18e3ce,_0x11a8e1){_0x18e3ce=_0x18e3ce-0xb1;let _0x46164c=_0x49e508[_0x18e3ce];return _0x46164c;},_0x18e3(_0x1e1d80,_0x153d01);}class ExtrahopTestRequest extends ExtrahopRequest{constructor(_0x400f3f,_0xe270f8,_0x3eba40){const _0x5b8594=_0x401713;super(_0x400f3f,'/api/v1/extrahop',_0xe270f8,_0x5b8594(0xb3),'',_0x3eba40);}}function _0x49e5(){const _0x21a5ea=['39111116kZEoLg','4682816YOhAOW','115PeOHrf','8140928BWHwYM','7rpYUMk','GET','2cujpaV','2202318HxpTMO','./extrahopRequest','1417708JezVwb','315ZKqnMm','208190hRDKmj','205110GeNEVc'];_0x49e5=function(){return _0x21a5ea;};return _0x49e5();}exports['ExtrahopTestRequest']=ExtrahopTestRequest;