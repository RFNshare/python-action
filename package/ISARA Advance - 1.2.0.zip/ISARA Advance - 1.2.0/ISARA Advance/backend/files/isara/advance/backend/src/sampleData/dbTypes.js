/**
 * @file dbTypes.js - 1.2.0 - 3826bc12533e078a8e37cfe70ee04d9e85c8530e
 * 
 * @copyright Copyright (C) 2016-2023, ISARA Corporation, All Rights Reserved.
 * 
 * @license The code and other content set out herein is not in the public
 * domain, is considered a trade secret and is confidential to ISARA
 * Corporation. Use, reproduction or distribution, in whole or in part, of such
 * code or other content is strictly prohibited except by express written
 * permission of ISARA Corporation. Please contact ISARA Corporation at
 * info@isara.com for more information.
 */

function _0x546a(_0x9987b6,_0x2d9e12){var _0x4ae788=_0x4ae7();return _0x546a=function(_0x546a98,_0x5200b9){_0x546a98=_0x546a98-0xe9;var _0x54cedf=_0x4ae788[_0x546a98];return _0x54cedf;},_0x546a(_0x9987b6,_0x2d9e12);}function _0x4ae7(){var _0x4ba63f=['25FOIsMK','notificationTypes','19319499vyXJdc','451532tliQct','connectionRatings','tagTypes','users','roles','strongProtocolVariants','protocolVariants','2ibTDLP','weakProtocolVariants','certificateTypes','allCryptoPrimitives','2063439fDZrLJ','5330038ASGWWp','layer4Protocols','4004784wnucbl','12056lNTElH','connectionCertificateTypes','4705884EkVJVl'];_0x4ae7=function(){return _0x4ba63f;};return _0x4ae7();}var _0xe73050=_0x546a;(function(_0xb169c1,_0x246872){var _0x35b759=_0x546a,_0x588d01=_0xb169c1();while(!![]){try{var _0x520f9d=parseInt(_0x35b759(0xf7))/0x1*(parseInt(_0x35b759(0xea))/0x2)+-parseInt(_0x35b759(0xfb))/0x3+-parseInt(_0x35b759(0xf0))/0x4*(parseInt(_0x35b759(0xed))/0x5)+parseInt(_0x35b759(0xec))/0x6+-parseInt(_0x35b759(0xfc))/0x7+-parseInt(_0x35b759(0xe9))/0x8+parseInt(_0x35b759(0xef))/0x9;if(_0x520f9d===_0x246872)break;else _0x588d01['push'](_0x588d01['shift']());}catch(_0x2fe77f){_0x588d01['push'](_0x588d01['shift']());}}}(_0x4ae7,0x68ab1),exports[_0xe73050(0xfa)]={},exports['allStrongCryptoPrimitives']={},exports['allWeakCryptoPrimitives']={},exports[_0xe73050(0xf9)]={},exports[_0xe73050(0xeb)]={},exports[_0xe73050(0xf1)]={},exports['deviceTypes']={},exports[_0xe73050(0xee)]={},exports['protocols']={},exports[_0xe73050(0xf6)]={},exports[_0xe73050(0xf5)]={},exports[_0xe73050(0xf8)]={},exports[_0xe73050(0xf4)]={},exports['softwareTypes']={},exports[_0xe73050(0xf2)]={},exports[_0xe73050(0xfd)]={},exports[_0xe73050(0xf3)]=[]);